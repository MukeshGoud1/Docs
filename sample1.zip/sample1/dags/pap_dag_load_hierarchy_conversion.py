##############################################################
##############################################################
####-       FILE NAME        : pap_dag_load_incr_fact.py -####
####-       FILE CREATED     : 2022/08/01                -####
####-       FILE LAST EDITED : 2023/03/20                -####
##############################################################
##############################################################
#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
from datetime import datetime,timedelta
import imp
import os
import ast
import urllib
from string import Template

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.operators.python import task, get_current_context
from airflow.configuration import conf as airflow_conf
import time
import boto3
import pandas as pd
from botocore.exceptions import ClientError
import uuid
import datetime as dt
import pendulum
import json
import yaml
import random


#functionality check                                        -done
#make the code production ready (parameterize it)           -done
#validate batch date                                        -done
#make code timezone aware                                   -done
#scheduling                                                 -done
#email notification on failure                              -pending
#documentation                                              -done
#SLA callback/retries callback                              -done
#max active run

ENV_NAME = ''
try:   
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"

class OrchestatorUtils():
    def send_email(self,email):
        for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=email["aws_region"])
        # Try to send the email.
        try:
            #Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': email["recipient_list"],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_html"],
                        },
                        'Text': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_text"],
                        },
                    },
                    'Subject': {
                        'Charset': email["msg_charset"],
                        'Data': email["msg_subject"],
                    },
                },
                Source=email["sender"],
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])
    
    def log_batch_dtl(batch_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(batch_config):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        #set the batch date
        if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()
            
        audit_batch_record['batch_id']=str(uuid.uuid4())
        audit_batch_record['batch_name']='PAP'
        audit_batch_record['status']='RUNNING'
        audit_batch_record['st']=pendulum.now().to_string()
        audit_batch_record['et']=''
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(batch_config,batch_date,batch_name):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
                
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+batch_date+'/'+str(batch_name)+'_log.json'        
        audit_batch_record=get_config(batch_bucket,batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status']='FINISHED'
        audit_batch_record['et']=pendulum.now()
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(batch_config,batch_date,batch_name,error_msg):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
                
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+batch_date+'/'+str(batch_name)+'_log.json'        
        audit_batch_record=get_config(batch_bucket,batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status']='FAILED'
        audit_batch_record['et']=pendulum.now()
        audit_batch_record['msg']='error_msg'
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
                   
#workflow config.            
orchestrator = OrchestatorUtils()
config_yml = orchestrator.get_config(CODE_ARTIFACTS_BUCKET,"configuration/dags/pap_dag_load_hierarchy_conversion.yml")

#validation of all the keys in dag config yaml:
for key in ('dag_id','owner','start_date','time_zone','load_type','schedule','tags','retries','concurrency','namespace','region_name','glue_iam_role','on_failure_callback','on_retry_callback','tasks'):
    if config_yml['dag'].get(key) is None:
        ValueError(f"Missing DAG config parameter -{key}")
              
def dag_complete_send_email(**kwargs):
        handle = OrchestatorUtils()
        context = get_current_context()
        dict_email={}
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='COMPLETED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp 
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))        
        
def dag_failure_send_email(context): 
        print("IN dag_failure_send_email")
        handle = OrchestatorUtils()
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        dict_email={}
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='FAILED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        dict_email['MESSAGE']=''
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_start_send_email(**kwargs):
        handle = OrchestatorUtils()
        context = get_current_context()
        dict_email={}
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='STARTED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_retry_send_email(context):
        handle = OrchestatorUtils()
        dict_email={}
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='RETRY'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

default_args = {
    "owner": config_yml['dag']['owner'],
    "start_date": pendulum.parse(config_yml['dag']['start_date'], tz=config_yml['dag']['time_zone']),
    "provide_context": True,
    #"retries": config_yml['dag']['retries'],
    #"retries":2,
    "max_active_runs": config_yml['dag']['max_active_runs'],
    #"on_failure_callback": dag_failure_send_email,
    #"on_failure_callback": getattr(sys.modules[__name__],config_yml['dag']['on_failure_callback']),
    "on_retry_callback": getattr(sys.modules[__name__],config_yml['dag']['on_retry_callback'])
    #"sla": timedelta(hours=6)
}


doc_md = config_yml['dag']['doc_md']

dag = DAG(
    dag_id=config_yml['dag']['dag_id'],
    default_args=default_args,
    doc_md=doc_md,
    concurrency=config_yml['dag']['concurrency'],
    schedule_interval=None,
    #schedule_interval = config_yml['dag']['schedule'],
    tags=config_yml['dag']['tags']
    #sla_miss_callback=getattr(sys.modules[__name__],config_yml['dag']['on_failure_callback'])
)

#read the job dependency into dataframe. 
tasks=pd.DataFrame(config_yml['dag']['tasks'])

#method to get the task by name
def get_task_by_name(tasks):
  task_list=[]
  for task_name in tasks:
      print(task_name)
      task_list.append(dag.get_task(str(task_name)))
  return task_list

# def to run glue job 
def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0,9)) # for giving delay in each job
    glue_client = boto3.client('glue', region_name=config_yml['dag']['region_name'])
    response = glue_client.start_job_run(
    JobName=kwargs["glue_job_name"],
    Arguments=kwargs["script_args"],
    WorkerType=kwargs["worker_type"],
    NumberOfWorkers=kwargs["no_of_workers"]
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    cloud_watch_url_output =  f"https://{config_yml['dag']['region_name']}.console.aws.amazon.com/cloudwatch/home?region={config_yml['dag']['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{config_yml['dag']['region_name']}.console.aws.amazon.com/cloudwatch/home?region={config_yml['dag']['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    while isJobRunning:
        time.sleep(config_yml['dag']['glue_job_poll_interval'])
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"

#check for the fields present in config
for task in config_yml['dag']['tasks']:
    if task.get("type") == "glue":
        for key in ('task_id','type','operator','depends_on','glue_job_name','path','glue_version','no_of_workers','python_callable','worker_type'):
            if task.get(key) is None:
                ValueError(f"Missing DAG config parameter -{key}")
    else:
        for key in ('task_id','type','operator','depends_on','python_callable'):
            if task.get(key) is None:
                ValueError(f"Missing DAG config parameter -{key}")
                
    if task.get("type") == "email":
        PythonOperator(  task_id=str(task['task_id']),
                                python_callable=getattr(sys.modules[__name__],task['python_callable']),
                                retries = config_yml['dag']['retries'],
                                doc_md=doc_md,
                                provide_context=True,
                                dag = dag)
    elif task.get("glue_job_name") == "pap-hierarchy-dynamic-conversion-job": 
        PythonOperator(  task_id=str(task['task_id']), 
                                python_callable=getattr(sys.modules[__name__],task['python_callable']),
                                op_kwargs={'glue_job_name': task['glue_job_name'], 
                                'no_of_workers':task['no_of_workers'],
                                'script_args':{'--job_config_object_key': task['path'],'--app_config_object_key': config_yml['dag']['app_config_object_key'],'--config_bucket': CODE_ARTIFACTS_BUCKET ,'--batch_date': "{{dag_run.conf['batch_date']}}",
                                '--table_name':task['table_name'],'--column_names':task['column_names'],'--date_column_name':task['date_column_name'],'--use_dim_calendar':task['use_dim_calendar']},
                                'worker_type':task['worker_type'] },
                                retries = config_yml['dag']['retries'],
                                provide_context=True,
                                on_failure_callback=dag_failure_send_email,
                                doc_md=doc_md,
                                dag = dag)
    else:
        PythonOperator(  task_id=str(task['task_id']), 
                                python_callable=getattr(sys.modules[__name__],task['python_callable']),
                                op_kwargs={'glue_job_name': task['glue_job_name'], 
                                'no_of_workers':task['no_of_workers'],
                                'script_args':{'--job_config_object_key': task['path'],'--app_config_object_key': config_yml['dag']['app_config_object_key'],'--config_bucket': CODE_ARTIFACTS_BUCKET ,'--batch_date': "{{dag_run.conf['batch_date']}}"},
                                'worker_type':task['worker_type'] },
                                retries = config_yml['dag']['retries'],
                                provide_context=True,
                                on_failure_callback=dag_failure_send_email,
                                doc_md=doc_md,
                                dag = dag)
                                
#connect the task as per dependency  
for task_name,depends_on in zip(tasks['task_id'],tasks['depends_on']):
    dag.get_task(str(task_name)).set_upstream(get_task_by_name(depends_on))

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################