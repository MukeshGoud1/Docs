##############################################################
##############################################################
####-       FILE NAME: pap_dag_modify_users_in_ad_grp.py -####
####-       FILE CREATED    : 2023/06/12                 -####
####-       FILE LAST EDITED: 2023/08/22                 -####
##############################################################
##############################################################
import sys
sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
from airflow import DAG
from datetime import datetime
import os
import ast
import io
import urllib
import time
import random

# Airflow level imports
from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.configuration import conf as airflow_conf
import boto3
import pandas as pd
from botocore.exceptions import ClientError
import uuid
import pendulum
import json
import yaml
#from airflow.decorators import task
from airflow.operators.python import get_current_context
from string import Template
from airflow.exceptions import AirflowSkipException
from airflow.models import Variable
import ast
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib, ssl
from smtplib import SMTPException
    
from ldap3 import ALL, Connection, Server
from ldap3.core.exceptions import LDAPException
from ldap3.extend.microsoft.addMembersToGroups import ad_add_members_to_groups as addUsersInGroups
from ldap3.extend.microsoft.removeMembersFromGroups import ad_remove_members_from_groups as removeUsersInGroups


ENV_NAME = ''
AD_SA_USER = ''
AD_SA_PWD = ''
PROD_ENV_NAME = 'PRD'
#PROD_ENV_NAME = 'TST'
try:   
    region_name     = os.environ['AWS_REGION']
    session         = boto3.session.Session()
    client          = session.client(service_name='secretsmanager',region_name=region_name)
    get_env_secret  = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME        = ast.literal_eval(get_env_secret['SecretString'])
    get_sa_secret   = client.get_secret_value(SecretId='pap-secret-service-account')
    credential      = ast.literal_eval(get_sa_secret['SecretString'])
    AD_SA_USER      = credential["user"]
    AD_SA_PWD       = credential["password"]
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"
PROCESSED_BUCKET = ""
CURATED_BUCKET = ""

class OrchestatorUtils():
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg             = MIMEMultipart('related')
            msg['Subject']  = email["msg_subject"]
            msg['From']     = email["sender"]
            msg['To']       = ','.join(email["recipient_list"])
            body            = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")
                  
    '''def send_email(self,email):
        for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=email["aws_region"])
        # Try to send the email.
        try:
            #Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': email["recipient_list"],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_html"],
                        },
                        'Text': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_text"],
                        },
                    },
                    'Subject': {
                        'Charset': email["msg_charset"],
                        'Data': email["msg_subject"],
                    },
                },
                Source=email["sender"],
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])'''
    
    def log_batch_dtl(self, app_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource     = boto3.resource('s3')
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object       = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        audit_batch_record['batch_date'] = batch_date
        #set the batch date
        '''if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()'''
            
        audit_batch_record['batch_id']      =str(uuid.uuid4())
        audit_batch_record['batch_name']    =app_config.get("APPLICATION_NAME")
        audit_batch_record['status']        ='STARTED'
        audit_batch_record['start_time']    =pendulum.now()
        audit_batch_record['end_time']      =''
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_bucket:{batch_bucket}")
        print(f"batch_object_key:{batch_object_key}")
        try:
            audit_batch_record=self.get_config(batch_bucket,batch_object_key)
        except Exception as err:
            print(str(err))
        print(str(audit_batch_record))
        print("Type:" +str(type(audit_batch_record)))
        audit_batch_record['status']    ='FINISHED'
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(self, app_config, batch_date, msg):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket                    =app_config['LOGS_BUCKET']
        batch_object_key                =app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_object_key:{batch_object_key}")
        audit_batch_record              =self.get_config(batch_bucket,batch_object_key)
        audit_batch_record['status']    =msg
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj     = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
            

orch_handle     =OrchestatorUtils()
app_config_yml  = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/app_config.yml")
PROCESSED_BUCKET = app_config_yml['environment'].get("PROCESSED_BUCKET")
CURATED_BUCKET = app_config_yml['environment'].get("CURATED_BUCKET")
DAG_NAME        ='pap_dag_modify_users_in_ad_grp'
dag_tags        =['PAP']
release         =1

def dag_start_send_email(**kwargs):
        print(ENV_NAME['name'].upper())
        if ENV_NAME['name'].upper() != PROD_ENV_NAME:
            print(f"Skipping the task as it is running in {ENV_NAME} env")
            raise AirflowSkipException
        if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
            print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
            raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        handle                                  = OrchestatorUtils()
        context                                 = get_current_context()
        #Variable.set('ds_nodash',context.get('ds_nodash'))
        dict_email                              ={}       
        dict_email['ENV']                       = ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
        dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
        dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']         ='STARTED'
        dict_email['EXECUTION_DATE']            =context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
        dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
        dict_email['MESSAGE']                   =''
        dag_id                                  = context["dag"].dag_id
        execution_date                          = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_failure_send_email(context):
        if ENV_NAME['name'].upper() != PROD_ENV_NAME:
            print(f"Skipping the task as it is running in {ENV_NAME} env")
            raise AirflowSkipException
        if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
            print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
            raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        try: 
            handle = OrchestatorUtils()
            #Variable.set('ds_nodash',context.get('ds_nodash'))
            dict_email                              ={}
            dict_email['ENV']                       = ENV_NAME['name'].upper()
            dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
            dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
            dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
            dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
            dict_email['PROCESS_RUN_STATE']         ='FAILED'
            dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
            dict_email['EXECUTION_DATE']            =context.get('execution_date')
            dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
            dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
            dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
            dict_email['MESSAGE']                   =''
            dag_id                                  = context["dag"].dag_id
            execution_date                          = context["execution_date"].isoformat()
            dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
            email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
            enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            #handle.send_email(json.loads(enriched_email))
        except Exception as err:
            print(f"ERROR:{str(err)}")

def dag_retry_send_email(context):
        if ENV_NAME['name'].upper() != PROD_ENV_NAME:
            print(f"Skipping the task as it is running in {ENV_NAME} env")
            raise AirflowSkipException
        if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
            print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
            raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        handle = OrchestatorUtils()
        dict_email={}
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='RETRY'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_end_send_email(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
        print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
    handle                                  = OrchestatorUtils()
    context                                 = get_current_context()
    dict_email                              ={}
    dict_email['ENV']                       = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
    dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE']         ='COMPLETED'
    dict_email['EXECUTION_DATE']            =context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']      =pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
    dict_email['MESSAGE']                   =''
    dag_id                                  = context["dag"].dag_id
    execution_date                          = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


default_args = {
    "owner": "PAP Project Team",
    "start_date": datetime(2023,1,1),
    "provide_context": True,
    "retries":2,
}

batch_dt        = Variable.get('ds_nodash')

def modify_users_in_groups(**kwargs):
    '''
    import os
    hostname = "Z1NADC01.na.gilead.com" #example
    response = os.system("ping -c 1 " + hostname)

    #and then check the response...
    if response == 0:
      print(hostname, 'is up!')
    else:
      print(hostname, 'is down!')
    '''
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
        print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
    try:
        s3Client = boto3.client('s3')
        file_key = "audit-table/pap-tableau-users/PAP_Tableau_Users_"+ str(Variable.get('ds_nodash')) +".txt"
        # file_key = "HRA/PAP_Tableau_Users_20230718.txt"
        print(file_key)
        data = s3Client.get_object(Bucket=CURATED_BUCKET, Key=file_key)
        pap_tableau_users_df = pd.read_csv(io.BytesIO(data['Body'].read()), sep='\|\|', engine='python')
            #print("pap_tableau_users_df", pap_tableau_users_df.shape)
    except (FileNotFoundError, ValueError, ClientError, Exception) as ex:
        print("exception occurred while reading pap-tableau-users text file", str(ex))
        raise ex
    group_dn = app_config_yml['environment'].get("PAP_AD_USER_GROUP_DN")
    print(f"AD Group:{group_dn}")
    add_users_list = pap_tableau_users_df[(pap_tableau_users_df["ACTION"] == "add") & (pap_tableau_users_df["AD_GROUP_UPDATED"] == "N") & (pap_tableau_users_df["EMAIL"] != "")]["EMAIL"].values.tolist()
    remove_users_list = pap_tableau_users_df[(pap_tableau_users_df["ACTION"] == "remove") & (pap_tableau_users_df["AD_GROUP_UPDATED"] == "N") & (pap_tableau_users_df["EMAIL"] != "")]["EMAIL"].values.tolist()
    print("add_users_list:" + str(add_users_list))
    print("remove_users_list:" + str(remove_users_list))    
    if len(add_users_list) == 0 and len(remove_users_list) == 0:
        print(f"NO USERS TO ADD OR REMOVE FROM AD GROUP {group_dn}.")
    else:
        ldap_base = f"CN={AD_SA_USER},OU=Standard,OU=Service Accounts,DC=na,DC=gilead,DC=com"
        # '(|(mail=pransh.saxena@gilead.com)(mail=mujeebuddin.syed1@gilead.com))'
        try:
            add_user_string,remove_user_string = '(|','(|'
            
            #  Get-ADDomainController
            server = Server(
                host=f"ldaps://{app_config_yml['environment'].get('GILEAD_AD_HOSTNAME')}",
                port=636,
                use_ssl=True,
                get_info=ALL,
            )
            
            with Connection(
            server=server,
            authentication="SIMPLE",
            user=f"{ldap_base}",
            password=AD_SA_PWD,
            auto_bind=True
            ) as connection:
                #print(connection.result)
                print("Connection is successful")  # "success" if bind is ok
                connection.search(
                search_base=group_dn,
                search_filter='(objectClass=group)',
                search_scope='SUBTREE',
                attributes = ['member']
                )
                
                print(f"List of users in {group_dn}")
                for entry in connection.entries:
                    print(f"No. of Users BEFORE: {str(len(entry.member.values))}")
                    print(entry.member.values)
                if len(remove_users_list) != 0:
                    for user_mail in remove_users_list:
                        remove_user_string +=f'(mail={user_mail})'
                    remove_user_string +=')'
                    connection.search(
                    search_base='DC=na,DC=gilead,DC=com',
                    search_filter=remove_user_string,
                    attributes = ['DistinguishedName']
                    )
                    remove_user_dn_list= []
                    for entry in connection.entries:
                        remove_user_dn_list.append(entry.distinguishedname.value)
                    print(remove_user_dn_list)
                    print(f"REMOVING USERS FROM GROUP {group_dn}")
                    for user_dn in remove_user_dn_list:
                        removeUsersInGroups(connection, user_dn, group_dn,fix=True)
                    print(connection.result)
                if len(add_users_list) != 0:
                    for user_mail in add_users_list:
                        add_user_string += f'(mail={user_mail})'
                    add_user_string +=')'
                    connection.search(
                    search_base='DC=na,DC=gilead,DC=com',
                    search_filter=add_user_string,
                    attributes = ['DistinguishedName']
                    )
                    add_user_dn_list= []
                    for entry in connection.entries:
                        add_user_dn_list.append(entry.distinguishedname.value)
                    print(add_user_dn_list)
                    print(f"ADDING USERS TO GROUP {group_dn}")
                    for user_dn in add_user_dn_list:
                        addUsersInGroups(connection, user_dn, group_dn)
                    print(connection.result)
                connection.search(
                search_base=group_dn,
                search_filter='(objectClass=group)',
                search_scope='SUBTREE',
                attributes = ['member']
                )
                print(f"List of users after modifying users in {group_dn}")
                for entry in connection.entries:
                    print(entry.member.values)
                    print(f"No. of Users AFTER: {str(len(entry.member.values))}")
                
        except LDAPException as e:
            print(str(e))
            raise e

def custom_glue_job_execution(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_MODIFY_USERS_IN_AD_GROUP") != "TRUE":
        print("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_MODIFY_USERS_IN_AD_GROUP property is disabled. Hence, Skipping the task")
    time.sleep(random.randint(0,9)) # for giving delay in each job
    region_name = os.environ['AWS_REGION']
    glue_client = boto3.client('glue', region_name=region_name)
    response = glue_client.start_job_run(
    JobName=kwargs["glue_job_name"],
    Arguments=kwargs["script_args"],
    WorkerType='G.1X',
    NumberOfWorkers=2
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    cloud_watch_url_output =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    while isJobRunning:
        time.sleep(30)
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"    

with DAG(
    dag_id                      =   DAG_NAME,
    start_date                  =   pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
    catchup                     =   False,
    schedule_interval           =   None,
    tags                        =   dag_tags,
    default_args                =   default_args,
    on_failure_callback         =   dag_failure_send_email) as dag:
    start                       = PythonOperator(task_id          ="Start",
                                   python_callable  =dag_start_send_email, 
                                   provide_context  =True,
                                )
    end                         = PythonOperator(task_id          ="End",
                                   python_callable  =dag_end_send_email, 
                                   provide_context  =True,
                                )

    flat_file_generate          = PythonOperator(task_id="Flat_File_Generation",
                                    python_callable=custom_glue_job_execution,
                                    op_kwargs={'glue_job_name': "pap-parquet-to-txt-conversion",
                                                'script_args': {'--input_output_path_list':"[{'input_path':'s3://"+PROCESSED_BUCKET+"/pap-tableau-users/','output_path':'s3://"+CURATED_BUCKET+"/audit-table/pap-tableau-users/','filename':'PAP_Tableau_Users'}]",
                                                                '--config_bucket': CODE_ARTIFACTS_BUCKET,
                                                                '--batch_date': str(Variable.get('ds_nodash'))
                                                                }},
                                    provide_context=True,
                                    on_failure_callback=dag_failure_send_email
                                    )

    pap_tableau_users_identify  = PythonOperator(task_id          ="PAP_Tableau_Users_Identify",
                                   python_callable  =custom_glue_job_execution, 
                                   op_kwargs={'glue_job_name': "pap-etlcore-dynamic-load-job",
                                                'script_args': {'--app_config_object_key':
                                                                    'configuration/app_config.yml',
                                                                '--job_config_object_key':
                                                                    'configuration/job/dimension/PAP_Tableau_Users_Identify.yml',
                                                                '--config_bucket': CODE_ARTIFACTS_BUCKET,
                                                                '--batch_date': str(Variable.get('ds_nodash'))
                                                                }},
                                    provide_context=True,
                                    on_failure_callback=dag_failure_send_email
                                )                 
        
    modify_users_in_ad_group    = PythonOperator(task_id          ="Modify_Users_In_AD_Group",
                                   python_callable  =modify_users_in_groups, 
                                   provide_context  =True,
                                   on_failure_callback=dag_failure_send_email
                                )
    
start >> pap_tableau_users_identify >> flat_file_generate >> modify_users_in_ad_group >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################