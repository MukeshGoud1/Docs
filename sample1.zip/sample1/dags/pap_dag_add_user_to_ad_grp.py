##############################################################
##############################################################
####-       FILE NAME       : pap_dag_tableau_extract.py -####
####-       FILE CREATED    : 2023/01/25                 -####
####-       FILE LAST EDITED: 2023/03/20                 -####
##############################################################
##############################################################
import sys
sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime as dt
from airflow import DAG
from datetime import datetime,timedelta
import imp
import os
import ast
import urllib
import time
import requests
import random
from io import StringIO

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.external_task import ExternalTaskSensor
#from airflow.operators.sensors import ExternalTaskSensor
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.configuration import conf as airflow_conf
import boto3
import pandas as pd
from botocore.exceptions import ClientError
import uuid
import pendulum
import json
import yaml
#from airflow.decorators import task
from airflow.operators.python import task, get_current_context
from string import Template
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.models import Variable
import ast

ENV_NAME = ''
try:   
    region_name     = os.environ['AWS_REGION']
    session         = boto3.session.Session()
    client          = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME        = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"

class OrchestatorUtils():
    def send_email(self,email):
        for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=email["aws_region"])
        # Try to send the email.
        try:
            #Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': email["recipient_list"],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_html"],
                        },
                        'Text': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_text"],
                        },
                    },
                    'Subject': {
                        'Charset': email["msg_charset"],
                        'Data': email["msg_subject"],
                    },
                },
                Source=email["sender"],
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])
    
    def log_batch_dtl(self, app_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource     = boto3.resource('s3')
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object       = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        audit_batch_record['batch_date'] = batch_date
        #set the batch date
        '''if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()'''
            
        audit_batch_record['batch_id']      =str(uuid.uuid4())
        audit_batch_record['batch_name']    =app_config.get("APPLICATION_NAME")
        audit_batch_record['status']        ='STARTED'
        audit_batch_record['start_time']    =pendulum.now()
        audit_batch_record['end_time']      =''
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_bucket:{batch_bucket}")
        print(f"batch_object_key:{batch_object_key}")
        try:
            audit_batch_record=self.get_config(batch_bucket,batch_object_key)
        except Exception as err:
            print(str(err))
        print(str(audit_batch_record))
        print("Type:" +str(type(audit_batch_record)))
        audit_batch_record['status']    ='FINISHED'
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(self, app_config, batch_date, msg):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket                    =app_config['LOGS_BUCKET']
        batch_object_key                =app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_object_key:{batch_object_key}")
        audit_batch_record              =self.get_config(batch_bucket,batch_object_key)
        audit_batch_record['status']    =msg
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj     = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
            

orch_handle     =OrchestatorUtils()
app_config_yml  = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/app_config.yml")
DAG_NAME        ='pap_dag_add_user_to_ad_grp'
dag_tags        =['PAP','Tableau Extract','RELEASE 1']
release         =1

def dag_start_send_email(**kwargs):
        handle                                  = OrchestatorUtils()
        context                                 = get_current_context()
        Variable.set('ds_nodash',context.get('ds_nodash'))
        dict_email                              ={}       
        dict_email['ENV']                       = ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
        dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
        dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']         ='STARTED'
        dict_email['EXECUTION_DATE']            =context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
        dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
        dict_email['MESSAGE']                   =''
        dag_id                                  = context["dag"].dag_id
        execution_date                          = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        #handle.send_email(json.loads(enriched_email))

def dag_failure_send_email(context):
        try: 
            handle = OrchestatorUtils()
            Variable.set('ds_nodash',context.get('ds_nodash'))
            dict_email                              ={}
            dict_email['ENV']                       = ENV_NAME['name'].upper()
            dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
            dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
            dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
            dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
            dict_email['PROCESS_RUN_STATE']         ='FAILED'
            dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
            dict_email['EXECUTION_DATE']            =context.get('execution_date')
            dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
            dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
            dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
            dict_email['MESSAGE']                   =''
            dag_id                                  = context["dag"].dag_id
            execution_date                          = context["execution_date"].isoformat()
            dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
            email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
            enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            #handle.send_email(json.loads(enriched_email))
        except Exception as err:
            print(f"ERROR:{str(err)}")
            #handle.fail_log_batch_ditl(app_config_yml['environment'], str(Variable.get('ds_nodash')),'FAILED')
    
def dag_end_send_email(**kwargs):
    handle                                  = OrchestatorUtils()
    context                                 = get_current_context()
    dict_email                              ={}
    dict_email['ENV']                       = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
    dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE']         ='COMPLETED'
    dict_email['EXECUTION_DATE']            =context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']      =pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
    dict_email['MESSAGE']                   =''
    dag_id                                  = context["dag"].dag_id
    execution_date                          = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    #handle.send_email(json.loads(enriched_email))

def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0,9)) # for giving delay in each job
    glue_client     = boto3.client('glue', region_name=kwargs['region_name'])
    response        = glue_client.start_job_run(
    JobName         =kwargs["glue_job_name"],
    Arguments       =kwargs["script_args"],
    WorkerType      =kwargs["worker_type"],
    NumberOfWorkers =kwargs["no_of_workers"]
    )
    job_run_id      = response["JobRunId"]
    isJobRunning    = True
    status          = ''
    while isJobRunning:
        time.sleep(15)
        status_detail   = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status          = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning    = False
    cloud_watch_url_output  =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error   =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    #print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"


default_args = {
    "owner": "PAP Project Team",
    "start_date": datetime(2023,1,1),
    "provide_context": True,
    "retries":2,
}

batch_dt        = Variable.get('ds_nodash')

def add_user(**kwargs):
    import os
    hostname = "Z1NADC01.na.gilead.com" #example
    response = os.system("ping -c 1 " + hostname)

    #and then check the response...
    if response == 0:
      print(hostname, 'is up!')
    else:
      print(hostname, 'is down!') 
    
    from ldap3 import ALL, Connection, Server
    from ldap3.core.exceptions import LDAPException
    from ldap3.extend.microsoft.addMembersToGroups import ad_add_members_to_groups as addUsersInGroups
    from ldap3.extend.microsoft.removeMembersFromGroups import ad_remove_members_from_groups as removeUsersInGroups
      
    username = "PAPGTPRFR"
    password = "c*7uW|V!@123"
    ldap_base = "CN=PAPGTPRFR,OU=Standard,OU=Service Accounts,DC=na,DC=gilead,DC=com"

    server = Server(
        host="ldaps://Z1NADC01.na.gilead.com",
        port=636,
        use_ssl=True,
        get_info=ALL,
    )
    
    try:
        with Connection(
        server=server,
        authentication="SIMPLE",
        user=f"{ldap_base}",
        password=password,
        auto_bind=True
        ) as connection:
            #print(connection.result)
            print("SUCCESS")  # "success" if bind is ok
            connection.search(
            search_base='CN=GTP_HR_Diversity_Developer_PRD,OU=Groups,OU=FC,DC=na,DC=gilead,DC=com',
            search_filter='(objectClass=group)',
            search_scope='SUBTREE',
            attributes = ['member']
            )
            print(f"List of users in group GTP_HR_Diversity_Developer_PRD")
            for entry in connection.entries:
                print(entry.member.values)

            
            group_dn = "CN=GTP_HR_Diversity_Developer_PRD,OU=Groups,OU=FC,DC=na,DC=gilead,DC=com"
            user_dn = "CN=Pransh Saxena,OU=Users,OU=FC,DC=na,DC=gilead,DC=com"
            print(f"ADDING USER: {user_dn} TO GROUP")
            addUsersInGroups(connection, user_dn, group_dn)
            print(connection.result)

    except LDAPException as e:
        print(str(e))
    

with DAG(
    dag_id              =   DAG_NAME,
    start_date          =   pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
    catchup             =   False,
    schedule_interval   =   None,
    tags                =   dag_tags,
    default_args        =   default_args,
    on_failure_callback =   dag_failure_send_email) as dag:
    start         = PythonOperator(task_id          ="Start",
                                   python_callable  =dag_start_send_email, 
                                   provide_context  =True,
                                )
    end           = PythonOperator(task_id          ="End",
                                   python_callable  =dag_end_send_email, 
                                   provide_context  =True,
                                )                  
        
    add_user_to_ad_group           = PythonOperator(task_id          ="Add_User_To_AD_Group",
                                   python_callable  =add_user, 
                                   provide_context  =True,
                                )
    
start >> add_user_to_ad_group >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################