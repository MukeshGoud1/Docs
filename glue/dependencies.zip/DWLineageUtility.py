#!/usr/bin/python
# -*- coding: utf-8 -*

__author__ = "ZS Associates"

import logging
import os
import traceback
import boto3
import CommonConstants as ProfilerConstants
from ConfigUtility import JsonConfigUtility
from MySQLConnectionManager import MySQLConnectionManager
from CustomS3Utility import CustomS3Utility

# """
# Doc_Type            : DWLineageUtility
# Tech Description    : To get the relation triplets from code files to create the lineage.
# Pre_requisites      : N/A
# Inputs              : rule_file_path, process_id
# Outputs             : N/A
# Config_file         : ProfilerConstants/CommonConstants file, environment_params.json
# Last modified by    : Sukhwinder Singh
# Last modified on    : 16th March 2021
# """


MODULE_NAME = "DWLineageUtility"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(MODULE_NAME)


class DWLineageUtility:

    def __init__(self):
        """
        Purpose: To prepare the triplets for the DW lineage
        """
        self.s3 = boto3.resource("s3")
        if (os.path.exists(ProfilerConstants.AIRFLOW_CODE_PATH)):
            self.configuration = JsonConfigUtility(ProfilerConstants.AIRFLOW_CODE_PATH + '/' +
                                                   ProfilerConstants.ENVIRONMENT_CONFIG_FILE)
        else:
            self.configuration = JsonConfigUtility(ProfilerConstants.ENVIRONMENT_CONFIG_FILE)
        self.profiler_db = self.configuration.get_configuration([ProfilerConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        self.mysql_conn = MySQLConnectionManager()

    def get_table_details(self, rule_file_name, dataset_detail, process_id=None):
        """

        :param rule_file_name:
        :param dataset_detail:
        :param process_id:
        :return:
        """
        response = dict()
        result = dict()
        try:
            result[ProfilerConstants.SUBJECT_KEY] = dict()
            result[ProfilerConstants.OBJECT_KEY] = dict()
            result[ProfilerConstants.PREDICATE_KEY] = dict()
            logger.info(dataset_detail)
            if dataset_detail[ProfilerConstants.TABLE_TYPE_COL_NAME].lower() == ProfilerConstants.SOURCE_TABLE_KEY.lower():
                table_detail_query = "select {staging_table_col} from {profiler_db}.{dataset_master_tbl} " \
                                     "where {dataset_id_col} = {dataset_id}".format(
                    staging_table_col=ProfilerConstants.STAGING_TABLE_COL_NAME,
                    profiler_db=self.profiler_db,
                    dataset_master_tbl=ProfilerConstants.DATASET_MASTER_TBL,
                    dataset_id_col=ProfilerConstants.DATASET_ID_COL_NAME,
                    dataset_id=dataset_detail[ProfilerConstants.DATASET_ID_COL_NAME]
                )
                logger.info(table_detail_query)
                table_detail = self.mysql_conn.execute_query_mysql(table_detail_query, False)
                if len(table_detail) != 0 and table_detail is not None and table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME] is not None:
                    logger.info(table_detail_query )
                    result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.SUBJECT_TYPE_KEY] = ProfilerConstants.SUBJECT_TABLE_KEY
                    if "." not in table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME]:
                        result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.SUBJECT_ENTITY_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME].strip()
                        result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.SUBJECT_DATABASE_NAME_KEY] = ProfilerConstants.DW_LINEAGE_DEFAULT_DATABASE_KEY
                    else:
                        result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.SUBJECT_ENTITY_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME].strip().split(".")[1]
                        result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.SUBJECT_DATABASE_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME].strip().split(".")[0]
                    result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.OBJECT_TYPE_KEY] = ProfilerConstants.SUBJECT_PYTHON_SCRIPT_KEY
                    result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.OBJECT_ENTITY_NAME_KEY] = rule_file_name
                    result[ProfilerConstants.PREDICATE_KEY] = ProfilerConstants.INPUT_PROCESS_KEY
                    response[ProfilerConstants.TABLE_NAME_KEY] = table_detail[0][ProfilerConstants.STAGING_TABLE_COL_NAME].strip()

                else:
                    response[ProfilerConstants.TABLE_NAME_KEY] = None
            elif dataset_detail[ProfilerConstants.TABLE_TYPE_COL_NAME].lower() == ProfilerConstants.TARGET_TABLE_KEY.lower():
                table_detail_query = "select {table_name_col} from {profiler_db}.{dataset_master_tbl} " \
                                     "where {dataset_id_col} = {dataset_id}".format(
                    table_name_col=ProfilerConstants.TABLE_NAME_COL,
                    profiler_db=self.profiler_db,
                    dataset_master_tbl=ProfilerConstants.DATASET_MASTER_TBL,
                    dataset_id_col=ProfilerConstants.DATASET_ID_COL_NAME,
                    dataset_id=dataset_detail[ProfilerConstants.DATASET_ID_COL_NAME]
                )
                logger.info(table_detail_query )
                table_detail = self.mysql_conn.execute_query_mysql(table_detail_query, False)
                if len(table_detail) != 0 and table_detail is not None and table_detail[0][ProfilerConstants.TABLE_NAME_COL] is not None:
                    result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.OBJECT_TYPE_KEY] = ProfilerConstants.SUBJECT_PYTHON_SCRIPT_KEY
                    result[ProfilerConstants.SUBJECT_KEY][ProfilerConstants.OBJECT_ENTITY_NAME_KEY] = rule_file_name
                    result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.SUBJECT_TYPE_KEY] = ProfilerConstants.SUBJECT_TABLE_KEY
                    if "." not in table_detail[0][ProfilerConstants.TABLE_NAME_COL]:
                        result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.SUBJECT_ENTITY_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.TABLE_NAME_COL].strip()
                        result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.SUBJECT_DATABASE_NAME_KEY] = ProfilerConstants.DW_LINEAGE_DEFAULT_DATABASE_KEY
                    else:
                        result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.SUBJECT_ENTITY_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.TABLE_NAME_COL].strip().split(".")[1]
                        result[ProfilerConstants.OBJECT_KEY][ProfilerConstants.SUBJECT_DATABASE_NAME_KEY] = \
                            table_detail[0][ProfilerConstants.TABLE_NAME_COL].strip().split(".")[0]
                    result[ProfilerConstants.PREDICATE_KEY] = ProfilerConstants.OUTPUT_PROCESS_KEY
                    response[ProfilerConstants.TABLE_NAME_KEY] = table_detail[0][ProfilerConstants.TABLE_NAME_COL].strip()
                else:
                    response[ProfilerConstants.TABLE_NAME_KEY] = None
            else:
                response[ProfilerConstants.TABLE_NAME_KEY] = None
            response[ProfilerConstants.STATUS_KEY] = ProfilerConstants.STATUS_SUCCESS
            response[ProfilerConstants.RESULT_KEY] = result
            logger.info("table detail is: {0}".format(response))
            return response

        except Exception as e:
            error = "Failed to get the table name for dataset id '{dataset_id}'. " \
                    "ERROR is: {error}".format(dataset_id=dataset_detail[ProfilerConstants.DATASET_ID_COL_NAME],
                                               error=str(e) + '\n' + str(traceback.format_exc()))
            logger.error(error)
            response[ProfilerConstants.STATUS_KEY] = ProfilerConstants.STATUS_FAILED
            response[ProfilerConstants.RESULT_KEY] = "Error"
            response[ProfilerConstants.ERROR_KEY] = error
            return response

    def main(self, rule_file_path, process_id):
        """

        :param rule_file_path:
        :param process_id:
        :return:
        """
        response = dict()
        triplets_list = []
        try:
            bucket_name = rule_file_path.split("//")[1].split("/", maxsplit=1)[0]
            s3_file_path = rule_file_path.split("//")[1].split("/", maxsplit=1)[1]
            rule_file_name = rule_file_path.rsplit("/", maxsplit=1)[1]
            rule_file_data = CustomS3Utility()._read_code_file_from_s3(bucket_name=bucket_name,key=s3_file_path)
            # for process_id in process_id_list:
            logger.info("process_id is: " + str(process_id))
            dataset_detail_query = "select {dataset_id_col}, {table_type_col} from {profiler_db}.{process_dependency_master_tbl} " \
                                   "where {process_id_col} = {process_id}".format(
                dataset_id_col=ProfilerConstants.DATASET_ID_COL_NAME,
                table_type_col=ProfilerConstants.TABLE_TYPE_COL_NAME,
                profiler_db=self.profiler_db,
                process_dependency_master_tbl=ProfilerConstants.PROCESS_DEPENDENCY_MASTER_TBL,
                process_id_col=ProfilerConstants.PROCESS_ID_COL_NAME,
                process_id=process_id
            )
            logger.info(dataset_detail_query)
            dataset_details = self.mysql_conn.execute_query_mysql(dataset_detail_query, False)
            for dataset_detail in dataset_details:
                table_details = self.get_table_details(rule_file_name=rule_file_name, dataset_detail=dataset_detail)
                if table_details[ProfilerConstants.STATUS_KEY] == ProfilerConstants.STATUS_SUCCESS:
                    table = table_details[ProfilerConstants.TABLE_NAME_KEY]
                    if table is not None:
                        #logger.info(rule_file_data)
                        for line in rule_file_data[ProfilerConstants.RESULT_KEY].split("\n"):
                            if line.strip().startswith("#"):
                                continue
                            elif table.strip() in line:
                                if table_details[ProfilerConstants.RESULT_KEY] not in triplets_list:
                                    triplets_list.append(table_details[ProfilerConstants.RESULT_KEY])
                else:
                    logger.info(table_details)
                    return table_details
            response[ProfilerConstants.STATUS_KEY] = ProfilerConstants.STATUS_SUCCESS
            response[ProfilerConstants.RESULT_KEY] = triplets_list
            logger.info("triplet is: {0}".format(response))
            return response
        except Exception as e:
            error = "Failed to get the lineage for file '{file_name}'. " \
                    "ERROR is: {error}".format(file_name=rule_file_path, error=str(e) + '\n' + str(traceback.format_exc()))
            logger.error(error)
            response[ProfilerConstants.STATUS_KEY] = ProfilerConstants.STATUS_FAILED
            response[ProfilerConstants.RESULT_KEY] = "Error"
            response[ProfilerConstants.ERROR_KEY] = error
            response[ProfilerConstants.FILEPATH_KEY] = rule_file_path
            return response

