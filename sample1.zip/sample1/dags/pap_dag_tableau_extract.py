##############################################################
##############################################################
####-       FILE NAME       : pap_dag_tableau_extract.py -####
####-       FILE CREATED    : 2023/01/25                 -####
####-       FILE LAST EDITED: 2023/10/06                 -####
##############################################################
##############################################################
import sys
sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime                                     as dt
from airflow                                        import DAG
from datetime                                       import datetime,timedelta
import imp
import os
import ast
import urllib
import time
import requests
import random
from io                                             import StringIO

# Airflow level imports
from airflow.models                                 import DAG
from airflow.operators.dummy_operator               import DummyOperator
from airflow.operators.bash_operator                import BashOperator
from airflow.providers.http.operators.http          import SimpleHttpOperator
from airflow.operators.python_operator              import PythonOperator
from airflow.sensors.external_task                  import ExternalTaskSensor
#from airflow.operators.sensors import ExternalTaskSensor
from airflow.providers.amazon.aws.operators.glue    import AwsGlueJobOperator
from airflow.operators.trigger_dagrun               import TriggerDagRunOperator
from airflow.utils.dates                            import days_ago
from airflow.models.baseoperator                    import chain
from airflow.configuration                          import conf                     as airflow_conf
import boto3
import pandas                                       as pd
from botocore.exceptions                            import ClientError
import uuid
import pendulum
import json
import yaml
#from airflow.decorators import task
from airflow.operators.python                       import task, get_current_context
from string                                         import Template
from airflow.providers.amazon.aws.operators.glue    import AwsGlueJobOperator
from airflow.models                                 import Variable
import tableauserverclient                          as TSC
import ast
import smtplib
from email.mime.multipart                           import MIMEMultipart
from email.mime.text                                import MIMEText

ENV_NAME = ''
try:   
    region_name     = os.environ['AWS_REGION']
    session         = boto3.session.Session()
    client          = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME        = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"

class OrchestatorUtils():
#    def send_email(self,email):
#        for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
#            if email.get(key) is None:
#                ValueError(f"Missing email parameter -{key}")
#        
#        # Create a new SES resource and specify a region.
#        client = boto3.client('ses',region_name=email["aws_region"])
#        # Try to send the email.
#        try:
#            #Provide the contents of the email.
#            response = client.send_email(
#                Destination={
#                    'ToAddresses': email["recipient_list"],
#                },
#                Message={
#                    'Body': {
#                        'Html': {
#                            'Charset': email["msg_charset"],
#                            'Data': email["msg_body_html"],
#                        },
#                        'Text': {
#                            'Charset': email["msg_charset"],
#                            'Data': email["msg_body_text"],
#                        },
#                    },
#                    'Subject': {
#                        'Charset': email["msg_charset"],
#                        'Data': email["msg_subject"],
#                    },
#                },
#                Source=email["sender"],
#            )
#        # Display an error if something goes wrong.	
#        except ClientError as e:
#            print(e.response['Error']['Message'])
#        else:
#            print("Email sent! Message ID:"),
#            print(response['MessageId'])

    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg             = MIMEMultipart('related')
            msg['Subject']  = email["msg_subject"]
            msg['From']     = email["sender"]
            msg['To']       = ','.join(email["recipient_list"])
            body            = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")
    
    def log_batch_dtl(self, app_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource     = boto3.resource('s3')
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object       = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        audit_batch_record['batch_date'] = batch_date
        #set the batch date
        '''if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()'''
            
        audit_batch_record['batch_id']      =str(uuid.uuid4())
        audit_batch_record['batch_name']    =app_config.get("APPLICATION_NAME")
        audit_batch_record['status']        ='STARTED'
        audit_batch_record['start_time']    =pendulum.now()
        audit_batch_record['end_time']      =''
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket    =app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_bucket:{batch_bucket}")
        print(f"batch_object_key:{batch_object_key}")
        try:
            audit_batch_record=self.get_config(batch_bucket,batch_object_key)
        except Exception as err:
            print(str(err))
        print(str(audit_batch_record))
        print("Type:" +str(type(audit_batch_record)))
        audit_batch_record['status']    ='FINISHED'
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(self, app_config, batch_date, msg):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket                    =app_config['LOGS_BUCKET']
        batch_object_key                =app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_object_key:{batch_object_key}")
        audit_batch_record              =self.get_config(batch_bucket,batch_object_key)
        audit_batch_record['status']    =msg
        audit_batch_record['end_time']  =pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj     = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
            

orch_handle     =OrchestatorUtils()
app_config_yml  = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/app_config.yml")
DAG_NAME        ='pap_dag_tableau_extract'
dag_tags        =['PAP','Tableau Extract','RELEASE 1']
release         =1

def s3_to_redshift_glue_job_execution():
    table_name              = "pap_log_batch_dtl"
    redshift_glue_jobname   = "pap-s3-to-redshift-load-job"
    glue_client             = boto3.client('glue', region_name=region_name)
    response                = glue_client.start_job_run(
    JobName                 =redshift_glue_jobname,
    Arguments={'--additional-python-modules': 'boto3==1.24.69,psycopg2-binary==2.9.3','--s3-path': f"s3://{app_config_yml['environment'].get('LOGS_BUCKET')}/audit-table/{table_name.replace('_','-')}/",'--schema-name': app_config_yml['environment'].get('REDSHIFT_LOAD_SCHEMA') ,'--table-name': table_name}
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    while isJobRunning:
        time.sleep(5)
        status_detail = glue_client.get_job_run(JobName=redshift_glue_jobname, RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    cloud_watch_url_output =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fpython-jobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fpython-jobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")    
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"

def dag_start_send_email(**kwargs):
        handle                                  = OrchestatorUtils()
        context                                 = get_current_context()
        #Variable.set('ds_nodash',context.get('ds_nodash'))
        dict_email                              ={}       
        dict_email['ENV']                       = ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
        dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
        dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']         ='STARTED'
        dict_email['EXECUTION_DATE']            =context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
        dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
        dict_email['MESSAGE']                   =''
        dag_id                                  = context["dag"].dag_id
        execution_date                          = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_failure_send_email(context):
        try: 
            handle = OrchestatorUtils()
            #Variable.set('ds_nodash',context.get('ds_nodash'))
            dict_email                              ={}
            dict_email['ENV']                       = ENV_NAME['name'].upper()
            dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
            dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
            dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
            dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
            dict_email['PROCESS_RUN_STATE']         ='FAILED'
            dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
            dict_email['EXECUTION_DATE']            =context.get('execution_date')
            dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
            dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
            dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
            dict_email['MESSAGE']                   =''
            dag_id                                  = context["dag"].dag_id
            execution_date                          = context["execution_date"].isoformat()
            dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
            email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
            print(email_template)
            enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            handle.send_email(json.loads(enriched_email))
        except Exception as err:
            print(f"ERROR:{str(err)}")

def dag_retry_send_email(context):
        handle = OrchestatorUtils()
        dict_email={}
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='RETRY'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))
    
def dag_end_send_email(**kwargs):
    handle                                  = OrchestatorUtils()
    context                                 = get_current_context()
    dict_email                              ={}
    dict_email['ENV']                       = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']              = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
    dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE']         ='COMPLETED'
    dict_email['EXECUTION_DATE']            =context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']      =pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
    dict_email['MESSAGE']                   =''
    dag_id                                  = context["dag"].dag_id
    execution_date                          = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email                          =Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))

def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0,9)) # for giving delay in each job
    glue_client     = boto3.client('glue', region_name=kwargs['region_name'])
    response        = glue_client.start_job_run(
    JobName         =kwargs["glue_job_name"],
    Arguments       =kwargs["script_args"],
    WorkerType      =kwargs["worker_type"],
    NumberOfWorkers =kwargs["no_of_workers"]
    )
    job_run_id      = response["JobRunId"]
    isJobRunning    = True
    status          = ''
    while isJobRunning:
        time.sleep(15)
        status_detail   = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status          = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning    = False
    cloud_watch_url_output  =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error   =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    #print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"


default_args = {
    "owner": "PAP Project Team",
    "start_date": datetime(2023,1,1),
    "provide_context": True,
    "retries":2,
    "max_active_runs": 1,
    "on_retry_callback": dag_retry_send_email
}

batch_dt        = Variable.get('ds_nodash')
glue_iam_role   = "AWSGlueServiceRoleDefault"
region_name     = "us-west-2"
script_args     = {
                        '--config_bucket': CODE_ARTIFACTS_BUCKET,
                        '--batch_date': batch_dt
                    }

script_arg_mand_file_chk= {
                            '--config_bucket': CODE_ARTIFACTS_BUCKET,
                            '--batch_date': batch_dt,
                            '--config': f"s3://{app_config_yml['environment'].get('CODE_ARTIFACTS_BUCKET')}/configuration/mandatoryfile_config.csv",
                            '--folder_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/landing/"
                            }

try:
    credential      = ''
    region_name     = os.environ['AWS_REGION']
    session         = boto3.session.Session()
    client          = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-service-account')
    credential      = ast.literal_eval(get_role_secret['SecretString'])
    
except Exception as e:
    print("Error While Fetching secrets")
    raise e

WORKFORCE_SUMMARY                   =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Workforce Summary" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

PLAN                                =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Plan" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DIVERSIFY                           =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Diversify" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

PEOPLE_ANALYTICS                    =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT2')}" --workbook "People Analytics" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

ATTRACT_DEEP_DIVE                   =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Attract Deep-Dive" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

RETAIN                              =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Retain" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

MOTIVATE_ENGAGE                     =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Motivate Engage" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

MOTIVATE_REWARD                     =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Motivate Reward" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

GROW                                =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Grow" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

LEVEL                               =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Level" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

BADGE                               =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Badge" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

EQUITY                              =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Equity" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

ATTRACT                             =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Attract" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

ORGANIZE                            =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Organize" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

RECRUITER_REQ_PERFORMANCE           =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Recruiter Req Performance" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

RECRUITER_APPLICANT_PERFORMANCE     =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Recruiter Applicant Performance" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

RECRUITER_SURVEY_PERFORMANCE        =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Recruiter Survey Performance" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

OVERVIEW_OF_TRENDS                  =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Overview of Trends" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

OVERVIEW_OF_HIRES_AND_CANDIDATES    =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Overview of Hires and Candidates" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

REQUISITION_MANAGEMENT              =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Requisition Management" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

APPLICANT_MANAGEMENT                =f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT')}" --workbook "Applicant Management" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''


# DATASOURCES STARTED

DS_ACT_AS_AND_LEADER=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Act as and Leader"  -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_AVAILABILITY_DATE=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Availability Date"  -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_EXIT_COMMENT_THEMES=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Exit Comment Themes"  -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_EXTERNAL_TURNOVER_RATES=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "External Turnover Rates"  -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_FACT_EMPLOYEE_SURVEY=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Fact Employee Survey" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_FACT_JOB_EVENTS=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Fact Job Events" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''
 
DS_FACT_RECRUITMENT_EVENTS=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Fact Recruitment Events" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_HIERARCHY_DATASET=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Hierarchy dataset" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_PLAN=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Plan" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_REQUISITION_TAG=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Requisition Tag" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_RETAIN_TOOLTIP=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Retain Tooltip" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''
 
DS_TAB_SECURITY=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Tab Security" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''
 
DS_USER=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "User" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_TRANSFER_DETAILED_REPORT=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Transfer Detailed Report" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''

DS_WORKER_TYPE=f'''python3 -m tabcmd refreshextracts --project "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE')}" --parent-project-path "{app_config_yml['environment'].get('TABLEAU_PROJECT_DATASOURCE_PARENT')}" --datasource "Worker Type" -s "{app_config_yml['environment'].get('TABLEAU_SERVER')}" -u "{credential["user"]}" -p "{credential["password"]}" -t "{app_config_yml['environment'].get('TABLEAU_SITE_ID')}" --no-certcheck'''


# DATASOURCES END

with DAG(
    dag_id              =   DAG_NAME,
    start_date          =   pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
    catchup             =   False,
    schedule_interval   =   None,
    concurrency         =   5,
    tags                =   dag_tags,
    default_args        =   default_args,
    on_failure_callback =   dag_failure_send_email) as dag:
    start         = PythonOperator(task_id          ="Start",
                                   python_callable  =dag_start_send_email, 
                                   provide_context  =True,
                                )
    end           = PythonOperator(task_id          ="End",
                                   python_callable  =dag_end_send_email, 
                                   provide_context  =True,
                                )                  
        
    extract_cmd_1  = BashOperator(task_id        ="WORKFORCE_SUMMARY",
                                  bash_command   =f"{WORKFORCE_SUMMARY}",
                                  dag            =dag
                                 )

    extract_cmd_2  = BashOperator(task_id        ="PLAN",
                                  bash_command   =f"{PLAN}",
                                  dag            =dag
                                 )

    extract_cmd_3  = BashOperator(task_id        ="DIVERSIFY",
                                  bash_command   =f"{DIVERSIFY}",
                                  dag            =dag
                                 )
    extract_cmd_4  = BashOperator(task_id        ="PEOPLE_ANALYTICS",
                                  bash_command   =f"{PEOPLE_ANALYTICS}",
                                  dag            =dag
                                 )

    extract_cmd_5  = BashOperator(task_id        ="ATTRACT_DEEP_DIVE",
                                  bash_command   =f"{ATTRACT_DEEP_DIVE}",
                                  dag            =dag
                                 )

    extract_cmd_6  = BashOperator(task_id        ="RETAIN",
                                  bash_command   =f"{RETAIN}",
                                  dag            =dag
                                 )

    extract_cmd_7  = BashOperator(task_id        ="MOTIVATE_ENGAGE",
                                  bash_command   =f"{MOTIVATE_ENGAGE}",
                                  dag            =dag
                                 )
    extract_cmd_8  = BashOperator(task_id        ="MOTIVATE_REWARD",
                                  bash_command   =f"{MOTIVATE_REWARD}",
                                  dag            =dag
                                 )

    extract_cmd_9  = BashOperator(task_id        ="GROW",
                                  bash_command   =f"{GROW}",
                                  dag            =dag
                                 )

    extract_cmd_10 = BashOperator(task_id        ="LEVEL",
                                  bash_command   =f"{LEVEL}",
                                  dag            =dag
                                 )

    extract_cmd_11 = BashOperator(task_id        ="BADGE",
                                  bash_command   =f"{BADGE}",
                                  dag            =dag
                                 )
    extract_cmd_12 = BashOperator(task_id        ="EQUITY",
                                  bash_command   =f"{EQUITY}",
                                  dag            =dag
                                 )

    extract_cmd_13 = BashOperator(task_id        ="ATTRACT",
                                  bash_command   =f"{ATTRACT}",
                                  dag            =dag
                                 )

    extract_cmd_14 = BashOperator(task_id        ="ORGANIZE",
                                  bash_command   =f"{ORGANIZE}",
                                  dag            =dag
                                 )

    extract_cmd_15 = BashOperator(task_id        ="RECRUITER_REQ_PERFORMANCE",
                                  bash_command   =f"{RECRUITER_REQ_PERFORMANCE}",
                                  dag            =dag
                                 )
    extract_cmd_16 = BashOperator(task_id        ="RECRUITER_APPLICANT_PERFORMANCE",
                                  bash_command   =f"{RECRUITER_APPLICANT_PERFORMANCE}",
                                  dag            =dag
                                 )

    extract_cmd_17 = BashOperator(task_id        ="RECRUITER_SURVEY_PERFORMANCE",
                                  bash_command   =f"{RECRUITER_SURVEY_PERFORMANCE}",
                                  dag            =dag
                                 )

    extract_cmd_18 = BashOperator(task_id        ="OVERVIEW_OF_TRENDS",
                                  bash_command   =f"{OVERVIEW_OF_TRENDS}",
                                  dag            =dag
                                 )

    extract_cmd_19 = BashOperator(task_id        ="OVERVIEW_OF_HIRES_AND_CANDIDATES",
                                  bash_command   =f"{OVERVIEW_OF_HIRES_AND_CANDIDATES}",
                                  dag            =dag
                                 )
    extract_cmd_20 = BashOperator(task_id        ="REQUISITION_MANAGEMENT",
                                  bash_command   =f"{REQUISITION_MANAGEMENT}",
                                  dag            =dag
                                 )

    extract_cmd_21 = BashOperator(task_id        ="APPLICANT_MANAGEMENT",
                                  bash_command   =f"{APPLICANT_MANAGEMENT}",
                                  dag            =dag
                                 )
    

    ds_extract_cmd_1 = BashOperator(task_id        ="DS_ACT_AS_AND_LEADER",
                                  bash_command   =f"{DS_ACT_AS_AND_LEADER}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_2 = BashOperator(task_id        ="DS_AVAILABILITY_DATE",
                                  bash_command   =f"{DS_AVAILABILITY_DATE}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_3 = BashOperator(task_id        ="DS_EXIT_COMMENT_THEMES",
                                  bash_command   =f"{DS_EXIT_COMMENT_THEMES}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_4 = BashOperator(task_id        ="DS_EXTERNAL_TURNOVER_RATES",
                                  bash_command   =f"{DS_EXTERNAL_TURNOVER_RATES}",
                                  dag            =dag
                                 )

    ds_extract_cmd_5 = BashOperator(task_id        ="DS_FACT_EMPLOYEE_SURVEY",
                                  bash_command   =f"{DS_FACT_EMPLOYEE_SURVEY}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_6 = BashOperator(task_id        ="DS_FACT_JOB_EVENTS",
                                  bash_command   =f"{DS_FACT_JOB_EVENTS}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_7 = BashOperator(task_id        ="DS_FACT_RECRUITMENT_EVENTS",
                                  bash_command   =f"{DS_FACT_RECRUITMENT_EVENTS}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_8 = BashOperator(task_id        ="DS_HIERARCHY_DATASET",
                                  bash_command   =f"{DS_HIERARCHY_DATASET}",
                                  dag            =dag
                                 )

    ds_extract_cmd_9 = BashOperator(task_id        ="DS_PLAN",
                                  bash_command   =f"{DS_PLAN}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_10 = BashOperator(task_id        ="DS_REQUISITION_TAG",
                                  bash_command   =f"{DS_REQUISITION_TAG}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_11 = BashOperator(task_id        ="DS_RETAIN_TOOLTIP",
                                  bash_command   =f"{DS_RETAIN_TOOLTIP}",
                                  dag            =dag
                                 )
    
    ds_extract_cmd_12 = BashOperator(task_id        ="DS_TAB_SECURITY",
                                  bash_command   =f"{DS_TAB_SECURITY}",
                                  dag            =dag
                                 )

    ds_extract_cmd_13 = BashOperator(task_id        ="DS_USER",
                                  bash_command   =f"{DS_USER}",
                                  dag            =dag
                                 )

    ds_extract_cmd_14 = BashOperator(task_id        ="DS_TRANSFER_DETAILED_REPORT",
                                  bash_command   =f"{DS_TRANSFER_DETAILED_REPORT}",
                                  dag            =dag
                                 )

    ds_extract_cmd_15 = BashOperator(task_id        ="DS_WORKER_TYPE",
                                  bash_command   =f"{DS_WORKER_TYPE}",
                                  dag            =dag
                                 )

    delay_task_py =  PythonOperator(task_id     ="delay_task",
                                  python_callable   = lambda: time.sleep(6000),
                                  dag            =dag
                                 )

#THE BELOW IS ONLY TO TEST THE CURL
#    curl = BashOperator(task_id        ="pap_curl",
#                                 bash_command   ="curl -k https://uatgtp.gilead.com/",
#                                 dag            =dag
#                                )
    
start >> [extract_cmd_1,extract_cmd_2,extract_cmd_3,extract_cmd_4,extract_cmd_5,extract_cmd_6,extract_cmd_7,extract_cmd_8,extract_cmd_9,extract_cmd_10,extract_cmd_11,extract_cmd_12,extract_cmd_13,extract_cmd_14,extract_cmd_15,extract_cmd_16,extract_cmd_17,extract_cmd_18,extract_cmd_19,extract_cmd_20,extract_cmd_21,ds_extract_cmd_1,ds_extract_cmd_3,ds_extract_cmd_4,ds_extract_cmd_5,ds_extract_cmd_6,ds_extract_cmd_7,ds_extract_cmd_8,ds_extract_cmd_9,ds_extract_cmd_10,ds_extract_cmd_11,ds_extract_cmd_12,ds_extract_cmd_13,ds_extract_cmd_14,ds_extract_cmd_15] >> delay_task_py >> ds_extract_cmd_2 >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################