-- DROP SCHEMA pap_view_schema;

CREATE SCHEMA pap_view_schema;

--------------------------------

-- pap_view_schema.pap_latest_data_availability_vw source

CREATE OR REPLACE VIEW pap_view_schema.pap_latest_data_availability_vw
AS SELECT derived_table1.batch_date, derived_table1.batch_id, derived_table1.batch_name, derived_table1.status, derived_table1.start_time, derived_table1.end_time, to_date(derived_table1.availability_date::character varying::text, 'YYYYMMDD'::character varying::text) AS availability_date
   FROM ( SELECT b.batch_date, b.batch_id, b.batch_name, b.status, b.start_time, b.end_time, COALESCE(ad.availability_date::numeric::numeric(18,0), b.batch_date::numeric(18,0)) AS availability_date, pg_catalog.row_number()
          OVER( 
          ORDER BY b.batch_date DESC, b.start_time DESC) AS rnum
           FROM gna_load_schema.pap_log_batch_dtl b
      LEFT JOIN gna_load_schema.override_availability_dates ad ON b.batch_date::text = ad.batch_date::character varying::text
     WHERE b.status::text = 'FINISHED'::character varying::text) derived_table1
  WHERE derived_table1.rnum = 1;  


-- pap_view_schema.tab_level_security_vw source

--drop view pap_view_schema.tab_level_security_vw;
CREATE OR REPLACE VIEW pap_view_schema.tab_level_security_vw
AS SELECT tab_level_security.dashboard_name,
tab_level_security."roles",
tab_level_security.flag,
tab_level_security.extra_condition,
tab_level_security.url,
row_num,
sort_order
from gna_load_schema.tab_level_security  where flag='T';




-- pap_view_schema.fact_job_events_denormalized_vw source;


create view pap_view_schema.fact_job_events_denormalized_vw as 
with load_dt_cte as (
              select 
			    max(availability_date) as load_date 
				--max(to_date(substring(end_time,0,11),'YYYY-MM-DD')) as load_date 
			  from pap_view_schema.pap_latest_data_availability_vw
			  where status='FINISHED'
       )
 select
 --count(distinct worker_id ) as worker_cnt
    --, sum(HEADCOUNT) as total_headcount
	concat(concat(',',fv.role_name_access_list),',') AS role_name_access_list
	,fv.employee_sub_cat_desc 			AS "Worker Type Sub Category Description"
	,fv.pay_grade_group
	,fv.office_type 					AS "Office Type"
	,fv.AGE_BAND_DESC 					AS "Age Group"
	,fv.DISABILITY_STATUS_US 			AS "Disability Status (US)"
	,fv.VETERAN_STATUS_US 				AS "Veteran Status (US)"
	,FV.gender_identity			
	,FV.hiest_degree 					AS "Highest Education Degree Description"
	,FV.job_req_tag 					AS "Job Req Tag"
	,FV.length_of_service
	,NVL(FV.sexual_orientation,'Unspecified') AS sexual_orientation
	,CASE WHEN FV.ETHNICITY_US	IN ('Black or African American','Black') 
			THEN 'Black or African American' 
		  ELSE FV.ETHNICITY_US 
	 END AS "Ethnicity (US)"
	,fv.employee_cat_code
	,fv.MAX_SEQ_IND
	,fv.SNAPSHOT_IND
	,fv.SUPERVISOR_EVT_IND
	,fv.HEADCOUNT
	,fv.ASSIGNMENT_NUM
	,fv.GRADE_INCREASE_FLG
	,fv.EVENT_CATEGORY 					AS "Event Category"
	
	,fv.BUSINESS_PROCESS				AS "Event Type"
	,fv.EVENT_REASON	 				AS "Event Reason"
	--,fv.EVENT_REASON_NAME 				AS "Event Reason"
	,fv.MOVEMENT_IND 
	,fv.TERM_STATUS_IND
	,fv.event_ind
	
	,FV.le_level1_val
    ,FV.le_level2_val
    ,FV.le_level3_val
    ,FV.le_level4_val
    ,FV.le_level5_val
    
	,FV.location_code_level1
    ,FV.location_code_level2
    ,FV.location_code_level3
    ,FV.location_code_level4
    ,FV.location_code_level5
    ,FV.location_code_level6
    ,FV.location_code_level7
    ,FV.location_code_level8
    ,FV.location_code_level9
    ,FV.location_code_level10
    ,FV.location_code_level11
    ,FV.location_code_level12
    ,fv.LEVEL13_VAL						AS BASE_LOCATION
    
	,FV.product_value1
    ,FV.product_value2
    ,FV.product_value3
    ,FV.product_value4
    ,FV.product_value5
    
	,FV.cc_level1_value
    ,FV.cc_level2_value
    ,FV.cc_level3_value
    ,FV.cc_level4_value
    ,FV.cc_level5_value
    ,FV.cc_level6_value
    ,FV.cc_level7_value
	
    ,FV.current_level1_emp_full_name
	,FV.current_level2_emp_full_name
    ,FV.current_level3_emp_full_name
    ,FV.current_level4_emp_full_name
    ,FV.current_level5_emp_full_name
    ,FV.current_level6_emp_full_name
    ,FV.current_level7_emp_full_name
    ,FV.current_level8_emp_full_name
    ,FV.current_level9_emp_full_name
    ,FV.current_level10_emp_full_name
    ,FV.current_level11_emp_full_name
    
	,FV.current_level1_emp_login
	,FV.current_level2_emp_login
    ,FV.current_level3_emp_login
    ,FV.current_level4_emp_login
    ,FV.current_level5_emp_login
    ,FV.current_level6_emp_login
    ,FV.current_level7_emp_login
    ,FV.current_level8_emp_login
    ,FV.current_level9_emp_login
    ,FV.current_level10_emp_login
    ,FV.current_level11_emp_login
	,FV.WORKER_ID 						AS "Worker ID"
	,FV.WORKER_PREF_NAME 				AS "Worker Name"
	,FV.PAY_GRADE_GROUP 				AS "Pay Grade Group"
	,FV.PAY_GRADE_CODE 					AS "Pay Grade"
	,FV.POSITION_ID 					AS "Position ID"
	,FV.JOB_CODE 						AS "Job Code"
	,FV.JOB_DESC 						AS "Job Title"
	,FV.JOB_FAMILY_DESC 				AS "Job Family"
	,FV.JOB_EXEMPT_FLG					
	,FV.Job_Exempt						AS "Job Exempt"
	,FV.CC_NODEVAL 						AS "Cost Center ID"
    ,FV.CC_NODENAME 					AS "Cost Center Name"
	,FV.SUPERVISOR_ID 					AS "Supervisior ID"
	,FV.SUPERVISOR_NAME 				AS "Supervisior Name"
	,FV.ORIG_HIRE_DT 					AS "Original Hire Date" -- emp_hire_dt changed to original_hire_dt || defect 1253
	,TO_DATE(FV.MOST_RECENT_HIRE_DT,'YYYY-MM-DD')				AS "Most Recent Hire Date"
	,TO_DATE(FV.CONTINUOUS_SERVICE_DT,'YYYY-MM-DD')				AS "Continuous Service Date"
	--,FV.LENGTH_OF_SERVICE_GROUP 		AS "Length of Service Group" -- to be handled in tableau
	--,FV.LENGTH_OF_SERVICE_YEARS 		AS "Length of Service (Years)" -- to be handled in tableau
	,FV.LEVEL2_DESC_NO_MGR 				AS "Geographic Location Level 2 Name"
	,FV.ATTR_MISC_DESC 					AS "Country Name"
	,FV.LOCATION_DESC_LEVEL13						AS "Location Name"
	,FV.FULL_TIME_FLG 					
	,FV.PEOPLE_MANAGER_FLG 				AS "People Manager Flag"
	,FV.REHIRE_FLAG 					AS "Rehire Flag"
	---,TO_DATE(FV.MOST_RECENT_ADVANCEMENT_DATE,'YYYY-MM-DD') 		AS "Most Recent Advancement Date"
    ,FV.Current_Employment_Status 		AS "Employement Status"
	,FV.SCHOOL_NAME 					AS "Highest Degree School Name"
	--,FV.AGE 							AS "Age (Years)" -- to be handled in tableau
	,CASE WHEN FV.SEX_DESC='Unknown' THEN 'Unspecified' ELSE NVL(FV.SEX_DESC ,'Unspecified') END AS "Gender"
	,FV.SOURCE_TYPE_NAME 				AS "Dim Recruitment Source"
	,FV.PERF_BAND_DESC 					AS "{Most Recent Year before Prompted End Date's} Year-End Rating"
	,FV.PREVIOUS_PERF_BAND_DESC 		AS "{Second-Most Recent Year before Prompted End Date's} Year-End Rating"
	,CASE WHEN FV.talent_quadrant='' 
			THEN  NULL 
		  ELSE FV.talent_quadrant	
	 END			AS "{Most Recent Year before Prompted End Date's} Talent Coordinate"
	,CASE WHEN FV.talent_quadrant_prv ='' 
			THEN  NULL 
		  ELSE FV.talent_quadrant_prv 	
	 END			AS "{Second-Most Recent Year before Prompted End Date's} Talent Coordinate"
	,FV.ASSIGNED_HR_BUSINESS_PARTNER 	AS "Assigned HR Business Partner"
	,FV.Cost_center_level2_desc
	,FV.ORGANIZATION_SIZE				AS "Organization Size"
	--,FV.POINT_TIME_ORG_SIZE 			AS "Organization Size"
	,FV.NUMBER_OF_DIRECT_REPORTS 		AS "Number of Direct Reports"
	--,FV.POINT_TIME_DIRECT_REPORTEE 	AS "Number of Direct Reports"
	,FV.NUMBER_OF_INDIRECT_REPORTS		AS "Number of Indirect Reports"
	--,FV.POINT_TIME_INDIRECT_ORG		AS "Number of Indirect Reports"
	,FV.WORKER_CATEGORY 				AS "Worker Category"
	,FV.VMS_SECURITY_ID 
	,TO_DATE(FV.CONTRACT_START_DATE,'YYYY-MM-DD')				AS "Contract Start Date"
	,TO_DATE(FV.CONTRACT_END_DATE,'YYYY-MM-DD') 				AS "Contract End Date"
	,TO_DATE(FV.EARLIEST_CONTRACT_START_DATE,'YYYY-MM-DD') 		AS "Earliest Contract Start Date"
	,TO_DATE(FV.EARLIEST_CONTRACT_END_DATE ,'YYYY-MM-DD')		AS "Earliest Contract End Date"
	,FV.AWR_VENDOR_AGENCY 				AS "Vendor/Agency Name"
	,FV.WORK_ORDER 						AS "Work Order"
	,FV.TASK_NAME 						AS "Task Name"
	,FV.AWR_PURCHASE_ORDER_NUM 			AS "PO Number"
	,FV.AWR_REQUISTION_NUM 				AS "Requisition Number"
	,FV.AWR_PAY_RATE 					AS "Pay Rate"		
	,FV.AWR_BILL_RATE					AS "Bill Rate"	
	,FV.AWR_BILLING_CURRENCY 			AS "Billing Currency"
	,FV.PAY_BILL_RATE_FREQUENCY  		AS "Pay/Bill Rate Frequency"
	,FV.SPACE 							AS "Space (Y/N)"
	,FV.BADGE 							AS "Badge (Y/N)"
	,FV.AWR_SECURITY_BDG_ACCESS_NUM 	AS "Security Badge Access Num"
	,TO_DATE(FV.EVENT_DT_KEY ,'YYYYMMDD')	AS "Event Date"
	--,FV.EFFECTIVE_START_DT 				AS "Event Date"
	--,FV.Most_Recent_New_Role 			AS "Most Recent New Role"
	,FV.MOST_RECENT_NEW_ROLE_DT			AS "Most Recent New Role"
	--,TO_DATE(FV.Movement_Date,'YYYY-MM-DD') 		AS "Most Recent Movement Date"
	,FV.MOST_RECENT_TERMINATION_DT		AS "Most Recent Termination Date"
	--,FV.TERMINATION_DT 					AS "Most Recent Termination Date"
	,FV.SOURCE_ID 						AS "Job Req ID"
	,FV.REPLACEMENT_CODE 				AS "Job Req Type"
	,FV.CATEGORY_DESC 					AS "Job Req Category"
	--,FV.POSITION_REASON 				AS "Position Desc"
	,FV.POSITION_DESC					AS "Position Desc"
	,FV.PREVIOUS_POSITION_ID 			AS "Previous Position ID"
	--,FV.prev_position_reason 			AS "Previous Position Desc"
	,FV.PREVIOUS_POSITION_DESC			AS "Previous Position Desc"
	,FV.PREV_PAY_GRADE_GROUP 			AS "Previous Pay Grade Group"
	,FV.PREV_PAY_GRADE_CODE				AS "Previous Pay Grade"
	,FV.previous_job_code 				AS "Previous Job Code"
	,FV.previous_job_title 				AS "Previous Job Title"
	,FV.previous_Job_family 			AS "Previous Job Family"
	,FV.prev_job_exempt_flg 			AS "Previous Job Exempt"
	,NVL(case when OFFICE_TYPE_PRV_KEY = 1001 then 'Gilead Office'  
          when OFFICE_TYPE_PRV_KEY = 1002 then 'Conversion'  
          when OFFICE_TYPE_PRV_KEY = 1003 then 'Remote'  
          when OFFICE_TYPE_PRV_KEY = 1004 then 'Field' 
		  when OFFICE_TYPE_PRV_KEY = 1005 then 'Gilead Site'
     end,FV.OFFICE_TYPE) 				AS "Previous Office Type"
	--,FV.OFFICE_TYPE 					AS "Previous Office Type"
	,FV.previous_supervisor_id 			AS "Previous Supervisor ID"
	,FV.previous_supervisor_name 		AS "Previous Supervisor Name"
	,FV.Previous_Cost_Center_ID 		AS "Previous Cost Center ID"
	,FV.Previous_Cost_Center_Name 		AS "Previous Cost Center Name"
	,FV.Prev_Geo_Loc_Lvl_2_Name 		AS "Previous Geographic Location Level 2 Name"
	,FV.PREVIOUS_COUNTRY_NAME 			AS "Previous Country Name"
	,FV.Previous_Location_Name 			AS "Previous Location Name"
	,FV.prev_cc_level2_value 			AS "Previous Cost Center Level 2 Code"
	,FV.prev_cost_center_level2_desc 	AS "Previous Cost Center Level 2 Name"
	,FV.Previous_LEVEL1_EMP_FULL_NAME 	AS "Previous Supervisory Org Current Level 1 Full Name"
	,FV.Previous_LEVEL2_EMP_FULL_NAME 	AS "Previous Supervisory Org Current Level 2 Full Name"
	,FV.Previous_LEVEL3_EMP_FULL_NAME 	AS "Previous Supervisory Org Current Level 3 Full Name"
	,FV.Previous_LEVEL4_EMP_FULL_NAME 	AS "Previous Supervisory Org Current Level 4 Full Name"
	,FV.Previous_LEVEL5_EMP_FULL_NAME 	AS "Previous Supervisory Org Current Level 5 Full Name"
	,case when FV.CHANGE_EVENT_TYPE = 'IASG_START' AND FV.ASSIGNMENT_NUM = 1 then FV.EFFECTIVE_START_DT END as "Assignment Start Date"
	,FV.IA_END_DT 						AS "Assignment End Date"
	,FV.HOME_SUPERVISOR_ID   			AS "Home Supervisor ID"
	,FV.HOME_SUPERVISOR_NAME 			AS "Home Supervisor Name" 
	--,FV.LOCATION_DESC_LEVEL8 			AS "Home Location"
	,FV.HOME_LOCATION					AS "Home Location"
	--,FV.Movement_Date 					AS "Time Since Most Recent Movement"
	--,FV.MOST_RECENT_ADVANCEMENT_DATE 	AS "Time Since Most Recent Advancement"
	,FV.Skills_First_or_OneTen_Emp 		AS "Skills First or OneTen Employee"
	,FV.INTL_ASSGN_TYPE_NAME 			AS "International Assignment Type"
	,FV.TERMINATION_DT1 				AS "Termination Effective Date"
	,FV.DAYS_SURVIVED 					AS "Days Survived"
	,FV.Official_Turnover_Reason 		AS "Official Turnover Reason"
	,fes_r.reason_for_leaving 			AS "Employee Choosen-Turnover Reason"
	--,THEME.theme_level1			 		AS "Exit Survey Comment Themes"
	--,FV.EXIT_SURVEY_COMMENTS_THEME 		AS "Exit Survey Comment"
	,FV.highest_degree_major 			AS "Highest Degree Major" -- may cause error
	,FV.EMP_ACTIVE_FLG
	,FV.EVENT_DT_KEY
	,FV.START_DT_WID
	,FV.END_DT_WID
	,FV.EVENT_MONTH_KEY
	,FV.SNAPSHOT_MONTH_END_IND
	,FV.INTERNAL_FILLED_REQ_IND
	,FV.JOB_FAMILY_GROUP
	,CASE WHEN FV.SALARY_ANNL=0 THEN fjes_sal.home_salary_annl ELSE NVL(FV.SALARY_ANNL,fjes_sal.home_salary_annl) END AS "Total Base Pay (Annualized)" 
	,FV.Currency_Code					AS "Currency Code"
	,FV.TERM_EVENT_IND
	--,FV.AWR_WORK_TYPE					AS "Work Type"
	,FV.employee_sub_cat_desc			AS "Work Type"
	,FV.total_annl_sal					
	,FV.individual_bonus_target
	,FV.annual_bonus_amount
	,FV.merit_stock_target
	,FV.unvested_equity
	,FV.cc_desc 
	,FV.cc_legal_entity 	
	--,FV.cc_owner 						AS "Cost Center Owner"	
	,FV.COST_CENTER_OWNER				AS "Cost Center Owner"
	,FV.functional_area 	            AS "Cost Center Function"
	,FV.currency 			
	,FV.product_link 		
	,FV.market_associated 
    ,FV.HRYID 
	,FV.SECTOR_A_FROM					AS "Salary Range Segment Min A"
	,FV.SECTOR_A_TO						AS "Salary Range Segment Max A"
  	,FV.SECTOR_B_FROM					AS "Salary Range Segment Min B1"
	,FV.SECTOR_1B_TO					AS "Salary Range Segment Max B1"
	,FV.SECTOR_2B_FROM					AS "Salary Range Segment Min B2"
	,FV.SALARY_MIDPOINT					AS "Salary Range Segment Midpoint (B2)"
	,FV.SECTOR_2B_TO					AS "Salary Range Segment Max B2"
	,FV.SECTOR_3B_FROM					AS "Salary Range Segment Min B3"
	,FV.SECTOR_3B_TO					AS "Salary Range Segment Max B3"
	,FV.SECTOR_C_FROM					AS "Salary Range Segment Min C"
	,FV.SECTOR_C_TO						AS "Salary Range Segment Max C"
	,case when FV.grade_change_ind=1 and FV.pay_grade_code = FV.PREV_PAY_GRADE_CODE then 0 else FV.grade_change_ind end AS grade_change_ind 				
	,FV.grade_decrease_flg 
	,FV.cc_hier_key 
	,FV.cc_hier_prv_key 
	,FV.CC_LEVEL1_DESC					AS "Cost Center Level Name1"			
	,FV.CC_LEVEL2_DESC					AS "Cost Center Level Name2"
	,FV.CC_LEVEL3_DESC                  AS "Cost Center Level Name3"
	,FV.CC_LEVEL4_DESC                  AS "Cost Center Level Name4"
	,FV.CC_LEVEL5_DESC                  AS "Cost Center Level Name5"
	,FV.CC_LEVEL6_DESC                  AS "Cost Center Level Name6"
	,FV.CC_LEVEL7_DESC                  AS "Cost Center Level Name7"
	,FV.LE_LEVEL1_DESC					AS "Legal Entity Name"
	,FV.LE_LEVEL5_DESC					AS "Legal Entity Name After Event"
	,FV.PREV_LOCATION_CODE_LEVEL2		AS "Geographic Location Level 2 Code Before Event"
	--,FV.PREVIOUS_LEVEL2_DESC_NO_MGR		AS "Geographic Location Level 2 Code Before Event"
	,FV.prev_le_level5_val				AS "Legal Entity ID Before Event"
	,FV.PREV_LE_LEVEL5_DESC				AS "Legal Entity Name Before Event"
	,FV.PREV_CC_OWNER					AS "Cost Center Owner Transferred From"
	--,FV.PAY_GRADE_NAME				AS "Grade Profile Name"
	,FV.PAY_GRADE_PROFILE				AS "Grade Profile Name"
	,FV.BUSINESS_TITLE					AS "Business Title"
	,case when FV.PAYLINE_CODE='Unspecified' then 'Unspecified' else  substring(FV.PAYLINE_CODE , 3 , 2) end as "Range ID"
	,case when FV.PAYLINE_CODE='Unspecified' then 'Unspecified' else  substring(FV.PAYLINE_CODE , 5 , 6) end as "TIER CODE"
	,case when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <  "Salary Range Segment Min A"  then 'Below A'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >= "Salary Range Segment Min A"  and  NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <  "Salary Range Segment Min B1" THEN 'A'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >= "Salary Range Segment Min B1" and  NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <= "Salary Range Segment Max B1" THEN 'B1'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >= "Salary Range Segment Min B2" and  NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <= "Salary Range Segment Max B2" THEN 'B2'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >= "Salary Range Segment Min B3" and  NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <= "Salary Range Segment Max B3" THEN 'B3'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >  "Salary Range Segment Max B3" and  NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) <= "Salary Range Segment Max C"  THEN 'C'
	 when NVL(FV.SALARY_ANNL/CASE WHEN fte=0 THEN NULL ELSE FTE END,0) >  "Salary Range Segment Max C" then 'Above C'
	 end as "Sector Position"
	,FV.WORKER_KEY
	,FV.FTE
    ,FV.EXCH_RATE
	,FV.Skills_First_or_OneTen_Emp 		AS "Skills First or OneTen Emp"
	,FV.TERMINATION_DT1-1 				as "Termination Date"
	,THEME.theme_level1					AS "Theme Level1"
	,THEME.Exit_Survey_Comment_Themes   AS "Exit Survey Comment Themes"
	,case when left(trim(fesd.exit_survey_resp_comments),1) in ('-','/','=')
		  then ''''||fesd.exit_survey_resp_comments||'''' 
	      else  fesd.exit_survey_resp_comments end AS "Exit Survey Comment"
	--,fesd.exit_survey_resp_comments	AS "Exit Survey Comment"
	,FV.TERMINATION_CATEGORY			AS "Termination Category"
	,FV.CC_NODEVAL
	,FV.CC_NODENAME
	,FV.BUILDING
	,FV.LAST_MONTH_IN_YEAR_IND
	,FV.TARGET_BONUS_PERCENT
	,FV.STOCK_TARGET_AMOUNT
	,FV.ANNUAL_BONUS_TARGET_AMOUNT
	--,FV.ANNUAL_COMPENSATION_IND
	--,FV.MIDYEAR_COMPENSATION_IND
	--,FV.COMPENSATION_PLAN
	--,FV.TOTAL_SALARY_AND_ALLOWANCES 
	--,FV.STOCK_ACTUAL_RSU 
	--,FV.STOCK_ACTUAL_PSU 
	--,FV.STOCK_ACTUAL_NQ  
	--,FV.STOCK_ACTUAL_PROMOTION_PSU 
	--,FV.STOCK_CURRENCY  
	
	,FV.BUSINESS_PROCESS
	,FV.ORIG_PERF_RATING 
	,FV.ORIG_PERF_RATING_PRV
	,FV.talent_quadrant
	,FV.talent_quadrant_prv

	,case when (fv.assignment_num = 1 and fv.change_event_type = 'IASG_START') or (fv.assignment_num = 0 and fv.supervisor_evt_ind= 0 and fv.event_category = 'Transfer')
	or (fv.assignment_num = 0 and fv.supervisor_evt_ind = 0 and (fv.event_category = 'Promotion' or fv.grade_increase_flg = 1)) or (fv.event_category = 'Hire' and fv.internal_filled_req_ind = 0) then 1 else 0 end as "Any Movement Flag"
	,FV.Le_level6_val
	,FV.LOCATION_CODE_LEVEL13
	,FV.birth_dt
	,CASE WHEN fre.rqstn_key IS NOT NULL THEN fre.rqstn_key
            ELSE fre1.rqstn_key
        END AS rqstn_key, 
        CASE
            WHEN fre.rqstn_key IS NOT NULL THEN fre.source_type_name
            ELSE fre1.source_type_name
        END AS "Recruitment Source"
	,FV.PRODUCT_DESC_1
	,FV.PRODUCT_DESC_2
	,FV.PRODUCT_DESC_3
	,FV.PRODUCT_DESC_4
	,FV.PRODUCT_DESC_5
	,FV.LE_LEVEL2_DESC
	,FV.LE_LEVEL3_DESC
	,FV.LE_LEVEL4_DESC
	,FV.LE_LEVEL5_DESC
	,FV.change_event_type
	,FV.LOCATION_DESC_LEVEL1
	,FV.LOCATION_DESC_LEVEL2
	,FV.LOCATION_DESC_LEVEL3
	,FV.LOCATION_DESC_LEVEL4
	,FV.LOCATION_DESC_LEVEL5
	,FV.LOCATION_DESC_LEVEL6
	,FV.LOCATION_DESC_LEVEL7
	,FV.LOCATION_DESC_LEVEL8
	,FV.LOCATION_DESC_LEVEL9
	,FV.LOCATION_DESC_LEVEL10
	,FV.LOCATION_DESC_LEVEL11
	,FV.LOCATION_DESC_LEVEL12
	,FV.job_req_tag1
	,FV.job_req_tag2
	,FV.job_req_tag3
	,FV.job_req_tag4
	,FV.job_req_tag5
	,FV.job_req_tag6
	,FV.job_req_tag7
	,FV.job_req_tag8
	,FV.job_req_tag9
	,FV.job_req_tag10
	,FV.LOC_HIER_KEY
	,FV.SUPERVISOR_HIER_KEY
	,FV.PROD_HIER_KEY
	,FV.le_hier_key
	,CASE WHEN FV.FULL_TIME_FLG = 'Y' THEN 'Full Time'
		  WHEN FV.FULL_TIME_FLG = 'N' THEN 'Part Time'
	      ELSE 'Unspecified'
	 END AS "Full Time Flag"
	,FV.TIME_TO_FILL
	,FV.TIME_TO_HIRE
	,FV.LOCATION_DESC_LEVEL13
	,FV.LE_LEVEL6_DESC
	,(select load_date from load_dt_cte) as load_dt
	,fre.RQSTN_ID
	,FV.LOGIN
	,FV.LE_LEVEL1_DESC
	,FV.CC_LEVEL3_DESC
	,FV.CC_LEVEL5_DESC
	,FV.COST_CENTER_OWNER 
	,FV.site_cc_level1_value
	,FV.site_cc_level2_value
	,FV.site_cc_level3_value
	,FV.site_cc_level4_value
	,FV.site_cc_level5_value
	,FV.site_cc_level6_value
	,FV.site_cc_level7_value
	,FV.site_CC_LEVEL1_DESC 
	,FV.site_CC_LEVEL2_DESC 
	,FV.site_CC_LEVEL3_DESC 
	,FV.site_CC_LEVEL4_DESC 
	,FV.site_CC_LEVEL5_DESC 
	,FV.site_CC_LEVEL6_DESC 
	,FV.site_CC_LEVEL7_DESC 
	,FV.FUNCTIONAL_AREA_DESC
	,'Total Gilead' AS company_level1_val
    ,'Total Gilead' AS company_level1_desc
	,FV.COMPANY AS company_level2_val
    /*,case when FV.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS company_level2_val */
	,FV.COMPANY AS company_level2_desc
    /*,case when FV.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS company_level2_desc */
	 ,fes_r.reason_for_leaving
	 ,FV.CC_OWNER_LEVEL1_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL2_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL3_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL4_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL5_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL6_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL7_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL8_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL9_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL10_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL11_EMP_FULL_NAME
	 ,FV.CC_OWNER_LEVEL1_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL2_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL3_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL4_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL5_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL6_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL7_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL8_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL9_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL10_EMP_LOGIN
	 ,FV.CC_OWNER_LEVEL11_EMP_LOGIN
	 ,CC_LEVEL8_DESC
	 ,CC_LEVEL8_VALUE
	 ,FV.PREVIOUS_CC_LEVEL1_DESC
	 ,FV.Previous_cc_level1_value
	 ,FV.PREVIOUS_CC_LEVEL2_DESC
	 ,FV.Previous_cc_level2_value
	 ,FV.PREVIOUS_CC_LEVEL3_DESC
	 ,FV.Previous_cc_level3_value
	 ,FV.PREVIOUS_CC_LEVEL4_DESC
	 ,FV.Previous_cc_level4_value
	 ,FV.PREVIOUS_CC_LEVEL5_DESC
	 ,FV.Previous_cc_level5_value
	 ,FV.PREVIOUS_CC_LEVEL6_DESC
	 ,FV.Previous_cc_level6_value 
	 ,FV.PREVIOUS_CC_LEVEL7_DESC
	 ,FV.Previous_cc_level7_value
	 ,FV.PREVIOUS_CC_LEVEL8_DESC
	 ,FV.Previous_cc_level8_value
	 ,CASE WHEN FV.SALARY_ANNL=0 THEN fjes_sal.home_salary_annl ELSE NVL(FV.SALARY_ANNL,fjes_sal.home_salary_annl) END AS SALARY_ANNL
	 ,'[Coming Soon]' AS Previous_Assigned_HR_Business_Partner
	 ,FV.PREVIOUS_COST_CENTER_OWNER
	 ,FV.prev_le_level6_val
	 ,FV.prev_le_level6_desc
	 ,FV.LEVEL13_VAL	AS LOCATION_LEVEL13_VAL
	 ,FV.PREVIOUS_LOCATION_CODE_LEVEL13
	 ,FV.PREVIOUS_LOCATION_DESC_LEVEL13
	 ,FV.role_change_dt
	 ,FV.NEXT_TERMINATION_DATE
	 ,FV.PREVIOUS_LOCATION_DESC_LEVEL2
	 ,FV.PREVIOUS_LOCATION_CODE_LEVEL2
	 ,FV.TERMINATION_DT
	 ,FV.TERMINATION_DT9 
	 ,FV.TERMINATION_DT8 
	 ,FV.TERMINATION_DT7 
	 ,FV.TERMINATION_DT6 
	 ,FV.TERMINATION_DT5 
	 ,FV.TERMINATION_DT4 
	 ,FV.TERMINATION_DT3 
	 ,FV.TERMINATION_DT2 
	 ,FV.TERMINATION_DT1
	 ,FV.LAST_REHIRE_DATE10
	 ,FV.LAST_REHIRE_DATE9 
	 ,FV.LAST_REHIRE_DATE8 
	 ,FV.LAST_REHIRE_DATE7 
	 ,FV.LAST_REHIRE_DATE6 
	 ,FV.LAST_REHIRE_DATE5 
	 ,FV.LAST_REHIRE_DATE4 
	 ,FV.LAST_REHIRE_DATE3 
	 ,FV.LAST_REHIRE_DATE2 
	 ,FV.LAST_REHIRE_DATE1
	 ,FV.LAST_JOB_CHANGE_DATE1 
	 ,FV.LAST_JOB_CHANGE_DATE2 
	 ,FV.LAST_JOB_CHANGE_DATE3 
	 ,FV.LAST_JOB_CHANGE_DATE4 
	 ,FV.LAST_JOB_CHANGE_DATE5 
	 ,FV.LAST_JOB_CHANGE_DATE6 
	 ,FV.LAST_JOB_CHANGE_DATE7 
	 ,FV.LAST_JOB_CHANGE_DATE8 
	 ,FV.LAST_JOB_CHANGE_DATE9 
	 ,FV.LAST_JOB_CHANGE_DATE10
	 ,FV.Movement_Date
	 ,FV.HIRE_EVENT_IND
	 ,FV.MOST_RECENT_TERMINATION_DT
	 ,FV.MOST_RECENT_NEW_ROLE_DT
	 ,FV.PERF_BAND_DESC
	 ,FV.PREVIOUS_PERF_BAND_DESC
	 ,FV.EFFECTIVE_START_DT
	 ,FV.EFFECTIVE_END_DT
	 ,FV.MOST_RECENT_HIRE_DT
	 ,(select max(x.movement_date) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(FV.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=FV.worker_key 
		and x.change_event_type!='SNAPSHOT'
		and FV.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Movement Date"
		
	 ,(select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(FV.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=FV.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and FV.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Advancement Date"
	 ,FV.ORIG_HIRE_DT
	 ,FV.EMP_HIRE_DT
	 ,FV.ACQ_COMP_NAME
	 ,FV.WORKER_SUBTYPE
	 ,(select max(TERMINATION_CATEGORY) from gna_load_schema.fact_job_events_denormalized x 
		where x.worker_key=FV.worker_key 
		and x.term_event_ind  =1
		and (FV.next_termination_date=to_date(x.event_dt_key,'YYYYMMDD')  
		   or dateadd(day,1,FV.next_termination_date)= to_date(x.event_dt_key,'YYYYMMDD'))
		) AS "Next Termination Category"
	 ,FV.JS_HIRE_DT
	 ,FV.OFFR_ACPT_DT
	 ,CASE WHEN fre.rqstn_key IS NOT NULL THEN fre.x_custom
            ELSE fre1.x_custom
        END AS "Candidate Type"
	 ,FV.WRKFC_EVENT_CATEGORY
	 ,cast(FV.ANNUAL_BONUS_TARGET_AMOUNT as decimal(20,3)) AS "Individual Bonus Target"
	 ,FV.INTL_ASSGN_KEY
	 ,FV.PAYLINE_CODE
	 ,FV.ACTUAL_BONUS_COMPANY_SHARE
	 ,FV.ACTUAL_BONUS_INDIVIDUAL_SHARE
	 ,FV.event_seq
	 ,FE.key_countributor
	 ,FV.RESCIND_STATUS
	 ,FV.TALENT_ACQUISITION_HR_EXCEPTION
	 ,FV.CC_CHANGE_IND
	 ,FV.position_change_ind
	 ,FV.job_change_ind
	 ,FV.supervisor_change_ind
	 ,FV.location_change_ind
	 ,CASE WHEN FV.position_change_ind = 0 THEN  FV.POSITION_ID 	ELSE FV.PREVIOUS_POSITION_ID 	END AS "Previous Position ID (Movement Detailed)"
	 ,CASE WHEN FV.position_change_ind = 0 THEN  FV.POSITION_DESC	ELSE FV.PREVIOUS_POSITION_DESC	END AS "Previous Position Desc (Movement Detailed)"
	 ,CASE WHEN (case when FV.grade_change_ind=1 and FV.pay_grade_code = FV.PREV_PAY_GRADE_CODE then 0 else FV.grade_change_ind end) = 0    THEN  FV.PAY_GRADE_CODE		ELSE FV.PREV_PAY_GRADE_CODE		END AS "Previous Pay Grade (Movement Detailed)"
     ,CASE WHEN (case when FV.grade_change_ind=1 and FV.pay_grade_code = FV.PREV_PAY_GRADE_CODE then 0 else FV.grade_change_ind end) = 0    THEN  FV.PAY_GRADE_GROUP	ELSE FV.PREV_PAY_GRADE_GROUP	END AS "Previous Pay Group (Movement Detailed)"
	 ,CASE WHEN FV.job_change_ind = 0      THEN  FV.JOB_CODE		ELSE FV.previous_job_code		END AS "Previous Job Code(Movement Detailed)"
	 ,CASE WHEN FV.job_change_ind = 0      THEN  FV.JOB_FAMILY_DESC	ELSE FV.previous_Job_family		END AS "Previous Job Family(Movement Detailed)"
	 ,CASE WHEN FV.job_change_ind = 0      THEN  FV.JOB_DESC		ELSE FV.previous_job_title		END AS "Previous Job Title (Movement Detailed)"
	 ,CASE WHEN FV.job_change_ind = 0      THEN  FV.Job_Exempt		ELSE FV.prev_job_exempt_flg 	END AS "Previous Job Exempt(Movement Detailed)"
	 
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.SUPERVISOR_ID		ELSE FV.previous_supervisor_id 	 END AS "Previous Supervisor ID(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.SUPERVISOR_NAME		ELSE FV.previous_supervisor_name END AS "Previous Supervisor Name(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.current_level1_emp_full_name	ELSE FV.Previous_LEVEL1_EMP_FULL_NAME END AS "Previous Supervisory Org Current Level 1 Full Name(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.current_level2_emp_full_name	ELSE FV.Previous_LEVEL2_EMP_FULL_NAME END AS "Previous Supervisory Org Current Level 2 Full Name(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.current_level3_emp_full_name	ELSE FV.Previous_LEVEL3_EMP_FULL_NAME END AS "Previous Supervisory Org Current Level 3 Full Name(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.current_level4_emp_full_name	ELSE FV.Previous_LEVEL4_EMP_FULL_NAME END AS "Previous Supervisory Org Current Level 4 Full Name(Movement Detailed)"
	 ,CASE WHEN FV.SUPERVISOR_CHANGE_IND = 0  THEN  FV.current_level5_emp_full_name	ELSE FV.Previous_LEVEL5_EMP_FULL_NAME END AS "Previous Supervisory Org Current Level 5 Full Name(Movement Detailed)"

	 ,CASE WHEN FV.cc_change_ind = 0  THEN  FV.CC_NODEVAL 		ELSE FV.Previous_Cost_Center_ID   END AS "Previous Cost Center ID(Movement Detailed)"
	 ,CASE WHEN FV.cc_change_ind = 0  THEN  FV.CC_NODENAME	    ELSE FV.Previous_Cost_Center_Name END AS "Previous Cost Center Name(Movement Detailed)"
	 ,CASE WHEN FV.cc_change_ind = 0  THEN  FV.cc_level4_value	ELSE FV.Previous_cc_level4_value 	END AS "Previous Cost Center Level 4 Code(Movement Detailed)"
	 ,CASE WHEN FV.cc_change_ind = 0  THEN  FV.CC_LEVEL4_DESC	ELSE FV.PREVIOUS_CC_LEVEL4_DESC 	END AS "Previous Cost Center Level 4 Name(Movement Detailed)"
	 
	 ,CASE WHEN FV.location_change_ind = 0  THEN  FV.LOCATION_CODE_LEVEL2	ELSE FV.PREV_LOCATION_CODE_LEVEL2 END AS "Previous Geographic Location Level 2 Code(Movement Detailed)"
	 ,CASE WHEN FV.location_change_ind = 0  THEN  FV.LEVEL2_DESC_NO_MGR		ELSE FV.Prev_Geo_Loc_Lvl_2_Name END AS "Previous Geographic Location Level 2 Name(Movement Detailed)"
	 ,CASE WHEN FV.MOVEMENT_IND = 0  		THEN  FV.ATTR_MISC_DESC			ELSE FV.PREVIOUS_COUNTRY_NAME 	END AS "Previous Country Name(Movement Detailed)"
	 ,CASE WHEN FV.location_change_ind = 0  THEN  FV.LOCATION_DESC_LEVEL13	ELSE FV.Previous_Location_Name  END AS "Previous Location Name(Movement Detailed)"
 	 ,CASE WHEN FV.cc_change_ind = 0 THEN FV.COST_CENTER_OWNER ELSE FV.PREVIOUS_COST_CENTER_OWNER END AS "Previous Cost Center Owner(Movement Detailed)"
	 --,CASE WHEN FV.cc_change_ind = 0 THEN FV.CC_OWNER ELSE FV.PREV_CC_OWNER END AS "Previous Cost Center Owner(Movement Detailed)"
	 ,CASE WHEN FV.LE_CHANGE_IND = 0 THEN FV.le_level5_val  ELSE FV.prev_le_level5_val  END AS "Previous Legal Entity ID(Movement Detailed)"
	 ,CASE WHEN FV.LE_CHANGE_IND = 0 THEN FV.LE_LEVEL5_DESC ELSE FV.PREV_LE_LEVEL5_DESC END AS "Previous Legal Entity Name(Movement Detailed)"
	 ,FV.WRKFC_EVENT_REASON_NAME	
     ,FV.WRKFC_BUSINESS_PROCESS
	 ,FV.PROM_EVENT_IND
	 ,case when FV.BUSINESS_TITLE='' then JOB_DESC else NVL(FV.BUSINESS_TITLE,FV.JOB_DESC) END AS BUSINESS_JOB_TITLE 
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.current_level1_emp_login,''),'|'),NVL(FV.current_level2_emp_login,'')),'|'), NVL(FV.current_level3_emp_login,'')),'|'),NVL(FV.current_level4_emp_login,'')),'|'),NVL(FV.current_level5_emp_login,'')),'|'),NVL(FV.current_level6_emp_login,'')),'|'),NVL(FV.current_level7_emp_login,'')),'|'),NVL(FV.current_level8_emp_login,'')),'|'),NVL(FV.current_level9_emp_login,'')),'|'),NVL(FV.current_level10_emp_login,'')),'|'),NVL(FV.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.product_value1,''),'|'),NVL(FV.product_value2,'')),'|'),NVL(FV.product_value3,'')),'|'),NVL(FV.product_value4,'')),'|'), NVL(FV.product_value5,'')),'|')) as PRODUCT_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.LOCATION_CODE_LEVEL1,''),'|'),NVL(FV.LOCATION_CODE_LEVEL2,'')),'|'), NVL(FV.LOCATION_CODE_LEVEL3,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL4,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL5,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL6,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL7,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL8,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL9,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL10,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL11,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL12,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL13,'')),'|')) as LOCATION_HIER_LIST 
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.cc_level1_value,''),'|'),NVL(FV.cc_level2_value,'')),'|'),NVL(FV.cc_level3_value,'')),'|'),NVL(FV.cc_level4_value,'')),'|'), NVL(FV.cc_level5_value,'')),'|'),NVL(FV.cc_level6_value,'')),'|'),NVL(FV.cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.le_level1_val,''),'|'),NVL(FV.le_level2_val,'')),'|'),NVL(FV.le_level3_val,'')),'|'),NVL(FV.le_level4_val,'')),'|'), NVL(FV.le_level5_val,'')),'|'),NVL(FV.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.site_cc_level1_value,''),'|'),NVL(FV.site_cc_level2_value,'')),'|'),NVL(FV.site_cc_level3_value,'')),'|'),NVL(FV.site_cc_level4_value,'')),'|'), NVL(FV.site_cc_level5_value,'')),'|'),NVL(FV.site_cc_level6_value,'')),'|'),NVL(FV.site_cc_level7_value,'')),'|')) as COST_CENTER_SITE_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.CC_OWNER_LEVEL1_EMP_LOGIN,''),'|'),NVL(FV.CC_OWNER_LEVEL2_EMP_LOGIN,'')),'|'), NVL(FV.CC_OWNER_LEVEL3_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL4_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL5_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL6_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL7_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL8_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL9_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL10_EMP_LOGIN,'')),'|'),NVL(FV.CC_OWNER_LEVEL11_EMP_LOGIN,'')),'|')) as COST_CENTER_OWNER_HIER_LIST 
	 ,FV.FACT_LOC_CURR_CODE
	 ,FV.COST_CENTER_OWNER_ID
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_LEVEL1_EMP_LOGIN,''),'|'),NVL(FV.PREVIOUS_LEVEL2_EMP_LOGIN,'')),'|'), NVL(FV.PREVIOUS_LEVEL3_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL4_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL5_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL6_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL7_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL8_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL9_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL10_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_LEVEL11_EMP_LOGIN,'')),'|')) as previous_supervisor_hier_list 
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_PRODUCT_VALUE1,''),'|'),NVL(FV.PREVIOUS_PRODUCT_VALUE2,'')),'|'),NVL(FV.PREVIOUS_PRODUCT_VALUE3,'')),'|'),NVL(FV.PREVIOUS_PRODUCT_VALUE4,'')),'|'), NVL(FV.PREVIOUS_PRODUCT_VALUE5,'')),'|')) as PREVIOUS_PRODUCT_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL1,''),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL2,'')),'|'), NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL3,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL4,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL5,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL6,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL7,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL8,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL9,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL10,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL11,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL12,'')),'|'),NVL(FV.PREVIOUS_LOCATION_CODE_LEVEL13,'')),'|')) as PREVIOUS_LOCATION_HIER_LIST 
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_CC_LEVEL1_VALUE,''),'|'),NVL(FV.PREVIOUS_CC_LEVEL2_VALUE,'')),'|'),NVL(FV.PREVIOUS_CC_LEVEL3_VALUE,'')),'|'),NVL(FV.PREVIOUS_CC_LEVEL4_VALUE,'')),'|'), NVL(FV.PREVIOUS_CC_LEVEL5_VALUE,'')),'|'),NVL(FV.PREVIOUS_CC_LEVEL6_VALUE,'')),'|'),NVL(FV.PREVIOUS_CC_LEVEL7_VALUE,'')),'|')) as PREVIOUS_COST_CENTER_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREV_LE_LEVEL1_VAL,''),'|'),NVL(FV.PREV_LE_LEVEL2_VAL,'')),'|'),NVL(FV.PREV_LE_LEVEL3_VAL,'')),'|'),NVL(FV.PREV_LE_LEVEL4_VAL,'')),'|'), NVL(FV.PREV_LE_LEVEL5_VAL,'')),'|'),NVL(FV.PREV_LE_LEVEL6_VAL,'')),'|')) as PREVIOUS_LEGAL_ENTITY_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_SITE_CC_LEVEL1_VALUE,''),'|'),NVL(FV.PREVIOUS_SITE_CC_LEVEL2_VALUE,'')),'|'),NVL(FV.PREVIOUS_SITE_CC_LEVEL3_VALUE,'')),'|'),NVL(FV.PREVIOUS_SITE_CC_LEVEL4_VALUE,'')),'|'), NVL(FV.PREVIOUS_SITE_CC_LEVEL5_VALUE,'')),'|'),NVL(FV.PREVIOUS_SITE_CC_LEVEL6_VALUE,'')),'|'),NVL(FV.PREVIOUS_SITE_CC_LEVEL7_VALUE,'')),'|')) as PREVIOUS_COST_CENTER_SITE_HIER_LIST
	 ,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.PREVIOUS_CC_OWNER_LEVEL1_EMP_LOGIN,''),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL2_EMP_LOGIN,'')),'|'), NVL(FV.PREVIOUS_CC_OWNER_LEVEL3_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL4_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL5_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL6_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL7_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL8_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL9_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL10_EMP_LOGIN,'')),'|'),NVL(FV.PREVIOUS_CC_OWNER_LEVEL11_EMP_LOGIN,'')),'|')) as PREVIOUS_COST_CENTER_OWNER_HIER_LIST 
	 ,FV.role_name_access_list_previous
	 ,FV.PREVIOUS_FUNCTIONAL_AREA_DESC
	 ,FV.PREVIOUS_COMPANY
	 ,FV.DEPT_CHANGE_IND
	 ,CASE WHEN FV.cc_change_ind = 0 THEN FV.COST_CENTER_OWNER_ID ELSE FV.PREVIOUS_COST_CENTER_OWNER_ID END AS "Previous Cost Center Owner ID(Movement Detailed)"
	 
	FROM gna_load_schema.fact_job_events_denormalized FV
	
	left join (select fesd.worker_key , 
					  listagg( distinct dtt.theme_level1,' | ') theme_level1 , 
					  listagg( distinct dtt.theme_level2,' | ') theme_level2 , 
					  listagg( distinct dtt.theme_level3 ,' | ') theme_level3,
					  listagg( distinct concat(concat(dtt.theme_level1,': '),dtt.theme_level2),' | ') as Exit_Survey_Comment_Themes
				from 
				gna_load_schema.fact_employee_survey_denormalized fesd 
				left join 
				gna_load_schema.dim_worker_term_themes dwtt 
				on fesd.worker_key = dwtt.worker_key 
				left join 
				gna_load_schema.dim_term_theme dtt 
				on dwtt.theme_key = dtt.theme_key 
				group by fesd.worker_key 
			) THEME on FV.worker_key = THEME.worker_key	
			
	left join (select fesd.worker_key,listagg( distinct fesd.survey_resp_comments,' ; ') exit_survey_resp_comments
			FROM  gna_load_schema.fact_employee_survey_denormalized fesd 
			where fesd.survey_ques_long_descr in ('What could have been done differently to have kept you at Gilead?',
												  'What could have been done differently to have kept you at Gilead (including Kite)?')
			group by fesd.worker_key 
			)fesd on FV.worker_key =fesd.worker_key 
			
	 LEFT JOIN ( SELECT ldrs.source_type_name, fact_rcrtmnt_events.start_dt_wid, fact_rcrtmnt_events.end_dt_wid, fact_rcrtmnt_events.worker_key, fact_rcrtmnt_events.rqstn_key, fact_rcrtmnt_events.rqstn_id, fact_rcrtmnt_events.hire_dt, fact_rcrtmnt_events.rqstn_filled_dt, fact_rcrtmnt_events.event_class, ldrs.x_custom
   FROM gna_load_schema.fact_rcrtmnt_events, gna_load_schema.lnk_dim_rcrtmnt_source ldrs
  WHERE ldrs.dim_rcrtmnt_source_key = fact_rcrtmnt_events.rcrtmnt_source_key AND fact_rcrtmnt_events.hire_dt >= fact_rcrtmnt_events.effective_start_dt AND fact_rcrtmnt_events.hire_dt <= fact_rcrtmnt_events.effective_end_dt) fre1 ON fre1.worker_key = fv.worker_key AND fre1.rqstn_key = fv.rqstn_key AND fre1.event_class::text = 'APPLICANT'::character varying::text AND fv.event_dt_key >= fre1.start_dt_wid AND fv.event_dt_key <= fre1.end_dt_wid
   LEFT JOIN ( SELECT ldrs.source_type_name, fact_rcrtmnt_events.start_dt_wid, fact_rcrtmnt_events.end_dt_wid, fact_rcrtmnt_events.worker_key, fact_rcrtmnt_events.rqstn_key, fact_rcrtmnt_events.rqstn_id, fact_rcrtmnt_events.hire_dt, fact_rcrtmnt_events.rqstn_filled_dt, fact_rcrtmnt_events.event_class, ldrs.x_custom
   FROM gna_load_schema.fact_rcrtmnt_events, gna_load_schema.lnk_dim_rcrtmnt_source ldrs
  WHERE ldrs.dim_rcrtmnt_source_key = fact_rcrtmnt_events.rcrtmnt_source_key AND 'now'::character varying::timestamp without time zone >= fact_rcrtmnt_events.effective_start_dt AND 'now'::character varying::timestamp without time zone <= fact_rcrtmnt_events.effective_end_dt) fre ON fre.worker_key = fv.worker_key AND fre.rqstn_key = fv.rqstn_key AND fre.event_class::text = 'JOB_RQSTN'::character varying::text AND fv.event_dt_key >= fre.start_dt_wid AND fv.event_dt_key <= fre.end_dt_wid
	 
	left join (select distinct FV.worker_key,FV.event_dt_key,FV.TERM_EVENT_IND,FV.MAX_SEQ_IND,main.survey_key,main.reason_for_leaving 
	  			from gna_load_schema.fact_job_events_snapshot FV 
					join gna_load_schema.fact_employee_survey main
					  on FV.worker_key=main.worker_key  
             		JOIN gna_load_schema.dim_survey_questions surv
               		  ON main.survey_key = surv.survey_key
                where 	survey_ques_long_descr like '%Please indicate the main reason for leaving%'
               		and DATEDIFF(day,to_date(main.survey_submitted_date,'YYYY-MM-DD'),TO_DATE(FV.EVENT_DT_key,'YYYYMMDD')) between -180 and 180
					--and (TO_DATE(FV.EVENT_DT_key,'YYYYMMDD') - 30)<=  main.survey_submitted_date and main.survey_submitted_date<=TO_DATE(FV.EVENT_DT_key,'YYYYMMDD')
					and FV.TERM_EVENT_IND=1
					--and FV.MAX_SEQ_IND=1
					--and main.survey_key  in (2051,2229)
					and survey_resp_status not in ('Rescinded')
				)fes_r 
				on FV.worker_key=fes_r.worker_key
			   and FV.event_dt_key=fes_r.event_dt_key
			   and FV.TERM_EVENT_IND= fes_r.TERM_EVENT_IND
			   and FV.MAX_SEQ_IND = fes_r.MAX_SEQ_IND
			   
	left join (select
				fj.worker_key,fj.event_dt_key,coalesce(key_cont,'N') as key_countributor
				,row_number() over(partition by fj.worker_key,fj.EVENT_DT_KEY order by fj.event_seq desc) r_num
				from gna_load_schema.fact_job_events_snapshot fj
				left join (	select 
								worker_key 
								,date_trunc('year',FE.grant_date) as start_key_con_grant_date
								,add_months(date_trunc('year',grant_date),12) as end_key_con_grant_date
								,grant_date 
								,class
								,'Y' as key_cont --10 aug
							from  gna_load_schema.FACT_EQUITY FE  
							where FE.class='KEY'
							) fe
				on fj.worker_key =fe.worker_key 
	   		   and to_date(fj.event_dt_key,'YYYYMMDD') >= start_key_con_grant_date
	   		   and to_date(fj.event_dt_key,'YYYYMMDD') < end_key_con_grant_date
	) FE
	ON FE.WORKER_KEY=FV.WORKER_KEY 
   AND FE.r_num=1
   and FE.event_dt_key = FV.event_dt_key
   
	left join (select 
				worker_key ,event_dt_key ,max(salary_annl) as home_salary_annl
			   from gna_load_schema.fact_job_events_snapshot fjes
			   where assignment_num=0 group by worker_key ,event_dt_key
	) fjes_sal 
	ON FV.worker_key   = fjes_sal.worker_key
   AND FV.event_dt_key = fjes_sal.event_dt_key
   
where to_date(fv.event_dt_key,'YYYYMMDD')<=(select load_date from load_dt_cte)	   
;	                   	       	           


-- pap_view_schema.fact_awards_denormalized_vw source;

create view pap_view_schema.fact_awards_denormalized_vw as 
select 
	concat(concat(',',role_name_access_list),',') AS role_name_access_list 
	,FAD.PAY_GRADE_CODE		AS "Pay Grade"
	,FAD.PAY_GRADE_GROUP	AS "Pay Grade Group"
	,FAD.PLAN_ID
	,FAD.PLAN_NAME			AS "Plan Name"
	,FAD.ACTUAL_AWD_AMT		AS "Award Amount"
	,FAD.ACTUAL_AWD_UNIT
	,to_date(FAD.Calendar_dt,'YYYY-MM-DD') AS Calendar_dt
	,FAD.AGE_BAND_DESC		AS "Age Group"
	,FAD.SEX_DESC 			AS "Gender"
	,FAD.GENDER_IDENTITY	AS "Gender Identity"
	,FAD.worker_key
	
	,FAD.cc_level1_value
	,FAD.cc_level2_value
	,FAD.cc_level3_value
	,FAD.cc_level4_value
	,FAD.cc_level5_value
	,FAD.cc_level6_value
	,FAD.cc_level7_value
	
	,FAD.current_level1_emp_full_name
	,FAD.current_level2_emp_full_name
	,FAD.current_level3_emp_full_name
	,FAD.current_level4_emp_full_name
	,FAD.current_level5_emp_full_name
	,FAD.current_level6_emp_full_name
	,FAD.current_level7_emp_full_name
	,FAD.current_level8_emp_full_name
	,FAD.current_level9_emp_full_name
	,FAD.current_level10_emp_full_name
	,FAD.current_level11_emp_full_name
	
	,FAD.location_code_level1
	,FAD.location_code_level10
	,FAD.location_code_level11
	,FAD.location_code_level12
	,FAD.location_code_level13
	,FAD.location_code_level2
	,FAD.location_code_level3
	,FAD.location_code_level4
	,FAD.location_code_level5
	,FAD.location_code_level6
	,FAD.location_code_level7
	,FAD.location_code_level8
	,FAD.location_code_level9
	
	,FAD.le_level1_val
	,FAD.le_level2_val
	,FAD.le_level3_val
	,FAD.le_level4_val
	,FAD.le_level5_val
	,FAD.le_level6_val
	
	,FAD.product_value1
	,FAD.product_value2
	,FAD.product_value3
	,FAD.product_value4
	,FAD.product_value5
	
	,FAD.current_level1_emp_login
	,FAD.current_level2_emp_login
	,FAD.current_level3_emp_login
	,FAD.current_level4_emp_login
	,FAD.current_level5_emp_login
	,FAD.current_level6_emp_login
	,FAD.current_level7_emp_login
	,FAD.current_level8_emp_login
	,FAD.current_level9_emp_login
	,FAD.current_level10_emp_login
	,FAD.current_level11_emp_login
	,FAD.WORKER_ID 						AS "Worker ID"
	,FAD.WORKER_PREF_NAME 				AS "Worker Name"
	,fjed.Current_Employment_Status 	AS "Current Employement Status"	
	,fjed.employment_status AS "Employement Status"
	,FAD.award_dt_key 					AS "Award Date" 
	,FAD.CURRENCY_CD 					AS "Award Currency"
	,FAD.AWARD_AMOUNT_US 				AS "Award Amount (USD)"
	,FAD.JOB_CODE 						AS "Job Code"
	,FAD.JOB_DESC 						AS "Job Title"
	,FAD.JOB_FAMILY_DESC 				AS "Job Family"
	,FAD.CC_NODEVAL 					AS "Cost Center ID"
	,FAD.CC_NODENAME				 	AS "Cost Center Name"
	,FAD.SUPERVISOR_ID   				AS "Supervisor ID"
	,FAD.SUPERVISOR_NAME 				AS "Supervisor Name"
	,fjed.MOST_RECENT_HIRE_DT			AS "Most Recent Hire Date"
	,TO_DATE(FAD.ORIG_HIRE_DT,'YYYY-MM-DD')					AS "Original Hire Date"
	,TO_DATE(FAD.CONTINUOUS_SERVICE_DT,'YYYY-MM-DD')		AS "Continuous Service Date"
	--,CAST(NULL AS VARCHAR(300)) 							AS "Length of Service Group"
	--,TO_DATE(FAD.MOST_RECENT_ADVANCEMENT_DATE,'YYYY-MM-DD') AS "Most Recent Advancement Date"
	,TO_DATE(FAD.Most_Recent_Termination_Date,'YYYY-MM-DD')	AS "Most Recent Termination Date"
	,FAD.LEVEL2_DESC_NO_MGR				AS "Geographic Location Level 2 Name"
	,FAD.ATTR_MISC_DESC					AS "Country Name"
	,FAD.LOCATION_DESC_LEVEL13 			AS "Location Name"
	
	,fjed.PERF_BAND_DESC 				AS "{Most Recent Year before Prompted End Date's} Year-End Rating"
	,fjed.PREVIOUS_PERF_BAND_DESC 		AS "{Second-Most Recent Year before Prompted End Date's} Year-End Rating"
	,CASE WHEN fjed.TALENT_QUADRANT ='' 
			THEN NULL 
		  ELSE 	fjed.TALENT_QUADRANT 
	 END 			AS "{Most Recent Year before Prompted End Date's} Talent Coordinate"
	,CASE WHEN fjed.TALENT_QUADRANT_PRV ='' 
			THEN NULL 
		  ELSE 	fjed.TALENT_QUADRANT_PRV 
	 END 			AS "{Second-Most Recent Year before Prompted End Date's} Talent Coordinate"
	,FAD.ETHNICITY_US 					AS "Ethnicity (US)"
	,FAD.hiest_degree 					AS "Highest Education Degree Description"
	,FAD.SCHOOL_NAME 					AS "Highest Degree School Name"
	,FAD.cc_level2_value				AS "Cost Center Level 2 Code"
	,FAD.Cost_center_level2_desc		AS "Cost Center Level 2 Name"
	,FAD.CURRENT_LEVEL1_EMP_FULL_NAME	AS "Supervisory Org Current Level 1 Full Name"
	,FAD.CURRENT_LEVEL2_EMP_FULL_NAME   AS "Supervisory Org Current Level 2 Full Name"
	,FAD.CURRENT_LEVEL3_EMP_FULL_NAME   AS "Supervisory Org Current Level 3 Full Name"
	,FAD.CURRENT_LEVEL4_EMP_FULL_NAME   AS "Supervisory Org Current Level 4 Full Name"
	,FAD.CURRENT_LEVEL5_EMP_FULL_NAME   AS "Supervisory Org Current Level 5 Full Name"
	--number of awards??
	,fjed.DISABILITY_STATUS_US			AS DISABILITY_STATUS
	,fjed.VETERAN_STATUS_US				AS VETERAN_STATUS_DESC
	,FAD.CC_NODENAME
    ,FAD.CC_NODEVAL
	,FAD.EMPLOYEE_CAT_CODE
	,FAD.EMPLOYEE_CAT_DESC
	,FAD.SEXUAL_ORIENTATION				AS "Sexual Orientation (US)"
	,FAD.job_req_tag					AS "Job Req Tag"
	,TO_DATE(FAD.JS_HIRE_DT,'YYYY-MM-DD') AS JS_HIRE_DT
	,FAD.OFFICE_TYPE					AS "Office Type"
	,FAD.EXCH_RATE
	,FAD.FULLTIME_PARTTIME				AS "Full Time Flag"
	,TO_DATE(FAD.BIRTH_DT,'YYYY-MM-DD') AS BIRTH_DT
	,FAD.AWARD_AMOUNT_US				AS "Award Amount US"
	,FAD.PAYLINE_CODE
	,FAD.LOC_CURR_CODE
	,FAD.SECTOR_POSITION
	,'Total Gilead' AS company_level1_val
    ,'Total Gilead' AS company_level1_desc
	,FAD.COMPANY AS company_level2_val
    /*,case when FAD.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS company_level2_val*/
	,FAD.COMPANY AS company_level2_desc
    /*,case when FAD.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS company_level2_desc*/
	,(select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(fjed.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=fjed.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and fjed.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Advancement Date"
	,FAD.SUP_HIER_KEY
	,FAD.PROD_HIER_KEY
	,FAD.CC_HIER_KEY
	,FAD.LE_HIER_KEY
	,FAD.LOC_HIER_KEY
	,FAD.CC_LEVEL1_DESC
	,FAD.CC_LEVEL2_DESC
	,FAD.CC_LEVEL3_DESC
	,FAD.CC_LEVEL4_DESC
	,FAD.CC_LEVEL5_DESC
	,FAD.CC_LEVEL6_DESC
	,FAD.CC_LEVEL7_DESC
	,FAD.le_level1_desc
	,FAD.le_level2_desc
	,FAD.le_level3_desc
	,FAD.le_level4_desc
	,FAD.le_level5_desc
	,FAD.PRODUCT_DESC_LEVEL1
	,FAD.PRODUCT_DESC_LEVEL2
	,FAD.PRODUCT_DESC_LEVEL3
	,FAD.PRODUCT_DESC_LEVEL4
	,FAD.PRODUCT_DESC_LEVEL5
	,FAD.LOCATION_DESC_LEVEL1
	,FAD.LOCATION_DESC_LEVEL2
	,FAD.LOCATION_DESC_LEVEL3
	,FAD.LOCATION_DESC_LEVEL4
	,FAD.LOCATION_DESC_LEVEL5
	,FAD.LOCATION_DESC_LEVEL6
	,FAD.LOCATION_DESC_LEVEL7
	,FAD.LOCATION_DESC_LEVEL8
	,FAD.LOCATION_DESC_LEVEL9
	,FAD.LOCATION_DESC_LEVEL10
	,FAD.LOCATION_DESC_LEVEL11
	,FAD.LOCATION_DESC_LEVEL12
	,FAD.LOCATION_DESC_LEVEL13
	,FAD.job_req_tag1
	,FAD.job_req_tag2
	,FAD.job_req_tag3
	,FAD.job_req_tag4
	,FAD.job_req_tag5
	,FAD.job_req_tag6
	,FAD.job_req_tag7
	,FAD.job_req_tag8
	,FAD.job_req_tag9
	,FAD.job_req_tag10
	,fjed.SALARY_ANNL	AS "Total Base Pay (Annualized)"
	,fjed.FTE
	,fjed.start_dt_wid
	,fjed.end_dt_wid
	,fjed.headcount
	,fjed.max_seq_ind
	,fjed.SUPERVISOR_EVT_IND
	,fjed.employee_sub_cat_desc AS "Worker Type Sub Category Description"
	,fjed.event_dt_key
	,fjed.SNAPSHOT_MONTH_END_IND
	,fjed.PEOPLE_MANAGER_FLG
	,FAD.LOGIN
	,FAD.TERMINATION_DT1   AS "Termination Effective Date"
	,FAD.CONTRACT_START_DATE
	,FAD.CONTRACT_END_DATE
	,FAD.EMPLOYEE_CAT_CODE AS "Worker Type"
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FAD.current_level1_emp_login,''),'|'),NVL(FAD.current_level2_emp_login,'')),'|'), NVL(FAD.current_level3_emp_login,'')),'|'),NVL(FAD.current_level4_emp_login,'')),'|'),NVL(FAD.current_level5_emp_login,'')),'|'),NVL(FAD.current_level6_emp_login,'')),'|'),NVL(FAD.current_level7_emp_login,'')),'|'),NVL(FAD.current_level8_emp_login,'')),'|'),NVL(FAD.current_level9_emp_login,'')),'|'),NVL(FAD.current_level10_emp_login,'')),'|'),NVL(FAD.current_level11_emp_login,'')),'|')) as SUPERVISOR_HIER_LIST 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FAD.product_value1,''),'|'),NVL(FAD.product_value2,'')),'|'),NVL(FAD.product_value3,'')),'|'),NVL(FAD.product_value4,'')),'|'), NVL(FAD.product_value5,'')),'|')) AS PRODUCT_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FAD.location_code_level1,''),'|'),NVL(FAD.location_code_level2,'')),'|'), NVL(FAD.location_code_level3,'')),'|'),NVL(FAD.location_code_level4,'')),'|'),NVL(FAD.location_code_level5,'')),'|'),NVL(FAD.location_code_level6,'')),'|'),NVL(FAD.location_code_level7,'')),'|'),NVL(FAD.location_code_level8,'')),'|'),NVL(FAD.location_code_level9,'')),'|'),NVL(FAD.location_code_level10,'')),'|'),NVL(FAD.location_code_level11,'')),'|'),NVL(FAD.location_code_level12,'')),'|'),NVL(FAD.location_code_level13,'')),'|')) as LOCATION_HIER_LIST 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FAD.cc_level1_value,''),'|'),NVL(FAD.cc_level2_value,'')),'|'),NVL(FAD.cc_level3_value,'')),'|'),NVL(FAD.cc_level4_value,'')),'|'), NVL(FAD.cc_level5_value,'')),'|'),NVL(FAD.cc_level6_value,'')),'|'),NVL(FAD.cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FAD.le_level1_val,''),'|'),NVL(FAD.le_level2_val,'')),'|'),NVL(FAD.le_level3_val,'')),'|'),NVL(FAD.le_level4_val,'')),'|'), NVL(FAD.le_level5_val,'')),'|'),NVL(FAD.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST

FROM gna_load_schema.fact_awards_denormalized FAD

	left join (select distinct fjed.employment_status,fjed.worker_key,fjed.PERF_BAND_DESC,fjed.PREVIOUS_PERF_BAND_DESC,fjed.TALENT_QUADRANT,Current_Employment_Status
							   ,fjed.TALENT_QUADRANT_PRV,fjed.event_dt_key,fjed.effective_start_dt ,fjed.effective_end_dt,MOST_RECENT_HIRE_DT
							   ,VETERAN_STATUS_US,DISABILITY_STATUS_US,fjed.SALARY_ANNL,FTE,EXCH_RATE,start_dt_wid,end_dt_wid,headcount
							   ,max_seq_ind,SUPERVISOR_EVT_IND,employee_sub_cat_desc,SNAPSHOT_MONTH_END_IND,PEOPLE_MANAGER_FLG
							   ,row_number() over(partition by worker_key,event_dt_key order by event_seq desc) as latest
                from gna_load_schema.fact_job_events_denormalized fjed                                              
                where  headcount =1 and max_seq_ind =1 and assignment_num=0 
               )fjed 
              on fjed.worker_key =FAD.worker_key 
             AND fjed.latest = 1
  WHERE fad.award_dt_key >= fjed.start_dt_wid AND fad.award_dt_key <= fjed.end_dt_wid
;





-- pap_view_schema.fact_employee_survey_denormalized_vw source;



create or replace VIEW pap_view_schema.fact_employee_survey_denormalized_vw as  
					 	
select 
   'User Data' AS data_source_flag
   ,concat(concat(',',ESD.role_name_access_list),',') AS role_name_access_list --Defect 1438
   ,ESD.calendar_dt
   ,ESD.cc_hier_key
   ,ESD.le_hier_key
   ,ESD.loc_hier_key
   ,ESD.SURVEY_TYPE 		 			AS survey
   ,ESD.survey_ques_long_descr		
   ,ESD.survey_rating 		 			AS "Survey Response"
   --,CASE WHEN ESD.survey_resp_status ='Completed' THEN ESD.survey_rating ELSE NULL AS "Survey Response"
   ,CASE WHEN ESD.survey_resp_status ='C' THEN 'Completed'
		 WHEN ESD.survey_resp_status ='I' THEN 'In Progress'
		 ELSE ESD.survey_resp_status 
	 END 	AS "Survey Response Status"
   ,ESD.attr_misc_desc       			AS "Country Name"
   ,ESD.DISABILITY_STATUS_US 			as  "Disability Status (US)"
   ,case when ESD.pay_grade_group = 'Unspecified' then fjed1.pay_grade_group else ESD.pay_grade_group end	AS "Pay Grade Group"
   --,ESD.pay_grade_group      			AS "Pay Grade Group"
   ,ESD.sex_desc             			as gender
   ,ESD.gender_identity		
   ,ESD.hiest_degree            		AS "Highest Education Degree Description"
   ,ESD.school_name						AS "Highest Degree School Name"   		
   --,ESD.talent_quadrant_1 				AS "{Most Recent Year before Prompted End Date's} Talent Coordinate"
   ,CASE WHEN fje.TALENT_QUADRANT='' 
			THEN NULL 
		 ELSE fje.TALENT_QUADRANT	
	END					   AS "{Most Recent Year before Prompted End Date's} Talent Coordinate"
   ,ESD.sexual_orientation		
   --,fje.PERF_BAND_DESC					AS "{Most Recent Year before Prompted End Date's} Year-End Rating"
   ,fje.PERF_BAND_DESC 								AS "{Most Recent Year before Prompted End Date's} Year-End Rating"
   ,coalesce(
		case when ESD.ATTR_MISC_DESC = 'United States' 
			then coalesce(T71173.DEMOGRAPHIC_DESC_CUSTOM,ESD.VETERAN_STATUS_US,'Unspecified') 
		else 'Non-US' 
		end ,ESD.VETERAN_STATUS_US,'Unspecified'
		) 									AS "Veteran Status (US)"
   ,ESD.ETHNICITY_US 						AS "Ethnicity (US)"
   ,ESD.source_id
   ,ESD.worker_key
   ,ESD.kcs_short_item
   ,ESD.survey_ques_short_descr
   ,ESD.current_level1_emp_full_name
   ,ESD.current_level2_emp_full_name
   ,ESD.current_level3_emp_full_name
   ,ESD.current_level4_emp_full_name
   ,ESD.current_level5_emp_full_name
   ,ESD.current_level6_emp_full_name
   ,ESD.current_level7_emp_full_name
   ,ESD.current_level8_emp_full_name
   ,ESD.current_level9_emp_full_name
   ,ESD.current_level10_emp_full_name
   ,ESD.current_level11_emp_full_name
   ,ESD.level1_val
   ,ESD.level2_val
   ,ESD.level3_val
   ,ESD.level4_val
   ,ESD.level5_val
   ,ESD.level6_val
   ,ESD.level7_val
   ,ESD.level8_val
   ,ESD.level9_val
   ,ESD.level10_val
   ,ESD.level11_val
   ,ESD.level12_val
   ,ESD.level13_val
   ,ESD.cc_level1_val
   ,ESD.cc_level2_val
   ,ESD.cc_level3_val
   ,ESD.cc_level4_val
   ,ESD.cc_level5_val
   ,ESD.cc_level6_val
   ,ESD.cc_level7_val
   ,ESD.le_level1_val
   ,ESD.le_level2_val
   ,ESD.le_level3_val
   ,ESD.le_level4_val
   ,ESD.le_level5_val
   ,ESD.le_level6_val
   ,ESD.current_level1_emp_login
   ,ESD.current_level2_emp_login
   ,ESD.current_level3_emp_login
   ,ESD.current_level4_emp_login
   ,ESD.current_level5_emp_login
   ,ESD.current_level6_emp_login
   ,ESD.current_level7_emp_login
   ,ESD.current_level8_emp_login
   ,ESD.current_level9_emp_login
   ,ESD.current_level10_emp_login
   ,ESD.current_level11_emp_login
   ,CASE WHEN LENGTH(ESD.SURVEY_RATING) = 1 and ASCII(ESD.SURVEY_RATING) IN (49, 50, 51) THEN 'Low Score'
		 WHEN LENGTH(ESD.SURVEY_RATING) = 1 and ASCII(ESD.SURVEY_RATING) IN (52,53) THEN 'High Score' 
	END AS Score	
	,CASE  WHEN  ESD.SURVEY_TYPE in ('G9_90_DAY','90 Day On-Boarding Questionnaire','90 Day Onboarding Survey') THEN '90 Days Survey' 
		  WHEN  ESD.SURVEY_TYPE  in ('G9_9_MONTH','9 Month Integration Questionnaire','9 Month Integration Survey') THEN '9 Months Survey' 
		  WHEN  ESD.SURVEY_TYPE  in ('G9_EXIT','Exit Questionnaire','Exit Survey Questionnaire') 				   THEN 'Exit Survey' 
		  WHEN  ESD.SURVEY_TYPE  in ('Recruitment Survey: Hiring Manager (July 2021)','Recruitment Survey: Hiring Manager') 		   
			THEN 'Hiring Manager Survey' 
		  WHEN  ESD.SURVEY_TYPE  in ('Recruitment Survey: New Hire') 				   THEN 'New Hire Survey'  
		  else  ESD.SURVEY_TYPE  END AS "Survey Type Detail"		  
    ,CASE WHEN ESD.SURVEY_TYPE IN ('1 Year Integration Survey', '9 Month Integration Questionnaire', 'G9_9_MONTH','9 Month Integration Survey'
								  ,'G9_90_DAY','90 Day On-Boarding Questionnaire','90 Day Onboarding Survey') THEN 'Onboarding Survey' 
         WHEN ESD.SURVEY_TYPE IN ('Exit Questionnaire', 'G9_EXIT', 'Exit Survey Questionnaire') THEN 'Exit Survey' 
    END AS "Survey Type Summary"	
   ,COUNT(DISTINCT 
				CASE  
					WHEN 
						CASE 
						WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e012f1a2322836024dbc0%') 
							THEN CONCAT ('How was the experience with your Recruiter? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
						WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e01e2740a22836024d4c0%')
							THEN CONCAT ('Overall, how satisfied were you with the recruitment process? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
						WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e0124d85522836024e2c0%') 
							THEN CONCAT ('How was your Interview experience? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
						WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e019d06d04dcc602488c1%')
							THEN CONCAT ('Overall, how satisfied were you with the recruitment process? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
						WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e014995264ecc60248fc1%')
							THEN CONCAT ('How satisfied were you with your Recruiter? - ',  ESD.SURVEY_QUES_LONG_DESCR ) 
						ELSE ESD.SURVEY_QUES_LONG_DESCR 
						END IN ('I would recommend Gilead (including Kite) as a great place to work.','I would recommend Gilead as a great place to work.')                  
						AND 							
						CASE 
						WHEN ESD.SURVEY_TYPE IN ('90 Day On-Boarding Questionnaire', 'G9_90_DAY') 
							THEN '90 Days Survey' 
						WHEN ESD.SURVEY_TYPE IN ('9 Month Integration Questionnaire', 'G9_9_MONTH') 
							THEN '9 Months Survey' 
						WHEN ESD.SURVEY_TYPE IN ('Exit Questionnaire', 'G9_EXIT' , 'Exit Survey Questionnaire') 
							THEN 'Exit Survey' 
						WHEN ESD.SURVEY_TYPE IN ('Recruitment Survey: Hiring Manager') 
							THEN 'Hiring Manager Survey' 
						WHEN ESD.SURVEY_TYPE IN ('Recruitment Survey: New Hire') 
							THEN 'New Hire Survey' 
						ELSE 
							ESD.SURVEY_TYPE 
						END IN ('1 Year Integration Survey', '9 Month Integration Questionnaire', 'G9_9_MONTH', '9 Month Integration Survey', '9 Months Survey','Exit Survey') 
						-- AND CAST ( DBMS_LOB.*/SUBSTRING (ESD.SURVEY_RATING, 3880, 1) AS VARCHAR (4000) ) IN (1, 2, 3)						
						AND 						
						LENGTH(ESD.SURVEY_RATING) = 1 and ASCII(ESD.SURVEY_RATING) IN (49, 50, 51) 
                    THEN 
						ESD.worker_key 
                END ) AS Denominator 
    ,COUNT (DISTINCT 
				CASE 
                    WHEN 
						CASE 
                        WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e012f1a2322836024dbc0%') 
							THEN CONCAT ('How was the experience with your Recruiter? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
                        WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e01e2740a22836024d4c0%')
							THEN CONCAT ('Overall, how satisfied were you with the recruitment process? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
                        WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e0124d85522836024e2c0%') 
							THEN CONCAT ('How was your Interview experience? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
                        WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e019d06d04dcc602488c1%')
							THEN CONCAT ('Overall, how satisfied were you with the recruitment process? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
                        WHEN ESD.SOURCE_ID LIKE ('%3c2708ae675e014995264ecc60248fc1%')
							THEN CONCAT ('How satisfied were you with your Recruiter? - ', ESD.SURVEY_QUES_LONG_DESCR ) 
                        ELSE ESD.SURVEY_QUES_LONG_DESCR 
                        END IN ('I would recommend Gilead (including Kite) as a great place to work.', 'I would recommend Gilead as a great place to work.')                         
						AND 						
						CASE 
                        WHEN ESD.SURVEY_TYPE IN ('90 Day On-Boarding Questionnaire', 'G9_90_DAY') 
							THEN '90 Days Survey' 
                        WHEN ESD.SURVEY_TYPE IN ('9 Month Integration Questionnaire', 'G9_9_MONTH') 
							THEN  '9 Months Survey' 
                        WHEN ESD.SURVEY_TYPE IN ('Exit Questionnaire', 'G9_EXIT' , 'Exit Survey Questionnaire') 
							THEN 'Exit Survey' 
                        WHEN ESD.SURVEY_TYPE IN ('Recruitment Survey: Hiring Manager') 
							THEN 'Hiring Manager Survey' 
                        WHEN ESD.SURVEY_TYPE IN ('Recruitment Survey: New Hire') 
							THEN 'New Hire Survey' 
                        ELSE ESD.SURVEY_TYPE 
                        END IN ('1 Year Integration Survey', '9 Month Integration Questionnaire', 'G9_9_MONTH', '9 Month Integration Survey', '9 Months Survey','Exit Survey') 
                            -- AND CAST ( /*DBMS_LOB.*/SUBSTRING (ESD.SURVEY_RATING,  3880, 1) AS VARCHAR (4000)  ) IN  (4, 5) 
						AND 						
						LENGTH(ESD.SURVEY_RATING) = 1 and ASCII(ESD.SURVEY_RATING) IN (52,53)
                    THEN 
                        ESD.worker_key 
                END ) AS numerator 
	,ESD.WORKER_ID 									AS "Worker ID"
	,ESD.Worker_Name 								AS "Worker Name"
	,case when ESD.PAY_GRADE_CODE = 'Unspecified' then 	fjed1.PAY_GRADE_CODE	else esd.PAY_GRADE_CODE end	AS "Pay Grade"
	,ESD.job_desc 									AS "Job Title"
	,ESD.JOB_FAMILY_DESC 							AS "Job Family"
	,ESD.CC_NODEVAL 								AS "Cost Center ID"
	,ESD.CC_NODENAME								AS "Cost Center Name"
	,ESD.SUPERVISOR_ID 								AS "Supervisor ID"
	,ESD.SUPERVISOR_NAME 							AS "Supervisor Name"
	--,TO_DATE(ESD.EMP_HIRE_DT ,'YYYY-MM-DD')			AS "Most Recent Hire Date"
	,ESD.MOST_RECENT_HIRE_DT						AS "Most Recent Hire Date"
	--,TO_DATE(ESD.TERMINATION_DT,'YYYY-MM-DD') 		AS "Most Recent Termination Date"
	,ESD.MOST_RECENT_TERMINATION_DT					AS "Most Recent Termination Date"
	,ESD.LEVEL2_DESC_NO_MGR 						AS "Geographic Location Level 2 Name"
	,ESD.LEVEL13_DESC 								AS "Location Name"
	,NVL(fje.OFFICE_TYPE,ESD.OFFICE_TYPE)			AS "Office Type"
	,INITCAP(REPLACE(COALESCE(T71169.time_type,ESD.FULLTIME_PARTTIME,'Unspecified'),'_',' ')) AS "Full Time Flag"																											 
	--,ESD.FULLTIME_PARTTIME							AS "Full Time Flag"
	,ESD.FULL_TIME_FLG 								
	,ESD.employee_sub_cat_desc						AS "Worker Type Sub Category Description"
	--,TO_DATE(ESD.MOST_RECENT_ADVANCEMENT_DATE,'YYYY-MM-DD')	AS "Most Recent Advancement Date"
	,ESD.AGE_BAND_DESC								AS "Age Group"
	,ESD.Age 										AS "Age (Years)"
	--,TALENT_QUADRANT_2 						AS "{Second-Most Recent Year before Prompted End Date's} Talent Coordinate"
	--,PERF_BAND2 								AS "{Second-Most Recent Year before Prompted End Date's} Year-End Rating"
	,CASE WHEN fje.TALENT_QUADRANT_PRV='' 
			THEN NULL 
		  ELSE fje.TALENT_QUADRANT_PRV	
	 END				AS "{Second-Most Recent Year before Prompted End Date's} Talent Coordinate"
	,fje.PREVIOUS_PERF_BAND_DESC					AS "{Second-Most Recent Year before Prompted End Date's} Year-End Rating"
	,ESD.ASSIGNED_HR_BUSINESS_PARTNER 				AS "Assigned HR Business Partner"
	,ESD.COST_CENTER_LEVEL2_NAME	
	,TO_DATE(ESD.survey_submitted_date,'YYYY-MM-DD') AS "Submitted Date"
	,ESD.SURVEY_QUESTION 							 AS "Survey Questions"
	,CASE WHEN QUANTATIVE_SURVEY IN ('1','2','3','4','5') THEN QUANTATIVE_SURVEY 
	 WHEN QUANTATIVE_SURVEY = ('1 - Below Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1)
	 WHEN QUANTATIVE_SURVEY = ('2 - Needs Improvement') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 WHEN QUANTATIVE_SURVEY = ('3 - Met Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 WHEN QUANTATIVE_SURVEY = ('4 - Exceeded Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 else null
	 end 			 	 					     	AS "Survey Numerical Response"
	,case when left(trim(ESD.survey_resp_comments),1) in ('-','/','=')
		  then ''''||ESD.survey_resp_comments 
	      else  ESD.survey_resp_comments end 		AS "Survey Response Comments - Start"
	,case when left(trim(ESD.survey_resp_comments),1) in ('-','/','=')
		  then ''''||ESD.survey_resp_comments 
	      else  ESD.survey_resp_comments end 		AS "Survey Response Comments - End"
	,CAST(NULL AS VARCHAR(300)) 				 	AS "Survey Version"
	,THEME.theme_level1							 	AS "Theme Level 1"
	,THEME.theme_level2							 	AS "Theme Level 2"
	,case when fje.job_exempt_flg = 1 THEN 'Exempt' 
		  ELSE 'Non Exempt' END 					AS "Job Exempt"
	,fjed1.EVENT_CATEGORY							AS "Termination Type"
	,fjed1.EVENT_REASON_NAME 						AS "Termination Reason"
	,TO_DATE(ESD.CONTINUOUS_SERVICE_DT,'YYYY-MM-DD') AS "Continuous Service Date"
	,ESD.REHIRE_FLAG								 AS "Rehire Flag"
	,CAST(null as VARCHAR(100))					 AS "Length of Service Group"
	,CAST(null as VARCHAR(100))					 AS "Length of Service (Years)"
	,CASE  WHEN fje.PAYROLL_STATUS  = 0 AND fje.LEAVE_STATUS = 0 THEN 'Active' 
           WHEN fje.PAYROLL_STATUS  = 0 AND fje.LEAVE_STATUS = 1 THEN 'Leave with Pay' 
           WHEN fje.PAYROLL_STATUS  = 1 AND fje.LEAVE_STATUS = 1 THEN 'Leave of Absence' 
     ELSE 'Inactive' END 				 		 AS "Employment Status"
	,ESD.job_req_tag							 as "Job Req Tag"										 
	,ESD.candidate_type							 as "Candidate Type"
	,ESD.cc_level2_val							 as "cost_center_level_2_code"
	,ESD.job_code								 as "Job_id"
	,ESD.le_level1_val							 as "legal_entity"
	,ESD.employee_cat_code
--	,ESD.level1_desc
	,ESD.CC_NODEVAL 
    ,ESD.CC_NODENAME
	,ESD.SOURCE_TYPE_NAME 						AS "Candidate Source"
	,THEME.Exit_Survey_Comment_Themes			AS "Theme Level"
	,fje.ORIG_PERF_RATING 
	,fje.ORIG_PERF_RATING_PRV 
	,fje.TALENT_QUADRANT 
	,fje.TALENT_QUADRANT_PRV
	,fje.PAYROLL_STATUS 
	,fje.LEAVE_STATUS
	,ESD.CC_LEVEL1_DESC
	,ESD.CC_LEVEL2_DESC
	,ESD.CC_LEVEL3_DESC
	,ESD.CC_LEVEL4_DESC
	,ESD.CC_LEVEL5_DESC
	,ESD.CC_LEVEL6_DESC
	,ESD.CC_LEVEL7_DESC
	,ESD.LE_LEVEL1_DESC
	,ESD.LE_LEVEL2_DESC
	,ESD.LE_LEVEL3_DESC
	,ESD.LE_LEVEL4_DESC
	,ESD.LE_LEVEL5_DESC
	,ESD.LE_LEVEL6_DESC
	,ESD.BIRTH_DT
	,TO_DATE(ESD.ORIG_HIRE_DT,'YYYY-MM-DD') AS ORIG_HIRE_DT
	,NVL(
		case when ESD.ATTR_MISC_DESC = 'United States' 
			then NVL(T71173.DEMOGRAPHIC_DESC_CUSTOM,'Unspecified') 
		else 'Non-US' 
		end ,'Unspecified'
		) AS VETERAN_STATUS_US
	,ESD.DISABILITY_STATUS_US
	,ESD.ETHNICITY_US
	,NULL AS "Recruitment Source"
	,NULL AS "Total Applicants"
	,NULL AS "Total Diverse Applicants"
	,ESD.LEVEL1_DESC
	,ESD.LEVEL2_DESC
	,ESD.LEVEL3_DESC
	,ESD.LEVEL4_DESC
	,ESD.LEVEL5_DESC
	,ESD.LEVEL6_DESC
	,ESD.LEVEL7_DESC
	,ESD.LEVEL8_DESC
	,ESD.LEVEL9_DESC
	,ESD.LEVEL10_DESC
	,ESD.LEVEL11_DESC
	,ESD.LEVEL12_DESC
	,ESD.LEVEL13_DESC
	,ESD.job_req_tag1
	,ESD.job_req_tag2
	,ESD.job_req_tag3
	,ESD.job_req_tag4
	,ESD.job_req_tag5
	,ESD.job_req_tag6
	,ESD.job_req_tag7
	,ESD.job_req_tag8
	,ESD.job_req_tag9
	,ESD.job_req_tag10
	,INITCAP(REPLACE(NVL(T71169.time_type,'Unspecified'),'_',' '))	as FULLTIME_PARTTIME																										  
	--,ESD.FULLTIME_PARTTIME
	,ESD.sup_hier_key
	--,ESD.loc_hier_key
	--,ESD.cc_hier_key
	--,ESD.le_hier_key
	,ESD.primary_sourcer1   
	,ESD.primary_sourcer1_name
	,ESD.JOB_REQ_ID																					  
	,ESD.TIME_TO_FILL
	,ESD.TIME_TO_HIRE
	,TO_DATE(ESD.OFFR_ACPT_DT,'YYYY-MM-DD') 	AS OFFR_ACPT_DT
	,TO_DATE(ESD.RQSTN_OPENED_DT,'YYYY-MM-DD') 	AS RQSTN_OPENED_DT
	,TO_DATE(ESD.JS_HIRE_DT,'YYYY-MM-DD') 		AS JS_HIRE_DT
	,TO_DATE(ESD.RQSTN_OFF_HOLD_DT,'YYYY-MM-DD') AS RQSTN_OFF_HOLD_DT
	,TO_DATE(ESD.RQSTN_HOLD_DT,'YYYY-MM-DD') 	AS RQSTN_HOLD_DT
	,ESD.PRODUCT_DESC_1
	,ESD.PRODUCT_DESC_2
	,ESD.PRODUCT_DESC_3
	,ESD.PRODUCT_DESC_4
	,ESD.PRODUCT_DESC_5
	,ESD.product_value1
	,ESD.product_value2
	,ESD.product_value3
	,ESD.product_value4
	,ESD.product_value5
	,ESD.POSITION_TYPE
	,ESD.QUANTATIVE_SURVEY
	,ESD.QUALITATIVE_SURVEY
	,CASE WHEN QUANTATIVE_SURVEY IN ('1','2','3','4','5') THEN QUANTATIVE_SURVEY 
	 WHEN QUANTATIVE_SURVEY = ('1 - Below Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1)
	 WHEN QUANTATIVE_SURVEY = ('2 - Needs Improvement') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 WHEN QUANTATIVE_SURVEY = ('3 - Met Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 WHEN QUANTATIVE_SURVEY = ('4 - Exceeded Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',1) 
	 else null
	 end as survey_numeric_response
	,CASE WHEN QUANTATIVE_SURVEY IN ('1','2','3','4','5') THEN QUANTATIVE_SURVEY 
	 WHEN QUANTATIVE_SURVEY = ('1 - Below Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',2)
	 WHEN QUANTATIVE_SURVEY = ('2 - Needs Improvement') THEN split_part(QUANTATIVE_SURVEY,'-',2)
	 WHEN QUANTATIVE_SURVEY = ('3 - Met Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',2)
	 WHEN QUANTATIVE_SURVEY = ('4 - Exceeded Expectations') THEN split_part(QUANTATIVE_SURVEY,'-',2)
	 else null
	 end as survey_response
	,ESD.PROD_HIER_KEY
	,TO_DATE(ESD.survey_sent_date,'YYYY-MM-DD') AS survey_sent_date
	,ESD.RQSTN_KEY
	,ESD.LOGIN
	,'Total Gilead' AS company_level1_val
    ,'Total Gilead' AS company_level1_desc
	,ESD.COMPANY AS company_level2_val
    /*,case when ESD.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS company_level2_val */
	,ESD.COMPANY AS company_level2_desc
    /*,case when ESD.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS company_level2_desc */
	,ESD.rank1
	,fje.GRADE_INCREASE_FLG
	,fje.EVENT_DT_KEY
	/*,CASE WHEN QUANTATIVE_SURVEY IN ('1','1 - Below Expectations') 		THEN 'Strongly disagree'
		  WHEN QUANTATIVE_SURVEY IN ('2','2 - Needs Improvement') 		THEN 'Disagree'
		  WHEN QUANTATIVE_SURVEY IN ('3','3 - Met Expectations') 		THEN 'Neither agree nor disagree' 
		  WHEN QUANTATIVE_SURVEY IN ('4','4 - Exceeded Expectations') 	THEN 'Agree'
		  WHEN QUANTATIVE_SURVEY IN ('5') 								THEN 'Strongly agree' 
	 else 
		case when left(trim(ESD.SURVEY_RATING),1) in ('-','/','=') then ''''||ESD.SURVEY_RATING
			 else  ESD.SURVEY_RATING end
	 end as survey_response_agree_diagree */
	,sresp_agg.survey_response_agree_diagree
	,fje.PERF_BAND_DESC
	,fje.PREVIOUS_PERF_BAND_DESC
	,ESD.MOST_RECENT_HIRE_DT
    ,ESD.MOST_RECENT_TERMINATION_DT  
	,(select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(fje.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=fje.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and fje.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Advancement Date"	
	,ESD.MANAGER_ID 
	,ESD.MANAGER_NAME 
	,fje_m.PAY_GRADE_CODE	AS MANAGER_PAY_GRADE
	,fje_m.PAY_GRADE_GROUP  AS MANAGER_PAY_GRADE_GROUP
	,fje_m.JOB_DESC 		AS MANAGER_JOB_TITLE 
	,fje_m.JOB_FAMILY_DESC 	AS MANAGER_JOB_FAMILY_DESC 
	,fje_m.Job_Exempt 		AS MANAGER_JOB_EXEMPT 
	,fje_m.CC_NODEVAL	    AS MANAGER_COST_CENTER_ID --for defect fix 1367
	,fje_m.CC_NODENAME	    AS MANAGER_COST_CENTER_NAME --for defect fix  1367
	,fje_m.SUPERVISOR_ID 	AS MANAGER_SUPERVISOR_ID				
	,fje_m.SUPERVISOR_NAME  AS MANAGER_SUPERVISOR_NAME
	,ESD.MANAGER_WORKER_KEY 
	,fje_m.MOST_RECENT_HIRE_DT 			AS MANAGER_MOST_RECENT_HIRE_DT
	,fje_m.MOST_RECENT_TERMINATION_DT 	AS MANAGER_MOST_RECENT_TERMINATION_DT 
	,ESD.MANAGER_CONTINUOUS_SERVICE_DT 
	,fje_m.LEVEL2_DESC_NO_MGR			AS MANAGER_GEOGRAPHIC_LOCATION_LEVEL2_NAME
	,fje_m.ATTR_MISC_DESC				AS MANAGER_COUNTRY_NAME
	,fje_m.LOCATION_DESC_LEVEL13		AS MANAGER_LOCATION_NAME
	,NVL(fje_m.OFFICE_TYPE,ESD.MANAGER_OFFICE_TYPE)				    AS MANAGER_OFFICE_TYPE 
	,CASE WHEN fje_m.FULL_TIME_FLG = 'Y' THEN 'Full Time'
		  WHEN fje_m.FULL_TIME_FLG = 'N' THEN 'Part Time'
	      ELSE 'Unspecified'
	 END AS MANAGER_FULLTIME_PARTTIME
	,fje_m.employee_sub_cat_desc		AS  MANAGER_WORKER_TYPE_SUB_CAT_DESC	
	,(select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(fje_m.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=fje_m.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and fje_m.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Manager Most Recent Advancement Date"	
	,ESD.MANAGER_REHIRE_FLAG 
	,ESD.MANAGER_EMPLOYMENT_STATUS 
	,ESD.MANAGER_BIRTH_DT 
	,ESD.MANAGER_SEX_DESC 
	,ESD.MANAGER_ETHNICITY_US 
	--,fje_m.VETERAN_STATUS_US AS MANAGER_VETERAN_STATUS
	,NVL(fje_m.VETERAN_STATUS_US,ESD.MANAGER_VETERAN_STATUS)		AS MANAGER_VETERAN_STATUS
	,fje_m.DISABILITY_STATUS_US 	AS MANAGER_DISABILITY_STATUS
	,fje_m.HIEST_DEGREE				AS "Manager Highest Education Degree Description"
	,fje_m.SCHOOL_NAME				AS "Manager Highest Degree School Name"
	,fje_m.PERF_BAND_DESC			AS MANAGER_PERF_BAND_DESC
	,fje_m.PREVIOUS_PERF_BAND_DESC	AS MANAGER_PREVIOUS_PERF_BAND_DESC
	,fje_m.TALENT_QUADRANT			AS MANAGER_TALENT_QUADRANT
	,fje_m.TALENT_QUADRANT_PRV 		AS MANAGER_TALENT_QUADRANT_PRV
	,fje_m.ASSIGNED_HR_BUSINESS_PARTNER	 AS MANAGER_ASSIGNED_HR_BUSINESS_PARTNER
	,fje_m.cc_level2_value			AS MANAGER_COST_CENTER_LEVEL2_VALUE
	,fje_m.CC_LEVEL2_DESC			AS MANAGER_COST_CENTER_LEVEL2_DESC
	,fje_m.CURRENT_LEVEL1_EMP_FULL_NAME AS MANAGER_CURRENT_LEVEL1_EMP_FULL_NAME 
    ,fje_m.CURRENT_LEVEL2_EMP_FULL_NAME AS MANAGER_CURRENT_LEVEL2_EMP_FULL_NAME
    ,fje_m.CURRENT_LEVEL3_EMP_FULL_NAME AS MANAGER_CURRENT_LEVEL3_EMP_FULL_NAME
    ,fje_m.CURRENT_LEVEL4_EMP_FULL_NAME AS MANAGER_CURRENT_LEVEL4_EMP_FULL_NAME
    ,fje_m.CURRENT_LEVEL5_EMP_FULL_NAME AS MANAGER_CURRENT_LEVEL5_EMP_FULL_NAME
	,fje_m.job_req_tag1				AS MANAGER_JOB_REQ_TAG1
	,fje_m.job_req_tag2             AS MANAGER_JOB_REQ_TAG2
	,fje_m.job_req_tag3             AS MANAGER_JOB_REQ_TAG3
	,fje_m.job_req_tag4             AS MANAGER_JOB_REQ_TAG4
	,fje_m.job_req_tag5             AS MANAGER_JOB_REQ_TAG5
	,fje_m.job_req_tag6             AS MANAGER_JOB_REQ_TAG6
	,fje_m.job_req_tag7             AS MANAGER_JOB_REQ_TAG7
	,fje_m.job_req_tag8             AS MANAGER_JOB_REQ_TAG8
	,fje_m.job_req_tag9             AS MANAGER_JOB_REQ_TAG9
	,fje_m.job_req_tag10            AS MANAGER_JOB_REQ_TAG10
	,fje_m.TIME_TO_FILL				AS MANAGER_TIME_TO_FILL
	,fje_m.TIME_TO_HIRE				AS MANAGER_TIME_TO_HIRE
	,fje_m.JS_HIRE_DT				AS MANAGER_JS_HIRE_DT
	,fje_m.job_req_tag				AS MANAGER_JOB_REQ_TAG
	,fje_m.COMPANY 					AS manager_company_level2_val
	/*,case when fje_m.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS manager_company_level2_val */
	,fje_m.COMPANY 					AS manager_company_level2_desc
	/*,case when fje_m.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS manager_company_level2_desc*/
	,fje_m.LE_LEVEL2_DESC 			AS MANAGER_LE_LEVEL2_DESC
	,fje_m.SEXUAL_ORIENTATION		AS MANAGER_SEXUAL_ORIENTATION
	,fje_m.GENDER_IDENTITY			AS MANAGER_GENDER_IDENTITY
	,case  when fje_m.WORKER_SUBTYPE in ('Fixed_Term', 'Post_Doctoral', 'Regular') 
           then replace(fje_m.WORKER_SUBTYPE , '_' , ' ')
     end  AS MANAGER_POSITION_TYPE
	,fje.PEOPLE_MANAGER_FLG
	,fjed1.TERMINATION_CATEGORY
	,ESD.Survey_key
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(ESD.current_level1_emp_login,''),'|'),NVL(ESD.current_level2_emp_login,'')),'|'), NVL(ESD.current_level3_emp_login,'')),'|'),NVL(ESD.current_level4_emp_login,'')),'|'),NVL(ESD.current_level5_emp_login,'')),'|'),NVL(ESD.current_level6_emp_login,'')),'|'),NVL(ESD.current_level7_emp_login,'')),'|'),NVL(ESD.current_level8_emp_login,'')),'|'),NVL(ESD.current_level9_emp_login,'')),'|'),NVL(ESD.current_level10_emp_login,'')),'|'),NVL(ESD.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(ESD.product_value1,''),'|'),NVL(ESD.product_value2,'')),'|'),NVL(ESD.product_value3,'')),'|'),NVL(ESD.product_value4,'')),'|'), NVL(ESD.product_value5,'')),'|')) as PRODUCT_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(ESD.level1_val,''),'|'),NVL(ESD.level2_val,'')),'|'), NVL(ESD.level3_val,'')),'|'),NVL(ESD.level4_val,'')),'|'),NVL(ESD.level5_val,'')),'|'),NVL(ESD.level6_val,'')),'|'),NVL(ESD.level7_val,'')),'|'),NVL(ESD.level8_val,'')),'|'),NVL(ESD.level9_val,'')),'|'),NVL(ESD.level10_val,'')),'|'),NVL(ESD.level11_val,'')),'|'),NVL(ESD.level12_val,'')),'|'),NVL(ESD.level13_val,'')),'|')) as LOCATION_HIER_LIST 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(ESD.cc_level1_val,''),'|'),NVL(ESD.cc_level2_val,'')),'|'),NVL(ESD.cc_level3_val,'')),'|'),NVL(ESD.cc_level4_val,'')),'|'), NVL(ESD.cc_level5_val,'')),'|'),NVL(ESD.cc_level6_val,'')),'|'),NVL(ESD.cc_level7_val,'')),'|')) as COST_CENTER_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(ESD.le_level1_val,''),'|'),NVL(ESD.le_level2_val,'')),'|'),NVL(ESD.le_level3_val,'')),'|'),NVL(ESD.le_level4_val,'')),'|'), NVL(ESD.le_level5_val,'')),'|'),NVL(ESD.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
from 
	gna_load_schema.fact_employee_survey_denormalized ESD	
	left join (select fesd.worker_key , 
					  listagg( distinct dtt.theme_level1,'|') theme_level1 , 
					  listagg( distinct dtt.theme_level2,'|') theme_level2 , 
					  listagg( distinct dtt.theme_level3 ,'|') theme_level3,
					  listagg( distinct concat(concat(dtt.theme_level1,': '),dtt.theme_level2),' | ') as Exit_Survey_Comment_Themes
				from 
				gna_load_schema.fact_employee_survey_denormalized fesd 
				left join 
				gna_load_schema.dim_worker_term_themes dwtt 
				on fesd.worker_key = dwtt.worker_key 
				left join 
				gna_load_schema.dim_term_theme dtt 
				on dwtt.theme_key = dtt.theme_key 
				group by fesd.worker_key 
				) THEME 
			on ESD.worker_key = THEME.worker_key 
			and ESD.SURVEY_TYPE IN ('Exit Questionnaire', 'G9_EXIT', 'Exit Survey Questionnaire')		
	LEFT JOIN (select ORIG_PERF_RATING,PERF_BAND_DESC,ORIG_PERF_RATING_PRV,PREVIOUS_PERF_BAND_DESC,TALENT_QUADRANT,TALENT_QUADRANT_PRV,
					  PAYROLL_STATUS,LEAVE_STATUS,EFFECTIVE_START_DT,EFFECTIVE_END_DT,worker_key,GRADE_INCREASE_FLG ,EVENT_DT_KEY,MOST_RECENT_HIRE_DT,
					  veteran_sts_demographic_key,job_exempt_flg,PEOPLE_MANAGER_FLG,OFFICE_TYPE,RQSTN_KEY,POSITION_KEY
				from gna_load_schema.fact_job_events_denormalized                                                      
				where max_seq_ind = 1 and ASSIGNMENT_NUM = 0
				)fje
			on coalesce(ESD.survey_submitted_date,ESD.survey_sent_date) between fje.EFFECTIVE_START_DT and fje.EFFECTIVE_END_DT
			and fje.worker_key = ESD.worker_key	
	left join gna_load_schema.dim_position T71169 
		   on T71169.position_key =fje.position_key 											 									  
	left  JOIN (select distinct JOB_DESC,JOB_FAMILY_DESC,cc_level2_value,CC_LEVEL2_DESC,SUPERVISOR_ID,SUPERVISOR_NAME ,MOST_RECENT_HIRE_DT ,MOST_RECENT_TERMINATION_DT 
					  ,LEVEL2_DESC_NO_MGR,ATTR_MISC_DESC,LOCATION_DESC_LEVEL13,FULL_TIME_FLG,employee_sub_cat_desc,event_dt_key ,worker_key ,VETERAN_STATUS_US
					  ,DISABILITY_STATUS_US,HIEST_DEGREE,SCHOOL_NAME,PERF_BAND_DESC,PREVIOUS_PERF_BAND_DESC,TALENT_QUADRANT,TALENT_QUADRANT_PRV,ASSIGNED_HR_BUSINESS_PARTNER
					  ,CURRENT_LEVEL1_EMP_FULL_NAME ,CURRENT_LEVEL2_EMP_FULL_NAME ,CURRENT_LEVEL3_EMP_FULL_NAME,CURRENT_LEVEL4_EMP_FULL_NAME ,CURRENT_LEVEL5_EMP_FULL_NAME
					  ,job_req_tag1,job_req_tag2,job_req_tag3 ,job_req_tag4,job_req_tag5,job_req_tag6,job_req_tag7 ,job_req_tag8,job_req_tag9,job_req_tag10,TIME_TO_FILL
					  ,TIME_TO_HIRE,JS_HIRE_DT	,EFFECTIVE_START_DT,EFFECTIVE_END_DT,GRADE_INCREASE_FLG ,veteran_sts_demographic_key,Job_Exempt,PAY_GRADE_GROUP,WORKER_SUBTYPE
					  ,PAY_GRADE_CODE,job_req_tag,CC_NODEVAL,LE_LEVEL2_DESC,SEXUAL_ORIENTATION,GENDER_IDENTITY,OFFICE_TYPE,COMPANY,CC_NODENAME
				from gna_load_schema.fact_job_events_denormalized  
				where max_seq_ind = 1 and ASSIGNMENT_NUM = 0
				)fje_m
			on coalesce(ESD.survey_submitted_date,ESD.survey_sent_date) between fje_m.EFFECTIVE_START_DT and fje_m.EFFECTIVE_END_DT
			and fje_m.worker_key = ESD.MANAGER_WORKER_KEY 	
	LEFT JOIN gna_load_schema.DIM_EMP_DEMOGRAPHICS T71173
              ON T71173.EMP_DEMOGRAPHIC_KEY = fje.VETERAN_STS_DEMOGRAPHIC_KEY
              AND (T71173.DEMOGRAPHIC_TYPE IN ('Military Status', 'Unspecified', 'Veteran Status'))			
	/* left join (select worker_key , LENGTH_OF_SERVICE_GROUP, LENGTH_OF_SERVICE_YEARS, job_exempt_flg, start_dt_wid, end_dt_wid 
				from gna_load_schema.fact_job_events_denormalized 
				where max_seq_ind = 1 and headcount = 1
				) fjed
			on ESD.cal_date_key between fjed.start_dt_wid and fjed.end_dt_wid
			and ESD.worker_key = fjed.worker_key */	
	left join (select FV.worker_key,FV.event_dt_key,FV.TERM_EVENT_IND,FV.MAX_SEQ_IND,main.survey_key,
					  FV.pay_grade_group,FV.pay_grade_code,main.reason_for_leaving,main.survey_submitted_date,main.survey_rating ,
	  				  CASE  WHEN T71130.BUSINESS_PROCESS = 'Terminate Employee' THEN T71130.EVENT_REASON_NAME end as EVENT_REASON_NAME,
	  				  T71130.EVENT_CATEGORY,FV.TERMINATION_CATEGORY
	  			from(select worker_key,event_dt_key,TERM_EVENT_IND,MAX_SEQ_IND,TERMINATION_CATEGORY,WORKER_EVENT_TYPE_KEY
							,pay_grade_group,pay_grade_code 
	  					from gna_load_schema.fact_job_events_denormalized where TERM_EVENT_IND = 1 and max_seq_ind=1) FV 				
					join gna_load_schema.fact_employee_survey_denormalized main
					  on FV.worker_key=main.worker_key					  
               		 LEFT JOIN gna_load_schema.DIM_WRKFC_EVENT_TYPE T71130 
           			  ON T71130.WRKR_EVENT_TYPE_KEY = FV.WORKER_EVENT_TYPE_KEY               		
                where  
					DATEDIFF(day,main.MOST_RECENT_TERMINATION_DT,TO_DATE(FV.EVENT_DT_key,'YYYYMMDD')) between -1 and 1
					and FV.TERM_EVENT_IND=1
					--and FV.MAX_SEQ_IND=1
				)fjed1 on ESD.worker_key=fjed1.worker_key
					  and ESD.survey_submitted_date=fjed1.survey_submitted_date
				      and ESD.survey_key= fjed1.survey_key
				      and ESD.survey_rating= fjed1.survey_rating				  
	/*left join (select distinct worker_key , EVENT_CATEGORY, EVENT_REASON_NAME, termination_dt, start_dt_wid, end_dt_wid 
				from gna_load_schema.fact_job_events_denormalized fjed  
				where term_status_ind = 1 and max_seq_ind = 1 and termination_dt is not null
				) fjed1
			on ESD.worker_key = fjed1.worker_key 
			and --fesd.termination_dt = fjed1.termination_dt
			ESD.cal_date_key between fjed1.start_dt_wid and fjed1.end_dt_wid
			*/			
	left join (select ESD.worker_id ,ESD.survey_submitted_date ,ESD.survey_ques_long_descr, ESD.survey_type,
				listagg((CASE WHEN QUANTATIVE_SURVEY IN ('1','1 - Below Expectations') 		THEN 'Strongly disagree'
						WHEN QUANTATIVE_SURVEY IN ('2','2 - Needs Improvement') 			THEN 'Disagree'
						WHEN QUANTATIVE_SURVEY IN ('3','3 - Met Expectations') 				THEN 'Neither agree nor disagree' 
						WHEN QUANTATIVE_SURVEY IN ('4','4 - Exceeded Expectations') 		THEN 'Agree'
						WHEN QUANTATIVE_SURVEY IN ('5') 									THEN 'Strongly agree' 
					else 
						case when left(trim(ESD.SURVEY_RATING),1) in ('-','/','=') then ''''||ESD.SURVEY_RATING
						else  ESD.SURVEY_RATING end 
					end ),' | ') as survey_response_agree_diagree 
				from 
				gna_load_schema.fact_employee_survey_denormalized ESD
				group by esd.survey_type,ESD.worker_id ,ESD.survey_submitted_date ,ESD.survey_ques_long_descr
			)sresp_agg 
			on ESD.worker_id = sresp_agg.worker_id 
		   and ESD.survey_submitted_date = sresp_agg.survey_submitted_date 
		   and ESD.survey_ques_long_descr = sresp_agg.survey_ques_long_descr
		   and ESD.survey_type = sresp_agg.survey_type
group by 
	ESD.role_name_access_list
    ,ESD.Calendar_dt
    ,ESD.CC_HIER_KEY
    ,ESD.le_hier_key
    ,ESD.LOC_HIER_KEY
    ,ESD.SURVEY_TYPE
    ,ESD.survey_ques_long_descr
    ,ESD.SURVEY_RATING
    ,ESD.Survey_resp_status
    ,ESD.attr_misc_desc
    ,case when ESD.pay_grade_group = 'Unspecified' then fjed1.pay_grade_group else ESD.pay_grade_group end
    ,ESD.sex_desc
    ,ESD.gender_identity
    ,ESD.HIEST_DEGREE
    ,ESD.SCHOOL_NAME
    ,ESD.FULL_TIME_FLG
    ,ESD.TALENT_QUADRANT_1
    ,ESD.SEXUAL_ORIENTATION
    ,ESD.PERF_BAND1
    ,ESD.source_id
    ,ESD.worker_key
    ,ESD.kcs_short_item
    ,ESD.SURVEY_QUES_SHORT_DESCR
    ,ESD.current_level1_emp_full_name
    ,ESD.current_level2_emp_full_name
    ,ESD.current_level3_emp_full_name
    ,ESD.current_level4_emp_full_name
    ,ESD.current_level5_emp_full_name
    ,ESD.current_level6_emp_full_name
    ,ESD.current_level7_emp_full_name
    ,ESD.current_level8_emp_full_name
    ,ESD.current_level9_emp_full_name
    ,ESD.current_level10_emp_full_name
    ,ESD.current_level11_emp_full_name    
    ,ESD.level1_val
    ,ESD.level2_val
    ,ESD.level3_val
    ,ESD.level4_val
    ,ESD.level5_val
    ,ESD.level6_val
    ,ESD.level7_val
    ,ESD.level8_val
    ,ESD.level9_val
    ,ESD.level10_val
    ,ESD.level11_val
    ,ESD.level12_val
    ,ESD.level13_val    
    ,ESD.CC_LEVEL1_VAL
    ,ESD.CC_LEVEL2_VAL
    ,ESD.CC_LEVEL3_VAL
    ,ESD.CC_LEVEL4_VAL
    ,ESD.CC_LEVEL5_VAL
    ,ESD.CC_LEVEL6_VAL
    ,ESD.CC_LEVEL7_VAL
    ,ESD.le_level1_val
    ,ESD.le_level2_val
    ,ESD.le_level3_val
    ,ESD.le_level4_val
    ,ESD.le_level5_val
	,ESD.le_level6_val
    ,ESD.current_level1_emp_login
	,ESD.current_level2_emp_login
    ,ESD.current_level3_emp_login
    ,ESD.current_level4_emp_login
    ,ESD.current_level5_emp_login
    ,ESD.current_level6_emp_login
    ,ESD.current_level7_emp_login
    ,ESD.current_level8_emp_login
    ,ESD.current_level9_emp_login
    ,ESD.current_level10_emp_login
    ,ESD.current_level11_emp_login
	,ESD.WORKER_ID 							
	,ESD.Worker_Name 						
    ,case when ESD.PAY_GRADE_CODE = 'Unspecified' then 	fjed1.PAY_GRADE_CODE	else esd.PAY_GRADE_CODE end 					
    ,ESD.job_desc 							
    ,ESD.JOB_FAMILY_DESC 					
    ,ESD.DEPT_ID 							
    ,ESD.DEPT_NAME 							
    ,ESD.SUPERVISOR_ID 						
    ,ESD.SUPERVISOR_NAME 					
    ,ESD.EMP_HIRE_DT 						
    ,ESD.TERMINATION_DT 					
    ,ESD.LEVEL2_DESC_NO_MGR 				
    ,ESD.LEVEL13_VAL 							
    ,fje.OFFICE_TYPE
    ,ESD.employee_sub_cat_desc				
    ,ESD.MOST_RECENT_ADVANCEMENT_DATE		
    ,ESD.AGE_BAND_DESC						
    ,ESD.Age 								
    ,ESD.ASSIGNED_HR_BUSINESS_PARTNER 		
    ,ESD.COST_CENTER_LEVEL2_NAME	
    ,ESD.SURVEY_QUESTION	
    ,ESD.survey_submitted_date 				
    ,ESD.SURVEY_QUESTION 					
    ,ESD.survey_rating 		 			
    ,ESD.survey_resp_comments 
	,ESD.Employment_Status
	,ESD.job_req_tag					
	,ESD.candidate_type
	,ESD.cc_level2_val	
	,ESD.job_code		
	,ESD.le_level1_val
	,ESD.employee_cat_code
	,ESD.level1_desc
	,THEME.theme_level1
	,THEME.theme_level2
	,fje.job_exempt_flg
	,fjed1.EVENT_CATEGORY
	,fjed1.EVENT_REASON_NAME
	,ESD.CONTINUOUS_SERVICE_DT
	,ESD.REHIRE_FLAG
	,ESD.Employment_Status						
	,ESD.job_req_tag							
	,ESD.candidate_type							
	,ESD.cc_level2_val							
	,ESD.job_code								
	,ESD.le_level1_val							
	,ESD.employee_cat_code
	,ESD.level1_desc
	,ESD.CC_NODEVAL 
    ,ESD.CC_NODENAME
	,ESD.SOURCE_TYPE_NAME
	,THEME.Exit_Survey_Comment_Themes 
	,"Survey Type Detail"
	,"Survey Type Summary"
	,Score
	,"Veteran Status (US)"
	,"Ethnicity (US)"
	,fje.ORIG_PERF_RATING 
	,fje.ORIG_PERF_RATING_PRV 
	,fje.TALENT_QUADRANT 
	,fje.TALENT_QUADRANT_PRV
	,fje.PAYROLL_STATUS 
	,fje.LEAVE_STATUS
	,ESD.CC_LEVEL1_DESC
	,ESD.CC_LEVEL2_DESC
	,ESD.CC_LEVEL3_DESC
	,ESD.CC_LEVEL4_DESC
	,ESD.CC_LEVEL5_DESC
	,ESD.CC_LEVEL6_DESC
	,ESD.CC_LEVEL7_DESC
	,ESD.LE_LEVEL1_DESC
	,ESD.LE_LEVEL2_DESC
	,ESD.LE_LEVEL3_DESC
	,ESD.LE_LEVEL4_DESC
	,ESD.LE_LEVEL5_DESC
	,ESD.LE_LEVEL6_DESC
    ,ESD.BIRTH_DT
    ,ESD.ORIG_HIRE_DT
    ,NVL(
		case when ESD.ATTR_MISC_DESC = 'United States' 
			then NVL(T71173.DEMOGRAPHIC_DESC_CUSTOM,'Unspecified') 
		else 'Non-US' 
		end ,'Unspecified'
		)
    ,ESD.DISABILITY_STATUS_US
    ,ESD.ETHNICITY_US
	,ESD.LEVEL1_DESC
	,ESD.LEVEL2_DESC
	,ESD.LEVEL3_DESC
	,ESD.LEVEL4_DESC
	,ESD.LEVEL5_DESC
	,ESD.LEVEL6_DESC
	,ESD.LEVEL7_DESC
	,ESD.LEVEL8_DESC
	,ESD.LEVEL9_DESC
	,ESD.LEVEL10_DESC
	,ESD.LEVEL11_DESC
	,ESD.LEVEL12_DESC
	,ESD.LEVEL13_DESC 
	,ESD.job_req_tag1
	,ESD.job_req_tag2
	,ESD.job_req_tag3
	,ESD.job_req_tag4
	,ESD.job_req_tag5
	,ESD.job_req_tag6
	,ESD.job_req_tag7
	,ESD.job_req_tag8
	,ESD.job_req_tag9
	,ESD.job_req_tag10 
	,ESD.FULLTIME_PARTTIME
	,T71169.time_type			  
	,ESD.sup_hier_key
	--,ESD.loc_hier_key
	--,ESD.cc_hier_key
	--,ESD.le_hier_key
	,ESD.primary_sourcer1   
	,ESD.primary_sourcer1_name
	,ESD.JOB_REQ_ID
	,ESD.TIME_TO_FILL
	,ESD.TIME_TO_HIRE																				 
	,ESD.OFFR_ACPT_DT
	,ESD.RQSTN_OPENED_DT
	,ESD.JS_HIRE_DT
	,ESD.RQSTN_OFF_HOLD_DT
	,ESD.RQSTN_HOLD_DT
	,ESD.PRODUCT_DESC_1
	,ESD.PRODUCT_DESC_2
	,ESD.PRODUCT_DESC_3
	,ESD.PRODUCT_DESC_4
	,ESD.PRODUCT_DESC_5
	,ESD.product_value1
	,ESD.product_value2
	,ESD.product_value3
	,ESD.product_value4
	,ESD.product_value5
	,ESD.POSITION_TYPE
	,ESD.QUANTATIVE_SURVEY
	,ESD.QUALITATIVE_SURVEY
	,survey_numeric_response
	,survey_response
	,ESD.PROD_HIER_KEY
	,ESD.survey_sent_date
	,ESD.RQSTN_KEY
	,ESD.LOGIN
	,ESD.rank1
	,fje.GRADE_INCREASE_FLG
	,fje.EVENT_DT_KEY
	,survey_response_agree_diagree
	,fje.PERF_BAND_DESC
	,fje.PREVIOUS_PERF_BAND_DESC
	,ESD.MOST_RECENT_HIRE_DT
    ,ESD.MOST_RECENT_TERMINATION_DT  
	,fje.event_dt_key
	,fje.worker_key
	,fje.MOST_RECENT_HIRE_DT
	,ESD.MANAGER_ID 
	,ESD.MANAGER_NAME 
	,fje_m.PAY_GRADE_CODE
	,fje_m.PAY_GRADE_GROUP
	,fje_m.JOB_DESC 		
	,fje_m.JOB_FAMILY_DESC 	
	,fje_m.JOB_EXEMPT 
	,fje_m.cc_level2_value	
	,fje_m.CC_LEVEL2_DESC	
	,fje_m.SUPERVISOR_ID 				
	,fje_m.SUPERVISOR_NAME  
	,ESD.MANAGER_WORKER_KEY 
	,fje_m.MOST_RECENT_HIRE_DT 			
	,fje_m.MOST_RECENT_TERMINATION_DT 	
	,ESD.MANAGER_CONTINUOUS_SERVICE_DT 
	,fje_m.LEVEL2_DESC_NO_MGR			
	,fje_m.ATTR_MISC_DESC				
	,fje_m.LOCATION_DESC_LEVEL13		
	,fje_m.OFFICE_TYPE 
	,fje_m.FULL_TIME_FLG 
	,fje_m.employee_sub_cat_desc
	,ESD.MANAGER_REHIRE_FLAG 
	,ESD.MANAGER_EMPLOYMENT_STATUS 
	,ESD.MANAGER_BIRTH_DT 
	,ESD.MANAGER_SEX_DESC 
	,ESD.MANAGER_ETHNICITY_US 
	,fje_m.VETERAN_STATUS_US		
	,fje_m.DISABILITY_STATUS_US 	
	,fje_m.HIEST_DEGREE				
	,fje_m.SCHOOL_NAME				
	,fje_m.PERF_BAND_DESC			
	,fje_m.PREVIOUS_PERF_BAND_DESC	
	,fje_m.TALENT_QUADRANT			
	,fje_m.TALENT_QUADRANT_PRV 		
	,fje_m.ASSIGNED_HR_BUSINESS_PARTNER	 
	,fje_m.CC_NODEVAL		
	,fje_m.CC_NODENAME		
	,fje_m.CURRENT_LEVEL1_EMP_FULL_NAME  
    ,fje_m.CURRENT_LEVEL2_EMP_FULL_NAME 
    ,fje_m.CURRENT_LEVEL3_EMP_FULL_NAME 
    ,fje_m.CURRENT_LEVEL4_EMP_FULL_NAME 
    ,fje_m.CURRENT_LEVEL5_EMP_FULL_NAME 
	,fje_m.job_req_tag1				
	,fje_m.job_req_tag2             
	,fje_m.job_req_tag3             
	,fje_m.job_req_tag4             
	,fje_m.job_req_tag5             
	,fje_m.job_req_tag6             
	,fje_m.job_req_tag7             
	,fje_m.job_req_tag8             
	,fje_m.job_req_tag9             
	,fje_m.job_req_tag10            
	,fje_m.TIME_TO_FILL				
	,fje_m.TIME_TO_HIRE				
	,fje_m.JS_HIRE_DT				
	,fje_m.event_dt_key
	,fje_m.worker_key
	,fje_m.MOST_RECENT_HIRE_DT
	,fje_m.job_req_tag
	,fje_m.cc_nodeval
	,fje_m.LE_LEVEL2_DESC
	,fje_m.SEXUAL_ORIENTATION
	,fje_m.GENDER_IDENTITY
	,fje_m.worker_subtype
	,fje.PEOPLE_MANAGER_FLG
	,fjed1.TERMINATION_CATEGORY
	,ESD.Survey_key
	,ESD.COMPANY
	,fje_m.COMPANY
	,ESD.OFFICE_TYPE
	,ESD.MANAGER_VETERAN_STATUS
	,ESD.MANAGER_OFFICE_TYPE
	,supervisor_hier_list
	,PRODUCT_HIER_LIST
	,LOCATION_HIER_LIST
	,COST_CENTER_HIER_LIST
	,LEGAL_ENTITY_HIER_LIST
	,sresp_agg.survey_response_agree_diagree
	,fjed1.pay_grade_group
;



-- pap_view_schema.fact_equity_denormalized_vw source;


CREATE VIEW pap_view_schema.fact_equity_denormalized_vw AS
with max_cancelled_share_cte as 
(select distinct worker_key, grant_date,cancel_date,max_x_vest_date, 
				sum(max_cancalled_shares) over(partition by worker_key, grant_date,cancel_date,max_x_vest_date) as max_cancalled_shares
	from (select distinct worker_key, grant_date,cancel_date,
				max(x_vest_date) over(partition by  worker_key ,grant_date,cancel_date) as max_x_vest_date,
				max(cancelled_shares) over(partition by  worker_key ,grant_date,cancel_date order by x_vest_date desc rows between unbounded preceding and current row ) as max_cancalled_shares
		  from gna_load_schema.fact_equity_denormalized fed)
  ) 
select 
	   concat(concat(',',FE.role_name_access_list),',') AS role_name_access_list --Defect 1438
     , FE.x_shares                     AS x_shares
     , FE.stock_plan_type              AS stock_plan_type
     , FE.plan_type                    AS plan_type
     , FE.PRICE
     , FE.x_vest_date                  AS x_vest_date
     , FE.class                        AS class
     , assumed_value                   AS assumed_value
	 , FE.grant_date                   AS grant_date /*award_date*/
	 , FE.grant_num                    AS grant_num /*award_no*/
     , FE.shares                       AS shares /*awarded_shares*/
     , FE.units_cancelled              AS units_cancelled
     , FE.units_exercisable_releasable AS units_exercisable_releasable
     , FE.plan                         AS plan
	 , FE.units_unvested               AS units_unvested /*unvested*/
     , FE.units_exercised_released     AS units_exercised_released
	 , FE.units_ostunreleased          AS units_ostunreleased
     , FE.stock_plan_grp               AS stock_plan_grp
     , FE.grant_record_type            AS grant_record_type
     , FE.source_id                    AS source_id
	 , FE.retirement_eligible_date     AS retirement_eligible_date
     , FE.vest_year
     
     , FE.pref_full_name               AS "Worker Name" --pref_full_name /*worker_name*/
     , FE.worker_key                   AS worker_key
	 , FE.employee_num                 AS "Worker ID" --employee_num /*worker_id*/
	 --, FE.job_title                    AS job_title
	 , FE.JOB_DESC					   AS "Job Title"
     , FE.perf_band1                   AS perf_band1                   -- most recent performance rating
	 , FE.talent_quadrant_1            AS talent_quadrant_1            -- most recent talent coordinate
     , FE.MOST_RECENT_ADVANCEMENT_DATE                                                     
	 , FE.termination_dt               AS termination_dt

     , FE.pay_grade_code               AS pay_grade_code
     , FE.pay_grade_group              AS pay_grade_group
	 , FE.current_level1_emp_full_name AS current_level1_emp_full_name /*supervisory_org_level_1*/
	 , FE.current_level2_emp_full_name AS current_level2_emp_full_name /*supervisory_org_level_2*/
	 , FE.current_level3_emp_full_name AS current_level3_emp_full_name /*supervisory_org_level_3*/
	 , FE.current_level4_emp_full_name AS current_level4_emp_full_name /*supervisory_org_level_4*/
	 , FE.current_level5_emp_full_name AS current_level5_emp_full_name /*supervisory_org_level_5*/
	 , FE.current_level6_emp_full_name AS current_level6_emp_full_name /*supervisory_org_level_6*/
	 , FE.current_level7_emp_full_name AS current_level7_emp_full_name /*supervisory_org_level_7*/
	 , FE.current_level8_emp_full_name AS current_level8_emp_full_name /*supervisory_org_level_8*/
	 , FE.current_level9_emp_full_name AS current_level9_emp_full_name /*supervisory_org_level_9*/
	 , FE.current_level10_emp_full_name AS current_level10_emp_full_name /*supervisory_org_level_10*/
	 , FE.current_level11_emp_full_name AS current_level11_emp_full_name /*supervisory_org_level_11*/
	 
	 , FE.CURRENT_LEVEL1_EMP_LOGIN
	 , FE.CURRENT_LEVEL2_EMP_LOGIN
	 , FE.CURRENT_LEVEL3_EMP_LOGIN
	 , FE.CURRENT_LEVEL4_EMP_LOGIN
	 , FE.CURRENT_LEVEL5_EMP_LOGIN
	 , FE.CURRENT_LEVEL6_EMP_LOGIN
	 , FE.CURRENT_LEVEL7_EMP_LOGIN
	 , FE.CURRENT_LEVEL8_EMP_LOGIN
	 , FE.CURRENT_LEVEL9_EMP_LOGIN
	 , FE.CURRENT_LEVEL10_EMP_LOGIN
	 , FE.CURRENT_LEVEL11_EMP_LOGIN
	 
	 , FE.cc_level1_value
	 , FE.cc_level2_value
	 , FE.cc_level3_value
	 , FE.cc_level4_value
	 , FE.cc_level5_value
	 , FE.cc_level6_value
	 , FE.cc_level7_value
	 , FE.CC_LEVEL1_DESC
	 , FE.CC_LEVEL2_DESC
	 , FE.CC_LEVEL3_DESC
	 , FE.CC_LEVEL4_DESC
	 , FE.CC_LEVEL5_DESC
	 , FE.CC_LEVEL6_DESC
	 , FE.CC_LEVEL7_DESC
	 
	 , FE.le_level1_val
	 , FE.le_level2_val
	 , FE.le_level3_val
	 , FE.le_level4_val
	 , FE.le_level5_val
	 , FE.le_level6_val 
	 , FE.LE_LEVEL1_DESC
	 , FE.LE_LEVEL2_DESC
	 , FE.LE_LEVEL3_DESC
	 , FE.LE_LEVEL4_DESC
	 , FE.LE_LEVEL5_DESC
	 , FE.LE_LEVEL6_DESC
	 
	 , FE.product_value1
	 , FE.product_value2
	 , FE.product_value3
	 , FE.product_value4
	 , FE.product_value5
	 , FE.product_desc1
	 , FE.product_desc2
	 , FE.product_desc3
	 , FE.product_desc4
	 , FE.product_desc5
	 
	 , FE.LOCATION_CODE_LEVEL1
	 , FE.LOCATION_CODE_LEVEL2
	 , FE.LOCATION_CODE_LEVEL3
	 , FE.LOCATION_CODE_LEVEL4
	 , FE.LOCATION_CODE_LEVEL5
	 , FE.LOCATION_CODE_LEVEL6
	 , FE.LOCATION_CODE_LEVEL7
	 , FE.LOCATION_CODE_LEVEL8
	 , FE.LOCATION_CODE_LEVEL9
	 , FE.LOCATION_CODE_LEVEL10
	 , FE.LOCATION_CODE_LEVEL11
	 , FE.LOCATION_CODE_LEVEL12
	 , FE.LOCATION_CODE_LEVEL13
	 , FE.LOCATION_DESC_LEVEL1
	 , FE.LOCATION_DESC_LEVEL2
	 , FE.LOCATION_DESC_LEVEL3
	 , FE.LOCATION_DESC_LEVEL4
	 , FE.LOCATION_DESC_LEVEL5
	 , FE.LOCATION_DESC_LEVEL6
	 , FE.LOCATION_DESC_LEVEL7
	 , FE.LOCATION_DESC_LEVEL8
	 , FE.LOCATION_DESC_LEVEL9
	 , FE.LOCATION_DESC_LEVEL10
	 , FE.LOCATION_DESC_LEVEL11
	 , FE.LOCATION_DESC_LEVEL12
	 , FE.LOCATION_DESC_LEVEL13
	 
	 , FE.level2_desc                  AS level2_desc
	 , FE.attr_misc_desc               AS "Country Name"
     , FE.attr_misc_code               AS "Country Code"
	 , FE.OFFICE_TYPE 				   AS "Office Type" 
	 
	 , FE.dept_id                      
	 , FE.dept_name                    
     
	 -- Cancelled Share Data not used in Agggregate query 
     , FE.cancelled_shares             AS cancelled_shares
	 , FE.cancel_date                  AS cancel_date
     , FE.cancel_reason                AS cancel_reason
	 , FE.CC_NODEVAL
	 , FE.CC_NODENAME
	 , FE.ETHNICITY_US 				   AS "Ethnicity (US)"
	 , FJESR.VETERAN_STATUS_US
	 , FJESR.DISABILITY_STATUS_US 
	 , FE.LOGIN 
	 , 'Total Gilead' AS company_level1_val
     , 'Total Gilead' AS company_level1_desc
	 , FE.COMPANY as company_level2_val
     /*, case when FE.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
      end AS company_level2_val */
	 , FE.COMPANY as company_level2_desc
    /*, case when FE.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
      end AS company_level2_desc */
	, FE.JOB_CODE						AS "Job Code"
	, FE.JOB_FAMILY_DESC 				AS "Job Family"
	, FJESR.Job_Exempt					AS "Job Exempt"
	, FE.CC_NODEVAL						AS "Cost Center ID"
	, FE.CC_NODENAME					AS "Cost Center Name"
	, FE.SUPERVISOR_NUM                 AS "Supervisior ID"
	, FE.SUPERVISOR_NAME                AS "Supervisior Name"
	, FJESR.MOST_RECENT_HIRE_DT			AS "Most Recent Hire Date"
	, FE.CONTINUOUS_SERVICE_DT
	, FE.LEVEL2_DESC_NO_MGR				AS "Geographic Location Level 2 Name"
	, FE.job_req_tag					AS "Job Req Tag"
	, FE.FULLTIME_PARTTIME				AS "Full Time Flag"
	, FE.EMPLOYEE_SUB_CAT_DESC			AS "Worker Type Sub Category Description"
	, FJESR.Current_Employment_Status	AS "Employment Status"
	, (select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_denormalized x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(FJESR.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=FJESR.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and FJESR.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Advancement Date"
	, FE.REHIRE_FLAG					AS "Rehire Flag"
	, FJESR.VETERAN_STATUS_US			AS "Veteran Status (US)"
	, FJESR.DISABILITY_STATUS_US		AS "Disability Status (US)"
	, FE.SEX_DESC						AS "Gender"
	, FJESR.PERF_BAND_DESC
	, FJESR.PREVIOUS_PERF_BAND_DESC
	, CASE WHEN FJESR.talent_quadrant ='' THEN NULL ELSE FJESR.talent_quadrant END AS talent_quadrant
	, CASE WHEN FJESR.talent_quadrant_prv ='' THEN NULL ELSE FJESR.talent_quadrant_prv END AS talent_quadrant_prv
	, FE.BIRTH_DT
	, FE.HIEST_DEGREE					AS "Highest Education Degree Description"
	, FE.SCHOOL_NAME					AS "Highest Degree School Name"
	, FE.AWR_START_DATE
	, FE.AWR_END_DT
	, FE.TERMINATION_DT10
	, FE.TERMINATION_DT9
	, FE.TERMINATION_DT8
	, FE.TERMINATION_DT7
	, FE.TERMINATION_DT6
	, FE.TERMINATION_DT5
	, FE.TERMINATION_DT4
	, FE.TERMINATION_DT3
	, FE.TERMINATION_DT2
	, FE.TERMINATION_DT1
	, CAST(FJESR.stock_target_amount AS DECIMAL(20,3)) as stock_target_amount
	, '[Coming Soon]'		                AS ASSIGNED_HR_BUSINESS_PARTNER
	, fre.source_type_name					AS "Recruitment Source"
	, FE.UNITS_VESTED
	, FE.SUP_HIER_PIT_KEY
	, FE.SNAPSHOT_DT_KEY
	, FE.AGE_BAND_KEY
	, FE.CC_HIER_KEY
	, FE.WORKER_TYPE_KEY
	, FE.DEPT_KEY
	, FE.PAY_GRADE_KEY
	, FE.JOB_KEY
	, FE.PROD_HIER_KEY
	, FE.DEPT_HIER_KEY
	, FE.LOC_HIER_KEY
	, FE.LE_HIER_KEY
	, FE.SER_BAND_KEY
	, FE.SUP_HIER_KEY
	, FJESR.NEXT_TERMINATION_DATE
	, FE.SEXUAL_ORIENTATION
	, FE.MOST_RECENT_TERMINATION_DT
	, FE.ORIG_HIRE_DT
	, FE.SECTOR_A_FROM					AS "Salary Range Segment Min A"
	, FE.SECTOR_A_TO					AS "Salary Range Segment Max A"
  	, FE.SECTOR_B_FROM					AS "Salary Range Segment Min B1"
	, FE.SECTOR_1B_TO					AS "Salary Range Segment Max B1"
	, FE.SECTOR_2B_FROM					AS "Salary Range Segment Min B2"
	, FE.SALARY_MIDPOINT				AS "Salary Range Segment Midpoint (B2)"
	, FE.SECTOR_2B_TO					AS "Salary Range Segment Max B2"
	, FE.SECTOR_3B_FROM					AS "Salary Range Segment Min B3"
	, FE.SECTOR_3B_TO					AS "Salary Range Segment Max B3"
	, FE.SECTOR_C_FROM					AS "Salary Range Segment Min C"
	, FE.SECTOR_C_TO					AS "Salary Range Segment Max C"
	, FJESR.MAX_EVENT_DT_KEY
	, FJESR.BUSINESS_TITLE
	, FE.PAY_GRADE_PROFILE
	, FE.JOB_FAMILY_GROUP
	, FE.Currency_Code
	, substring(FE.PAYLINE_CODE , 3 , 2) as "Range ID"
	, FJESR.SALARY_ANNL
	, case  when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <  "Salary Range Segment Min A"  then 'Below A'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >= "Salary Range Segment Min A"  and  NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <  "Salary Range Segment Min B1" THEN 'A'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >= "Salary Range Segment Min B1" and  NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <= "Salary Range Segment Max B1" THEN 'B1'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >= "Salary Range Segment Min B2" and  NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <= "Salary Range Segment Max B2" THEN 'B2'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >= "Salary Range Segment Min B3" and  NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <= "Salary Range Segment Max B3" THEN 'B3'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >  "Salary Range Segment Max B3" and  NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) <= "Salary Range Segment Max C"  THEN 'C'
			when NVL(FJESR.SALARY_ANNL/CASE WHEN FJESR.FTE=0 THEN NULL ELSE FJESR.FTE END,0) >  "Salary Range Segment Max C" then 'Above C'
	  end as "Sector Position"
	, FJESR.ACTUAL_BONUS_INDIVIDUAL_SHARE
	, FJESR.annual_bonus_amount
	, FJESR.PEOPLE_MANAGER_FLG
	, FJESR.TIER_CODE
	, coalesce(KEY_CONTR.key_cont,'N') 			AS KEY_CONTRIBUTOR
	, FJESR.ASSIGNMENT_NUM
	, FJESR.INTL_ASSGN_KEY
	, FJESR.PAYLINE_CODE
	, FJESR.FTE
	, FJESR.EFFECTIVE_START_DT
	, FJESR.EFFECTIVE_END_DT
	, FJESR.HEADCOUNT
	, FJESR.MAX_SEQ_IND
	, FJESR.SNAPSHOT_MONTH_END_IND
	, FJESR.SUPERVISOR_EVT_IND
	, FE.EMPLOYEE_CAT_CODE				AS WORKER_TYPE
	, FJESR.term_event_ind
	, FJESR.event_month_key
	, nvl(mcs.max_cancalled_shares,0) 	AS max_cancalled_shares
	, concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FE.current_level1_emp_login,''),'|'),NVL(FE.current_level2_emp_login,'')),'|'), NVL(FE.current_level3_emp_login,'')),'|'),NVL(FE.current_level4_emp_login,'')),'|'),NVL(FE.current_level5_emp_login,'')),'|'),NVL(FE.current_level6_emp_login,'')),'|'),NVL(FE.current_level7_emp_login,'')),'|'),NVL(FE.current_level8_emp_login,'')),'|'),NVL(FE.current_level9_emp_login,'')),'|'),NVL(FE.current_level10_emp_login,'')),'|'),NVL(FE.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
	, concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FE.product_value1,''),'|'),NVL(FE.product_value2,'')),'|'),NVL(FE.product_value3,'')),'|'),NVL(FE.product_value4,'')),'|'), NVL(FE.product_value5,'')),'|')) as PRODUCT_HIER_LIST
	, concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FE.LOCATION_CODE_LEVEL1,''),'|'),NVL(FE.LOCATION_CODE_LEVEL2,'')),'|'), NVL(FE.LOCATION_CODE_LEVEL3,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL4,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL5,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL6,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL7,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL8,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL9,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL10,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL11,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL12,'')),'|'),NVL(FE.LOCATION_CODE_LEVEL13,'')),'|')) as LOCATION_HIER_LIST 
	, concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FE.cc_level1_value,''),'|'),NVL(FE.cc_level2_value,'')),'|'),NVL(FE.cc_level3_value,'')),'|'),NVL(FE.cc_level4_value,'')),'|'), NVL(FE.cc_level5_value,'')),'|'),NVL(FE.cc_level6_value,'')),'|'),NVL(FE.cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	, concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FE.le_level1_val,''),'|'),NVL(FE.le_level2_val,'')),'|'),NVL(FE.le_level3_val,'')),'|'),NVL(FE.le_level4_val,'')),'|'), NVL(FE.le_level5_val,'')),'|'),NVL(FE.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST


FROM gna_load_schema.FACT_EQUITY_DENORMALIZED FE

	 LEFT JOIN (SELECT DISTINCT WORKER_KEY,EVENT_DT_KEY,EFFECTIVE_START_DT,EFFECTIVE_END_DT,HEADCOUNT,MAX_SEQ_IND,MOST_RECENT_HIRE_DT,Job_Exempt
								,Current_Employment_Status,VETERAN_STATUS_US,DISABILITY_STATUS_US,PERF_BAND_DESC,PREVIOUS_PERF_BAND_DESC
								,talent_quadrant,talent_quadrant_prv,stock_target_amount,NEXT_TERMINATION_DATE,BUSINESS_TITLE,SALARY_ANNL
								,TIER_CODE,ACTUAL_BONUS_INDIVIDUAL_SHARE,annual_bonus_amount,PEOPLE_MANAGER_FLG,ASSIGNMENT_NUM,INTL_ASSGN_KEY
								,PAYLINE_CODE,FTE,MAX_EVENT_DT_KEY,SNAPSHOT_MONTH_END_IND,SUPERVISOR_EVT_IND,term_event_ind,event_month_key		
								,row_number() over(partition by worker_key,EVENT_DT_KEY order by event_seq desc) r_num
                FROM (select * , max(to_date(EVENT_DT_KEY,'YYYYMMDD')) over(partition by WORKER_KEY) as MAX_EVENT_DT_KEY 
				from gna_load_schema.FACT_JOB_EVENTS_DENORMALIZED )
                where HEADCOUNT =1 AND MAX_SEQ_IND =1 ) FJESR 
       ON FE.WORKER_KEY=FJESR.WORKER_KEY 
	   AND r_num=1
       AND FE.GRANT_DATE BETWEEN FJESR.EFFECTIVE_START_DT  AND FJESR.EFFECTIVE_END_DT
	   
	 LEFT JOIN (SELECT ldrs.source_type_name,START_DT_WID,effective_start_dt,END_DT_WID,effective_end_dt,WORKER_KEY,RQSTN_KEY,RQSTN_ID,hire_dt
					   ,event_class,row_number() over(partition by x.worker_key,x.rqstn_key,x.event_dt order by x.event_seq desc) rnum
                     FROM gna_load_schema.FACT_RCRTMNT_EVENTS x,
                     	  gna_load_schema.LNK_DIM_RCRTMNT_SOURCE ldrs 
                     WHERE ldrs.DIM_RCRTMNT_SOURCE_KEY=x.RCRTMNT_SOURCE_KEY 
						AND x.event_class = 'JOB_RQSTN'
                     --AND sysdate BETWEEN effective_start_dt AND effective_end_dt
                     )fre 
		ON fre.worker_key = FE.WORKER_KEY 
		AND fre.rqstn_key = FE.rqstn_key 
		AND rnum = 1
		AND FE.GRANT_DATE BETWEEN fre.effective_start_dt AND fre.effective_end_dt
		
	left join (select
				fe.worker_key,fe.start_key_con_grant_date,fe.end_key_con_grant_date,key_cont
				,row_number() over(partition by fe.worker_key,fe.start_key_con_grant_date,fe.end_key_con_grant_date  order by fe.start_key_con_grant_date desc) r_num
				from  (	select 
								worker_key 
								,date_trunc('year',FE.grant_date) as start_key_con_grant_date
								,add_months(date_trunc('year',grant_date),12) as end_key_con_grant_date
								,grant_date 
								,class
								,'Y' as key_cont 
							from  gna_load_schema.FACT_EQUITY FE  
							where FE.class='KEY' 
							
							) fe
							
			)KEY_CONTR
			on KEY_CONTR.worker_key =FE.worker_key 
		   and KEY_CONTR.r_num=1
	   	   and FE.grant_date >= start_key_con_grant_date
	   	   and FE.grant_date < end_key_con_grant_date	
	   	   
	left join max_cancelled_share_cte mcs 
		 on mcs.worker_key  =FE.worker_key
        and mcs.grant_date  =FE.grant_date
        and mcs.cancel_date =FE.cancel_date
        and mcs.max_x_vest_date= FE.x_vest_date	

 ;
 
 
 
-- pap_view_schema.fact_hyperion_forecast_denormalized_vw source;


create view pap_view_schema.fact_hyperion_forecast_denormalized_vw as 
 select
	 concat(concat(',',role_name_access_list),',') AS role_name_access_list
	,COMPANYCODE 
	,COSTCENTER 
	,EMPTYP 
	,HCUNITS 
	,MANDT 
	,MARKET 
	,replace(PAYGRADE,'GR_','') as PAYGRADE
	,PROFITCENTER 
	,SCENARIO 
	,substring("time",0,5)||substring("time",6,8) as "time" 
	,MONTH_KEY 
	,CREATED_DT  
	,CREATED_BY_KEY 
	,CC_HIER_KEY 
	,BUDGET_KEY 
	,PROD_HIER_KEY 
	,MARKET_KEY 
	,ROW_ID 
	,LE_HIER_KEY 
	,HC_TYPE 
	,cc_level1_value 
	,cc_level2_value 
	,cc_level3_value 
	,cc_level4_value 
	,cc_level5_value 
	,cc_level6_value 
	,cc_level7_value
	,cc_level8_value
	,CC_LEVEL1_DESC 
	,CC_LEVEL2_DESC 
	,CC_LEVEL3_DESC 
	,CC_LEVEL4_DESC 
	,CC_LEVEL5_DESC 
	,CC_LEVEL6_DESC 
	,CC_LEVEL7_DESC 
	,CC_LEVEL8_DESC
	,base_cost_center_desc  
	,Cost_center_level2_desc 
	,cc_desc 
	,cc_legal_entity 
	,cc_owner 
	,functional_area 
	,currency 
	,product_link 
	,market_associated 
	,current_level1_emp_full_name 
	,current_level2_emp_full_name 
	,current_level3_emp_full_name 
	,current_level4_emp_full_name 
	,current_level5_emp_full_name 
	,current_level6_emp_full_name 
	,current_level7_emp_full_name 
	,current_level8_emp_full_name 
	,current_level9_emp_full_name 
	,current_level10_emp_full_name 
	,current_level11_emp_full_name 
	,current_level1_emp_login 
	,current_level2_emp_login 
	,current_level3_emp_login 
	,current_level4_emp_login 
	,current_level5_emp_login 
	,current_level6_emp_login 
	,current_level7_emp_login 
	,current_level8_emp_login 
	,current_level9_emp_login 
	,current_level10_emp_login 
	,current_level11_emp_login 
	,le_level1_val 
	,le_level2_val 
	,le_level3_val 
	,le_level4_val 
	,le_level5_val 
	,le_level6_val 
	,le_level1_desc 
	,le_level2_desc 
	,le_level3_desc 
	,le_level4_desc 
	,le_level5_desc 
	,le_level6_desc 
	,product_value1 
	,product_value2 
	,product_value3 
	,product_value4 
	,product_value5 
	,product_DESC1 
	,product_DESC2 
	,product_DESC3 
	,product_DESC4 
	,product_DESC5 
	,product_desc 
	,site_cc_level1_value 
	,site_cc_level2_value 
	,site_cc_level3_value 
	,site_cc_level4_value 
	,site_cc_level5_value 
	,site_cc_level6_value 
	,site_cc_level7_value 
	,site_CC_LEVEL1_DESC 
	,site_CC_LEVEL2_DESC 
	,site_CC_LEVEL3_DESC 
	,site_CC_LEVEL4_DESC 
	,site_CC_LEVEL5_DESC 
	,site_CC_LEVEL6_DESC 
	,site_CC_LEVEL7_DESC 
	,FUNCTIONAL_AREA_DESC 
	,COST_CENTER_OWNER 
	,LOGIN 
	,BUDGET_DESC 
	,BUDGET_NAME 
	,cc_nodeval
	,CC_NODENAME
	,'Total Gilead' AS company_level1_val
    ,'Total Gilead' AS company_level1_desc
	,COMPANY AS company_level2_val
    /*,case when cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS company_level2_val*/
	,COMPANY AS company_level2_desc
    /*,case when cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS company_level2_desc*/
	,case
		when replace(PAYGRADE,'GR_','') in ('21','22','23','24','25','26') then '21-26'
		when replace(PAYGRADE,'GR_','') in ('27','28','29')  then '27-29'
		when replace(PAYGRADE,'GR_','') in ('30','31','32')  then '30-32'
		when replace(PAYGRADE,'GR_','') in ('33','34')  then '33-34'
		when replace(PAYGRADE,'GR_','') in ('35','36','37','38','85','90','95') then '35+'
		else replace(PAYGRADE,'GR_','')
	 end as pay_grade_group
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(current_level1_emp_login,''),'|'),NVL(current_level2_emp_login,'')),'|'), NVL(current_level3_emp_login,'')),'|'),NVL(current_level4_emp_login,'')),'|'),NVL(current_level5_emp_login,'')),'|'),NVL(current_level6_emp_login,'')),'|'),NVL(current_level7_emp_login,'')),'|'),NVL(current_level8_emp_login,'')),'|'),NVL(current_level9_emp_login,'')),'|'),NVL(current_level10_emp_login,'')),'|'),NVL(current_level11_emp_login,'')),'|')) as COST_CENTER_OWNER_HIER_LIST 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(product_value1,''),'|'),NVL(product_value2,'')),'|'),NVL(product_value3,'')),'|'),NVL(product_value4,'')),'|'), NVL(product_value5,'')),'|')) as PRODUCT_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(cc_level1_value,''),'|'),NVL(cc_level2_value,'')),'|'),NVL(cc_level3_value,'')),'|'),NVL(cc_level4_value,'')),'|'), NVL(cc_level5_value,'')),'|'),NVL(cc_level6_value,'')),'|'),NVL(cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(le_level1_val,''),'|'),NVL(le_level2_val,'')),'|'),NVL(le_level3_val,'')),'|'),NVL(le_level4_val,'')),'|'), NVL(le_level5_val,'')),'|'),NVL(le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(site_cc_level1_value,''),'|'),NVL(site_cc_level2_value,'')),'|'),NVL(site_cc_level3_value,'')),'|'),NVL(site_cc_level4_value,'')),'|'), NVL(site_cc_level5_value,'')),'|'),NVL(site_cc_level6_value,'')),'|'),NVL(site_cc_level6_value,'')),'|')) as COST_CENTER_SITE_HIER_LIST
	,COST_CENTER_OWNER_ID
	FROM gna_load_schema.fact_hyperion_forecast_denormalized 
;	



-- pap_view_schema.fact_rec_events_denormalized_vw source;



CREATE or replace VIEW pap_view_schema.fact_rec_events_denormalized_vw as 
-- Applicant data 
(
with load_dt_cte as (
			  --to_date(max(batch_date),'YYYYMMDD') as load_date 
              --to_date(max(substring(end_time,0,11)),'YYYY-MM-DD') as load_date
              select 
				max(availability_date) as load_date 
				--max(to_date(substring(end_time,0,11),'YYYY-MM-DD')) as load_date 
			  from pap_view_schema.pap_latest_data_availability_vw
			  where status='FINISHED'
       )
SELECT 
    concat(concat(',',role_name_access_list),',') AS role_name_access_list --Defect 1438
   ,FR.event_class
   ,CAL.calendar_dt
   ,FR.applicant_id 			AS "Applicant ID"
   ,FR.applicant_name 			AS "Applicant Name"
   ,FR.dept_id 					AS "Cost Center ID"
   ,FR.dept_name 				AS "Cost Center Name"
   ,NULL AS dept_hier_level2_code
   ,NULL AS dept_hier_level2_desc
   ,FR.pay_grade_code  			AS "Pay Grade"
   ,FR.pay_grade_group 			AS "Pay Grade Group"
   ,FR.job_code 				AS "Job Code"
   ,FR.job_desc 				AS "Job Title"
   ,FR.rqstn_created_dt
   ,TO_DATE(FR.offr_acpt_dt,'YYYY-MM-DD') 			AS "Offer Accepted Date"
   ,TO_DATE(FR.offr_extd_dt ,'YYYY-MM-DD')			AS "Offer Extended Date"
   ,FR.req_filled_closed_dt
   ,TO_DATE(FR.rqstn_hold_dt ,'YYYY-MM-DD')			AS "Freeze Date"
   ,FR.job_posting_title 		AS "Job Posting Title"
   ,TO_DATE(FR.js_hire_dt ,'YYYY-MM-DD')				AS "Job Req Hire Date"
   ,FR.rqstn_id					AS "Job Req ID"
   ,FR.req_status
   ,FR.replacement_code			AS "Job Req Type"
   ,TO_DATE(FR.rqstn_opened_dt,'YYYY-MM-DD') 		AS "Opened Date"
   ,FR.rqstn_off_hold_dt
   ,FR.replacement_worker_id 	AS "Replaced Employee ID"
   ,FR.replacement_name			AS "Replaced Employee Name"
   ,FR.position_id  			AS "Position ID"
   ,FR.custom_position_reason
   ,FR.recruiter_num
   ,FR.recruiter_name			AS "Recruiter Name"
   ,FR.x_custom
   ,FR.supervisor_num		
   ,FR.supervisor_name
   ,FR.job_req_tag 				AS "Job Req Tag"
   ,FR.pending_approval
   ,FR.rqstn_open
   ,FR.on_hold
   ,FR.country_code
   ,FR.job_key
   ,FR.w_event_code
   ,FR.current_level1_emp_full_name 	
   ,FR.current_level2_emp_full_name 	
   ,FR.current_level3_emp_full_name 	
   ,FR.current_level4_emp_full_name 	
   ,FR.current_level5_emp_full_name 	
   ,FR.current_level6_emp_full_name 	
   ,FR.current_level7_emp_full_name 	
   ,FR.current_level8_emp_full_name 	
   ,FR.current_level9_emp_full_name 	
   ,FR.current_level10_emp_full_name 	
   ,FR.current_level11_emp_full_name 	
   ,FR.current_level1_emp_login
   ,FR.current_level2_emp_login
   ,FR.current_level3_emp_login
   ,FR.current_level4_emp_login
   ,FR.current_level5_emp_login
   ,FR.current_level6_emp_login
   ,FR.current_level7_emp_login
   ,FR.current_level8_emp_login
   ,FR.current_level9_emp_login
   ,FR.current_level10_emp_login
   ,FR.current_level11_emp_login
   ,FR.level1_desc
   ,FR.level2_desc
   ,FR.level3_desc
   ,FR.level4_desc
   ,FR.level5_desc
   ,FR.level6_desc
   ,FR.level7_desc
   ,FR.level8_desc
   ,FR.level9_desc
   ,FR.level10_desc
   ,FR.level11_desc
   ,FR.level12_desc
   ,FR.level13_desc
   ,FR.level1_val
   ,FR.level2_val
   ,FR.level3_val
   ,FR.level4_val
   ,FR.level5_val
   ,FR.level6_val
   ,FR.level7_val
   ,FR.level8_val
   ,FR.level9_val
   ,FR.level10_val
   ,FR.level11_val
   ,FR.level12_val
   ,FR.level13_val
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level1_value else FR.cc_hier_level1 end as cc_hier_level1
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level2_value else FR.cc_hier_level2 end as cc_hier_level2
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level3_value else FR.cc_hier_level3 end as cc_hier_level3
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level4_value else FR.cc_hier_level4 end as cc_hier_level4
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level5_value else FR.cc_hier_level5 end as cc_hier_level5
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level6_value else FR.cc_hier_level6 end as cc_hier_level6
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level7_value else FR.cc_hier_level7 end as cc_hier_level7
   ,FR.worker_type_key
   ,FR.le_hier_level1_val
   ,FR.le_hier_level2_val
   ,FR.le_hier_level3_val
   ,FR.le_hier_level4_val
   ,FR.le_hier_level5_val
   ,CASE WHEN FR.le_hier_key =0 then fjed.le_level6_val else FR.le_hier_level6_val end as le_hier_level6_val
   ,FR.le_hier_level1_desc
   ,FR.le_hier_level2_desc
   ,FR.le_hier_level3_desc
   ,FR.le_hier_level4_desc
   ,FR.le_hier_level5_desc
   ,CASE WHEN FR.le_hier_key =0 then fjed.le_level6_desc else FR.le_hier_level6_desc end as le_hier_level6_desc
   ,FR.employee_cat_code
   ,FR.rqstn_name 		AS "Job Req Name"
   ,FR.event_cnt
   ,FR.rqstn_key
   ,FR.w_stage_code
   ,'Coming Soon'			AS "Target Hire Date"
   ,FR.w_sub_stage_code
   ,FR.start_dt_wid
   ,FR.end_dt_wid
   ,FR.effective_end_dt
   ,FR.product_value1
   ,FR.product_value2
   ,FR.product_value3
   ,FR.product_value4
   ,FR.product_value5
   ,FR.cc_hier_key
   ,FR.le_hier_key
   ,FR.prod_hier_key
   ,FR.loc_hier_key
   ,FR.supervisor_hier_key
   ,FR.event_dt_key
   ,CASE WHEN FR.sex_desc  ='Unknown' THEN 'Unspecified' ELSE NVL(FR.sex_desc,'Unspecified') END			AS "Gender"
   ,FR.applicant_key
   ,FR.source_id
   ,FR.candidate_type 		AS "Candidate Type"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(FR.sexual_orientation,'Unspecified') else 'Non-US' end AS "Sexual Orientation"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
			then 
				CASE WHEN FR.gender_identity ='Unknown' 
						THEN 'Unspecified'
					 ELSE NVL(FR.gender_identity,'Unspecified') 
				END
			else 'Non-US' end AS "Gender Identity"
   ,FR.office_type			AS "Office Type"
   ,FR.veteran_status_desc	AS "Veteran Status"
   ,FR.disposition_reason
   ,TO_DATE(FR.disposition_date,'YYYY-MM-DD') as disposition_date
   ,FR.disposition_category
   ,FR.disposition_code
   ,FR.disposition_flg
   ,FR.manager_resume_review_date
   ,FR.recruiter_phone_screen_date
   ,TO_DATE(FR.ta_resume_review_date,'YYYY-MM-DD') as ta_resume_review_date
   ,FR.assessment_date
   ,FR.manager_phone_screen_date
   ,FR.manager_resume_screen_date
   ,FR.review_decision_date
   ,FR.referrer_worker_id
   ,FR.referrer_name
   ,TO_DATE(FR.ADDL_INTERVIEW_STEP_DT,'YYYY-MM-DD')	as ADDL_INTERVIEW_STEP_DT	---"1st_round_interview_date"
   ,TO_DATE(FR.ADDITIONAL_INTERVIEW_DATE,'YYYY-MM-DD') as ADDITIONAL_INTERVIEW_DATE				--"2nd_round_interview_date"
   ,TO_DATE(FR.INTERVIEW_DT,'YYYY-MM-DD')	as INTERVIEW_DT										--additional_interview_date
   ,FR.job_family_code 
   ,FR.status_desc 						AS "Job Req Status as of {End Date}"
   ,FR.job_family_desc 					AS "Job Family"
   ,FR.job_exempt_flg 					AS "Job Exempt"
   ,FR.fulltime_parttime 				AS "Full Time Flag"
   ,FR.employee_sub_cat_desc 			AS "Worker Type Sub Category Description"
   ,TO_DATE(FR.rqstn_off_hold_dt ,'YYYY-MM-DD')				AS "Reopened Date"
   --,FR.time_to_fill 					AS "Time to Fill"
   ,cast (0 as int)						AS "Time to Fill" 
   ,FR.total_applicants 				AS "Total Applicants"
   ,FR.total_active_applicants 			AS "Total Active/Undispositioned Applicants"
   ,sl.total_diverse_applicants 		AS "Total Diverse Applicants"													
   ,FR.job_req_comments 				AS "Job Req Notes"
   ,FR.job_req_comments_author_name 	AS "Job Req Notes Author"
   ,TO_DATE(FR.job_req_comments_dt,'YYYY-MM-DD') 				AS "Job Req Notes Date"
   ,FR.attribute_type
   ,FR.worker_key
   ,FR.hire_evnt_cnt
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(FR.ethnic_group_custom_desc,'Unspecified') else 'Non-US' end AS "Ethnicity (US)"
   ,FR.appl_race_on_rqstn
   ,FR.dim_rcrtmnt_evt_key
   ,FR.appl_veteran_sts_on_rqstn
   ,FR.appl_disability_sts_on_rqstn
   ,FR.appln_strt_dt
   ,FR.reference_check_date
   ,TO_DATE(FR.interview_assessment_date,'YYYY-MM-DD') AS interview_assessment_date
   ,FR.appl_stage_wd					AS "Application Stage"
   ,FR.appl_step_wd
   ,FR.appl_sex_desc_on_rqstn
   ,FR.budget_id
   ,TO_DATE(FR.rqstn_filled_dt ,'YYYY-MM-DD')					AS "Job Req Filled Date"
   ,FR.rqstn_closed_dt 					AS "Job Req Closed Date "
   --,FR.status_code						AS "Job Req Stage"
   ,FR.JOB_REQ_STAGE					AS "Job Req Stage"
   ,FR.awr_gilead_tenure
   ,FR.hiest_degree
   ,FR.assignment_num
   ,FR.perf_band1
   ,FR.perf_band2
   ,FR.perf_band3
   ,FR.talent_quadrant_1
   ,FR.talent_quadrant_2
   ,FR.talent_quadrant_3
   ,FR.job_title
   ,FR.continuous_service_dt
   ,FR.time_to_hire_req 				AS "Time to Hire"
   ,FR.cost_center_name 				AS "Cost Center Level 2 Name"
   ,FR.primary_sourcer1 				
   ,FR.primary_sourcer1_name 			
   ,FR.school_name 						AS "Highest Degree School Name"
   ,FR.age 								AS "Applicant Age"
   ,FR.orig_hire_dt						AS applicant_orig_hire_dt
   ,FR.HIEST_EDU_DEG_NAME				AS "Highest Education Degree Name"
   ,FR.EMPLOYMENT_STAT_DESC				AS "Employement Status"
   ,FR.rehire_flag
   ,FR.sup_supervisor_flg
   ,FR.applicant_supervisor_flg
   ,FR.offer_accepted
   ,FR.total_no_of_offer
   ,TO_DATE(FR.birth_dt,'YYYY-MM-DD')	AS birth_dt
   ,FR.level2_desc_no_mgr 				AS "Geographic Location Level 2 Name"
   ,FR.POSITION_REASON 					AS "Position Reason"
   ,FR.HIRING_MANAGER_NAME 				AS "Hiring Manager Name"
   ,FR.HIRING_MGR_WORKER_ID 			AS "Hiring Manager Worker ID"
   ,FR.recruiter_num					AS "Recruiter ID"
   --,FR.RECRUITER_WORKER_ID 				AS "Recruiter ID"
   ,FR.Hired_Applicant_ID 				AS "Hired Applicant ID"
   ,FR.level13_desc						AS "Location Name"
   ,FR.source_type_name 				AS "Hired Applicant Recruitment Source"
   ,FR.source_code						AS "Hired Applicant Specific Recruitment Source"
   ,FR.cc_hier_level2 					AS "Cost Center Level 2 Code"
   ,FR.attr_misc_desc					AS "Country Name"
   ,FR.ASSIGNED_HR_BUSINESS_PARTNER 	AS "Assigned HR Business Partner"
   ,FR.Skills_First_Qualified_Req 		AS "Skills First Qualified Req?"
   ,FR.Offer_Acceptance_Rate			AS "Offer Acceptance Rate"
   ,FR.DAYS_OPEN						AS "Number of Days Open"
   ,DEMOGRAPHIC_DESC_CUSTOM 			AS "Disability Status" -- dim_worker (should come from this table)
   ,FR.hire_dt
   ,case when FR.w_sub_stage_code!='EMPLOYMENT_PRE_POW1' THEN NULL ELSE FR.Hired_Applicant_Worker_ID END AS "Hired Applicant Worker ID"
   ,case when FR.w_sub_stage_code!='EMPLOYMENT_PRE_POW1' THEN NULL ELSE FR.WORKER_NAME	END AS "Hired Applicant Name"
   --,FR.applicant_name 					AS "Hired Applicant Name"			
   ,FR.rqstn_open_stg_cnt
   ,FR.primary_sourcer1 				AS "Sourcer ID"
   ,FR.primary_sourcer1_name 			AS "Sourcer Name"
   ,FR.cc_desc 
   ,FR.cc_legal_entity 	
   ,FR.COST_CENTER_OWNER 				AS "Cost Center Owner"		
   ,FR.functional_area 					AS "Cost Center Function"
   ,FR.currency 
   ,FR.PRODUCT_DESC_5					AS "Cost Center Product"
   --,FR.product_link 					AS "Cost Center Product"
   ,FR.market_associated 
   ,FR.HRYID
   ,FR.EFFECTIVE_START_DT
   ,TO_DATE(FR.appln_strt_dt,'YYYY-MM-DD')						AS "Application Submission Date"
   ,TO_DATE(FR.review_decision_date,'YYYY-MM-DD')				AS "Recruiter Review Date"
   ,TO_DATE(FR.manager_resume_review_date,'YYYY-MM-DD')			AS "Manager Resume Calibration Date"
   ,TO_DATE(FR.recruiter_phone_screen_date,'YYYY-MM-DD')		AS "TA Phone Screen Date"
   ,TO_DATE(FR.interview_assessment_date,'YYYY-MM-DD')			AS "Pre-Interview Assessment Date"
   ,TO_DATE(FR.manager_phone_screen_date,'YYYY-MM-DD')			AS "Manager Phone Interview Date"
   ,TO_DATE(FR.addl_interview_step_dt,'YYYY-MM-DD')				AS "1st_round_interview_date"
   ,TO_DATE(FR.additional_interview_date,'YYYY-MM-DD')			AS "2nd_round_interview_date"
   ,CASE WHEN FR.sex_desc  ='Unknown' THEN 'Unspecified' ELSE NVL(FR.sex_desc,'Unspecified') END AS "Applicant Gender"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(FR.sexual_orientation,'Unspecified') else 'Non-US' end	AS "Applicant Sexual Orientation (US)"
   --,FR.ethnic_group_custom_desc								AS "Applicant Ethnicity"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.APPLIACNT_DISABILITY_STATUS),'Unspecified') else 'Non-US' end AS "Applicant Disability Status (US)"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then
		CASE WHEN FR.worker_key != 0 AND FR.APPL_STAGE_WD = 'Hired' THEN NVL(INITCAP(FR.WORKER_VETERAN_STATUS),'Unspecified')
			 ELSE case WHEN FR.ATTR_MISC_DESC = 'United States'
                    THEN
                        CASE
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I AM NOT A VETERAN','I_AM_NOT_A_VETERAN')
                           THEN 'I am not a veteran'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I DO NOT WISH TO SELF-IDENTIFY','I_DO_NOT_WISH_TO_SELF_IDENTIFY')
                           THEN 'I do not wish to self-identify'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I IDENTIFY AS A VETERAN, JUST NOT A PROTECTED VETERAN','I_IDENTIFY_AS_A_VETERAN_JUST_NOT_A_PROTECTED_VETERAN')
                           THEN 'I identify as a veteran, just not a protected veteran'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I IDENTIFY AS ONE OR MORE OF THE CLASSIFICATIONS OF PROTECTED VETERANS LISTED ABOVE','I_IDENTIFY_AS_ONE_OR_MORE_OF_THE_CLASSIFICATIONS_OF_PROTECTED_VETERANS_LISTED_ABOVE')
                           THEN 'I identify as one or more of the classifications of protected veterans listed above'
                           else nvl(FR.APPL_VETERAN_STS_ON_RQSTN,'Unspecified')
                        END
                     ELSE
                        'Non-US'
					 END	
			 END ELSE 'Non-US' END AS  "Applicant Veteran Status (US)"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
			then
				CASE WHEN FR.gender_identity ='Unknown' 
						THEN 'Unspecified'
					 ELSE NVL(FR.gender_identity,'Unspecified') 
				END
			else 'Non-US' end AS "Applicant Gender Identity (US)"
   ,FR.APPLICANT_NUM											AS "Applicant Worker ID"
   ,FR.source_type_name 										AS "Candidate Source"
   ,FR.POSITION_TYPE											AS "Position Type"
   ,TO_DATE(FR.rqstn_opened_dt,'YYYY-MM-DD')					AS "Posted Date" 
   ,FR.DISPOSITION_STAGE 										as "Disposition Stage"
   ,FR.status_key												AS "Status Key"
   ,case when UPPER( (NVL (FR.DISPOSITION_REASON,'NOT DISPOSITIONED'))) NOT IN
							('CONFLICT OF INTEREST',
							'DID NOT PASS BACKGROUND CHECK',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EDUCATION)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EXPERIENCE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EXPERIENCE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (LICENSE/CERTIFICATE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (TRAVEL)',
							'NOT CONSIDERED -',
							'NOT CONSIDERED - NOT CONSIDERED',
							'NOT CONSIDERED (APPLIED POST OFFER)',
							'NOT CONSIDERED (NO REVIEW OF RESUME)',
							'OFFER RESCINDED REASON - DATA ENTRY ERROR ON APPROVED OFFER',
							'REASON FOR AGENCY SUBMISSION DECLINE - NEED CANDIDATE INFORMATION',
							'UNABLE TO CONTACT (AFTER 3 ATTEMPTS)',
							'UNCONSIDERED - DOES NOT MEET MINIMUM QUALIFICATIONS',
							'NOT PROGRESSED',
							'CANDIDATE CHOSE TO WITHDRAW FROM THE PROCESS',
							'CANDIDATE WITHDREW',
							'CANDIDATE WITHDREW - DECIDED TO STAY WITH CURRENT COMPANY (SAME EMPLOYER)',
							'CANDIDATE WITHDREW - PREFERS MORE FLEXIBILITY THAN G.FLEX PROGRAM ALLOWANCE',
							'CANDIDATE WITHDREW - RELOCATION',
							'CANDIDATE WITHDREW - SEEKING 100% REMOTE WORK',
							'CANDIDATE WITHDREW - VACCINE COMPLIANCE',
							'CURRENT COMPANY COUNTER-OFFERED',
							'DECIDED TO STAY WITH CURRENT COMPANY (SAME EMPLOYER)',
							'DOES NOT MEET BASIC QUALIFICATIONS PER SCREENING QUESTIONS',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (LANGUAGE SKILLS)',
							'NOT CONSIDERED - APPLICATION / TASKS INCOMPLETE',
							'NOT CONSIDERED - RESUME NOT REVIEWED',
							'NOT CONSIDERED (POSITION CANCELLED)',
							'NOT ELIGIBLE FOR REHIRE',
							'NOT INTERESTED - ACCEPTED AN OFFER FROM ANOTHER EMPLOYER',
							'NOT INTERESTED - COMPENSATION NOT AGREED/EXPECTATIONS NOT ALIGNED',
							'NOT INTERESTED - JOB TITLE/JOB LEVEL NOT ALIGNED',
							'REVIEW - BASIC QUALIFICATIONS NOT MET',
							'UNWILLING TO RELOCATE',
							'UNSPECIFIED')  AND UPPER(FR.w_stage_code)  NOT in ( UPPER('TA Phone Screen'),
							   UPPER('Manager Resume Calibration'),
                               UPPER('TA Resume Review'),
                               UPPER('Recruiter Review'),
                               UPPER('Application Submitted')) then 'Y' else 'N' end as qualified_flag
		,sl."% Female Qualified Applicants"
		,sl."% Minority Qualified Applicants"
		,NVL(x.diverse_applicant,'Unspecified') 	AS "Diverse Applicant"
	    ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_nodeval else fr.cc_nodeval end as cc_nodeval
		,CASE WHEN FR.cc_hier_key =0 then fjed.cc_nodename else fr.cc_nodename end as cc_nodename
		,FR.supervisor_num 		AS "Supervisor ID"
		,FR.WORKER_ID			AS "Worker ID"
		,FR.WORKER_NAME			AS "Worker Name"
		,NVL(FR.RECRUITER_ETHNICITY,'Unspecified') AS "Recruiter Ethnicity"
		,NVL(FR.APPLICANT_ETHNICITY,'Unspecified') AS "Applicant Ethnicity"
		,CAL.cal_date_key
		,FR.PRODUCT_DESC_1 
		,FR.PRODUCT_DESC_2
		,FR.PRODUCT_DESC_3
		,FR.PRODUCT_DESC_4
		,FR.PRODUCT_DESC_5
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL1_DESC else FR.CC_LEVEL1_DESC end as CC_LEVEL1_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL2_DESC else FR.CC_LEVEL2_DESC end as CC_LEVEL2_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL3_DESC else FR.CC_LEVEL3_DESC end as CC_LEVEL3_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL4_DESC else FR.CC_LEVEL4_DESC end as CC_LEVEL4_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL5_DESC else FR.CC_LEVEL5_DESC end as CC_LEVEL5_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL6_DESC else FR.CC_LEVEL6_DESC end as CC_LEVEL6_DESC
        ,case when FR.cc_hier_key=0 then fjed.CC_LEVEL7_DESC else FR.CC_LEVEL7_DESC end as CC_LEVEL7_DESC
		,FR.job_req_tag1
		,FR.job_req_tag2
		,FR.job_req_tag3
		,FR.job_req_tag4
		,FR.job_req_tag5
		,FR.job_req_tag6
		,FR.job_req_tag7
		,FR.job_req_tag8
		,FR.job_req_tag9
		,FR.job_req_tag10
		,CASE 
			--WHEN (sl.total_diverse_applicants / sl.total_qlf_applicant)* 100 >= 25   
			WHEN sl."% Minority Qualified Applicants" >=25 and sl."% Female Qualified Applicants" >=25 THEN 'Y' 
			WHEN sl."% Minority Qualified Applicants" IS NULL and sl."% Female Qualified Applicants" IS NULL THEN 'NA' 
			ELSE 'N' END AS "Has Diverse Slate"
		,FR.MOST_RECENT_ADVANCEMENT_DATE
		,(select load_date from load_dt_cte) as LOAD_DT
		,fjes.orig_perf_rating
		,fjes.orig_perf_rating_prv
		,CASE WHEN fjes.talent_quadrant ='' THEN NULL ELSE fjes.talent_quadrant END AS talent_quadrant
		,CASE WHEN fjes.talent_quadrant_prv ='' THEN NULL ELSE fjes.talent_quadrant_prv END AS talent_quadrant_prv
		,FR.EVENT_SEQ
		,FR.LOGIN
		,FR.COST_CENTER_OWNER 
		,FR.site_cc_level1_value
		,FR.site_cc_level2_value
		,FR.site_cc_level3_value
		,FR.site_cc_level4_value
		,FR.site_cc_level5_value
		,FR.site_cc_level6_value
		,FR.site_cc_level7_value
		,FR.site_CC_LEVEL1_DESC 
		,FR.site_CC_LEVEL2_DESC 
		,FR.site_CC_LEVEL3_DESC 
		,FR.site_CC_LEVEL4_DESC 
		,FR.site_CC_LEVEL5_DESC 
		,FR.site_CC_LEVEL6_DESC 
		,FR.site_CC_LEVEL7_DESC 
		,FR.FUNCTIONAL_AREA_DESC
		,'Total Gilead' AS company_level1_val
		,'Total Gilead' AS company_level1_desc
		,FR.COMPANY AS company_level2_val
		/*,case when FR.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
								'1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
								'2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
								'1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
			then 'Kite' else 'Gilead' 
		end AS company_level2_val */
		,FR.COMPANY AS company_level2_desc
		/*,case when FR.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
								'1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
								'2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
								'1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
			then 'Kite' else 'Gilead' 
		end AS company_level2_desc */
		,CC_OWNER_LEVEL1_EMP_FULL_NAME
		,CC_OWNER_LEVEL2_EMP_FULL_NAME
		,CC_OWNER_LEVEL3_EMP_FULL_NAME
		,CC_OWNER_LEVEL4_EMP_FULL_NAME
		,CC_OWNER_LEVEL5_EMP_FULL_NAME
		,CC_OWNER_LEVEL6_EMP_FULL_NAME
		,CC_OWNER_LEVEL7_EMP_FULL_NAME
		,CC_OWNER_LEVEL8_EMP_FULL_NAME
		,CC_OWNER_LEVEL9_EMP_FULL_NAME
		,CC_OWNER_LEVEL10_EMP_FULL_NAME
		,CC_OWNER_LEVEL11_EMP_FULL_NAME
		,CC_OWNER_LEVEL1_EMP_LOGIN
		,CC_OWNER_LEVEL2_EMP_LOGIN
		,CC_OWNER_LEVEL3_EMP_LOGIN
		,CC_OWNER_LEVEL4_EMP_LOGIN
		,CC_OWNER_LEVEL5_EMP_LOGIN
		,CC_OWNER_LEVEL6_EMP_LOGIN
		,CC_OWNER_LEVEL7_EMP_LOGIN
		,CC_OWNER_LEVEL8_EMP_LOGIN
		,CC_OWNER_LEVEL9_EMP_LOGIN
		,CC_OWNER_LEVEL10_EMP_LOGIN
		,CC_OWNER_LEVEL11_EMP_LOGIN
		,FR.JOB_REQ_STAGE
		,FR.FACT_OFFR_EXTD_DT
		,FR.FACT_OFFR_ACPT_DT
		,FR.WORKER_SEX_DESC
		,CASE WHEN FR.source_type_name IN ('Contractor Conversion','Current Associated Worker','Referral','Rehire') THEN 'Referral, Rehire or Contingent Worker Conversion'
			  WHEN FR.source_type_name IN ('Internal Employee') THEN 'Internal'
			  WHEN FR.source_type_name IN ('Staffing Agency')  THEN 'Staffing Agency'
			  ELSE 'Other External Source'
		 END AS "Hired Applicant Recruitment Source (Group)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_SEXUAL_ORIENTATION),'Unspecified') else 'Non-US' end AS "Worker Sexual Orientation (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_DISABILITY_STATUS),'Unspecified') else 'Non-US' end AS "Worker Disability Status (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_VETERAN_STATUS),'Unspecified') else 'Non-US' end AS  "Worker Veteran Status (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
				then 
					CASE WHEN FR.WORKER_GENDER_IDENTITY ='Unknown' 
							THEN 'Unspecified'
						ELSE NVL(FR.WORKER_GENDER_IDENTITY,'Unspecified') 
					END
				else 'Non-US' end AS "Worker Gender Identity (US)"
		,TO_DATE(FR.WORKER_ORIG_HIRE_DT,'YYYY-MM-DD')		AS WORKER_ORIG_HIRE_DT
		,x.FEMALE_SCORE
		,x.VETERANSTATUS_SCORE
		,x.DISABILITY_SCORE
		,x.ETHNIC_HISPANIC_SCORE
		,x.ETHNIC_ASIAN_SCORE
		,x.ETHNIC_BLACK_SCORE
		,x.ETHNIC_GROUP_SCORE
		,x.LESBIAN_SCORE
		,x.GAY_SCORE
		,x.BISEXUAL_SCORE
		,x.TRANSGENDER_SCORE				
		,case when max(FR.EVENT_SEQ) over (partition by FR.rqstn_key,coalesce(FR.worker_key ,FR.applicant_key),FR.applicant_key,FR.event_dt_key,FR.appl_stage_wd) = FR.EVENT_SEQ 
				then 'Y' 
				else 'N' 
		 end as MAX_EVENT_SEQ_FLG
		,x.GENDER_PREFINAL
		,x.VETERAN_STATUS_PREFINAL
		,x.DISABILITY_PREFINAL
		,x.ETHNIC_GROUP_PREFINAL
		,x.SEXUALORIENTATION AS SEXUALORIENTATION_PREFINAL
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.current_level1_emp_login,''),'|'),NVL(FR.current_level2_emp_login,'')),'|'), NVL(FR.current_level3_emp_login,'')),'|'),NVL(FR.current_level4_emp_login,'')),'|'),NVL(FR.current_level5_emp_login,'')),'|'),NVL(FR.current_level6_emp_login,'')),'|'),NVL(FR.current_level7_emp_login,'')),'|'),NVL(FR.current_level8_emp_login,'')),'|'),NVL(FR.current_level9_emp_login,'')),'|'),NVL(FR.current_level10_emp_login,'')),'|'),NVL(FR.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.product_value1,''),'|'),NVL(FR.product_value2,'')),'|'),NVL(FR.product_value3,'')),'|'),NVL(FR.product_value4,'')),'|'), NVL(FR.product_value5,'')),'|')) as PRODUCT_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.level1_val,''),'|'),NVL(FR.level2_val,'')),'|'), NVL(FR.level3_val,'')),'|'),NVL(FR.level4_val,'')),'|'),NVL(FR.level5_val,'')),'|'),NVL(FR.level6_val,'')),'|'),NVL(FR.level7_val,'')),'|'),NVL(FR.level8_val,'')),'|'),NVL(FR.level9_val,'')),'|'),NVL(FR.level10_val,'')),'|'),NVL(FR.level11_val,'')),'|'),NVL(FR.level12_val,'')),'|'),NVL(FR.level13_val,'')),'|')) as LOCATION_HIER_LIST 
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.cc_hier_level1,''),'|'),NVL(FR.cc_hier_level2,'')),'|'),NVL(FR.cc_hier_level3,'')),'|'),NVL(FR.cc_hier_level4,'')),'|'), NVL(FR.cc_hier_level5,'')),'|'),NVL(FR.cc_hier_level6,'')),'|'),NVL(FR.cc_hier_level7,'')),'|')) as COST_CENTER_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.le_hier_level1_val,''),'|'),NVL(FR.le_hier_level2_val,'')),'|'),NVL(FR.le_hier_level3_val,'')),'|'),NVL(FR.le_hier_level4_val,'')),'|'), NVL(FR.le_hier_level5_val,'')),'|'),NVL(FR.le_hier_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.site_cc_level1_value,''),'|'),NVL(FR.site_cc_level2_value,'')),'|'),NVL(FR.site_cc_level3_value,'')),'|'),NVL(FR.site_cc_level4_value,'')),'|'), NVL(FR.site_cc_level5_value,'')),'|'),NVL(FR.site_cc_level6_value,'')),'|'),NVL(FR.site_cc_level7_value,'')),'|')) as COST_CENTER_SITE_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.CC_OWNER_LEVEL1_EMP_LOGIN,''),'|'),NVL(FR.CC_OWNER_LEVEL2_EMP_LOGIN,'')),'|'), NVL(FR.CC_OWNER_LEVEL3_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL4_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL5_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL6_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL7_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL8_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL9_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL10_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL11_EMP_LOGIN,'')),'|')) as COST_CENTER_OWNER_HIER_LIST 
		,FR.COST_CENTER_OWNER_ID
		,case when FR.CONFIDENTIAL_JOB ='Yes' 
				then 
					case when FR.JS_HIRE_DT is not null and FR.JS_HIRE_DT >= (select load_date from load_dt_cte) then 'Y' 
						 when FR.JS_HIRE_DT is not null and FR.JS_HIRE_DT <  (select load_date from load_dt_cte) then 'N'
					else 'Y'
					end 
				else 'N' 
		 end as confidential_req_security_flag
		
FROM gna_load_schema.fact_rec_events_denormalized FR

JOIN gna_load_schema.dim_calendar CAL
	 ON  FR.event_dt_key = CAL.cal_date_key
	--and CAL.cal_date_key BETWEEN FR.start_dt_wid AND FR.end_dt_wid // No snapshotting for applicant data
	AND FR.EFFECTIVE_END_DT >= CAL.CALENDAR_DT
	AND FR.event_class = 'APPLICANT'
	and cal.calendar_dt between to_date ('2015-01-01','YYYY-MM-DD') and (select load_date from load_dt_cte) 
	--and cal.year_num between dateadd(year,-3,sysdate+1) and sysdate-1 --latest data load date to be included
	and rqstn_id in (select ds.source_id 
	                   from gna_load_schema.dim_rqstn ds
					  where ( ds.RQSTN_OPENED_DT > to_date ('2015-01-01','YYYY-MM-DD') or
                              ds.RQSTN_CREATED_DT > to_date ('2015-01-01','YYYY-MM-DD')))
							  
	left join gna_load_schema.fact_job_events_snapshot fjes 
     ON FR.worker_key = fjes.WORKER_KEY 
     and fjes.max_seq_ind =1
     and fjes.assignment_num =0
     AND FR.rqstn_key = fjes.rqstn_key 
     AND fr.EFFECTIVE_END_DT BETWEEN fjes.effective_start_dt  AND fjes.effective_end_dt
						  
	LEFT JOIN ( SELECT sl."RQSTN_KEY", sl.female_qlf_applicant, sl.ethnicity_qlf_applicant, sl.minority_qlf_applicant, sl.total_qlf_applicant, sl.total_diverse_applicants, round((sl.female_qlf_applicant * 1.0) / (COALESCE(sl.total_qlf_applicant, 0) * 1.0) * 100, 1) AS "% Female Qualified Applicants", round((sl.minority_qlf_applicant * 1.0) / (COALESCE(sl.total_qlf_applicant, 0) * 1.0) * 100, 1) AS "% Minority Qualified Applicants"
      FROM ( SELECT sl."RQSTN_KEY", count(DISTINCT 
                   CASE
                       WHEN sl."FEMALE_SCORE" = 1 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS female_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN sl."ETHNIC_GROUP_SCORE" = 1 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS ethnicity_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0)) > 0 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS minority_qlf_applicant, count(DISTINCT sl."APPLICANT_KEY") AS total_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0) + COALESCE(sl."FEMALE_SCORE", 0)) > 0 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS total_diverse_applicants
              FROM gna_load_schema.fact_rcrtmnt_events_slates_t1 sl
             GROUP BY sl."RQSTN_KEY") sl) sl ON fr.rqstn_key = sl."RQSTN_KEY"
			 
	LEFT JOIN (SELECT  sl."RQSTN_KEY",sl."APPLICANT_KEY" , 
					   case WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + 
					   			  COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0) + 
					   			  COALESCE(sl."FEMALE_SCORE", 0)) > 0 THEN      'Y'
					   				ELSE 'N'
					   END AS diverse_applicant 
					   ,"FEMALE_SCORE" as FEMALE_SCORE,"VETERANSTATUS_SCORE" as VETERANSTATUS_SCORE,"DISABILITY_SCORE" as DISABILITY_SCORE,"ETHNIC_HISPANIC_SCORE" as ETHNIC_HISPANIC_SCORE
					   ,"ETHNIC_ASIAN_SCORE" as ETHNIC_ASIAN_SCORE,"ETHNIC_BLACK_SCORE" as ETHNIC_BLACK_SCORE,"ETHNIC_GROUP_SCORE" as ETHNIC_GROUP_SCORE,"LESBIAN_SCORE" as LESBIAN_SCORE
					   ,"GAY_SCORE" as GAY_SCORE,"BISEXUAL_SCORE" as BISEXUAL_SCORE,"TRANSGENDER_SCORE" as TRANSGENDER_SCORE,"GENDER_PREFINAL" as GENDER_PREFINAL
					   ,"VETERAN_STATUS_PREFINAL" as VETERAN_STATUS_PREFINAL,"DISABILITY_PREFINAL" as DISABILITY_PREFINAL,"ETHNIC_GROUP_PREFINAL" as ETHNIC_GROUP_PREFINAL
					   ,"SEXUALORIENTATION" as SEXUALORIENTATION
			   FROM (SELECT   sl."RQSTN_KEY",sl."APPLICANT_KEY","ETHNIC_GROUP_SCORE","VETERANSTATUS_SCORE","DISABILITY_SCORE","LESBIAN_SCORE"
							,"GAY_SCORE","BISEXUAL_SCORE","TRANSGENDER_SCORE","FEMALE_SCORE" ,"ETHNIC_HISPANIC_SCORE","ETHNIC_ASIAN_SCORE","ETHNIC_BLACK_SCORE"
							,"GENDER_PREFINAL","VETERAN_STATUS_PREFINAL","DISABILITY_PREFINAL","ETHNIC_GROUP_PREFINAL","SEXUALORIENTATION" 
							,row_number() over(partition by sl."APPLICANT_KEY", sl."RQSTN_KEY" 
   				  					order by nvl("ETHNIC_GROUP_SCORE", 0) desc,nvl("VETERANSTATUS_SCORE", 0) desc,nvl("DISABILITY_SCORE", 0) desc, 
   				  							 nvl("LESBIAN_SCORE", 0) desc, nvl("GAY_SCORE", 0) desc,nvl("BISEXUAL_SCORE",0) desc,nvl("TRANSGENDER_SCORE",0) desc,
   				  							 nvl("FEMALE_SCORE",0) desc,nvl("ETHNIC_HISPANIC_SCORE",0) desc,nvl("ETHNIC_ASIAN_SCORE",0) desc,
											 nvl("ETHNIC_BLACK_SCORE",0) desc) as latest
					 FROM gna_load_schema.fact_rcrtmnt_events_slates_t1 sl 
					 ) sl
			   where sl.latest = 1           
			  ) x on FR.applicant_key = x."APPLICANT_KEY" 
				 and FR.rqstn_key = x."RQSTN_KEY"
	
	LEFT JOIN gna_load_schema.dim_worker dw 
		ON dw.source_id =FR.hiring_mgr_worker_id
		
	LEFT JOIN (select worker_key, start_dt_wid, end_dt_wid, max_seq_ind, cc_nodeval, cc_nodename, cc_level1_value, cc_level1_desc
					, cc_level2_value, cc_level2_desc, cc_level3_value, cc_level3_desc, cc_level4_value, cc_level4_desc
					, cc_level5_value, cc_level5_desc, cc_level6_value, cc_level6_desc, cc_level7_value, cc_level7_desc
					, le_level6_desc, le_level6_val
			  from gna_load_schema.fact_job_events_denormalized where max_seq_ind =1 )fjed
		ON fjed.worker_key =dw.worker_key 
	   AND FR.event_dt_key between fjed.start_dt_wid  and fjed.end_dt_wid
	
	where FR.event_class = 'APPLICANT'
							  
UNION ALL


SELECT 
    concat(concat(',',role_name_access_list),',') AS role_name_access_list --Defect 1438
   ,FR.event_class
   ,CAL.calendar_dt
   ,FR.applicant_id 								AS "Applicant ID"
   ,FR.applicant_name 								AS "Applicant Name"
   ,FR.dept_id 										AS "Cost Center ID"
   ,FR.dept_name 									AS "Cost Center Name"
   ,NULL AS dept_hier_level2_code
   ,NULL AS dept_hier_level2_desc
   ,FR.pay_grade_code  								AS "Pay Grade"
   ,FR.pay_grade_group 								AS "Pay Grade Group"
   ,FR.job_code 									AS "Job Code"
   ,FR.job_desc 									AS "Job Title"
   ,FR.rqstn_created_dt
   ,TO_DATE(FR.offr_acpt_dt ,'YYYY-MM-DD')			AS "Offer Accepted Date"
   ,TO_DATE(FR.offr_extd_dt ,'YYYY-MM-DD')			AS "Offer Extended Date"
   ,FR.req_filled_closed_dt
   ,TO_DATE(FR.rqstn_hold_dt,'YYYY-MM-DD') 			AS "Freeze Date"
   ,FR.job_posting_title 							AS "Job Posting Title"
   ,TO_DATE(FR.js_hire_dt ,'YYYY-MM-DD')			AS "Job Req Hire Date"
   ,FR.rqstn_id										AS "Job Req ID"
   ,FR.req_status
   ,FR.replacement_code								AS "Job Req Type"
   ,TO_DATE(FR.rqstn_opened_dt,'YYYY-MM-DD') 		AS "Opened Date"			
   ,FR.rqstn_off_hold_dt
   ,FR.replacement_worker_id 						AS "Replaced Employee ID"
   ,FR.replacement_name								AS "Replaced Employee Name"
   ,FR.position_id  								AS "Position ID"
   ,FR.custom_position_reason
   ,FR.recruiter_num
   ,FR.recruiter_name								AS "Recruiter Name"
   ,FR.x_custom
   ,FR.supervisor_num
   ,FR.supervisor_name
   ,FR.job_req_tag 									AS "Job Req Tag"
   ,FR.pending_approval
   ,FR.rqstn_open
   ,FR.on_hold
   ,FR.country_code
   ,FR.job_key
   ,FR.w_event_code
   ,FR.current_level1_emp_full_name 	
   ,FR.current_level2_emp_full_name 	
   ,FR.current_level3_emp_full_name 	
   ,FR.current_level4_emp_full_name 	
   ,FR.current_level5_emp_full_name 	
   ,FR.current_level6_emp_full_name 	
   ,FR.current_level7_emp_full_name 	
   ,FR.current_level8_emp_full_name 	
   ,FR.current_level9_emp_full_name 	
   ,FR.current_level10_emp_full_name 	
   ,FR.current_level11_emp_full_name 	
   ,FR.current_level1_emp_login
   ,FR.current_level2_emp_login
   ,FR.current_level3_emp_login
   ,FR.current_level4_emp_login
   ,FR.current_level5_emp_login
   ,FR.current_level6_emp_login
   ,FR.current_level7_emp_login
   ,FR.current_level8_emp_login
   ,FR.current_level9_emp_login
   ,FR.current_level10_emp_login
   ,FR.current_level11_emp_login
   ,FR.level1_desc
   ,FR.level2_desc
   ,FR.level3_desc
   ,FR.level4_desc
   ,FR.level5_desc
   ,FR.level6_desc
   ,FR.level7_desc
   ,FR.level8_desc
   ,FR.level9_desc
   ,FR.level10_desc
   ,FR.level11_desc
   ,FR.level12_desc
   ,FR.level13_desc
   ,FR.level1_val
   ,FR.level2_val
   ,FR.level3_val
   ,FR.level4_val
   ,FR.level5_val
   ,FR.level6_val
   ,FR.level7_val
   ,FR.level8_val
   ,FR.level9_val
   ,FR.level10_val
   ,FR.level11_val
   ,FR.level12_val
   ,FR.level13_val
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level1_value else FR.cc_hier_level1 end as cc_hier_level1
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level2_value else FR.cc_hier_level2 end as cc_hier_level2
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level3_value else FR.cc_hier_level3 end as cc_hier_level3
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level4_value else FR.cc_hier_level4 end as cc_hier_level4
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level5_value else FR.cc_hier_level5 end as cc_hier_level5
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level6_value else FR.cc_hier_level6 end as cc_hier_level6
   ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_level7_value else FR.cc_hier_level7 end as cc_hier_level7
   ,FR.worker_type_key
   ,FR.le_hier_level1_val
   ,FR.le_hier_level2_val
   ,FR.le_hier_level3_val
   ,FR.le_hier_level4_val
   ,FR.le_hier_level5_val
   ,CASE WHEN FR.le_hier_key =0 then fjed.le_level6_val else FR.le_hier_level6_val end as le_hier_level6_val
   ,FR.le_hier_level1_desc
   ,FR.le_hier_level2_desc
   ,FR.le_hier_level3_desc
   ,FR.le_hier_level4_desc
   ,FR.le_hier_level5_desc
   ,CASE WHEN FR.le_hier_key =0 then fjed.le_level6_desc else FR.le_hier_level6_desc end as le_hier_level6_desc
   ,FR.employee_cat_code
   ,FR.rqstn_name 		AS "Job Req Name"
   ,FR.event_cnt
   ,FR.rqstn_key
   ,FR.w_stage_code
   ,'Coming Soon' 			AS "Target Hire Date"
   ,FR.w_sub_stage_code
   ,FR.start_dt_wid
   ,FR.end_dt_wid
   ,FR.effective_end_dt
   ,FR.product_value1
   ,FR.product_value2
   ,FR.product_value3
   ,FR.product_value4
   ,FR.product_value5
   ,FR.cc_hier_key
   ,FR.le_hier_key
   ,FR.prod_hier_key
   ,FR.loc_hier_key
   ,FR.supervisor_hier_key
   ,FR.event_dt_key
   ,CASE WHEN FR.sex_desc  ='Unknown' THEN 'Unspecified' ELSE NVL(FR.sex_desc,'Unspecified') END			AS "Gender"
   ,FR.applicant_key
   ,FR.source_id
   ,FR.candidate_type 		AS "Candidate Type"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(FR.sexual_orientation,'Unspecified') else 'Non-US' end AS "Sexual Orientation"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
			then 
				CASE WHEN FR.gender_identity ='Unknown' 
						THEN 'Unspecified'
					 ELSE NVL(FR.gender_identity,'Unspecified') 
				END
			else 'Non-US' end "Gender Identity"
   ,FR.office_type			AS "Office Type"
   ,FR.veteran_status_desc	AS "Veteran Status"
   ,FR.disposition_reason
   ,TO_DATE(FR.disposition_date,'YYYY-MM-DD') as disposition_date
   ,FR.disposition_category
   ,FR.disposition_code
   ,FR.disposition_flg
   ,FR.manager_resume_review_date
   ,FR.recruiter_phone_screen_date
   ,TO_DATE(FR.ta_resume_review_date,'YYYY-MM-DD') as ta_resume_review_date
   ,FR.assessment_date
   ,FR.manager_phone_screen_date
   ,FR.manager_resume_screen_date
   ,FR.review_decision_date
   ,FR.referrer_worker_id
   ,FR.referrer_name
   ,TO_DATE(FR.ADDL_INTERVIEW_STEP_DT,'YYYY-MM-DD')		as ADDL_INTERVIEW_STEP_DT		---"1st_round_interview_date"
   ,TO_DATE(FR.ADDITIONAL_INTERVIEW_DATE,'YYYY-MM-DD') 	as ADDITIONAL_INTERVIEW_DATE	--"2nd_round_interview_date"
   ,TO_DATE(FR.INTERVIEW_DT,'YYYY-MM-DD') 				as INTERVIEW_DT					--additional_interview_date
   ,FR.job_family_code 
   ,FR.status_desc 						AS "Job Req Status as of {End Date}"
   ,FR.job_family_desc 					AS "Job Family"
   ,FR.job_exempt_flg 					AS "Job Exempt"
   ,FR.fulltime_parttime 				AS "Full Time Flag"
   ,FR.employee_sub_cat_desc 			AS "Worker Type Sub Category Description"
   ,TO_DATE(FR.rqstn_off_hold_dt,'YYYY-MM-DD') 				AS "Reopened Date"
   --,FR.time_to_fill 					AS "Time to Fill"
   ,cast (0 as int)						AS "Time to Fill" --to be updated after fixing time to fill in pyspark
   ,FR.total_applicants 				AS "Total Applicants"
   ,FR.total_active_applicants 			AS "Total Active/Undispositioned Applicants"
   ,sl.total_diverse_applicants 		AS "Total Diverse Applicants"
   ,FR.job_req_comments 				AS "Job Req Notes"
   ,FR.job_req_comments_author_name 	AS "Job Req Notes Author"
   ,TO_DATE(FR.job_req_comments_dt ,'YYYY-MM-DD')			AS "Job Req Notes Date"
   ,FR.attribute_type
   ,FR.worker_key
   ,FR.hire_evnt_cnt
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then nvl(FR.ethnic_group_custom_desc,'Unspecified') else 'Non-US' end AS "Ethnicity (US)"
   ,FR.appl_race_on_rqstn
   ,FR.dim_rcrtmnt_evt_key
   ,FR.appl_veteran_sts_on_rqstn
   ,FR.appl_disability_sts_on_rqstn
   ,FR.appln_strt_dt
   ,FR.reference_check_date
   ,TO_DATE(FR.interview_assessment_date,'YYYY-MM-DD') AS interview_assessment_date
   ,FR.appl_stage_wd     				AS "Application Stage"
   ,FR.appl_step_wd
   ,FR.appl_sex_desc_on_rqstn
   ,FR.budget_id
   ,TO_DATE(FR.rqstn_filled_dt ,'YYYY-MM-DD')					AS "Job Req Filled Date"
   ,FR.rqstn_closed_dt 					AS "Job Req Closed Date "
   --,FR.status_code						AS "Job Req Stage"
   ,FR.JOB_REQ_STAGE					AS "Job Req Stage"
   ,FR.awr_gilead_tenure
   ,FR.hiest_degree
   ,FR.assignment_num
   ,FR.perf_band1
   ,FR.perf_band2
   ,FR.perf_band3
   ,FR.talent_quadrant_1
   ,FR.talent_quadrant_2
   ,FR.talent_quadrant_3
   ,FR.job_title
   ,FR.continuous_service_dt
   ,FR.time_to_hire_req 				AS "Time to Hire"
   ,FR.cost_center_name 				AS "Cost Center Level 2 Name"
   ,FR.primary_sourcer1 				
   ,FR.primary_sourcer1_name 			
   ,FR.school_name 						AS "Highest Degree School Name"
   ,FR.age 								AS "Applicant Age"
   ,FR.orig_hire_dt						AS applicant_orig_hire_dt
   ,FR.HIEST_EDU_DEG_NAME				AS "Highest Education Degree Name"
   ,FR.EMPLOYMENT_STAT_DESC				AS "Employement Status"
   ,FR.rehire_flag
   ,FR.sup_supervisor_flg
   ,FR.applicant_supervisor_flg
   ,FR.offer_accepted
   ,FR.total_no_of_offer
   ,TO_DATE(FR.birth_dt,'YYYY-MM-DD')	AS birth_dt
   ,FR.level2_desc_no_mgr 				AS "Geographic Location Level 2 Name"
   ,FR.POSITION_REASON 					AS "Position Reason"
   ,FR.HIRING_MANAGER_NAME 				AS "Hiring Manager Name"
   ,FR.HIRING_MGR_WORKER_ID 			AS "Hiring Manager Worker ID"
   ,FR.recruiter_num					AS "Recruiter ID"
   --,FR.RECRUITER_WORKER_ID 				AS "Recruiter ID"
   ,FR.Hired_Applicant_ID 				AS "Hired Applicant ID"
   ,FR.level13_desc						AS "Location Name"
   ,FR.source_type_name 				AS "Hired Applicant Recruitment Source"
   ,FR.source_code						AS "Hired Applicant Specific Recruitment Source"
   ,FR.cc_hier_level2 					AS "Cost Center Level 2 Code"
   ,FR.attr_misc_desc					AS "Country Name"
   ,FR.ASSIGNED_HR_BUSINESS_PARTNER 	AS "Assigned HR Business Partner"
   ,FR.Skills_First_Qualified_Req 		AS "Skills First Qualified Req?"
   ,FR.Offer_Acceptance_Rate			AS "Offer Acceptance Rate"
   ,FR.DAYS_OPEN						AS "Number of Days Open"
   ,DEMOGRAPHIC_DESC_CUSTOM 			AS "Disability Status"
   ,FR.hire_dt
   ,case when FR.w_sub_stage_code!='RQSTN_FILLED_CLOSED' THEN NULL ELSE FR.Hired_Applicant_Worker_ID END AS "Hired Applicant Worker ID"
   ,case when FR.w_sub_stage_code!='RQSTN_FILLED_CLOSED' THEN NULL ELSE FR.WORKER_NAME	END	AS "Hired Applicant Name"
   --,FR.applicant_name 					AS "Hired Applicant Name"			
   ,FR.rqstn_open_stg_cnt
   ,FR.primary_sourcer1 				AS "Sourcer ID"
   ,FR.primary_sourcer1_name 			AS "Sourcer Name"
   ,FR.cc_desc 
   ,FR.cc_legal_entity 	
   ,FR.COST_CENTER_OWNER 				AS "Cost Center Owner"		
   ,FR.functional_area 					AS "Cost Center Function"
   ,FR.currency
   ,FR.PRODUCT_DESC_5					AS "Cost Center Product"   
   --,FR.product_link 					AS "Cost Center Product"
   ,FR.market_associated 
   ,FR.HRYID
   ,FR.EFFECTIVE_START_DT
   ,TO_DATE(FR.appln_strt_dt,'YYYY-MM-DD')						AS "Application Submission Date"
   ,TO_DATE(FR.review_decision_date,'YYYY-MM-DD')				AS "Recruiter Review Date"
   ,TO_DATE(FR.manager_resume_review_date,'YYYY-MM-DD')			AS "Manager Resume Calibration Date"
   ,TO_DATE(FR.recruiter_phone_screen_date,'YYYY-MM-DD')		AS "TA Phone Screen Date"
   ,TO_DATE(FR.interview_assessment_date,'YYYY-MM-DD')			AS "Pre-Interview Assessment Date"
   ,TO_DATE(FR.manager_phone_screen_date,'YYYY-MM-DD')			AS "Manager Phone Interview Date"
   ,TO_DATE(FR.addl_interview_step_dt,'YYYY-MM-DD')				AS "1st_round_interview_date"
   ,TO_DATE(FR.additional_interview_date,'YYYY-MM-DD')			AS "2nd_round_interview_date"
   ,CASE WHEN FR.sex_desc  ='Unknown' THEN 'Unspecified' ELSE NVL(FR.sex_desc,'Unspecified') END AS "Applicant Gender"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(FR.sexual_orientation,'Unspecified') else 'Non-US' end	AS "Applicant Sexual Orientation (US)"
   --,FR.ethnic_group_custom_desc								AS "Applicant Ethnicity"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.APPLIACNT_DISABILITY_STATUS),'Unspecified') else 'Non-US' end AS "Applicant Disability Status (US)"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then
		CASE WHEN FR.worker_key != 0 AND FR.APPL_STAGE_WD = 'Hired' THEN NVL(INITCAP(FR.WORKER_VETERAN_STATUS),'Unspecified')
			 ELSE case WHEN FR.ATTR_MISC_DESC = 'United States'
                    THEN
                        CASE
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I AM NOT A VETERAN','I_AM_NOT_A_VETERAN')
                           THEN 'I am not a veteran'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I DO NOT WISH TO SELF-IDENTIFY','I_DO_NOT_WISH_TO_SELF_IDENTIFY')
                           THEN 'I do not wish to self-identify'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I IDENTIFY AS A VETERAN, JUST NOT A PROTECTED VETERAN','I_IDENTIFY_AS_A_VETERAN_JUST_NOT_A_PROTECTED_VETERAN')
                           THEN 'I identify as a veteran, just not a protected veteran'
                           WHEN FR.APPL_VETERAN_STS_ON_RQSTN in ('I IDENTIFY AS ONE OR MORE OF THE CLASSIFICATIONS OF PROTECTED VETERANS LISTED ABOVE','I_IDENTIFY_AS_ONE_OR_MORE_OF_THE_CLASSIFICATIONS_OF_PROTECTED_VETERANS_LISTED_ABOVE')
                           THEN 'I identify as one or more of the classifications of protected veterans listed above'
                           else nvl(FR.APPL_VETERAN_STS_ON_RQSTN,'Unspecified')
                        END
                     ELSE
                        'Non-US'
					 END	
			 END ELSE 'Non-US' END AS  "Applicant Veteran Status (US)"
   ,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
			then
				CASE WHEN FR.gender_identity ='Unknown' 
						THEN 'Unspecified'
					 ELSE NVL(FR.gender_identity,'Unspecified') 
				END
			else 'Non-US' end AS "Applicant Gender Identity (US)"
   ,FR.APPLICANT_NUM					AS "Applicant Worker ID"
   ,FR.source_type_name 				AS "Candidate Source"
   ,FR.POSITION_TYPE					AS "Position Type"
   ,TO_DATE(FR.rqstn_opened_dt,'YYYY-MM-DD')					AS "Posted Date" 
   ,FR.DISPOSITION_STAGE 				as "Disposition Stage"
   ,CASE WHEN FR.status_key	= 34024 then 100037 when FR.status_key =34012 then 100033 else FR.status_key end AS "Status Key" --only for event_class='JOB_RQSTN'
   ,case when UPPER( (NVL (FR.DISPOSITION_REASON,'NOT DISPOSITIONED'))) NOT IN
							('CONFLICT OF INTEREST',
							'DID NOT PASS BACKGROUND CHECK',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EDUCATION)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EXPERIENCE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (EXPERIENCE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (LICENSE/CERTIFICATE)',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (TRAVEL)',
							'NOT CONSIDERED -',
							'NOT CONSIDERED - NOT CONSIDERED',
							'NOT CONSIDERED (APPLIED POST OFFER)',
							'NOT CONSIDERED (NO REVIEW OF RESUME)',
							'OFFER RESCINDED REASON - DATA ENTRY ERROR ON APPROVED OFFER',
							'REASON FOR AGENCY SUBMISSION DECLINE - NEED CANDIDATE INFORMATION',
							'UNABLE TO CONTACT (AFTER 3 ATTEMPTS)',
							'UNCONSIDERED - DOES NOT MEET MINIMUM QUALIFICATIONS',
							'NOT PROGRESSED',
							'CANDIDATE CHOSE TO WITHDRAW FROM THE PROCESS',
							'CANDIDATE WITHDREW',
							'CANDIDATE WITHDREW - DECIDED TO STAY WITH CURRENT COMPANY (SAME EMPLOYER)',
							'CANDIDATE WITHDREW - PREFERS MORE FLEXIBILITY THAN G.FLEX PROGRAM ALLOWANCE',
							'CANDIDATE WITHDREW - RELOCATION',
							'CANDIDATE WITHDREW - SEEKING 100% REMOTE WORK',
							'CANDIDATE WITHDREW - VACCINE COMPLIANCE',
							'CURRENT COMPANY COUNTER-OFFERED',
							'DECIDED TO STAY WITH CURRENT COMPANY (SAME EMPLOYER)',
							'DOES NOT MEET BASIC QUALIFICATIONS PER SCREENING QUESTIONS',
							'DOES NOT MEET MINIMUM QUALIFICATIONS (LANGUAGE SKILLS)',
							'NOT CONSIDERED - APPLICATION / TASKS INCOMPLETE',
							'NOT CONSIDERED - RESUME NOT REVIEWED',
							'NOT CONSIDERED (POSITION CANCELLED)',
							'NOT ELIGIBLE FOR REHIRE',
							'NOT INTERESTED - ACCEPTED AN OFFER FROM ANOTHER EMPLOYER',
							'NOT INTERESTED - COMPENSATION NOT AGREED/EXPECTATIONS NOT ALIGNED',
							'NOT INTERESTED - JOB TITLE/JOB LEVEL NOT ALIGNED',
							'REVIEW - BASIC QUALIFICATIONS NOT MET',
							'UNWILLING TO RELOCATE',
							'UNSPECIFIED')  AND UPPER(FR.w_stage_code)  NOT in ( UPPER('TA Phone Screen'),
							   UPPER('Manager Resume Calibration'),
                               UPPER('TA Resume Review'),
                               UPPER('Recruiter Review'),
                               UPPER('Application Submitted')) then 'Y' else 'N' end as qualified_flag
		,sl."% Female Qualified Applicants"
		,sl."% Minority Qualified Applicants"
		,NVL(x.diverse_applicant,'Unspecified') AS "Diverse Applicant"
	    ,CASE WHEN FR.cc_hier_key =0 then fjed.cc_nodeval else fr.cc_nodeval end as cc_nodeval
		,CASE WHEN FR.cc_hier_key =0 then fjed.cc_nodename else fr.cc_nodename end as cc_nodename
		,FR.supervisor_num  AS "Supervisor ID"
		,FR.WORKER_ID		AS "Worker ID"
		,FR.WORKER_NAME		AS "Worker Name"
		,NVL(FR.RECRUITER_ETHNICITY,'Unspecified') AS "Recruiter Ethnicity"
		,NVL(FR.APPLICANT_ETHNICITY,'Unspecified') AS "Applicant Ethnicity"
		,CAL.cal_date_key
		,FR.PRODUCT_DESC_1
        ,FR.PRODUCT_DESC_2
        ,FR.PRODUCT_DESC_3
        ,FR.PRODUCT_DESC_4
        ,FR.PRODUCT_DESC_5
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL1_DESC else FR.CC_LEVEL1_DESC end as CC_LEVEL1_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL2_DESC else FR.CC_LEVEL2_DESC end as CC_LEVEL2_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL3_DESC else FR.CC_LEVEL3_DESC end as CC_LEVEL3_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL4_DESC else FR.CC_LEVEL4_DESC end as CC_LEVEL4_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL5_DESC else FR.CC_LEVEL5_DESC end as CC_LEVEL5_DESC
		,case when FR.cc_hier_key=0 then fjed.CC_LEVEL6_DESC else FR.CC_LEVEL6_DESC end as CC_LEVEL6_DESC
        ,case when FR.cc_hier_key=0 then fjed.CC_LEVEL7_DESC else FR.CC_LEVEL7_DESC end as CC_LEVEL7_DESC
		,FR.job_req_tag1
		,FR.job_req_tag2
		,FR.job_req_tag3
		,FR.job_req_tag4
		,FR.job_req_tag5
		,FR.job_req_tag6
		,FR.job_req_tag7
		,FR.job_req_tag8
        ,FR.job_req_tag9
	    ,FR.job_req_tag10
		,CASE 
			--WHEN (sl.total_diverse_applicants / sl.total_qlf_applicant)* 100 >= 25   
			WHEN sl."% Minority Qualified Applicants" >=25 and sl."% Female Qualified Applicants" >=25 THEN 'Y' 
			WHEN sl."% Minority Qualified Applicants" IS NULL and sl."% Female Qualified Applicants" IS NULL THEN 'NA'
			ELSE 'N' END AS "Has Diverse Slate"
		,FR.MOST_RECENT_ADVANCEMENT_DATE
		,(select load_date from load_dt_cte) as LOAD_DT
		,fjes.orig_perf_rating
		,fjes.orig_perf_rating_prv
		,CASE WHEN fjes.talent_quadrant ='' THEN NULL ELSE fjes.talent_quadrant END AS talent_quadrant
		,CASE WHEN fjes.talent_quadrant_prv ='' THEN NULL ELSE fjes.talent_quadrant_prv END AS talent_quadrant_prv
		,FR.EVENT_SEQ
		,FR.LOGIN
		,FR.COST_CENTER_OWNER 
		,FR.site_cc_level1_value
		,FR.site_cc_level2_value
		,FR.site_cc_level3_value
		,FR.site_cc_level4_value
		,FR.site_cc_level5_value
		,FR.site_cc_level6_value
		,FR.site_cc_level7_value
		,FR.site_CC_LEVEL1_DESC 
		,FR.site_CC_LEVEL2_DESC 
		,FR.site_CC_LEVEL3_DESC 
		,FR.site_CC_LEVEL4_DESC 
		,FR.site_CC_LEVEL5_DESC 
		,FR.site_CC_LEVEL6_DESC 
		,FR.site_CC_LEVEL7_DESC 
		,FR.FUNCTIONAL_AREA_DESC
		,'Total Gilead' AS company_level1_val
		,'Total Gilead' AS company_level1_desc
		,FR.COMPANY AS company_level2_val
		/*,case when FR.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
								'1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
								'2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
								'1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
			then 'Kite' else 'Gilead' 
		end AS company_level2_val */
		,FR.COMPANY AS company_level2_desc
		/*,case when FR.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
								'1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
								'2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
								'1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
			then 'Kite' else 'Gilead' 
		end AS company_level2_desc */
		,CC_OWNER_LEVEL1_EMP_FULL_NAME
		,CC_OWNER_LEVEL2_EMP_FULL_NAME
		,CC_OWNER_LEVEL3_EMP_FULL_NAME
		,CC_OWNER_LEVEL4_EMP_FULL_NAME
		,CC_OWNER_LEVEL5_EMP_FULL_NAME
		,CC_OWNER_LEVEL6_EMP_FULL_NAME
		,CC_OWNER_LEVEL7_EMP_FULL_NAME
		,CC_OWNER_LEVEL8_EMP_FULL_NAME
		,CC_OWNER_LEVEL9_EMP_FULL_NAME
		,CC_OWNER_LEVEL10_EMP_FULL_NAME
		,CC_OWNER_LEVEL11_EMP_FULL_NAME
		,CC_OWNER_LEVEL1_EMP_LOGIN
		,CC_OWNER_LEVEL2_EMP_LOGIN
		,CC_OWNER_LEVEL3_EMP_LOGIN
		,CC_OWNER_LEVEL4_EMP_LOGIN
		,CC_OWNER_LEVEL5_EMP_LOGIN
		,CC_OWNER_LEVEL6_EMP_LOGIN
		,CC_OWNER_LEVEL7_EMP_LOGIN
		,CC_OWNER_LEVEL8_EMP_LOGIN
		,CC_OWNER_LEVEL9_EMP_LOGIN
		,CC_OWNER_LEVEL10_EMP_LOGIN
		,CC_OWNER_LEVEL11_EMP_LOGIN
		,FR.JOB_REQ_STAGE
		,FR.FACT_OFFR_EXTD_DT
		,FR.FACT_OFFR_ACPT_DT
		,FR.WORKER_SEX_DESC 
		,CASE WHEN FR.source_type_name IN ('Contractor Conversion','Current Associated Worker','Referral','Rehire') THEN 'Referral, Rehire or Contingent Worker Conversion'
			  WHEN FR.source_type_name IN ('Internal Employee') THEN 'Internal'
			  WHEN FR.source_type_name IN ('Staffing Agency')  THEN 'Staffing Agency'
			  ELSE 'Other External Source'
		 END AS "Hired Applicant Recruitment Source (Group)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_SEXUAL_ORIENTATION),'Unspecified') else 'Non-US' end AS "Worker Sexual Orientation (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_DISABILITY_STATUS),'Unspecified') else 'Non-US' end AS "Worker Disability Status (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' then NVL(INITCAP(FR.WORKER_VETERAN_STATUS),'Unspecified') else 'Non-US' end AS  "Worker Veteran Status (US)"
		,CASE WHEN FR.ATTR_MISC_DESC = 'United States' 
				then 
					CASE WHEN FR.WORKER_GENDER_IDENTITY ='Unknown' 
							THEN 'Unspecified'
						ELSE NVL(FR.WORKER_GENDER_IDENTITY,'Unspecified')
					END
				else 'Non-US' end AS "Worker Gender Identity (US)"
		,TO_DATE(FR.WORKER_ORIG_HIRE_DT,'YYYY-MM-DD')		AS WORKER_ORIG_HIRE_DT
		,x.FEMALE_SCORE
		,x.VETERANSTATUS_SCORE
		,x.DISABILITY_SCORE
		,x.ETHNIC_HISPANIC_SCORE
		,x.ETHNIC_ASIAN_SCORE
		,x.ETHNIC_BLACK_SCORE
		,x.ETHNIC_GROUP_SCORE
		,x.LESBIAN_SCORE
		,x.GAY_SCORE
		,x.BISEXUAL_SCORE
		,x.TRANSGENDER_SCORE
		,case when max(FR.EVENT_SEQ) over (partition by FR.rqstn_key,coalesce(FR.worker_key ,FR.applicant_key),FR.applicant_key,FR.event_dt_key,FR.appl_stage_wd) = FR.EVENT_SEQ 
				then 'Y' 
				else 'N' 
		 end as MAX_EVENT_SEQ_FLG
		,x.GENDER_PREFINAL
		,x.VETERAN_STATUS_PREFINAL
		,x.DISABILITY_PREFINAL
		,x.ETHNIC_GROUP_PREFINAL
		,x.SEXUALORIENTATION AS SEXUALORIENTATION_PREFINAL
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.current_level1_emp_login,''),'|'),NVL(FR.current_level2_emp_login,'')),'|'), NVL(FR.current_level3_emp_login,'')),'|'),NVL(FR.current_level4_emp_login,'')),'|'),NVL(FR.current_level5_emp_login,'')),'|'),NVL(FR.current_level6_emp_login,'')),'|'),NVL(FR.current_level7_emp_login,'')),'|'),NVL(FR.current_level8_emp_login,'')),'|'),NVL(FR.current_level9_emp_login,'')),'|'),NVL(FR.current_level10_emp_login,'')),'|'),NVL(FR.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.product_value1,''),'|'),NVL(FR.product_value2,'')),'|'),NVL(FR.product_value3,'')),'|'),NVL(FR.product_value4,'')),'|'), NVL(FR.product_value5,'')),'|')) as PRODUCT_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.level1_val,''),'|'),NVL(FR.level2_val,'')),'|'), NVL(FR.level3_val,'')),'|'),NVL(FR.level4_val,'')),'|'),NVL(FR.level5_val,'')),'|'),NVL(FR.level6_val,'')),'|'),NVL(FR.level7_val,'')),'|'),NVL(FR.level8_val,'')),'|'),NVL(FR.level9_val,'')),'|'),NVL(FR.level10_val,'')),'|'),NVL(FR.level11_val,'')),'|'),NVL(FR.level12_val,'')),'|'),NVL(FR.level13_val,'')),'|')) as LOCATION_HIER_LIST 
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.cc_hier_level1,''),'|'),NVL(FR.cc_hier_level2,'')),'|'),NVL(FR.cc_hier_level3,'')),'|'),NVL(FR.cc_hier_level4,'')),'|'), NVL(FR.cc_hier_level5,'')),'|'),NVL(FR.cc_hier_level6,'')),'|'),NVL(FR.cc_hier_level7,'')),'|')) as COST_CENTER_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.le_hier_level1_val,''),'|'),NVL(FR.le_hier_level2_val,'')),'|'),NVL(FR.le_hier_level3_val,'')),'|'),NVL(FR.le_hier_level4_val,'')),'|'), NVL(FR.le_hier_level5_val,'')),'|'),NVL(FR.le_hier_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.site_cc_level1_value,''),'|'),NVL(FR.site_cc_level2_value,'')),'|'),NVL(FR.site_cc_level3_value,'')),'|'),NVL(FR.site_cc_level4_value,'')),'|'), NVL(FR.site_cc_level5_value,'')),'|'),NVL(FR.site_cc_level6_value,'')),'|'),NVL(FR.site_cc_level7_value,'')),'|')) as COST_CENTER_SITE_HIER_LIST
		,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FR.CC_OWNER_LEVEL1_EMP_LOGIN,''),'|'),NVL(FR.CC_OWNER_LEVEL2_EMP_LOGIN,'')),'|'), NVL(FR.CC_OWNER_LEVEL3_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL4_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL5_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL6_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL7_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL8_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL9_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL10_EMP_LOGIN,'')),'|'),NVL(FR.CC_OWNER_LEVEL11_EMP_LOGIN,'')),'|')) as COST_CENTER_OWNER_HIER_LIST 
		,FR.COST_CENTER_OWNER_ID
		,case when FR.CONFIDENTIAL_JOB ='Yes' 
				then 
					case when FR.JS_HIRE_DT is not null and FR.JS_HIRE_DT >= (select load_date from load_dt_cte) then 'Y' 
						 when FR.JS_HIRE_DT is not null and FR.JS_HIRE_DT <  (select load_date from load_dt_cte) then 'N'
					else 'Y'
					end 
				else 'N' 
		 end as confidential_req_security_flag
		
   FROM gna_load_schema.fact_rec_events_denormalized FR

   JOIN gna_load_schema.dim_calendar CAL
	 ON CAL.cal_date_key BETWEEN FR.start_dt_wid AND FR.end_dt_wid
	--AND FR.EFFECTIVE_END_DT >= CAL.CALENDAR_DT
	AND FR.event_class = 'JOB_RQSTN'
	AND case when FR.status_key  in ('100033' ,'100029','100037','34012','34024') 
               then  FR.EFFECTIVE_START_DT else  FR.EFFECTIVE_END_DT end >= CAL.CALENDAR_DT
	and cal.calendar_dt between to_date ('2015-01-01','YYYY-MM-DD') and (select load_date from load_dt_cte) 
	--and cal.year_num between dateadd(year,-3,sysdate+1) and sysdate-1 --latest data load date to be included
	and rqstn_id in (select ds.source_id 
	                   from gna_load_schema.dim_rqstn ds
					  where ( ds.RQSTN_OPENED_DT > to_date ('2015-01-01','YYYY-MM-DD') or
                              ds.RQSTN_CREATED_DT > to_date ('2015-01-01','YYYY-MM-DD')))
							  
	left join gna_load_schema.fact_job_events_snapshot fjes 
     ON FR.worker_key = fjes.WORKER_KEY 
     and fjes.max_seq_ind =1
     and fjes.assignment_num =0
     AND FR.rqstn_key = fjes.rqstn_key 
     AND fr.EFFECTIVE_END_DT BETWEEN fjes.effective_start_dt  AND fjes.effective_end_dt						  
							  
							  
	LEFT JOIN ( SELECT sl."RQSTN_KEY", sl.female_qlf_applicant, sl.ethnicity_qlf_applicant, sl.minority_qlf_applicant, sl.total_qlf_applicant, sl.total_diverse_applicants, round((sl.female_qlf_applicant * 1.0)/ (COALESCE(sl.total_qlf_applicant, 0) * 1.0) * 100, 1) AS "% Female Qualified Applicants", round((sl.minority_qlf_applicant * 1.0)/ (COALESCE(sl.total_qlf_applicant, 0) * 1.0) * 100, 1) AS "% Minority Qualified Applicants"
      FROM ( SELECT sl."RQSTN_KEY", count(DISTINCT 
                   CASE
                       WHEN sl."FEMALE_SCORE" = 1 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS female_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN sl."ETHNIC_GROUP_SCORE" = 1 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS ethnicity_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0)) > 0 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS minority_qlf_applicant, count(DISTINCT sl."APPLICANT_KEY") AS total_qlf_applicant, count(DISTINCT 
                   CASE
                       WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0) + COALESCE(sl."FEMALE_SCORE", 0)) > 0 THEN sl."APPLICANT_KEY"
                       ELSE NULL
                   END) AS total_diverse_applicants
              FROM gna_load_schema.fact_rcrtmnt_events_slates_t1 sl
             GROUP BY sl."RQSTN_KEY") sl) sl ON fr.rqstn_key = sl."RQSTN_KEY"
			 
	LEFT JOIN (SELECT  sl."RQSTN_KEY",sl."APPLICANT_KEY" , 
					   case WHEN (COALESCE(sl."ETHNIC_GROUP_SCORE", 0) + COALESCE(sl."VETERANSTATUS_SCORE", 0) + COALESCE(sl."DISABILITY_SCORE", 0) + 
					   			  COALESCE(sl."LESBIAN_SCORE", 0) + COALESCE(sl."GAY_SCORE", 0) + COALESCE(sl."BISEXUAL_SCORE", 0) + COALESCE(sl."TRANSGENDER_SCORE", 0) + 
					   			  COALESCE(sl."FEMALE_SCORE", 0)) > 0 THEN      'Y'
					   				ELSE 'N'
					   END AS diverse_applicant 
					   ,"FEMALE_SCORE" as FEMALE_SCORE,"VETERANSTATUS_SCORE" as VETERANSTATUS_SCORE,"DISABILITY_SCORE" as DISABILITY_SCORE,"ETHNIC_HISPANIC_SCORE" as ETHNIC_HISPANIC_SCORE
					   ,"ETHNIC_ASIAN_SCORE" as ETHNIC_ASIAN_SCORE,"ETHNIC_BLACK_SCORE" as ETHNIC_BLACK_SCORE,"ETHNIC_GROUP_SCORE" as ETHNIC_GROUP_SCORE,"LESBIAN_SCORE" as LESBIAN_SCORE
					   ,"GAY_SCORE" as GAY_SCORE,"BISEXUAL_SCORE" as BISEXUAL_SCORE,"TRANSGENDER_SCORE" as TRANSGENDER_SCORE,"GENDER_PREFINAL" as GENDER_PREFINAL
					   ,"VETERAN_STATUS_PREFINAL" as VETERAN_STATUS_PREFINAL,"DISABILITY_PREFINAL" as DISABILITY_PREFINAL,"ETHNIC_GROUP_PREFINAL" as ETHNIC_GROUP_PREFINAL
					   ,"SEXUALORIENTATION" as SEXUALORIENTATION
			   FROM (SELECT   sl."RQSTN_KEY",sl."APPLICANT_KEY","ETHNIC_GROUP_SCORE","VETERANSTATUS_SCORE","DISABILITY_SCORE","LESBIAN_SCORE"
							,"GAY_SCORE","BISEXUAL_SCORE","TRANSGENDER_SCORE","FEMALE_SCORE" ,"ETHNIC_HISPANIC_SCORE","ETHNIC_ASIAN_SCORE","ETHNIC_BLACK_SCORE"
							,"GENDER_PREFINAL","VETERAN_STATUS_PREFINAL","DISABILITY_PREFINAL","ETHNIC_GROUP_PREFINAL","SEXUALORIENTATION" 
							,row_number() over(partition by sl."APPLICANT_KEY", sl."RQSTN_KEY" 
   				  					order by nvl("ETHNIC_GROUP_SCORE", 0) desc,nvl("VETERANSTATUS_SCORE", 0) desc,nvl("DISABILITY_SCORE", 0) desc, 
   				  							 nvl("LESBIAN_SCORE", 0) desc, nvl("GAY_SCORE", 0) desc,nvl("BISEXUAL_SCORE",0) desc,nvl("TRANSGENDER_SCORE",0) desc,
   				  							 nvl("FEMALE_SCORE",0) desc,nvl("ETHNIC_HISPANIC_SCORE",0) desc,nvl("ETHNIC_ASIAN_SCORE",0) desc,
											 nvl("ETHNIC_BLACK_SCORE",0) desc) as latest
					 FROM gna_load_schema.fact_rcrtmnt_events_slates_t1 sl 
					 ) sl
			   where sl.latest = 1           
			  ) x on FR.applicant_key = x."APPLICANT_KEY" 
				 and FR.rqstn_key = x."RQSTN_KEY"
	
	LEFT JOIN gna_load_schema.dim_worker dw 
		ON dw.source_id =FR.hiring_mgr_worker_id
		
	LEFT JOIN(select worker_key, start_dt_wid, end_dt_wid, max_seq_ind, cc_nodeval, cc_nodename, cc_level1_value, cc_level1_desc
					, cc_level2_value, cc_level2_desc, cc_level3_value, cc_level3_desc, cc_level4_value, cc_level4_desc
					, cc_level5_value, cc_level5_desc, cc_level6_value, cc_level6_desc, cc_level7_value, cc_level7_desc
					, le_level6_desc, le_level6_val
			  from gna_load_schema.fact_job_events_denormalized where max_seq_ind =1 )fjed
		ON fjed.worker_key =dw.worker_key  
	   AND FR.event_dt_key between fjed.start_dt_wid  and fjed.end_dt_wid

	where FR.event_class = 'JOB_RQSTN'
);				 
	
	


-- pap_view_schema.fact_rec_events_slates_denormalized_vw source;

CREATE VIEW pap_view_schema.fact_rec_events_slates_denormalized_vw AS
select 
   FRES.role_name_access_list 
   ,FRES.dept_id
   ,FRES.dept_name
   ,FRES.dept_hier_level2_code
   ,FRES.dept_hier_level2_desc
   ,FRES.pay_grade_code            
   ,FRES.pay_grade_group
   ,FRES.job_code
   ,FRES.job_desc
   ,FRES.job_posting_title
   ,FRES.replacement_code
   ,FRES.attr_misc_desc 
   ,FRES.loc_hier_level2_desc
   ,FRES.loc_hier_level8_desc
   ,FRES.custom_position_reason
   ,FRES.employee_num 
   ,FRES.pref_full_name 
   ,FRES.employee_num recruiter_emp_num
   ,FRES.pref_full_name recruiter_name
   ,FRES.job_req_tag
   ,FRES.attr_misc_code 
   ,FRES.job_key
   ,FRES.effective_start_dt
   ,FRES.effective_end_dt
   ,FRES.EMPLOYEE_CAT_CODE
   ,FRES.EMPLOYEE_SUB_CAT_DESC
   ,FRES.start_dt_wid
   ,FRES.end_dt_wid
   ,FRES.VETERANSTATUS_SCORE
   ,FRES.ETHNIC_HISPANIC_SCORE
   ,FRES.FEMALE_SCORE
   ,FRES.DISABILITY_SCORE
   ,FRES.ETHNIC_ASIAN_SCORE
   ,FRES.ETHNIC_BLACK_SCORE
   ,FRES.APPL_VETERAN_STS_ON_RQSTN
   ,FRES.APPL_DISABILITY_STS_ON_RQSTN
   ,FRES.SEXUALORIENTATION
   ,FRES.req_status
   ,FRES.rqstn_id
   ,FRES.supervisor_name
   ,FRES.MINORITY_APPLICANT
   ,FRES.FEMALE_APPLICANT
   ,FRES.JOB_TITLE 
   ,FRES.CANDIDATE_TYPE
   ,FRES.SEXUAL_ORIENTATION
   ,FRES.GENDER_IDENTITY 
   ,FRES.SEX_DESC AS GENDER
   ,FRES.ETHNIC_GROUP_CUSTOM_DESC
   ,FRES.cost_center_name
   ,FRES.JOB_FAMILY_CODE
   ,FRES.JOB_FAMILY_DESC
   ,FRES.VETERAN_STATUS_DESC
   ,FRES.OFFICE_TYPE
   ,FRES.DISABILITY_STATUS
   ,FRES.w_stage_code
   ,FRES.w_sub_stage_code
   ,FRES.TOTAL_APPLICANTS
   ,FRES.RQSTN_CREATED_DT
   ,FRES.RQSTN_OPENED_DT
   ,FRES.RQSTN_HOLD_DT
   ,FRES.RQSTN_OFFHOLD_DT
   ,FRES.RQSTN_FILLED_DT
   ,FRES.HIRE_DT
   ,FRES.CC_NODEVAL
   ,FRES.CC_NODENAME
from 
	gna_load_schema.fact_rec_events_slates_denormalized FRES
;


	

-- pap_view_schema.fact_upd_feedback_survey_denormalized_vw source;

create view pap_view_schema.fact_upd_feedback_survey_denormalized_vw as 
 SELECT
	 concat(concat(',',FV.role_name_access_list),',') AS role_name_access_list --Defect 1438
	,FV.STRENGTHS_OPPORTUNITIES
    ,FV.SURVEY_ANS
    ,FV.LEVEL2_DESC 
    ,FV.EMPLOYEE_NUM					AS "Target ID"
    ,FV.PREF_FULL_NAME  				AS "Target Name"
    ,FV.CALENDAR_DT			
    ,FV.DIM_SURVEY_QUES_KEY			
    ,FV.NUMBER_OF_RESPONSES				AS "Number Responded"
    ,FV.NUMBER_OF_INVITES   			AS "Number Invited"
	,CAST(FV.NUMBER_OF_RESPONSES AS INTEGER) AS NUMBER_OF_RESPONSES			
    ,CAST(FV.NUMBER_OF_INVITES   AS INTEGER) AS NUMBER_OF_INVITES		
    ,FV.FACT_SURVEY_QUES_KEY
    ,FV.RECORD_TYPE
    ,FV.FACT_SURVEY_QUES_ANS
    ,FV.MGR_WORKER_ID
    ,FV.OFFICE_TYPE						AS "Office Type"
    ,FV.AGE_BAND_DESC
    ,FV.SEX_DESC
    ,FV.ETHNIC_GROUP_CUSTOM_DESC
    ,FV.GENDER_IDENTITY 
    ,FV.SEXUAL_ORIENTATION
    --,FV.DISABILITY_STATUS
	,FV.DISABILITY_STATUS_US
    --,FV.VETERAN_STATUS_DESC
	,FV.VETERAN_STATUS_US
    ,FV.HIEST_DEGREE
    ,FV.ATTRIBUTE_TYPE
    ,FV.TALENT_QUADRANT_1
    ,FV.PERF_BAND1
    ,FV.PAY_GRADE_CODE					as "Pay Grade"
	,FV.PAY_GRADE_GROUP					as "Pay Grade Group"
	,FV.JOB_CODE 						as "Job Code"
	,FV.JOB_DESC 						as "Job Title"
	,FV.JOB_FAMILY_DESC 				as "Job Family"
	,FV.JOB_EXEMPT_FLG 					as "Job Exempt"
	,FV.cc_nodeval 						AS "Cost Center ID"
	,FV.CC_NODENAME 					AS "Cost Center Name"
	,FV.EMP_HIRE_DT 					AS "Original Hire Date"
	,FV.CONTINUOUS_SERVICE_DT 			AS "Continuous Service Date"
    ,FV.ATTR_MISC_DESC					AS "Country Name"
    ,FV.LEVEL2_DESC_NO_MGR  			as "Geographic Location Level 2 Name"
    ,FV.LOCATION_CODE_LEVEL13			AS "Location Name"
    ,FV.FULL_TIME_FLG       			AS "Full Time Flag"
    ,FV.Rehire_Flag 					AS "Rehire Flag"
	,FV.cc_level2_value 				AS "Cost Center Level 2 Code"
    ,FV.TALENT_QUADRANT_2 
    ,FV.PERF_BAND2
    ,FV.SCHOOL_NAME
    ,FV.SCHOOL_NAME         			AS "Highest Degree School Name"
    ,FV.WORKER_KEY
    ,FV.CC_LEVEL2_DESC					AS "Cost Center Level 2 Name"
	,FV.SOURCE_ID						AS "Position ID"
    ,FV.cc_level1_value
    ,FV.cc_level2_value		
    ,FV.cc_level3_value
    ,FV.cc_level4_value
    ,FV.cc_level5_value
    ,FV.cc_level6_value
    ,FV.cc_level7_value
    
    ,FV.current_level1_emp_full_name
    ,FV.current_level10_emp_full_name
    ,FV.current_level11_emp_full_name
    ,FV.current_level2_emp_full_name
    ,FV.current_level3_emp_full_name
    ,FV.current_level4_emp_full_name
    ,FV.current_level5_emp_full_name
    ,FV.current_level6_emp_full_name
    ,FV.current_level7_emp_full_name
    ,FV.current_level8_emp_full_name
    ,FV.current_level9_emp_full_name
    
    ,FV.le_level1_val
    ,FV.le_level2_val
    ,FV.le_level3_val
    ,FV.le_level4_val
    ,FV.le_level5_val
    ,FV.le_level6_val
    
    ,FV.location_code_level1
    ,FV.location_code_level10
    ,FV.location_code_level11
    ,FV.location_code_level12
    ,FV.location_code_level13
    ,FV.location_code_level2
    ,FV.location_code_level3
    ,FV.location_code_level4
    ,FV.location_code_level5
    ,FV.location_code_level6
    ,FV.location_code_level7
    ,FV.location_code_level8
    ,FV.location_code_level9
    
	,FV.product_value1
    ,FV.product_value2
    ,FV.product_value3
    ,FV.product_value4
    ,FV.product_value5
    
    ,FV.current_level1_emp_login
    ,FV.current_level2_emp_login
    ,FV.current_level3_emp_login
    ,FV.current_level4_emp_login
    ,FV.current_level5_emp_login
    ,FV.current_level6_emp_login
    ,FV.current_level7_emp_login
    ,FV.current_level8_emp_login
    ,FV.current_level9_emp_login
    ,FV.current_level10_emp_login
    ,FV.current_level11_emp_login
	,CASE  WHEN fje.PAYROLL_STATUS = 0 AND fje.LEAVE_STATUS = 0 THEN 'Active' 
                  WHEN fje.PAYROLL_STATUS = 0 AND fje.LEAVE_STATUS = 1 THEN 'Leave with Pay' 
                  WHEN fje.PAYROLL_STATUS = 1 AND fje.LEAVE_STATUS = 1 THEN 'Leave of Absence' 
                  ELSE 'Inactive' 
           END							AS "Employement Status"
	,CAST(NULL AS VARCHAR(765)) 		AS "Length of Service Group"
	,CAST(NULL AS VARCHAR(765)) 		AS "Length of Service (Years)"
	,FV.employee_sub_cat_desc 			AS "Worker Type Sub Category Description"
	,FV.MOST_RECENT_HIRE_DT 			AS "Most Recent Hire Date"
	,FV.MOST_RECENT_ADVANCEMENT_DATE 	AS "Most Recent Advancement Date"
	,FV.BUS_SURVEY_QUES
	,FV.CC_NODEVAL
	,FV.CC_NODENAME
	,NVL(FV.FULLTIME_PARTTIME,fje.FULLTIME_PARTTIME) AS FULLTIME_PARTTIME
	,FV.ETHNICITY_US
	
	,fjesr.ORIG_PERF_RATING
	,fjesr.ORIG_PERF_RATING_PRV
	,CASE WHEN fjesr.TALENT_QUADRANT='' THEN NULL 	  ELSE fjesr.TALENT_QUADRANT 	 END AS TALENT_QUADRANT
	,CASE WHEN fjesr.TALENT_QUADRANT_PRV='' THEN NULL ELSE fjesr.TALENT_QUADRANT_PRV END AS TALENT_QUADRANT_PRV
	,fjesr.END_DT_WID
	,fjesr.START_DT_WID
	,fjesr.LEAVE_STATUS
	,fjesr.PAYROLL_STATUS
	,fjesr.BUSINESS_TITLE
	,fjesr.SALARY_ANNL
	,FV.LE_LEVEL1_DESC
	,FV.LE_LEVEL2_DESC
	,FV.LE_LEVEL3_DESC
	,FV.LE_LEVEL4_DESC
	,FV.LE_LEVEL5_DESC
	,FV.LE_LEVEL6_DESC
	,FV.PRODUCT_DESC_1
	,FV.PRODUCT_DESC_2
	,FV.PRODUCT_DESC_3
	,FV.PRODUCT_DESC_4
	,FV.PRODUCT_DESC_5
	,FV.LOCATION_DESC_LEVEL1
	,FV.LOCATION_DESC_LEVEL2
	,FV.LOCATION_DESC_LEVEL3
	,FV.LOCATION_DESC_LEVEL4
	,FV.LOCATION_DESC_LEVEL5
	,FV.LOCATION_DESC_LEVEL6
	,FV.LOCATION_DESC_LEVEL7
	,FV.LOCATION_DESC_LEVEL8
	,FV.LOCATION_DESC_LEVEL9
	,FV.LOCATION_DESC_LEVEL10
	,FV.LOCATION_DESC_LEVEL11
	,FV.LOCATION_DESC_LEVEL12
	,FV.LOCATION_DESC_LEVEL13
	,FV.CC_LEVEL1_DESC
	,FV.CC_LEVEL2_DESC
	,FV.CC_LEVEL3_DESC
	,FV.CC_LEVEL4_DESC
	,FV.CC_LEVEL5_DESC
	,FV.CC_LEVEL6_DESC
	,FV.CC_LEVEL7_DESC
	,FV.MGR_SUP_HIER_KEY
	,FV.LE_HIER_KEY
	,FV.PROD_HIER_KEY
	,FV.LOC_HIER_KEY
	,FV.CC_HIER_KEY
	,'Total Gilead' AS company_level1_val
    ,'Total Gilead' AS company_level1_desc
	,FV.COMPANY AS company_level2_val
    /*,case when FV.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
     end AS company_level2_val*/
	,FV.COMPANY AS company_level2_desc
    /*,case when FV.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
     end AS company_level2_desc*/
	,FV.job_req_tag
	,FV.login
	,FV.HIEST_DEGREE_MAJOR	 AS "Highest Degree Major"
	,FV.EMPLOYEE_CAT_CODE
	,FV.AWR_START_DATE
	,FV.AWR_END_DT
	,fjesr.PEOPLE_MANAGER_FLG
	,fje.headcount
	,fjed.term_event_ind
	,fjed.event_category
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.current_level1_emp_login,''),'|'),NVL(FV.current_level2_emp_login,'')),'|'), NVL(FV.current_level3_emp_login,'')),'|'),NVL(FV.current_level4_emp_login,'')),'|'),NVL(FV.current_level5_emp_login,'')),'|'),NVL(FV.current_level6_emp_login,'')),'|'),NVL(FV.current_level7_emp_login,'')),'|'),NVL(FV.current_level8_emp_login,'')),'|'),NVL(FV.current_level9_emp_login,'')),'|'),NVL(FV.current_level10_emp_login,'')),'|'),NVL(FV.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.product_value1,''),'|'),NVL(FV.product_value2,'')),'|'),NVL(FV.product_value3,'')),'|'),NVL(FV.product_value4,'')),'|'), NVL(FV.product_value5,'')),'|')) as PRODUCT_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.LOCATION_CODE_LEVEL1,''),'|'),NVL(FV.LOCATION_CODE_LEVEL2,'')),'|'), NVL(FV.LOCATION_CODE_LEVEL3,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL4,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL5,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL6,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL7,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL8,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL9,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL10,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL11,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL12,'')),'|'),NVL(FV.LOCATION_CODE_LEVEL13,'')),'|')) as LOCATION_HIER_LIST 
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.cc_level1_value,''),'|'),NVL(FV.cc_level2_value,'')),'|'),NVL(FV.cc_level3_value,'')),'|'),NVL(FV.cc_level4_value,'')),'|'), NVL(FV.cc_level5_value,'')),'|'),NVL(FV.cc_level6_value,'')),'|'),NVL(FV.cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	,concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FV.le_level1_val,''),'|'),NVL(FV.le_level2_val,'')),'|'),NVL(FV.le_level3_val,'')),'|'),NVL(FV.le_level4_val,'')),'|'), NVL(FV.le_level5_val,'')),'|'),NVL(FV.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
	,FV.WORKER_ETHNICITY_US
	,FV.EFFECTIVE_START_DT
	,FV.EFFECTIVE_END_DT
	,FV.STRENGTH_COMMENTS
	,FV.OPPORTUNITIES_COMMENTS
	,case 
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Create Inclusion' THEN 1
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Demonstrates empathy and compassion, even when busy.' THEN 2
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Makes space for others to speak up and share diverse perspectives, a difficult message, or a contrary opinion.' THEN 3
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Seeks and acts on feedback from others.' THEN 4
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Takes specific steps to create a more inclusive work environment.' THEN 5
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Takes accountability for own behaviors and actions, even when it is difficult.' THEN 6
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Develop Talent' THEN 7
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Encourages me to learn from mistakes, setbacks, and failures.' THEN 8
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Consistently recognizes my contributions.' THEN 9
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Helps me pursue opportunities to grow in my role and career.' THEN 10
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Contributes to my development by providing constructive and actionable feedback in a thoughtful way.' THEN 11
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Empower Teams' THEN 12
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Helps our team explore new ideas and innovative solutions.' THEN 13
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Anticipates and adapts to changes in the environment and makes course corrections as needed.' THEN 14
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Explains the rationale for their thinking and decisions.' THEN 15
		WHEN extract(year from effective_start_dt) = 2023 AND  bus_survey_ques = 'Delegates and trusts me to make decisions and deliver, even when there are unknowns.' THEN 16
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'I am BOLD in aspiration and agile in execution' THEN 17
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Helps our team explore new ideas and innovative solutions.' THEN 18
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Encourages me to learn from mistakes, setbacks, and failures.' THEN 19
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Anticipates and adapts to changes in the environment and makes course corrections as needed.' THEN 20
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'I CARE and make time for people' THEN 21
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Consistently recognizes my contributions.' THEN 22
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Demonstrates empathy and compassion, even when busy.' THEN 23
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Helps me pursue opportunities to grow in my role and career.' THEN 24
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'I LISTEN, speak openly, and explain the "why"' THEN 25
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Makes space for others to speak up and share diverse perspectives, a difficult message, or a contrary opinion.' THEN 26
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Seeks and acts on feedback from others.' THEN 27
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Explains the rationale for their thinking and decisions.' THEN 28
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'I TRUST others and myself to make sound decisions' THEN 29
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Delegates and trusts me to make decisions and deliver, even when there are unknowns.' THEN 30
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Takes specific steps to create a more inclusive work environment.' THEN 31
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'I OWN the impact of my words and actions' THEN 32
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Contributes to my development by providing constructive and actionable feedback in a thoughtful way.' THEN 33
		WHEN extract(year from effective_start_dt) = 2022 AND  bus_survey_ques = 'Takes accountability for own behaviors and actions, even when it is difficult.' THEN 34
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'I am BOLD in aspiration and agile in execution' THEN 35
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Helps our team explore new ideas and innovative solutions.' THEN 36
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Encourages me to learn from mistakes, setbacks, and failures.' THEN 37
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Anticipates and adapts to changes in the environment and makes course corrections as needed.' THEN 38
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'I CARE and make time for people' THEN 39
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Consistently recognizes my contributions.' THEN 40
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Demonstrates empathy and compassion, even when busy.' THEN 41
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Helps me pursue opportunities to grow in my role and career.' THEN 42
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'I LISTEN, speak openly, and explain the "why"' THEN 43
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Makes space for others to speak up and share diverse perspectives, a difficult message, or a contrary opinion.' THEN 44
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Seeks and acts on feedback from others.' THEN 45
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Explains the rationale for their thinking and decisions.' THEN 46
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'I TRUST others and myself to make sound decisions' THEN 47
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Delegates and trusts me to make decisions and deliver, even when there are unknowns.' THEN 48
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Takes specific steps to create a more inclusive work environment.' THEN 49
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'I OWN the impact of my words and actions' THEN 50
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Contributes to my development by providing constructive and actionable feedback in a thoughtful way.' THEN 51
		WHEN extract(year from effective_start_dt) = 2021 AND  bus_survey_ques = 'Takes accountability for own behaviors and actions, even when it is difficult.' THEN 52
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Core Values' THEN 53
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Exhibits the core value of Integrity.' THEN 54
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Exhibits the core value of Inclusion.' THEN 55
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Exhibits the core value of Teamwork.' THEN 56
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Exhibits the core value of Excellence.' THEN 57
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Exhibits the core value of Accountability.' THEN 58
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Encourages Diversity of Thought' THEN 59
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Treats me with respect.' THEN 60
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Listens to me.' THEN 61
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Seeks diverse perspectives to inform his/her decision making.' THEN 62
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Provides Vision & Direction' THEN 63
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Sets clear priorities and ensures his/her and others\' time is spent on priorities.' THEN 64
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Delegates effectively, providing the right balance of autonomy and direction.' THEN 65
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Regularly communicates progress toward achieving department goals.' THEN 66
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Communicates department and company information that is relevant to my work.' THEN 67
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Holds regular staff meetings with our team.' THEN 68
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Holds regular one-on-one meetings with me.' THEN 69
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Devotes undivided attention to me during our one-on-one meetings.' THEN 70
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Develops Team' THEN 71
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'And I regularly discuss opportunities for me to develop in my career.' THEN 72
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Regularly gives me clear feedback on my performance.' THEN 73
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Recognizes me for my contributions on the job.' THEN 74
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Writes and delivers fair and effective Mid-Year and Year-End performance reviews.' THEN 75
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Facilitates collaboration within our team and with others at Gilead.' THEN 76
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Drives for Excellence' THEN 77
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Sets clear and consistent performance expectations.' THEN 78
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Focuses on results rather than activities.' THEN 79
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Motivates me to do my best work.' THEN 80
		WHEN extract(year from effective_start_dt) BETWEEN 2014 AND 2019  AND  bus_survey_ques = 'Encourages me to come up with new and better ways of doing things.' THEN 81
	ELSE 99 end AS bus_survey_ques_sequence
	
FROM 
	gna_load_schema.fact_upd_feedback_survey_denormalized FV
	
	LEFT JOIN (select WORKER_KEY,ORIG_PERF_RATING,ORIG_PERF_RATING_PRV,TALENT_QUADRANT ,TALENT_QUADRANT_PRV,END_DT_WID,START_DT_WID
					 ,LEAVE_STATUS,PAYROLL_STATUS,BUSINESS_TITLE,SALARY_ANNL,PEOPLE_MANAGER_FLG
					 ,row_number() over(partition by worker_key,event_dt_key order by event_seq desc) as latest
				from gna_load_schema.fact_job_events_denormalized 
				where MAX_SEQ_IND =1 AND headcount=1 and ASSIGNMENT_NUM=0
				)fjesr
		 ON fjesr.WORKER_KEY = FV.MGR_WORKER_KEY
		AND FV.event_dt_key BETWEEN fjesr.start_dt_wid AND fjesr.end_dt_wid
		and fjesr.latest=1
	
	 --for employement status field the below join is added 
	LEFT JOIN (select WORKER_KEY,event_dt_key,headcount,event_category,term_event_ind,start_dt_wid,end_dt_wid,LEAVE_STATUS,PAYROLL_STATUS
					 ,FULLTIME_PARTTIME,row_number() over(partition by worker_key,event_dt_key order by event_seq desc) as latest
				from gna_load_schema.fact_job_events_denormalized 
				where MAX_SEQ_IND =1and ASSIGNMENT_NUM=0
				)fje
		 ON fje.WORKER_KEY = FV.MGR_WORKER_KEY
		AND FV.event_dt_key BETWEEN fje.start_dt_wid AND fje.end_dt_wid
		and fje.latest=1 
		
	left join (select worker_key,event_dt_key,term_event_ind,fjed.event_category,  
				row_number() over(partition by worker_key,event_dt_key order by event_seq desc) as latest
				from gna_load_schema.fact_job_events_denormalized fjed where fjed.term_event_ind =1
			) fjed
		 on fjed.worker_key =FV.mgr_worker_key 
		and DATEDIFF(day,FV.NEXT_TERMINATION_DATE,TO_DATE(fjed.EVENT_DT_key,'YYYYMMDD')) between -1 and 1
		and record_type ='Aggregated Response'
		and fjed.latest=1
		 
;


	
-- pap_view_schema.fact_vfw_badge_dtl_denormalized_vw source;


CREATE VIEW pap_view_schema.fact_vfw_badge_dtl_denormalized_vw AS 
select 
	   concat(concat(',',FB.role_name_access_list),',') AS role_name_access_list
	  ,FB.EMPLOYEE_CAT_CODE
	  ,FB.EMPLOYEE_CAT_DESC
	  ,FB.EMPLOYEE_SUB_CAT_DESC
	  ,FB.LEVEL2_DESC
	  ,FB.WORKER_KEY
	  ,FB.EMPLOYEE_NUM
	  ,FB.ACCESS_DT_KEY
	  ,FB.DOORNAME
	  ,FB.ACCESS_DATIME_LOCAL
	  ,FB.AGE
	  ,FB.BUILDING
      ,FB.ATTR_MISC_DESC  AS COUNTRY_NAME
	  ,FB.DISABILITY_STATUS
	  ,FB.GENDER
	  ,FB.GENDER_IDENTITY
	  ,FB.HIEST_DEGREE
	  ,FB.job_req_tag
	  ,NULL AS LENGTH_OF_SERVICE
	  ,fjesr.PEOPLE_MANAGER_FLG
	  ,FB.SER_POW_BAND_DESC
	  ,FB.perf_band1
	  ,FB.OFFICE_TYPE
	  ,FB.Sexual_Orientation
	  ,FB.Supervisor_ID
	  ,FB.CONTINUOUS_SERVICE_DT
	  ,FB.Rehire_Flag
	  ,FB.SUPERVISOR_NAME
	  ,FB.VETERAN_STATUS
	  ,FB.product_value1
	  ,FB.product_value2
	  ,FB.product_value3
	  ,FB.product_value4
	  ,FB.product_value5
	  ,FB.product_desc
	  ,FB.le_level1_val
	  ,FB.le_level2_val
	  ,FB.le_level3_val
	  ,FB.le_level4_val
	  ,FB.le_level5_val
	  ,FB.le_level6_val
	  ,FB.le_level6_desc
	  ,FB.cc_level1_value 
	  ,FB.cc_level2_value
	  ,FB.cc_level3_value
	  ,FB.cc_level4_value
	  ,FB.cc_level5_value
	  ,FB.cc_level6_value
	  ,FB.cc_level7_value
	  ,FB.base_cost_center_desc 
	  ,FB.Cost_center_level2_desc
	  ,FB.LOCATION_CODE_LEVEL1
	  ,FB.LOCATION_CODE_LEVEL2
	  ,FB.LOCATION_CODE_LEVEL3
	  ,FB.LOCATION_CODE_LEVEL4
	  ,FB.LOCATION_CODE_LEVEL5
	  ,FB.LOCATION_CODE_LEVEL6
	  ,FB.LOCATION_CODE_LEVEL7
	  ,FB.LOCATION_CODE_LEVEL8
	  ,FB.LOCATION_CODE_LEVEL9
	  ,FB.LOCATION_CODE_LEVEL10
	  ,FB.LOCATION_CODE_LEVEL11
	  ,FB.LOCATION_CODE_LEVEL12
	  ,FB.LEVEL13_VAL
	  
	  ,FB.LOCATION_DESC_LEVEL1
	  ,FB.LOCATION_DESC_LEVEL2
	  ,FB.LOCATION_DESC_LEVEL3
	  ,FB.LOCATION_DESC_LEVEL4
	  ,FB.LOCATION_DESC_LEVEL5
      ,FB.LOCATION_DESC_LEVEL6
	  ,FB.LOCATION_DESC_LEVEL7
	  ,FB.LOCATION_DESC_LEVEL8
	  ,FB.LOCATION_DESC_LEVEL9
	  ,FB.LOCATION_DESC_LEVEL10
	  ,FB.LOCATION_DESC_LEVEL11
	  ,FB.LOCATION_DESC_LEVEL12
	  ,FB.LOCATION_DESC_LEVEL13
	  
	  
	  ,FB.CURRENT_LEVEL1_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL2_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL3_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL4_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL5_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL6_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL7_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL8_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL9_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL10_EMP_FULL_NAME
	  ,FB.CURRENT_LEVEL11_EMP_FULL_NAME
	  
	  
	  
	  ,FB.CURRENT_LEVEL1_EMP_LOGIN
	  ,FB.CURRENT_LEVEL2_EMP_LOGIN
	  ,FB.CURRENT_LEVEL3_EMP_LOGIN
	  ,FB.CURRENT_LEVEL4_EMP_LOGIN
	  ,FB.CURRENT_LEVEL5_EMP_LOGIN
	  ,FB.CURRENT_LEVEL6_EMP_LOGIN
	  ,FB.CURRENT_LEVEL7_EMP_LOGIN
	  ,FB.CURRENT_LEVEL8_EMP_LOGIN
	  ,FB.CURRENT_LEVEL9_EMP_LOGIN
	  ,FB.CURRENT_LEVEL10_EMP_LOGIN
	  ,FB.CURRENT_LEVEL11_EMP_LOGIN
	  
	  
	  ,FB.POSITION_ID
	  ,FB.WORKER_ID
	  ,FB.WORKER_PREF_NAME
	  ,FB.PAY_GRADE_CODE
	  ,FB.PAY_GRADE_GROUP
	  ,FB.JOB_CODE
	  ,FB.JOB_EXEMPT_FLG
	  ,FB.JOB_FAMILY_DESC
	  ,FB.JOB_DESC
	  ,FB.DEPT_ID
	  ,FB.DEPT_NAME
	  ,FB.EMP_HIRE_DT
	  ,FB.LEVEL2_DESC_NO_MGR
	  ,FB.ATTRIBUTE_TYPE
	  ,FB.LEVEL13_VAL AS LOCATION
	  ,FB.WORKER_ETHNICITY
	  ,FB.VETERAN_STATUS_DESC
	  ,FB.KEY_PERFORMER_YEAR_1
	  ,FB.KEY_PERFORMER_YEAR_2
	  ,FB.KEY_PERFORMER_YEAR_3
	  ,FB.TALENT_QUADRANT_1
	  ,FB.TALENT_QUADRANT_2
	  ,FB.TIMEZONE
	  ,FB.SITENAME
	  ,FB.CARDNUMBER
	  ,FB.FLOOR
	  ,FB.ROOM
	  ,FB.AGE_BAND_DESC
	  ,FB.LAST_PROMOTION_DATE_1
	  ,FB.role_change_dt
	  ,FB.Most_Recent_Advancement_Date
	  ,FB.SCHOOL_NAME
	  ,FB.ETHNIC_GROUP_CUSTOM_DESC
	  ,FB.CC_NODEVAL
	  ,FB.CC_NODENAME
	  ,FB.EVENT_YEAR_KEY
	  ,FB.RECRUITER_HIER_KEY
	  ,FB.RECRUITER_KEY
	  ,FB.APPLICANT_KEY
	  ,FB.LAST_DATE_OF_MONTH_KEY
	  ,FB.RQSTN_KEY
	  ,FB.MGRLEAD_PERF_BAND_KEY
	  ,FB.INTL_ASSGN_KEY
	  ,FB.SER_BAND_KEY
	  ,FB.PERF_BAND_KEY
	  ,FB.WORKER_EVENT_TYPE_KEY
	  ,FB.EVENT_QTR_KEY
	  ,FB.EVENT_MONTH_KEY
	  ,FB.EVENT_DT_KEY
	  ,FB.orig_hire_dt
	  ,FB.birth_dt
	  ,FB.ETHNICITY_US
	  ,FB.VETERAN_STATUS_US
	  ,FB.DISABILITY_STATUS_US
	  ,FB.le_level1_desc
	  ,FB.le_level2_desc
	  ,FB.le_level3_desc
	  ,FB.le_level4_desc
	  ,FB.le_level5_desc
	  ,FB.cc_level1_desc
	  ,FB.cc_level2_desc
	  ,FB.cc_level3_desc
	  ,FB.cc_level4_desc
	  ,FB.cc_level5_desc
	  ,FB.cc_level6_desc
	  ,FB.cc_level7_desc
	  ,FB.product_desc1
	  ,FB.product_desc2
	  ,FB.product_desc3
	  ,FB.product_desc4
	  ,FB.product_desc5
	  ,FB.DISABILITY_DEMOGRAPHIC_KEY
	  ,FB.VETERAN_STS_DEMOGRAPHIC_KEY
	  ,FB.ACCESS_DT
	  ,fjesr.PERF_BAND_DESC
	  ,fjesr.PREVIOUS_PERF_BAND_DESC
	  ,CASE WHEN fjesr.TALENT_QUADRANT='' THEN NULL ELSE fjesr.TALENT_QUADRANT END AS TALENT_QUADRANT
	  ,CASE WHEN fjesr.TALENT_QUADRANT_PRV='' THEN NULL ELSE fjesr.TALENT_QUADRANT_PRV END AS TALENT_QUADRANT_PRV
	  ,FB.job_req_tag1
	  ,FB.job_req_tag2
	  ,FB.job_req_tag3
	  ,FB.job_req_tag4
	  ,FB.job_req_tag5
	  ,FB.job_req_tag6
	  ,FB.job_req_tag7
	  ,FB.job_req_tag8
	  ,FB.job_req_tag9
	  ,FB.job_req_tag10
	  ,FB.SUPERVISOR_HIER_KEY
	  ,FB.DEPT_HIER_KEY
	  ,FB.le_hier_key
	  ,FB.LOC_HIER_KEY
	  ,FB.CC_HIER_KEY
	  ,FB.PROD_HIER_KEY
	  ,FB.FULLTIME_PARTTIME
	  ,FB.LOGIN
	  --,FB.FULL_TIME_FLG
	  ,CASE WHEN FB.EMPLOYEE_CAT_CODE  = 'CONTINGENT' THEN 'Contingent Worker' 
            WHEN FB.EMPLOYEE_CAT_CODE  = 'EMPLOYEE' THEN 'Employee' 
       END AS WORKER_CATEGORY
	  ,FB.COMPANY AS company_level2_val
	  /*,case when FB.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
          then 'Kite' else 'Gilead' 
       end AS company_level2_val*/
	  ,FB.COMPANY AS company_level2_desc
      /*,case when FB.cc_nodeval in ('1110255801','2310351001','1110254201','4000158201','2140150101','1110251501','1110253001',
                              '1110252001','2310362001','2310670101','1110257101','1110250200','1110310101','1110255901',
                              '2120151001','4100185101','1110205101','1110641101','1110640803','1110625303','1110361000',
                              '1110250101','1110256101','1110200301','1110321000','1110250701','1110256601') 
           then 'Kite' else 'Gilead' 
      end AS company_level2_desc*/
	 ,FB.EMP_ACTIVE_FLG
	 ,(select max(to_date(x.event_dt_key,'YYYYMMDD')) from gna_load_schema.fact_job_events_snapshot x 
		where to_date(x.event_dt_key,'YYYYMMDD')<=to_date(fjesr.event_dt_key,'YYYYMMDD') 
		and  x.worker_key=fjesr.worker_key 
		and x.grade_increase_flg =1 
		and x.change_event_type!='SNAPSHOT'
		and x.event_category not in ('Deactivate','Grade Decrease','Unspecified')
		and fjesr.MOST_RECENT_HIRE_DT<=to_date(x.event_dt_key,'YYYYMMDD') ) AS "Most Recent Advancement Date"
	 , TERMINATION_DT10
	 , TERMINATION_DT9 
	 , TERMINATION_DT8 
	 , TERMINATION_DT7 
	 , TERMINATION_DT6 
	 , TERMINATION_DT5 
	 , TERMINATION_DT4 
	 , TERMINATION_DT3 
	 , TERMINATION_DT2 
	 , TERMINATION_DT1 
	 , TERMINATION_DT  
	 , AWR_START_DATE
	 , AWR_END_DT
	 , fjesr.term_event_ind
	 , concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FB.current_level1_emp_login,''),'|'),NVL(FB.current_level2_emp_login,'')),'|'), NVL(FB.current_level3_emp_login,'')),'|'),NVL(FB.current_level4_emp_login,'')),'|'),NVL(FB.current_level5_emp_login,'')),'|'),NVL(FB.current_level6_emp_login,'')),'|'),NVL(FB.current_level7_emp_login,'')),'|'),NVL(FB.current_level8_emp_login,'')),'|'),NVL(FB.current_level9_emp_login,'')),'|'),NVL(FB.current_level10_emp_login,'')),'|'),NVL(FB.current_level11_emp_login,'')),'|')) as supervisor_hier_list 
	 , concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FB.product_value1,''),'|'),NVL(FB.product_value2,'')),'|'),NVL(FB.product_value3,'')),'|'),NVL(FB.product_value4,'')),'|'), NVL(FB.product_value5,'')),'|')) as PRODUCT_HIER_LIST
	 , concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FB.LOCATION_CODE_LEVEL1,''),'|'),NVL(FB.LOCATION_CODE_LEVEL2,'')),'|'), NVL(FB.LOCATION_CODE_LEVEL3,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL4,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL5,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL6,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL7,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL8,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL9,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL10,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL11,'')),'|'),NVL(FB.LOCATION_CODE_LEVEL12,'')),'|'),NVL(FB.LEVEL13_VAL,'')),'|')) as LOCATION_HIER_LIST 
	 , concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FB.cc_level1_value,''),'|'),NVL(FB.cc_level2_value,'')),'|'),NVL(FB.cc_level3_value,'')),'|'),NVL(FB.cc_level4_value,'')),'|'), NVL(FB.cc_level5_value,'')),'|'),NVL(FB.cc_level6_value,'')),'|'),NVL(FB.cc_level7_value,'')),'|')) as COST_CENTER_HIER_LIST
	 , concat('|',concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(NVL(FB.le_level1_val,''),'|'),NVL(FB.le_level2_val,'')),'|'),NVL(FB.le_level3_val,'')),'|'),NVL(FB.le_level4_val,'')),'|'), NVL(FB.le_level5_val,'')),'|'),NVL(FB.le_level6_val,'')),'|')) as LEGAL_ENTITY_HIER_LIST
	 , fjesr.MOST_RECENT_HIRE_DT
	 , FB.MOST_RECENT_TERMINATION_DT
	 
from 
	gna_load_schema.fact_vfw_badge_dtl_denormalized FB 
	
	--DISTINCT is used in the below join due to data duplicacy in fact_job_events_snapshot (issue in oracle itself)
	LEFT JOIN (SELECT DISTINCT orig_perf_rating,PERF_BAND_DESC,ORIG_PERF_RATING_PRV,PREVIOUS_PERF_BAND_DESC,talent_quadrant,talent_quadrant_prv,
							   EFFECTIVE_END_DT,EFFECTIVE_START_DT,WORKER_KEY,MOST_RECENT_HIRE_DT ,event_dt_key,term_event_ind,PEOPLE_MANAGER_FLG
				FROM gna_load_schema.fact_job_events_denormalized 
				WHERE MAX_SEQ_IND =1 AND ASSIGNMENT_NUM=0 AND HEADCOUNT=1)fjesr 
			ON fjesr.WORKER_KEY =FB.WORKER_KEY  
			AND FB.WORKER_KEY!=0
			AND FB.ACCESS_DT  BETWEEN fjesr.EFFECTIVE_START_DT AND fjesr.EFFECTIVE_END_DT

;

   
-- pap_view_schema.fact_comment_themes_vw source;

CREATE OR REPLACE VIEW pap_view_schema.fact_comment_themes_vw
AS 
select
              t71214.role_name_access_list,
              t71214.pay_grade_group,
              t71214."Office Type",
              t71214."Age Group",
              t71214."Disability Status (US)",
              t71214."Veteran Status (US)",
              t71214.gender_identity,
              t71214."Highest Education Degree Description",
              t71214."Job Req Tag",
              t71214.length_of_service,
              t71214.sexual_orientation,
              t71214."Ethnicity (US)",
              t71214.employee_cat_code,
              t71214.max_seq_ind,
              t71214.snapshot_ind,
              t71214.supervisor_evt_ind,
              t71214.headcount,
              t71214.assignment_num,
              t71214.grade_increase_flg,
              t71214."Event Category",
              t71214."Event Type",
              t71214."Event Reason",
              t71214.movement_ind,
              t71214.term_status_ind,
              t71214.event_ind,
              t71214.le_level1_val,
              t71214.le_level2_val,
              t71214.le_level3_val,
              t71214.le_level4_val,
              t71214.le_level5_val,
              t71214.location_code_level1,
              t71214.location_code_level2,
              t71214.location_code_level3,
              t71214.location_code_level4,
              t71214.location_code_level5,
              t71214.location_code_level6,
              t71214.location_code_level7,
              t71214.location_code_level8,
              t71214.location_code_level9,
              t71214.location_code_level10,
              t71214."Worker Type Sub Category Description",
              t71214.location_code_level11,
              t71214.location_code_level12,
              t71214.base_location,
              t71214.product_value1,
              t71214.product_value2,
              t71214.product_value3,
              t71214.product_value4,
              t71214.product_value5,
              t71214.cc_level1_value,
              t71214.cc_level2_value,
              t71214.cc_level3_value,
              t71214.cc_level4_value,
              t71214.cc_level5_value,
              t71214.cc_level6_value,
              t71214.cc_level7_value,
              t71214.current_level1_emp_full_name,
              t71214.current_level2_emp_full_name,
              t71214.current_level3_emp_full_name,
              t71214.current_level4_emp_full_name,
              t71214.current_level5_emp_full_name,
              t71214.current_level6_emp_full_name,
              t71214.current_level7_emp_full_name,
              t71214.current_level8_emp_full_name,
              t71214.current_level9_emp_full_name,
              t71214.current_level10_emp_full_name,
              t71214.current_level11_emp_full_name,
              t71214.current_level1_emp_login,
              t71214.current_level2_emp_login,
              t71214.current_level3_emp_login,
              t71214.current_level4_emp_login,
              t71214.current_level5_emp_login,
              t71214.current_level6_emp_login,
              t71214.current_level7_emp_login,
              t71214.current_level8_emp_login,
              t71214.current_level9_emp_login,
              t71214.current_level10_emp_login,
              t71214.current_level11_emp_login,
              t71214."Worker ID",
              t71214."Worker Name",
              t71214."Pay Grade Group",
              t71214."Pay Grade",
              t71214."Position ID",
              t71214."Job Code",
              t71214."Job Title",
              t71214."Job Family",
              t71214.job_exempt_flg,
              t71214."Job Exempt",
              t71214."Cost Center ID",
              t71214."Cost Center Name",
              t71214."Supervisior ID",
              t71214."Supervisior Name",
              t71214."Original Hire Date",
              t71214."Most Recent Hire Date",
              t71214."Continuous Service Date",
              t71214."Geographic Location Level 2 Name",
              t71214."Country Name",
              t71214."Location Name",
              t71214."Full Time Flag",
              t71214."People Manager Flag",
              t71214."Rehire Flag",
              t71214."Most Recent Advancement Date",
              t71214."Employement Status",
              t71214."Highest Degree School Name",
              t71214."Gender",
              t71214."{Most Recent Year before Prompted End Date's} Year-End Rating",
              t71214."{Second-Most Recent Year before Prompted End Date's} Year-End Rating",
              t71214."{Most Recent Year before Prompted End Date's} Talent Coordinate",
              t71214."{Second-Most Recent Year before Prompted End Date's} Talent Coordinate",
              t71214."Assigned HR Business Partner",
              t71214.cost_center_level2_desc,
              t71214."Organization Size",
              t71214."Number of Direct Reports",
              t71214."Number of Indirect Reports",
              t71214."Worker Category",
              t71214.vms_security_id,
              t71214."Contract Start Date",
              t71214."Contract End Date",
              t71214."Earliest Contract Start Date",
              t71214."Earliest Contract End Date",
              t71214."Vendor/Agency Name",
              t71214."Work Order",
              t71214."Task Name",
              t71214."PO Number",
              t71214."Requisition Number",
              t71214."Pay Rate",
              t71214."Bill Rate",
              t71214."Billing Currency",
              t71214."Pay/Bill Rate Frequency",
              t71214."Space (Y/N)",
              t71214."Badge (Y/N)",
              t71214."Security Badge Access Num",
              t71214."Event Date",
              t71214."Most Recent New Role",
              t71214."Most Recent Movement Date",
              t71214."Most Recent Termination Date",
              t71214."Job Req ID",
              t71214."Job Req Type",
              t71214."Job Req Category",
              t71214."Position Desc",
              t71214."Previous Position ID",
              t71214."Previous Position Desc",
              t71214."Previous Pay Grade Group",
              t71214."Previous Pay Grade",
              t71214."Previous Job Code",
              t71214."Previous Job Title",
              t71214."Previous Job Family",
              t71214."Previous Job Exempt",
              t71214."Previous Office Type",
              t71214."Previous Supervisor ID",
              t71214."Previous Supervisor Name",
              t71214."Previous Cost Center ID",
              t71214."Previous Cost Center Name",
              t71214."Previous Geographic Location Level 2 Name",
              t71214."Previous Country Name",
              t71214."Previous Location Name",
              t71214."Previous Cost Center Level 2 Code",
              t71214."Previous Cost Center Level 2 Name",
              t71214."Previous Supervisory Org Current Level 1 Full Name",
              t71214."Previous Supervisory Org Current Level 2 Full Name",
              t71214."Previous Supervisory Org Current Level 3 Full Name",
              t71214."Previous Supervisory Org Current Level 4 Full Name",
              t71214."Previous Supervisory Org Current Level 5 Full Name",
              t71214."Assignment Start Date",
              t71214."Assignment End Date",
              t71214."Home Supervisor ID",
              t71214."Home Supervisor Name",
              t71214."Home Location",
              t71214."Skills First or OneTen Employee",
              t71214."International Assignment Type",
              t71214."Termination Effective Date",
              t71214."Days Survived",
              t71214."Official Turnover Reason",
              t71214."Employee Choosen-Turnover Reason",
              t71214."Exit Survey Comment Themes",
              t71214."Exit Survey Comment",
              t71214."Highest Degree Major",
              t71214.emp_active_flg,
              t71214.event_dt_key,
              t71214.start_dt_wid,
              t71214.end_dt_wid,
              t71214.event_month_key,
              t71214.snapshot_month_end_ind,
              t71214.internal_filled_req_ind,
              t71214.job_family_group,
              t71214."Total Base Pay (Annualized)",
              t71214."Currency Code",
              t71214.term_event_ind,
              t71214."Work Type",
              t71214.total_annl_sal,
              t71214.individual_bonus_target,
              t71214.annual_bonus_amount,
              t71214.merit_stock_target,
              t71214.unvested_equity,
              t71214.cc_desc,
              t71214.cc_legal_entity,
              t71214."Cost Center Owner",
              t71214."Cost Center Function",
              t71214.currency,
              t71214.product_link,
              t71214.market_associated,
              t71214.hryid,
              t71214.grade_change_ind,
              t71214.grade_decrease_flg,
              t71214.cc_hier_key,
              t71214.cc_hier_prv_key,
              t71214."Cost Center Level Name1",
              t71214."Cost Center Level Name2",
              t71214."Cost Center Level Name3",
              t71214."Cost Center Level Name4",
              t71214."Cost Center Level Name5",
              t71214."Cost Center Level Name6",
              t71214."Cost Center Level Name7",
              t71214."Legal Entity Name",
              t71214."Legal Entity Name After Event",
              t71214."Geographic Location Level 2 Code Before Event",
              t71214."Legal Entity ID Before Event",
              t71214."Legal Entity Name Before Event",
              t71214."Cost Center Owner Transferred From",
              t71214."Grade Profile Name",
              t71214."Business Title",
              t71214."Range ID",
              t71214."TIER CODE",
              t71214."Sector Position",
              t71214.worker_key,
              t71214.fte,
              t71214.exch_rate,
              t71214."Skills First or OneTen Emp",
              t71214."Termination Date",
              t71214.cc_nodeval,
              t71214.cc_nodename,
              t71214.loc_hier_key,
              t71214.prod_hier_key,
              t71214.le_hier_key,
              t71214.supervisor_hier_key,
              sum(
                case
                    when t71214.employee_cat_code::text = 'EMPLOYEE'::character varying::text and t71214.supervisor_evt_ind = 0 then t71214.term_status_ind
                    else 0::numeric::numeric(18, 0)
                end) as terms,
              t116051.theme_level1,
              count(distinct 
                case
                    when t71214."Worker ID"::text > 2147483647::character varying::text or t71214."Worker ID"::numeric < (- 2147483648::bigint::character varying::numeric) then t71214."Worker ID"::integer
                    else t71214."Worker ID"::integer
                end) as "# of Terms",
        t71214.wrkfc_event_category,
        t71214.birth_dt,
        t71214."Recruitment Source",
        t71214."Salary Range Segment Midpoint (B2)",
        T116046.THEME_KEY,
        fes_r."Survey Type",
        fes_r."Survey Response" ,
        fes_r."Survey Response Status" ,
        fes_r."Survey Response Comments - Start" ,
        fes_r."Submitted Date" ,
        fes_r."Survey Questions",
        fes_r."Theme Level 1",
        fes_r."Theme Level 2",
	    t71214.login,
		t71214.supervisor_hier_list,
		t71214.COST_CENTER_HIER_LIST,
		t71214.LEGAL_ENTITY_HIER_LIST,
		t71214.LOCATION_HIER_LIST,
		t71214.PRODUCT_HIER_LIST,
		t71214.company_level2_desc
       from
              gna_load_schema.dim_calendar t71197
       inner join pap_view_schema.fact_job_events_denormalized_vw t71214
       on t71197.cal_date_key = t71214.event_dt_key
       left join gna_load_schema.dim_worker_term_themes t116046 
       on t71214.worker_key = t116046.worker_key
       and trunc(t71214."Event Date") = trunc(t116046.term_date)
       inner join gna_load_schema.dim_term_theme t116051
       on t116046.theme_key = t116051.theme_key
       left join (select
       FV.worker_key,
       FV.event_dt_key,
       FV.TERM_EVENT_IND,
       FV.MAX_SEQ_IND,
       'Exit Survey' "Survey Type",
       fesdv."Survey Response" ,
       fesdv."Survey Response Status" ,
       fesdv."Survey Response Comments - Start" ,
       fesdv."Submitted Date" ,
       fesdv."Survey Questions",
       fesdv."Theme Level 1",
       fesdv."Theme Level 2" 
from
       gna_load_schema.fact_job_events_snapshot FV
join pap_view_schema.fact_employee_survey_denormalized_vw fesdv 
on fv.worker_key = fesdv.worker_key
and DATEDIFF(day,to_date(fesdv."Submitted Date",'YYYY-MM-DD'),TO_DATE(FV.EVENT_DT_key,'YYYYMMDD')) between -180 and 180
where
                                FV.TERM_EVENT_IND=1
                                  and FV.MAX_SEQ_IND=1
                                  and "Survey Response Status" not in ('Rescinded','Canceled')
                                  and fesdv.survey in ('Exit Questionnaire', 'G9_EXIT', 'Exit Survey Questionnaire')
                                 and "Survey Response" in ('1','2','3','4','5')   
                           )fes_r 
                           on t71214.worker_key=fes_r.worker_key
                        and t71214.event_dt_key=fes_r.event_dt_key
                        and t71214.TERM_EVENT_IND= fes_r.TERM_EVENT_IND
                        and t71214.MAX_SEQ_IND = fes_r.MAX_SEQ_IND
       where
              t71197.calendar_dt <= (select 
                           max(to_date(substring(end_time,0,11),'YYYY-MM-DD')) as load_date 
                       from gna_load_schema.pap_log_batch_dtl  
                       where status='FINISHED')--to_date('2023-01-12 00:00:00'::character varying::text, 'YYYY-MM-DD HH24:MI:SS'::character varying::text)
--            and T116051.THEME_LEVEL1 NOT IN ('Nothing Reported / Could Not Decipher')
       /*     and t71197.per_name_month::text >= '2021 / 04'::character varying::text
              and t71197.per_name_month::text <= '2022 / 03'::character varying::text*/
                       and t71214.term_event_ind = 1
       group by
              t71214.wrkfc_event_category,
              T116046.THEME_KEY,
              t116051.theme_level1,
              t71214.role_name_access_list,
              t71214.pay_grade_group,
              t71214."Office Type",
              t71214."Age Group",
              t71214."Disability Status (US)",
              t71214."Veteran Status (US)",
              t71214.gender_identity,
              t71214."Highest Education Degree Description",
              t71214."Job Req Tag",
              t71214.length_of_service,
              t71214.sexual_orientation,
              t71214."Ethnicity (US)",
              t71214.employee_cat_code,
              t71214.max_seq_ind,
              t71214.snapshot_ind,
              t71214.supervisor_evt_ind,
              t71214.headcount,
              t71214.assignment_num,
              t71214.grade_increase_flg,
              t71214."Event Category",
              t71214."Event Type",
              t71214."Event Reason",
              t71214.movement_ind,
              t71214.term_status_ind,
              t71214.event_ind,
              t71214.le_level1_val,
              t71214.le_level2_val,
              t71214.le_level3_val,
              t71214.le_level4_val,
              t71214.le_level5_val,
              t71214.location_code_level1,
              t71214.location_code_level2,
              t71214.location_code_level3,
              t71214.location_code_level4,
              t71214.location_code_level5,
              t71214.location_code_level6,
              t71214.location_code_level7,
              t71214.location_code_level8,
              t71214.location_code_level9,
              t71214.location_code_level10,
              t71214."Worker Type Sub Category Description",
              t71214.location_code_level11,
              t71214.location_code_level12,
              t71214.base_location,
              t71214.product_value1,
              t71214.product_value2,
              t71214.product_value3,
              t71214.product_value4,
              t71214.product_value5,
              t71214.cc_level1_value,
              t71214.cc_level2_value,
              t71214.cc_level3_value,
              t71214.cc_level4_value,
              t71214.cc_level5_value,
              t71214.cc_level6_value,
              t71214.cc_level7_value,
              t71214.current_level1_emp_full_name,
              t71214.current_level2_emp_full_name,
              t71214.current_level3_emp_full_name,
              t71214.current_level4_emp_full_name,
              t71214.current_level5_emp_full_name,
              t71214.current_level6_emp_full_name,
              t71214.current_level7_emp_full_name,
              t71214.current_level8_emp_full_name,
              t71214.current_level9_emp_full_name,
              t71214.current_level10_emp_full_name,
              t71214.current_level11_emp_full_name,
              t71214.current_level1_emp_login,
              t71214.current_level2_emp_login,
              t71214.current_level3_emp_login,
              t71214.current_level4_emp_login,
              t71214.current_level5_emp_login,
              t71214.current_level6_emp_login,
              t71214.current_level7_emp_login,
              t71214.current_level8_emp_login,
              t71214.current_level9_emp_login,
              t71214.current_level10_emp_login,
              t71214.current_level11_emp_login,
              t71214."Worker ID",
              t71214."Worker Name",
              t71214."Pay Grade Group",
              t71214."Pay Grade",
              t71214."Position ID",
              t71214."Job Code",
              t71214."Job Title",
              t71214."Job Family",
              t71214.job_exempt_flg,
              t71214."Job Exempt",
              t71214."Cost Center ID",
              t71214."Cost Center Name",
              t71214."Supervisior ID",
              t71214."Supervisior Name",
              t71214."Original Hire Date",
              t71214."Most Recent Hire Date",
              t71214."Continuous Service Date",
              t71214."Geographic Location Level 2 Name",
              t71214."Country Name",
              t71214."Location Name",
              t71214."Full Time Flag",
              t71214."People Manager Flag",
              t71214."Rehire Flag",
              t71214."Most Recent Advancement Date",
              t71214."Employement Status",
              t71214."Highest Degree School Name",
              t71214."Gender",
              t71214."{Most Recent Year before Prompted End Date's} Year-End Rating",
              t71214."{Second-Most Recent Year before Prompted End Date's} Year-End Rating",
              t71214."{Most Recent Year before Prompted End Date's} Talent Coordinate",
              t71214."{Second-Most Recent Year before Prompted End Date's} Talent Coordinate",
              t71214."Assigned HR Business Partner",
              t71214.cost_center_level2_desc,
              t71214."Organization Size",
              t71214."Number of Direct Reports",
              t71214."Number of Indirect Reports",
              t71214."Worker Category",
              t71214.vms_security_id,
              t71214."Contract Start Date",
              t71214."Contract End Date",
              t71214."Earliest Contract Start Date",
              t71214."Earliest Contract End Date",
              t71214."Vendor/Agency Name",
              t71214."Work Order",
              t71214."Task Name",
              t71214."PO Number",
              t71214."Requisition Number",
              t71214."Pay Rate",
              t71214."Bill Rate",
              t71214."Billing Currency",
              t71214."Pay/Bill Rate Frequency",
              t71214."Space (Y/N)",
              t71214."Badge (Y/N)",
              t71214."Security Badge Access Num",
              t71214."Event Date",
              t71214."Most Recent New Role",
              t71214."Most Recent Movement Date",
              t71214."Most Recent Termination Date",
              t71214."Job Req ID",
              t71214."Job Req Type",
              t71214."Job Req Category",
              t71214."Position Desc",
              t71214."Previous Position ID",
              t71214."Previous Position Desc",
              t71214."Previous Pay Grade Group",
              t71214."Previous Pay Grade",
              t71214."Previous Job Code",
              t71214."Previous Job Title",
              t71214."Previous Job Family",
              t71214."Previous Job Exempt",
              t71214."Previous Office Type",
              t71214."Previous Supervisor ID",
              t71214."Previous Supervisor Name",
              t71214."Previous Cost Center ID",
              t71214."Previous Cost Center Name",
              t71214."Previous Geographic Location Level 2 Name",
              t71214."Previous Country Name",
              t71214."Previous Location Name",
              t71214."Previous Cost Center Level 2 Code",
              t71214."Previous Cost Center Level 2 Name",
              t71214."Previous Supervisory Org Current Level 1 Full Name",
              t71214."Previous Supervisory Org Current Level 2 Full Name",
              t71214."Previous Supervisory Org Current Level 3 Full Name",
              t71214."Previous Supervisory Org Current Level 4 Full Name",
              t71214."Previous Supervisory Org Current Level 5 Full Name",
              t71214."Assignment Start Date",
              t71214."Assignment End Date",
              t71214."Home Supervisor ID",
              t71214."Home Supervisor Name",
              t71214."Home Location",
              t71214."Skills First or OneTen Employee",
              t71214."International Assignment Type",
              t71214."Termination Effective Date",
              t71214."Days Survived",
              t71214."Official Turnover Reason",
              t71214."Employee Choosen-Turnover Reason",
              t71214."Exit Survey Comment Themes",
              t71214."Exit Survey Comment",
              t71214."Highest Degree Major",
              t71214.emp_active_flg,
              t71214.event_dt_key,
              t71214.start_dt_wid,
              t71214.end_dt_wid,
              t71214.event_month_key,
              t71214.snapshot_month_end_ind,
              t71214.internal_filled_req_ind,
              t71214.job_family_group,
              t71214."Total Base Pay (Annualized)",
              t71214."Currency Code",
              t71214.term_event_ind,
              t71214."Work Type",
              t71214.total_annl_sal,
              t71214.individual_bonus_target,
              t71214.annual_bonus_amount,
              t71214.merit_stock_target,
              t71214.unvested_equity,
              t71214.cc_desc,
              t71214.cc_legal_entity,
              t71214."Cost Center Owner",
              t71214."Cost Center Function",
              t71214.currency,
              t71214.product_link,
              t71214.market_associated,
              t71214.hryid,
              t71214.grade_change_ind,
              t71214.grade_decrease_flg,
              t71214.cc_hier_key,
              t71214.cc_hier_prv_key,
              t71214."Cost Center Level Name1",
              t71214."Cost Center Level Name2",
              t71214."Cost Center Level Name3",
              t71214."Cost Center Level Name4",
              t71214."Cost Center Level Name5",
              t71214."Cost Center Level Name6",
              t71214."Cost Center Level Name7",
              t71214."Legal Entity Name",
              t71214."Legal Entity Name After Event",
              t71214."Geographic Location Level 2 Code Before Event",
              t71214."Legal Entity ID Before Event",
              t71214."Legal Entity Name Before Event",
              t71214."Cost Center Owner Transferred From",
              t71214."Grade Profile Name",
              t71214."Business Title",
              t71214."Range ID",
              t71214."TIER CODE",
              t71214."Sector Position",
              t71214.worker_key,
              t71214.fte,
              t71214.exch_rate,
              t71214."Skills First or OneTen Emp",
              t71214."Termination Date",
              t71214.cc_nodeval,
              t71214.cc_nodename,
              t71214.loc_hier_key,
              t71214.prod_hier_key,
              t71214.le_hier_key,
              t71214.supervisor_hier_key,
              t71214.birth_dt,
              t71214."Recruitment Source",
              t71214."Salary Range Segment Midpoint (B2)",
              fes_r."Survey Type",
              fes_r."Survey Response" ,
              fes_r."Survey Response Status" ,
              fes_r."Survey Response Comments - Start" ,
              fes_r."Submitted Date" ,
              fes_r."Survey Questions",
              fes_r."Theme Level 1",
              fes_r."Theme Level 2",
			  t71214.login,
			  t71214.supervisor_hier_list,
              t71214.COST_CENTER_HIER_LIST,
              t71214.LEGAL_ENTITY_HIER_LIST,
              t71214.LOCATION_HIER_LIST,
              t71214.PRODUCT_HIER_LIST,
              t71214.company_level2_desc
;
  

-- pap_view_schema.cost_center_owner_vw source;

create view pap_view_schema.cost_center_owner_vw as
select 
 	T71108_CC.CURRENT_LEVEL1_EMP_FULL_NAME  AS CC_OWNER_LEVEL1_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL2_EMP_FULL_NAME  AS CC_OWNER_LEVEL2_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL3_EMP_FULL_NAME  AS CC_OWNER_LEVEL3_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL4_EMP_FULL_NAME  AS CC_OWNER_LEVEL4_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL5_EMP_FULL_NAME  AS CC_OWNER_LEVEL5_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL6_EMP_FULL_NAME  AS CC_OWNER_LEVEL6_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL7_EMP_FULL_NAME  AS CC_OWNER_LEVEL7_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL8_EMP_FULL_NAME  AS CC_OWNER_LEVEL8_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL9_EMP_FULL_NAME  AS CC_OWNER_LEVEL9_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL10_EMP_FULL_NAME AS CC_OWNER_LEVEL10_EMP_FULL_NAME,
    T71108_CC.CURRENT_LEVEL11_EMP_FULL_NAME AS CC_OWNER_LEVEL11_EMP_FULL_NAME 
	from gna_load_schema.dim_cost_center_hier T71116 
		left join gna_load_schema.DIM_SUPERVISOR_HIER T71108_CC
              ON T71108_CC.BASE_WORKER_ID = T71116.CC_OWNER 
             AND T71108_CC.CURRENT_FLG  = 'Y'
        where 
        	T71116.hryid like ('%Z0001%') 
        	and T71116.level1_desc is not null 
        	and T71116.datasource_name = 'EHANA' ;
			


-- pap_view_schema.cost_center_site_vw source;

CREATE OR REPLACE VIEW pap_view_schema.cost_center_site_vw
AS SELECT DISTINCT fhf.cc_hier_key, fhf.site_cc_level1_desc, fhf.site_cc_level2_desc, fhf.site_cc_level3_desc, fhf.site_cc_level4_desc, fhf.site_cc_level5_desc, fhf.site_cc_level6_desc, fhf.site_cc_level7_desc
   FROM pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
   JOIN gna_load_schema.dim_cost_center_hier dcch ON fhf.cc_hier_key = dcch.cc_hier_key AND dcch.hryid::text ~~ '%Z0001%'::character varying::text
   JOIN gna_load_schema.dim_cost_center_hier dcch1 ON dcch.cc_nodeval::text = dcch1.cc_nodeval::text AND dcch1.hryid::text ~~ '%Z0003%'::character varying::text;



-- pap_view_schema.dim_sec_user_leader_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_sec_user_leader_vw
AS WITH RECURSIVE numbers(number) AS (
         SELECT 1 AS number
UNION ALL 
         SELECT 1 + numbers.number AS number
           FROM numbers
          WHERE numbers.number < 30
        )
 SELECT src_flat.worker_key, dim_worker.worker_key AS leader_worker_key, dim_worker.full_name, src_flat.worker_id, dim_worker.employee_num AS leader_worker_id, src_flat.worker_login, src_flat.leader_worker_login, src_flat.load_key, src_flat.source_id, src_flat.datasource_num_id, src_flat.datasource_name, src_flat.received_file_name, src_flat.created_by_key, src_flat.created_dt, src_flat.updated_by_key, src_flat.updated_dt
   FROM ( SELECT src.worker_key, src.worker_id, src.worker_login, split_part(src.data_values::text, ','::character varying::text, numbers.number) AS leader_worker_login, src.load_key, src.source_id, src.datasource_num_id, src.datasource_name, src.received_file_name, src.created_by_key, src.created_dt, src.updated_by_key, src.updated_dt
           FROM numbers
      JOIN ( SELECT dim_sec_user_resp.worker_key, dim_sec_user_resp.role_name, dim_sec_user_resp.worker_id, dim_sec_user_resp.worker_login, dim_sec_user_resp.dim_type, dim_sec_user_resp.data_values, dim_sec_user_resp.record_type, dim_sec_user_resp.record_order, dim_sec_user_resp.load_key, dim_sec_user_resp.source_id, dim_sec_user_resp.datasource_num_id, dim_sec_user_resp.datasource_name, dim_sec_user_resp.received_file_name, dim_sec_user_resp.created_by_key, dim_sec_user_resp.created_dt, dim_sec_user_resp.updated_by_key, dim_sec_user_resp.updated_dt, dim_sec_user_resp.worker_name, dim_sec_user_resp.termination_dt
                   FROM gna_load_schema.dim_sec_user_resp
                  WHERE dim_sec_user_resp.dim_type::text = 'Supervisor'::character varying::text AND dim_sec_user_resp.record_type::text = 'Include'::character varying::text) src ON split_part(src.data_values::text, ','::character varying::text, numbers.number) <> ''::character varying::text) src_flat
   LEFT JOIN ( SELECT derived_table1.employee_num, derived_table1.worker_key, derived_table1.login, derived_table1.full_name
           FROM ( SELECT dim_worker.employee_num, dim_worker.worker_key, dim_worker.login, pg_catalog.row_number()
                  OVER( 
                  PARTITION BY dim_worker.login
                  ORDER BY dim_worker.employee_num DESC, dim_worker.worker_key DESC) AS rnum, dim_worker.full_name
                   FROM gna_load_schema.dim_worker) derived_table1
          WHERE derived_table1.rnum = 1) dim_worker ON src_flat.leader_worker_login = dim_worker.login::text;
		  

-- pap_view_schema.dim_stock_price_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_stock_price_vw
AS SELECT dim_stock_price.stock_date, dim_stock_price.close_mkt_val, dim_stock_price.col_comment, dim_stock_price.datasource_num_id, dim_stock_price.datasource_name, dim_stock_price.created_dt, dim_stock_price.updated_dt
   FROM gna_load_schema.dim_stock_price;
   
   
   
-- pap_view_schema.requisition_tag_vw source

CREATE OR REPLACE VIEW pap_view_schema.requisition_tag_vw
AS ((((((((( SELECT dim_rqstn.job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn
UNION 
 SELECT dim_rqstn.job_req_tag2 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag3 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag4 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag5 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag6 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag7 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag8 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag9 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT dim_rqstn.job_req_tag10 AS job_req_tag1
   FROM gna_load_schema.dim_rqstn dim_rqstn)
UNION 
 SELECT 'All' AS job_req_tag1;
 
 
-- pap_view_schema.dim_act_as_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_act_as_vw
AS SELECT impersonate.security_identifier, impersonate.worker_login, impersonate.leader_worker_login, impersonate.leader_name, rol.role_con::character varying AS role_con
   FROM ( SELECT 'Act As'::character varying AS security_identifier, lower(mv_proxy_user.proxyid::text)::character varying AS worker_login, lower(mv_proxy_user.targetid::text)::character varying AS leader_worker_login, mv_proxy_user.targetid_name AS leader_name
           FROM gna_load_schema.mv_proxy_user
UNION 
         SELECT DISTINCT 'Leader'::character varying AS security_identifier, lower(dim_sec_user_leader_vw.worker_login::text)::character varying AS worker_login, lower(dim_sec_user_leader_vw.leader_worker_login)::character varying AS leader_worker_login, dim_sec_user_leader_vw.full_name AS leader_worker_name
           FROM pap_view_schema.dim_sec_user_leader_vw) impersonate
   LEFT JOIN ( SELECT lower(dim_sec_user_resp.worker_login::text) AS worker_login, "max"(dim_sec_user_resp.role_name::text) AS role_con
           FROM ( SELECT DISTINCT dim_sec_user_resp.worker_login, dim_sec_user_resp.role_name
                   FROM gna_load_schema.dim_sec_user_resp) dim_sec_user_resp
          GROUP BY dim_sec_user_resp.worker_login) rol ON rol.worker_login = impersonate.leader_worker_login::text
INNER JOIN  gna_load_schema.dim_sec_user_resp dim_sec_user_resp on dim_sec_user_resp.worker_login = impersonate.leader_worker_login
UNION 
 SELECT DISTINCT 'Act As'::character varying AS security_identifier, lower(mv_proxy_user.proxyid::text)::character varying AS worker_login, NULL::character varying AS leader_worker_login, NULL::character varying AS leader_name, NULL::character varying AS role_con
   FROM gna_load_schema.mv_proxy_user;
   
   
-- pap_view_schema.dim_cost_center_hier_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_cost_center_hier_vw
AS SELECT dim_cost_center_hier.level1_desc AS level1_val, dim_cost_center_hier.level2_desc AS level2_val, dim_cost_center_hier.level3_desc AS level3_val, dim_cost_center_hier.level4_desc AS level4_val, dim_cost_center_hier.level5_desc AS level5_val, dim_cost_center_hier.level6_desc AS level6_val, dim_cost_center_hier.level7_desc AS level7_val, dim_cost_center_hier.cc_hier_key
   FROM gna_load_schema.dim_cost_center_hier
  WHERE dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text AND dim_cost_center_hier.level1_desc IS NOT NULL AND dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text;


-- pap_view_schema.dim_legal_entity_hier_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_legal_entity_hier_vw
AS SELECT dim_legal_entity_hier.level1_desc AS level1_val, dim_legal_entity_hier.level2_desc AS level2_val, dim_legal_entity_hier.level3_desc AS level3_val, dim_legal_entity_hier.level4_desc AS level4_val, dim_legal_entity_hier.level5_desc AS level5_val, dim_legal_entity_hier.level6_desc AS level6_val, dim_legal_entity_hier.le_hier_key
   FROM gna_load_schema.dim_legal_entity_hier
  WHERE dim_legal_entity_hier.level1_desc IS NOT NULL AND dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text;



-- pap_view_schema.dim_location_hier_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_location_hier_vw
AS SELECT dim_location_hier.level1_desc AS level1_val, dim_location_hier.level2_desc AS level2_val, dim_location_hier.level3_desc AS level3_val, dim_location_hier.level4_desc AS level4_val, dim_location_hier.level5_desc AS level5_val, dim_location_hier.level6_desc AS level6_val, dim_location_hier.level7_desc AS level7_val, dim_location_hier.level8_desc AS level8_val, dim_location_hier.level9_desc AS level9_val, dim_location_hier.level10_desc AS level10_val, dim_location_hier.level11_desc AS level11_val, dim_location_hier.level12_desc AS level12_val, dim_location_hier.level13_desc AS level13_val, dim_location_hier.loc_hier_key
   FROM gna_load_schema.dim_location_hier
  WHERE dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text;



-- pap_view_schema.dim_product_hier_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_product_hier_vw
AS SELECT dim_product_hier.level1_desc AS level1_value, dim_product_hier.level2_desc AS level2_value, dim_product_hier.level3_desc AS level3_value, dim_product_hier.level4_desc AS level4_value, dim_product_hier.level5_desc AS level5_value, dim_product_hier.prod_hier_key
   FROM gna_load_schema.dim_product_hier
  WHERE dim_product_hier.level1_desc IS NOT NULL AND dim_product_hier.datasource_name::text = 'EHANA'::character varying::text AND dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text;



-- pap_view_schema.dim_supervisor_hier_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_supervisor_hier_vw
AS SELECT dim_supervisor_hier.current_level1_emp_full_name AS level1_emp_full_name, dim_supervisor_hier.current_level2_emp_full_name AS level2_emp_full_name, dim_supervisor_hier.current_level3_emp_full_name AS level3_emp_full_name, dim_supervisor_hier.current_level4_emp_full_name AS level4_emp_full_name, dim_supervisor_hier.current_level5_emp_full_name AS level5_emp_full_name, dim_supervisor_hier.current_level6_emp_full_name AS level6_emp_full_name, dim_supervisor_hier.current_level7_emp_full_name AS level7_emp_full_name, dim_supervisor_hier.current_level8_emp_full_name AS level8_emp_full_name, dim_supervisor_hier.current_level9_emp_full_name AS level9_emp_full_name, dim_supervisor_hier.current_level10_emp_full_name AS level10_emp_full_name, dim_supervisor_hier.current_level11_emp_full_name AS level11_emp_full_name, dim_supervisor_hier.sup_hier_key
   FROM gna_load_schema.dim_supervisor_hier
  WHERE dim_supervisor_hier."type"::text = 'Worker'::character varying::text AND dim_supervisor_hier.base_worker_id::text <> '999999'::character varying::text AND trunc('now'::character varying::timestamp without time zone) >= dim_supervisor_hier.effective_start_dt AND trunc('now'::character varying::timestamp without time zone) <= dim_supervisor_hier.effective_end_dt AND dim_supervisor_hier.datasource_name::text = 'WORKDAY'::character varying::text;
	  

-- pap_view_schema.dim_worker_vw source

CREATE OR REPLACE VIEW pap_view_schema.dim_worker_vw
AS SELECT dim_worker.worker_key, dim_worker.employee_num, dim_worker.gnetid_worker_num, dim_worker.applicant_num, dim_worker.rqstn_num, dim_worker.applicant_flg, dim_worker.fst_name, dim_worker.mid_name, dim_worker.last_name, dim_worker.full_name, dim_worker.login, dim_worker.pref_full_name, dim_worker.pref_first_name, dim_worker.alt_name, dim_worker.job_title, dim_worker.religion_name, dim_worker.age, dim_worker.marital_status, dim_worker.sex_code, dim_worker.sex_desc, dim_worker.emp_active_flg, dim_worker.emp_flg, dim_worker.emp_hire_dt, dim_worker.birth_dt, dim_worker.country_of_birth, dim_worker.country_region, dim_worker.email_addr, dim_worker.orig_hire_dt, dim_worker.ethnic_grp_desc, dim_worker.mobile_num, dim_worker.home_phone, dim_worker.home_address, dim_worker.work_address, dim_worker.office_ph_num, dim_worker.extn, dim_worker.position_id, dim_worker.department_code, dim_worker.department_name, dim_worker.effective_from_dt, dim_worker.func_area_desc, dim_worker.func_area, dim_worker."location", dim_worker.room, dim_worker.floor, dim_worker.building, dim_worker.country, dim_worker.state_name, dim_worker.zipcode, dim_worker.work_duration_in_days, dim_worker.work_duration_in_years, dim_worker.work_auth_status, dim_worker.work_auth_start_date, dim_worker.work_auth_end_date, dim_worker.school_country, dim_worker.school_name, dim_worker.hiest_edu_deg_code, dim_worker.hiest_edu_deg_name, dim_worker.hiest_deg_attained_sch_loc, dim_worker.non_major_other_degrees, dim_worker.major_other_degrees, dim_worker.school_other_degrees, dim_worker.school_loc_other_degrees, dim_worker.graduation_date_other_degrees, dim_worker.graduation_dt, dim_worker.hiest_degree, dim_worker.hiest_degree_major, dim_worker.visa_status, dim_worker.nationality, dim_worker.native_lang_name, dim_worker.other_languages, dim_worker.sec_flu_lang_name, dim_worker.assignment_num, dim_worker.rehire_date, dim_worker.contractor_to_hire_flg, dim_worker.anniversary_dt, dim_worker.years_since_last_promotion, dim_worker.rehire_flag, dim_worker.relocation, dim_worker.pay_grade, dim_worker.job_code, dim_worker.worker_type, dim_worker.referrer, dim_worker.referrer_job_code, dim_worker.referrer_pay_grade, dim_worker.supervisor_flg, dim_worker.supervisor_key, dim_worker.supervisor_num, dim_worker.supervisor_name, dim_worker.supervisor_gender, dim_worker.supervisor_ethnicity, dim_worker.emp_manager_gender, dim_worker.prev_employer, dim_worker.prev_employer_job_title, dim_worker.prev_employer_ppl_mgr_status, dim_worker.prev_employer_location, dim_worker.last_promotion_date_1, dim_worker.last_promotion_date_2, dim_worker.last_promotion_date_3, dim_worker.last_promotion_date_4, dim_worker.last_promotion_date_5, dim_worker.last_promotion_date_6, dim_worker.last_promotion_date_7, dim_worker.last_promotion_date_8, dim_worker.last_promotion_date_9, dim_worker.last_promotion_date_10, dim_worker.last_rehire_date1, dim_worker.last_rehire_date2, dim_worker.last_rehire_date3, dim_worker.last_rehire_date4, dim_worker.last_rehire_date5, dim_worker.awr_insert_dt, dim_worker.awr_update_dt, dim_worker.awr_active_flg, dim_worker.awr_onsite_offsite, dim_worker.awr_pay_rate, dim_worker.product_code, dim_worker.product_desc, dim_worker.awr_purchase_order_num, dim_worker.awr_purpose_of_engagement, dim_worker.awr_requistion_num, dim_worker.awr_security_bdg_access_num, dim_worker.awr_space_required_flg, dim_worker.awr_start_date, dim_worker.awr_vendor_agency, dim_worker.awr_temp_assignment_length, dim_worker.awr_work_type, dim_worker.awr_multiple_times, dim_worker.awr_bill_rate, dim_worker.awr_billing_currency, dim_worker.awr_extended_times, dim_worker.awr_gilead_tenure, dim_worker.awr_hours_per_week, dim_worker.awr_created_by_user, dim_worker.awr_deployed_to_site, dim_worker.awr_end_dt, dim_worker.total_experience_in_years, dim_worker.total_pharma_exp_years, dim_worker.total_specific_role_exp_years, dim_worker.tot_role_relevant_experience, dim_worker.no_of_years_per_promotion, dim_worker.days_since_last_promotion, dim_worker.worker_perf_rating, dim_worker.field_employee_flg, dim_worker.last_date_worked, dim_worker.termination_dt, dim_worker.load_key, dim_worker.source_id, dim_worker.datasource_num_id, dim_worker.datasource_name, dim_worker.received_file_name, dim_worker.created_by_key, dim_worker.created_dt, dim_worker.updated_by_key, dim_worker.updated_dt, dim_worker.hist_source_id, dim_worker.hist_employee_num, dim_worker.hist_contingent_employee_num, dim_worker.hist_applicant_num, dim_worker.hist_gnetid_worker_num, dim_worker.hiest_deg_attained, dim_worker.adjusted_service_dt, dim_worker.race, dim_worker.candidate_type, dim_worker.source_type_name, dim_worker.acquisition_dt, dim_worker.rescind_status, dim_worker.veteran_status, dim_worker.disability_status, dim_worker.home_city, dim_worker.payroll_status, dim_worker.leave_status, dim_worker.continuous_service_dt, dim_worker.benefits_service_dt, dim_worker.seniority_dt, dim_worker.acquired_dt, dim_worker.vms_security_id, dim_worker.work_order, dim_worker.task_name, dim_worker.hashdiff, dim_worker.degree_rank, dim_worker.native_langname, dim_worker.adjusted_service_date, dim_worker.total_biopharma_exp_in_years, dim_worker.total_spec_role_exp_in_years, dim_worker.seniority_date, dim_worker.winner_worker_key, dim_worker.vms_applicant_id, dim_worker.vms_worker_id, dim_worker.vms_person_id, dim_worker.vms_contr_on_multi_assgn, dim_worker.vms_days_on_site_per_wk, dim_worker.vms_employee_to_contractor, dim_worker.vms_erp_access, dim_worker.vms_glearn_access, dim_worker.vms_gxp_access, dim_worker.vms_system_access, dim_worker.vms_billable_per_diem, dim_worker.vms_buyer_code, dim_worker.vms_job_posting_owner, dim_worker.vms_rate_category, dim_worker.vms_remit_to_address_code, dim_worker.vms_site_code, dim_worker.vms_wo_original_start_dt, dim_worker.vms_worker_closed_dt, dim_worker.vms_fte, dim_worker.vms_vendor_number, dim_worker.vms_revision_owner, dim_worker.vms_revision_owner_emp_id, dim_worker.vms_category_type, dim_worker.task_code, dim_worker.buddy_id, dim_worker.veteran_status_desc, dim_worker.worker_type_id, dim_worker.suggested_ethnicity, dim_worker.suggested_ethnicity_man, dim_worker.role_change_dt, dim_worker.perf_band1, dim_worker.perf_band2, dim_worker.perf_band3, dim_worker.manager_rating1, dim_worker.manager_rating2, dim_worker.manager_rating3, dim_worker.midyear_rating1, dim_worker.midyear_rating2, dim_worker.long_term_relocation_flg, dim_worker.long_term_relocation_areas, dim_worker.short_term_relocation_flg, dim_worker.shor_term_relocation_areas, dim_worker.relocation_addtnl_comments, dim_worker.willing_to_travel_flg, dim_worker.travel_percent, dim_worker.travel_additional_information, dim_worker.ethnic_group_custom_desc, dim_worker.ethnic_group_custom_sort_order, dim_worker.last_job_change_date1, dim_worker.last_job_change_date2, dim_worker.last_job_change_date3, dim_worker.last_job_change_date4, dim_worker.last_job_change_date5, dim_worker.last_job_change_date6, dim_worker.last_job_change_date7, dim_worker.last_job_change_date8, dim_worker.last_job_change_date9, dim_worker.last_job_change_date10, dim_worker.suggested_gender_manual, dim_worker.talent_quadrant_1, dim_worker.talent_quadrant_2, dim_worker.talent_quadrant_3, dim_worker.office_type, dim_worker.sexual_orientation, dim_worker.gender_identity, dim_worker.key_performer_year_1, dim_worker.key_performer_year_2, dim_worker.key_performer_year_3, dim_worker.legal_local_name, dim_worker.preferred_local_name, dim_worker.last_rehire_date6, dim_worker.last_rehire_date7, dim_worker.last_rehire_date8, dim_worker.last_rehire_date9, dim_worker.last_rehire_date10, dim_worker.termination_dt1, dim_worker.termination_dt2, dim_worker.termination_dt3, dim_worker.termination_dt4, dim_worker.termination_dt5, dim_worker.termination_dt6, dim_worker.termination_dt7, dim_worker.termination_dt8, dim_worker.termination_dt9, dim_worker.termination_dt10, dim_worker.private_hire_ind, dim_worker.acq_comp_name, dim_worker.military_status, dim_worker.military_status_1, dim_worker.military_status_2, dim_worker.military_status_3, dim_worker.military_status_4, dim_worker.military_status_5, dim_worker.military_status_6, dim_worker.military_status_7, dim_worker.military_status_8, dim_worker.military_status_9, dim_worker.military_status_10
   FROM gna_load_schema.dim_worker;	



-- pap_view_schema.mv_proxy_user_vw source

CREATE OR REPLACE VIEW pap_view_schema.mv_proxy_user_vw
AS SELECT mv_proxy_user.proxyid, mv_proxy_user.targetid, mv_proxy_user.proxylevel, mv_proxy_user.targetid_name
   FROM gna_load_schema.mv_proxy_user; 



-- pap_view_schema.user_vw source

CREATE OR REPLACE VIEW pap_view_schema.user_vw
AS SELECT lower(derived_table1.worker_login::text) AS worker_login, "max"(derived_table1.role_name::text) AS role_con
   FROM ( SELECT DISTINCT dim_sec_user_resp.worker_login, dim_sec_user_resp.role_name
           FROM gna_load_schema.dim_sec_user_resp) derived_table1
  GROUP BY derived_table1.worker_login;  
  
 
-- pap_view_schema.dim_combined_hier_vw source

create or replace view pap_view_schema.dim_combined_hier_vw
as
with cte as
(
select
	'All' as level1_desc,
	'All' as level1_val,
	0 as level_number,
	'Supervisor' as flag
union all
select
	concat(concat(concat(concat(dim_supervisor_hier.current_level11_emp_full_name, ' '), '('), split_part(dim_worker.email_addr, '@', 1)), ')') as level1_desc,
	dim_supervisor_hier.current_level11_emp_login as level1_val,
	dim_supervisor_hier.hierarchy_level as level_number,
	'Supervisor' as flag
from
	(
	select
		dim_supervisor_hier.current_level11_emp_full_name,
		dim_supervisor_hier.current_level11_emp_login,
		dim_supervisor_hier.hierarchy_level
	from
		gna_load_schema.dim_supervisor_hier
	where
		dim_supervisor_hier."type"::text = 'Worker'::character varying::text
		and dim_supervisor_hier.base_worker_id::text <> '999999'::character varying::text
		and trunc('now'::character varying::timestamp without time zone) >= dim_supervisor_hier.effective_start_dt
		and trunc('now'::character varying::timestamp without time zone) <= dim_supervisor_hier.effective_end_dt
		and dim_supervisor_hier.datasource_name::text = 'WORKDAY'::character varying::text
		and dim_supervisor_hier.current_level11_emp_login is not null 
		and dim_supervisor_hier.current_level11_emp_login <> 'Unspecified' 
		and dim_supervisor_hier.current_level11_emp_login<>'null'
	) dim_supervisor_hier
inner join 
(
	select
		distinct login,
		email_addr
	from
		gna_load_schema.dim_worker
	where
		emp_flg = 'Y' and email_addr is not null) dim_worker 
on
	lower(dim_supervisor_hier.current_level11_emp_login) = lower(dim_worker.login)
union all
select
'All' as level1_desc,
'All' as level1_val,
0 as level_number,
'Cost Center' as flag
union all
select
distinct dim_cost_center_hier.level1_desc,
dim_cost_center_hier.level1_val,
1 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level2_desc as level1_desc,
dim_cost_center_hier.level2_val as level1_val,
2 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level3_desc as level1_desc,
dim_cost_center_hier.level3_val as level1_val,
3 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level4_desc as level1_desc,
dim_cost_center_hier.level4_val as level1_val,
4 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level5_desc as level1_desc,
dim_cost_center_hier.level5_val as level1_val,
5 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level6_desc as level1_desc,
dim_cost_center_hier.level6_val as level1_val,
6 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_cost_center_hier.level7_desc as level1_desc,
dim_cost_center_hier.level7_val as level1_val,
7 as level_number,
'Cost Center'::character varying as flag
from
gna_load_schema.dim_cost_center_hier
where
dim_cost_center_hier.hryid::text ~~ '%Z0001%'::character varying::text
and dim_cost_center_hier.level1_desc is not null
and dim_cost_center_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
'All' as level1_desc,
'All' as level1_val,
0 as level_number,
'Location' as flag
union all
select
distinct dim_location_hier.level1_desc,
dim_location_hier.level1_val,
1 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level2_desc as level1_desc,
dim_location_hier.level2_val as level1_val,
2 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level3_desc as level1_desc,
dim_location_hier.level3_val as level1_val,
3 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level4_desc as level1_desc,
dim_location_hier.level4_val as level1_val,
4 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level5_desc as level1_desc,
dim_location_hier.level5_val as level1_val,
5 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level6_desc as level1_desc,
dim_location_hier.level6_val as level1_val,
6 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level7_desc as level1_desc,
dim_location_hier.level7_val as level1_val,
7 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level8_desc as level1_desc,
dim_location_hier.level8_val as level1_val,
8 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level9_desc as level1_desc,
dim_location_hier.level9_val as level1_val,
9 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level10_desc as level1_desc,
dim_location_hier.level10_val as level1_val,
10 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level11_desc as level1_desc,
dim_location_hier.level11_val as level1_val,
11 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level12_desc as level1_desc,
dim_location_hier.level12_val as level1_val,
12 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
distinct dim_location_hier.level13_desc as level1_desc,
dim_location_hier.level13_val as level1_val,
13 as level_number,
'Location'::character varying as flag
from
gna_load_schema.dim_location_hier
where
dim_location_hier.datasource_name::text = 'WORKDAY'::character varying::text
union all
select
'All' as level1_desc,
'All' as level1_val,
0 as level_number,
'Product' as flag
union all
select
distinct dim_product_hier.level1_desc,
dim_product_hier.level1_value as level1_val,
1 as level_number,
'Product'::character varying as flag
from
gna_load_schema.dim_product_hier
where
dim_product_hier.level1_desc is not null
and dim_product_hier.datasource_name::text = 'EHANA'::character varying::text
and dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text
union all
select
distinct dim_product_hier.level2_desc as level1_desc,
dim_product_hier.level2_value as level1_val,
2 as level_number,
'Product'::character varying as flag
from
gna_load_schema.dim_product_hier
where
dim_product_hier.level1_desc is not null
and dim_product_hier.datasource_name::text = 'EHANA'::character varying::text
and dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text
union all
select
distinct dim_product_hier.level3_desc as level1_desc,
dim_product_hier.level3_value as level1_val,
3 as level_number,
'Product'::character varying as flag
from
gna_load_schema.dim_product_hier
where
dim_product_hier.level1_desc is not null
and dim_product_hier.datasource_name::text = 'EHANA'::character varying::text
and dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text
union all
select
distinct dim_product_hier.level4_desc as level1_desc,
dim_product_hier.level4_value as level1_val,
4 as level_number,
'Product'::character varying as flag
from
gna_load_schema.dim_product_hier
where
dim_product_hier.level1_desc is not null
and dim_product_hier.datasource_name::text = 'EHANA'::character varying::text
and dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text
union all
select
distinct dim_product_hier.level5_desc as level1_desc,
dim_product_hier.level5_value as level1_val,
5 as level_number,
'Product'::character varying as flag
from
gna_load_schema.dim_product_hier
where
dim_product_hier.level1_desc is not null
and dim_product_hier.datasource_name::text = 'EHANA'::character varying::text
and dim_product_hier.hryid::text = '0106/1000/TOTALPROD'::character varying::text
union all
select
	'All' as level1_desc,
	'All' as level1_val,
	0 as level_number,
	'Legal Entity' as flag
union all
select
distinct dim_legal_entity_hier.level1_desc,
dim_legal_entity_hier.level1_val,
1 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_legal_entity_hier.level2_desc as level1_desc,
dim_legal_entity_hier.level2_val as level1_val,
2 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_legal_entity_hier.level3_desc as level1_desc,
dim_legal_entity_hier.level3_val as level1_val,
3 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_legal_entity_hier.level4_desc as level1_desc,
dim_legal_entity_hier.level4_val as level1_val,
4 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_legal_entity_hier.level5_desc as level1_desc,
dim_legal_entity_hier.level5_val as level1_val,
5 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
distinct dim_legal_entity_hier.level6_desc as level1_desc,
dim_legal_entity_hier.level6_val as level1_val,
6 as level_number,
'Legal Entity'::character varying as flag
from
gna_load_schema.dim_legal_entity_hier
where
dim_legal_entity_hier.level1_desc is not null
and dim_legal_entity_hier.datasource_name::text = 'EHANA'::character varying::text
union all
select
	'All' as level1_desc,
	'All' as level1_val,
	0 as level_number,
	'CC Site' as flag
union all
select
distinct fhf.site_cc_level1_desc as level1_desc,
fhf.site_cc_level1_value as level1_val,
1 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level2_desc as level1_desc,
fhf.site_cc_level2_value as level1_val,
2 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level3_desc as level1_desc,
fhf.site_cc_level3_value as level1_val,
3 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level4_desc as level1_desc,
fhf.site_cc_level4_value as level1_val,
4 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level5_desc as level1_desc,
fhf.site_cc_level5_value as level1_val,
5 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level6_desc as level1_desc,
fhf.site_cc_level6_value as level1_val,
6 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
distinct fhf.site_cc_level7_desc as level1_desc,
fhf.site_cc_level7_value as level1_val,
7 as level_number,
'CC Site'::character varying as flag
from
pap_view_schema.fact_hyperion_forecast_denormalized_vw fhf
join gna_load_schema.dim_cost_center_hier dcch on
fhf.cc_hier_key = dcch.cc_hier_key
and dcch.hryid::text ~~ '%Z0001%'::character varying::text
join gna_load_schema.dim_cost_center_hier dcch1 on
dcch.cc_nodeval::text = dcch1.cc_nodeval::text
and dcch1.hryid::text ~~ '%Z0003%'::character varying::text
union all
select
'All' as level1_desc,
'All' as level1_val,
0 as level_number,
'CC Owner' as flag
union all 
 select
	distinct t71108_cc.current_level11_emp_full_name as level1_desc,
	t71108_cc.current_level11_emp_login as level1_val,
	t71108_cc.hierarchy_level as level_number,
	'CC Owner'::character varying as flag
from
	gna_load_schema.dim_cost_center_hier t71116
left join gna_load_schema.dim_supervisor_hier t71108_cc on
	t71108_cc.base_worker_id::text = t71116.cc_owner::text
	and t71108_cc.current_flg::text = 'Y'::character varying::text
where
	t71116.hryid::text ~~ '%Z0001%'::character varying::text
	and t71116.level1_desc is not null
	and t71116.datasource_name::text = 'EHANA'::character varying::text
	)
	select distinct a.level1_desc, a.level1_val, b.level_number, a.flag
	from cte a
	join (select level1_desc, min(level_number) level_number, flag from cte
	group by level1_desc, flag)
	b
	on a.level1_desc = b.level1_desc
	and a.flag = b.flag
	and a.level_number = b.level_number
;



-- pap_view_schema.dim_combined_hier_vw_rls1

CREATE OR REPLACE VIEW pap_view_schema.dim_combined_hier_vw_rls1 AS 
SELECT 
  CASE WHEN (
    "vw"."flag" = CAST('Supervisor' AS TEXT)
  ) THEN (
    (
      "vw"."level1_desc" || CAST('-' AS TEXT)
    ) || CAST("vw"."level_number" AS VARCHAR)
  ) ELSE "vw"."level1_desc" END AS "level1_desc", 
  "vw"."level1_val" AS "level1_val", 
  "vw"."level_number" AS "level_number", 
  "vw"."flag" AS "flag", 
  "row_sec"."role_name_access_list" AS "role_name_access_list", 
  CASE WHEN (
    (
      "badge_us_nonus"."dim_value1" IS NULL 
      AND (
        "vw"."level1_val" <> CAST('All' AS TEXT)
      )
    ) 
    AND (
      "vw"."flag" = CAST('Location' AS TEXT)
    )
  ) THEN CAST('Non US' AS TEXT) WHEN (
    (
      "badge_us_nonus"."dim_value1" IS NOT NULL 
      OR (
        "vw"."level1_val" = CAST('All' AS TEXT)
      )
    ) 
    AND (
      "vw"."flag" = CAST('Location' AS TEXT)
    )
  ) THEN CAST('US' AS TEXT) ELSE CAST(NULL AS TEXT) END AS "us_nonus_flag" 
FROM 
  (
    "pap_view_schema"."dim_combined_hier_vw" AS "vw" 
    LEFT JOIN (
      SELECT 
        DISTINCT "unnamed_unpivot17"."dim_value1" AS "dim_value1" 
      FROM 
        (
          SELECT 
            DISTINCT "dlh"."level1_val" AS "level1_val", 
            "dlh"."level2_val" AS "level2_val", 
            "dlh"."level3_val" AS "level3_val", 
            "dlh"."level4_val" AS "level4_val", 
            "dlh"."level5_val" AS "level5_val", 
            "dlh"."level6_val" AS "level6_val", 
            "dlh"."level7_val" AS "level7_val", 
            "dlh"."level8_val" AS "level8_val", 
            "dlh"."level9_val" AS "level9_val", 
            "dlh"."level10_val" AS "level10_val", 
            "dlh"."level11_val" AS "level11_val", 
            "dlh"."level12_val" AS "level12_val", 
            "dlh"."level13_val" AS "level13_val" 
          FROM 
            "gna_load_schema"."dim_location_hier" AS "dlh" 
          WHERE 
            (
              (
                "dlh"."level2_val" = CAST('LO_US_COMM' AS TEXT)
              ) 
              OR (
                "dlh"."level2_val" = CAST(
                  'LOCATION_HIERARCHY-3-582' AS TEXT
                )
              )
            ) 
            AND (
              (
                (
                  (
                    "dlh"."level3_val" = CAST(
                      'LOCATION_HIERARCHY-3-582' AS TEXT
                    )
                  ) 
                  OR (
                    "dlh"."level3_val" = CAST('US000' AS TEXT)
                  )
                ) 
                OR (
                  "dlh"."level3_val" = CAST('LO_US000' AS TEXT)
                )
              ) 
              OR (
                "dlh"."level3_val" = CAST(
                  'LOCATION_HIERARCHY-3-586' AS TEXT
                )
              )
            )
        ) AS "a" UNPIVOT EXCLUDE NULLS (
          "dim_value1" FOR "dim_name1" IN (
            "a"."level1_val" AS "level1_val", 
            "a"."level2_val" AS "level2_val", 
            "a"."level3_val" AS "level3_val", 
            "a"."level4_val" AS "level4_val", 
            "a"."level5_val" AS "level5_val", 
            "a"."level6_val" AS "level6_val", 
            "a"."level7_val" AS "level7_val", 
            "a"."level8_val" AS "level8_val", 
            "a"."level9_val" AS "level9_val", 
            "a"."level10_val" AS "level10_val", 
            "a"."level11_val" AS "level11_val", 
            "a"."level12_val" AS "level12_val", 
            "a"."level13_val" AS "level13_val"
          )
        ) AS "unnamed_unpivot17"
    ) AS "badge_us_nonus" ON (
      "vw"."level1_val" = "badge_us_nonus"."dim_value1"
    ) 
    AND (
      "vw"."flag" = CAST('Location' AS TEXT)
    )
  ) 
  LEFT JOIN (
    SELECT 
      "derived_table18"."dim_value" AS "dim_value", 
      "derived_table18"."dim_flag" AS "dim_flag", 
      LISTAGG(
        "derived_table18"."login_user", 
        CAST(',' AS TEXT)
      ) WITHIN GROUP (
        ORDER BY 
          "derived_table18"."login_user" ASC NULLS LAST
      ) AS "role_name_access_list" 
    FROM 
      (
        SELECT 
          DISTINCT "t"."dim_value" AS "dim_value", 
          CAST(
            "role_name_access_list1" AS VARCHAR
          ) AS "login_user", 
          CASE WHEN (
            "t"."dim_name" LIKE CAST('cc_owner%' AS TEXT)
          ) THEN CAST('CC Owner' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('le_hier%' AS TEXT)
          ) THEN CAST('Legal Entity' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('le_level%' AS TEXT)
          ) THEN CAST('Legal Entity' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('site_%' AS TEXT)
          ) THEN CAST('CC Site' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('cc_%' AS TEXT)
          ) THEN CAST('Cost Center' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('product%' AS TEXT)
          ) THEN CAST('Product' AS TEXT) WHEN (
            "t"."dim_name" LIKE CAST('current_%' AS TEXT)
          ) THEN CAST('Supervisor' AS TEXT) ELSE CAST('Location' AS TEXT) END AS "dim_flag" 
        FROM 
          (
            (
              (
                (
                  (
                    (
                      (
                        (
                          SELECT 
                            "unnamed_unpivot2"."role_name_access_list" AS "role_name_access_list", 
                            "unnamed_unpivot2"."login" AS "login", 
                            "unnamed_unpivot2"."dim_name" AS "dim_name", 
                            "unnamed_unpivot2"."dim_value" AS "dim_value" 
                          FROM 
                            (
                              SELECT 
                                DISTINCT "jd"."current_level11_emp_login" AS "current_level11_emp_login", 
                                "jd"."cc_level1_value" AS "cc_level1_value", 
                                "jd"."cc_level2_value" AS "cc_level2_value", 
                                "jd"."cc_level3_value" AS "cc_level3_value", 
                                "jd"."cc_level4_value" AS "cc_level4_value", 
                                "jd"."cc_level5_value" AS "cc_level5_value", 
                                "jd"."cc_level6_value" AS "cc_level6_value", 
                                "jd"."cc_level7_value" AS "cc_level7_value", 
                                "jd"."product_value1" AS "product_value1", 
                                "jd"."product_value2" AS "product_value2", 
                                "jd"."product_value3" AS "product_value3", 
                                "jd"."product_value4" AS "product_value4", 
                                "jd"."product_value5" AS "product_value5", 
                                "jd"."location_code_level1" AS "location_code_level1", 
                                "jd"."location_code_level2" AS "location_code_level2", 
                                "jd"."location_code_level3" AS "location_code_level3", 
                                "jd"."location_code_level4" AS "location_code_level4", 
                                "jd"."location_code_level5" AS "location_code_level5", 
                                "jd"."location_code_level6" AS "location_code_level6", 
                                "jd"."location_code_level7" AS "location_code_level7", 
                                "jd"."location_code_level8" AS "location_code_level8", 
                                "jd"."location_code_level9" AS "location_code_level9", 
                                "jd"."location_code_level10" AS "location_code_level10", 
                                "jd"."location_code_level11" AS "location_code_level11", 
                                "jd"."location_code_level12" AS "location_code_level12", 
                                "jd"."location_code_level13" AS "location_code_level13", 
                                "jd"."cc_owner_level11_emp_login" AS "cc_owner_level11_emp_login", 
                                "jd"."site_cc_level1_value" AS "site_cc_level1_value", 
                                "jd"."site_cc_level2_value" AS "site_cc_level2_value", 
                                "jd"."site_cc_level3_value" AS "site_cc_level3_value", 
                                "jd"."site_cc_level4_value" AS "site_cc_level4_value", 
                                "jd"."site_cc_level5_value" AS "site_cc_level5_value", 
                                "jd"."site_cc_level6_value" AS "site_cc_level6_value", 
                                "jd"."site_cc_level7_value" AS "site_cc_level7_value", 
                                "jd"."le_level1_val" AS "le_level1_val", 
                                "jd"."le_level2_val" AS "le_level2_val", 
                                "jd"."le_level3_val" AS "le_level3_val", 
                                "jd"."le_level4_val" AS "le_level4_val", 
                                "jd"."le_level5_val" AS "le_level5_val", 
                                "jd"."le_level6_val" AS "le_level6_val", 
                                "jd"."role_name_access_list" AS "role_name_access_list", 
                                SPLIT_TO_ARRAY(
                                  "jd"."role_name_access_list", 
                                  CAST(',' AS TEXT)
                                ) AS "login" 
                              FROM 
                                "gna_load_schema"."fact_job_events_denormalized" AS "jd"
                            ) AS "derived_table1" UNPIVOT EXCLUDE NULLS (
                              "dim_value" FOR "dim_name" IN (
                                "derived_table1"."current_level11_emp_login" AS "current_level11_emp_login", 
                                "derived_table1"."cc_level1_value" AS "cc_level1_value", 
                                "derived_table1"."cc_level2_value" AS "cc_level2_value", 
                                "derived_table1"."cc_level3_value" AS "cc_level3_value", 
                                "derived_table1"."cc_level4_value" AS "cc_level4_value", 
                                "derived_table1"."cc_level5_value" AS "cc_level5_value", 
                                "derived_table1"."cc_level6_value" AS "cc_level6_value", 
                                "derived_table1"."cc_level7_value" AS "cc_level7_value", 
                                "derived_table1"."product_value1" AS "product_value1", 
                                "derived_table1"."product_value2" AS "product_value2", 
                                "derived_table1"."product_value3" AS "product_value3", 
                                "derived_table1"."product_value4" AS "product_value4", 
                                "derived_table1"."product_value5" AS "product_value5", 
                                "derived_table1"."location_code_level1" AS "location_code_level1", 
                                "derived_table1"."location_code_level2" AS "location_code_level2", 
                                "derived_table1"."location_code_level3" AS "location_code_level3", 
                                "derived_table1"."location_code_level4" AS "location_code_level4", 
                                "derived_table1"."location_code_level5" AS "location_code_level5", 
                                "derived_table1"."location_code_level6" AS "location_code_level6", 
                                "derived_table1"."location_code_level7" AS "location_code_level7", 
                                "derived_table1"."location_code_level8" AS "location_code_level8", 
                                "derived_table1"."location_code_level9" AS "location_code_level9", 
                                "derived_table1"."location_code_level10" AS "location_code_level10", 
                                "derived_table1"."location_code_level11" AS "location_code_level11", 
                                "derived_table1"."location_code_level12" AS "location_code_level12", 
                                "derived_table1"."location_code_level13" AS "location_code_level13", 
                                "derived_table1"."cc_owner_level11_emp_login" AS "cc_owner_level11_emp_login", 
                                "derived_table1"."site_cc_level1_value" AS "site_cc_level1_value", 
                                "derived_table1"."site_cc_level2_value" AS "site_cc_level2_value", 
                                "derived_table1"."site_cc_level3_value" AS "site_cc_level3_value", 
                                "derived_table1"."site_cc_level4_value" AS "site_cc_level4_value", 
                                "derived_table1"."site_cc_level5_value" AS "site_cc_level5_value", 
                                "derived_table1"."site_cc_level6_value" AS "site_cc_level6_value", 
                                "derived_table1"."site_cc_level7_value" AS "site_cc_level7_value", 
                                "derived_table1"."le_level1_val" AS "le_level1_val", 
                                "derived_table1"."le_level2_val" AS "le_level2_val", 
                                "derived_table1"."le_level3_val" AS "le_level3_val", 
                                "derived_table1"."le_level4_val" AS "le_level4_val", 
                                "derived_table1"."le_level5_val" AS "le_level5_val", 
                                "derived_table1"."le_level6_val" AS "le_level6_val"
                              )
                            ) AS "unnamed_unpivot2"
                        ) 
                        UNION ALL 
                          (
                            SELECT 
                              "unnamed_unpivot4"."role_name_access_list" AS "role_name_access_list", 
                              "unnamed_unpivot4"."login" AS "login", 
                              "unnamed_unpivot4"."dim_name" AS "dim_name", 
                              "unnamed_unpivot4"."dim_value" AS "dim_value" 
                            FROM 
                              (
                                SELECT 
                                  DISTINCT "jd_1"."current_level11_emp_login" AS "current_level11_emp_login", 
                                  "jd_1"."cc_level1_value" AS "cc_level1_value", 
                                  "jd_1"."cc_level2_value" AS "cc_level2_value", 
                                  "jd_1"."cc_level3_value" AS "cc_level3_value", 
                                  "jd_1"."cc_level4_value" AS "cc_level4_value", 
                                  "jd_1"."cc_level5_value" AS "cc_level5_value", 
                                  "jd_1"."cc_level6_value" AS "cc_level6_value", 
                                  "jd_1"."cc_level7_value" AS "cc_level7_value", 
                                  "jd_1"."product_value1" AS "product_value1", 
                                  "jd_1"."product_value2" AS "product_value2", 
                                  "jd_1"."product_value3" AS "product_value3", 
                                  "jd_1"."product_value4" AS "product_value4", 
                                  "jd_1"."product_value5" AS "product_value5", 
                                  "jd_1"."location_code_level1" AS "location_code_level1", 
                                  "jd_1"."location_code_level2" AS "location_code_level2", 
                                  "jd_1"."location_code_level3" AS "location_code_level3", 
                                  "jd_1"."location_code_level4" AS "location_code_level4", 
                                  "jd_1"."location_code_level5" AS "location_code_level5", 
                                  "jd_1"."location_code_level6" AS "location_code_level6", 
                                  "jd_1"."location_code_level7" AS "location_code_level7", 
                                  "jd_1"."location_code_level8" AS "location_code_level8", 
                                  "jd_1"."location_code_level9" AS "location_code_level9", 
                                  "jd_1"."location_code_level10" AS "location_code_level10", 
                                  "jd_1"."location_code_level11" AS "location_code_level11", 
                                  "jd_1"."location_code_level12" AS "location_code_level12", 
                                  "jd_1"."level13_val" AS "level13_val", 
                                  "jd_1"."role_name_access_list" AS "role_name_access_list", 
                                  SPLIT_TO_ARRAY(
                                    "jd_1"."role_name_access_list", 
                                    CAST(',' AS TEXT)
                                  ) AS "login" 
                                FROM 
                                  "gna_load_schema"."fact_vfw_badge_dtl_denormalized" AS "jd_1"
                              ) AS "derived_table3" UNPIVOT EXCLUDE NULLS (
                                "dim_value" FOR "dim_name" IN (
                                  "derived_table3"."current_level11_emp_login" AS "current_level11_emp_login", 
                                  "derived_table3"."cc_level1_value" AS "cc_level1_value", 
                                  "derived_table3"."cc_level2_value" AS "cc_level2_value", 
                                  "derived_table3"."cc_level3_value" AS "cc_level3_value", 
                                  "derived_table3"."cc_level4_value" AS "cc_level4_value", 
                                  "derived_table3"."cc_level5_value" AS "cc_level5_value", 
                                  "derived_table3"."cc_level6_value" AS "cc_level6_value", 
                                  "derived_table3"."cc_level7_value" AS "cc_level7_value", 
                                  "derived_table3"."product_value1" AS "product_value1", 
                                  "derived_table3"."product_value2" AS "product_value2", 
                                  "derived_table3"."product_value3" AS "product_value3", 
                                  "derived_table3"."product_value4" AS "product_value4", 
                                  "derived_table3"."product_value5" AS "product_value5", 
                                  "derived_table3"."location_code_level1" AS "location_code_level1", 
                                  "derived_table3"."location_code_level2" AS "location_code_level2", 
                                  "derived_table3"."location_code_level3" AS "location_code_level3", 
                                  "derived_table3"."location_code_level4" AS "location_code_level4", 
                                  "derived_table3"."location_code_level5" AS "location_code_level5", 
                                  "derived_table3"."location_code_level6" AS "location_code_level6", 
                                  "derived_table3"."location_code_level7" AS "location_code_level7", 
                                  "derived_table3"."location_code_level8" AS "location_code_level8", 
                                  "derived_table3"."location_code_level9" AS "location_code_level9", 
                                  "derived_table3"."location_code_level10" AS "location_code_level10", 
                                  "derived_table3"."location_code_level11" AS "location_code_level11", 
                                  "derived_table3"."location_code_level12" AS "location_code_level12", 
                                  "derived_table3"."level13_val" AS "level13_val"
                                )
                              ) AS "unnamed_unpivot4"
                          )
                      ) 
                      UNION ALL 
                        (
                          SELECT 
                            "unnamed_unpivot6"."role_name_access_list" AS "role_name_access_list", 
                            "unnamed_unpivot6"."login" AS "login", 
                            "unnamed_unpivot6"."dim_name" AS "dim_name", 
                            "unnamed_unpivot6"."dim_value" AS "dim_value" 
                          FROM 
                            (
                              SELECT 
                                DISTINCT "fact_upd_feedback_survey_denormalized"."current_level11_emp_login" AS "current_level11_emp_login", 
                                "fact_upd_feedback_survey_denormalized"."cc_level1_value" AS "cc_level1_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level2_value" AS "cc_level2_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level3_value" AS "cc_level3_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level4_value" AS "cc_level4_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level5_value" AS "cc_level5_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level6_value" AS "cc_level6_value", 
                                "fact_upd_feedback_survey_denormalized"."cc_level7_value" AS "cc_level7_value", 
                                "fact_upd_feedback_survey_denormalized"."product_value1" AS "product_value1", 
                                "fact_upd_feedback_survey_denormalized"."product_value2" AS "product_value2", 
                                "fact_upd_feedback_survey_denormalized"."product_value3" AS "product_value3", 
                                "fact_upd_feedback_survey_denormalized"."product_value4" AS "product_value4", 
                                "fact_upd_feedback_survey_denormalized"."product_value5" AS "product_value5", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level1" AS "location_code_level1", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level2" AS "location_code_level2", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level3" AS "location_code_level3", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level4" AS "location_code_level4", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level5" AS "location_code_level5", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level6" AS "location_code_level6", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level7" AS "location_code_level7", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level8" AS "location_code_level8", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level9" AS "location_code_level9", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level10" AS "location_code_level10", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level11" AS "location_code_level11", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level12" AS "location_code_level12", 
                                "fact_upd_feedback_survey_denormalized"."location_code_level13" AS "location_code_level13", 
                                "fact_upd_feedback_survey_denormalized"."role_name_access_list" AS "role_name_access_list", 
                                SPLIT_TO_ARRAY(
                                  "fact_upd_feedback_survey_denormalized"."role_name_access_list", 
                                  CAST(',' AS TEXT)
                                ) AS "login" 
                              FROM 
                                "gna_load_schema"."fact_upd_feedback_survey_denormalized" AS "fact_upd_feedback_survey_denormalized"
                            ) AS "derived_table5" UNPIVOT EXCLUDE NULLS (
                              "dim_value" FOR "dim_name" IN (
                                "derived_table5"."current_level11_emp_login" AS "current_level11_emp_login", 
                                "derived_table5"."cc_level1_value" AS "cc_level1_value", 
                                "derived_table5"."cc_level2_value" AS "cc_level2_value", 
                                "derived_table5"."cc_level3_value" AS "cc_level3_value", 
                                "derived_table5"."cc_level4_value" AS "cc_level4_value", 
                                "derived_table5"."cc_level5_value" AS "cc_level5_value", 
                                "derived_table5"."cc_level6_value" AS "cc_level6_value", 
                                "derived_table5"."cc_level7_value" AS "cc_level7_value", 
                                "derived_table5"."product_value1" AS "product_value1", 
                                "derived_table5"."product_value2" AS "product_value2", 
                                "derived_table5"."product_value3" AS "product_value3", 
                                "derived_table5"."product_value4" AS "product_value4", 
                                "derived_table5"."product_value5" AS "product_value5", 
                                "derived_table5"."location_code_level1" AS "location_code_level1", 
                                "derived_table5"."location_code_level2" AS "location_code_level2", 
                                "derived_table5"."location_code_level3" AS "location_code_level3", 
                                "derived_table5"."location_code_level4" AS "location_code_level4", 
                                "derived_table5"."location_code_level5" AS "location_code_level5", 
                                "derived_table5"."location_code_level6" AS "location_code_level6", 
                                "derived_table5"."location_code_level7" AS "location_code_level7", 
                                "derived_table5"."location_code_level8" AS "location_code_level8", 
                                "derived_table5"."location_code_level9" AS "location_code_level9", 
                                "derived_table5"."location_code_level10" AS "location_code_level10", 
                                "derived_table5"."location_code_level11" AS "location_code_level11", 
                                "derived_table5"."location_code_level12" AS "location_code_level12", 
                                "derived_table5"."location_code_level13" AS "location_code_level13"
                              )
                            ) AS "unnamed_unpivot6"
                        )
                    ) 
                    UNION ALL 
                      (
                        SELECT 
                          "unnamed_unpivot8"."role_name_access_list" AS "role_name_access_list", 
                          "unnamed_unpivot8"."login" AS "login", 
                          "unnamed_unpivot8"."dim_name" AS "dim_name", 
                          "unnamed_unpivot8"."dim_value" AS "dim_value" 
                        FROM 
                          (
                            SELECT 
                              DISTINCT "fact_awards_denormalized"."current_level11_emp_login" AS "current_level11_emp_login", 
                              "fact_awards_denormalized"."cc_level1_value" AS "cc_level1_value", 
                              "fact_awards_denormalized"."cc_level2_value" AS "cc_level2_value", 
                              "fact_awards_denormalized"."cc_level3_value" AS "cc_level3_value", 
                              "fact_awards_denormalized"."cc_level4_value" AS "cc_level4_value", 
                              "fact_awards_denormalized"."cc_level5_value" AS "cc_level5_value", 
                              "fact_awards_denormalized"."cc_level6_value" AS "cc_level6_value", 
                              "fact_awards_denormalized"."cc_level7_value" AS "cc_level7_value", 
                              "fact_awards_denormalized"."product_value1" AS "product_value1", 
                              "fact_awards_denormalized"."product_value2" AS "product_value2", 
                              "fact_awards_denormalized"."product_value3" AS "product_value3", 
                              "fact_awards_denormalized"."product_value4" AS "product_value4", 
                              "fact_awards_denormalized"."product_value5" AS "product_value5", 
                              "fact_awards_denormalized"."location_code_level1" AS "location_code_level1", 
                              "fact_awards_denormalized"."location_code_level2" AS "location_code_level2", 
                              "fact_awards_denormalized"."location_code_level3" AS "location_code_level3", 
                              "fact_awards_denormalized"."location_code_level4" AS "location_code_level4", 
                              "fact_awards_denormalized"."location_code_level5" AS "location_code_level5", 
                              "fact_awards_denormalized"."location_code_level6" AS "location_code_level6", 
                              "fact_awards_denormalized"."location_code_level7" AS "location_code_level7", 
                              "fact_awards_denormalized"."location_code_level8" AS "location_code_level8", 
                              "fact_awards_denormalized"."location_code_level9" AS "location_code_level9", 
                              "fact_awards_denormalized"."location_code_level10" AS "location_code_level10", 
                              "fact_awards_denormalized"."location_code_level11" AS "location_code_level11", 
                              "fact_awards_denormalized"."location_code_level12" AS "location_code_level12", 
                              "fact_awards_denormalized"."location_code_level13" AS "location_code_level13", 
                              "fact_awards_denormalized"."role_name_access_list" AS "role_name_access_list", 
                              SPLIT_TO_ARRAY(
                                "fact_awards_denormalized"."role_name_access_list", 
                                CAST(',' AS TEXT)
                              ) AS "login" 
                            FROM 
                              "gna_load_schema"."fact_awards_denormalized" AS "fact_awards_denormalized"
                          ) AS "derived_table7" UNPIVOT EXCLUDE NULLS (
                            "dim_value" FOR "dim_name" IN (
                              "derived_table7"."current_level11_emp_login" AS "current_level11_emp_login", 
                              "derived_table7"."cc_level1_value" AS "cc_level1_value", 
                              "derived_table7"."cc_level2_value" AS "cc_level2_value", 
                              "derived_table7"."cc_level3_value" AS "cc_level3_value", 
                              "derived_table7"."cc_level4_value" AS "cc_level4_value", 
                              "derived_table7"."cc_level5_value" AS "cc_level5_value", 
                              "derived_table7"."cc_level6_value" AS "cc_level6_value", 
                              "derived_table7"."cc_level7_value" AS "cc_level7_value", 
                              "derived_table7"."product_value1" AS "product_value1", 
                              "derived_table7"."product_value2" AS "product_value2", 
                              "derived_table7"."product_value3" AS "product_value3", 
                              "derived_table7"."product_value4" AS "product_value4", 
                              "derived_table7"."product_value5" AS "product_value5", 
                              "derived_table7"."location_code_level1" AS "location_code_level1", 
                              "derived_table7"."location_code_level2" AS "location_code_level2", 
                              "derived_table7"."location_code_level3" AS "location_code_level3", 
                              "derived_table7"."location_code_level4" AS "location_code_level4", 
                              "derived_table7"."location_code_level5" AS "location_code_level5", 
                              "derived_table7"."location_code_level6" AS "location_code_level6", 
                              "derived_table7"."location_code_level7" AS "location_code_level7", 
                              "derived_table7"."location_code_level8" AS "location_code_level8", 
                              "derived_table7"."location_code_level9" AS "location_code_level9", 
                              "derived_table7"."location_code_level10" AS "location_code_level10", 
                              "derived_table7"."location_code_level11" AS "location_code_level11", 
                              "derived_table7"."location_code_level12" AS "location_code_level12", 
                              "derived_table7"."location_code_level13" AS "location_code_level13"
                            )
                          ) AS "unnamed_unpivot8"
                      )
                  ) 
                  UNION ALL 
                    (
                      SELECT 
                        "unnamed_unpivot10"."role_name_access_list" AS "role_name_access_list", 
                        "unnamed_unpivot10"."login" AS "login", 
                        "unnamed_unpivot10"."dim_name" AS "dim_name", 
                        "unnamed_unpivot10"."dim_value" AS "dim_value" 
                      FROM 
                        (
                          SELECT 
                            DISTINCT "fact_equity_denormalized"."current_level11_emp_login" AS "current_level11_emp_login", 
                            "fact_equity_denormalized"."cc_level1_value" AS "cc_level1_value", 
                            "fact_equity_denormalized"."cc_level2_value" AS "cc_level2_value", 
                            "fact_equity_denormalized"."cc_level3_value" AS "cc_level3_value", 
                            "fact_equity_denormalized"."cc_level4_value" AS "cc_level4_value", 
                            "fact_equity_denormalized"."cc_level5_value" AS "cc_level5_value", 
                            "fact_equity_denormalized"."cc_level6_value" AS "cc_level6_value", 
                            "fact_equity_denormalized"."cc_level7_value" AS "cc_level7_value", 
                            "fact_equity_denormalized"."product_value1" AS "product_value1", 
                            "fact_equity_denormalized"."product_value2" AS "product_value2", 
                            "fact_equity_denormalized"."product_value3" AS "product_value3", 
                            "fact_equity_denormalized"."product_value4" AS "product_value4", 
                            "fact_equity_denormalized"."product_value5" AS "product_value5", 
                            "fact_equity_denormalized"."location_code_level1" AS "location_code_level1", 
                            "fact_equity_denormalized"."location_code_level2" AS "location_code_level2", 
                            "fact_equity_denormalized"."location_code_level3" AS "location_code_level3", 
                            "fact_equity_denormalized"."location_code_level4" AS "location_code_level4", 
                            "fact_equity_denormalized"."location_code_level5" AS "location_code_level5", 
                            "fact_equity_denormalized"."location_code_level6" AS "location_code_level6", 
                            "fact_equity_denormalized"."location_code_level7" AS "location_code_level7", 
                            "fact_equity_denormalized"."location_code_level8" AS "location_code_level8", 
                            "fact_equity_denormalized"."location_code_level9" AS "location_code_level9", 
                            "fact_equity_denormalized"."location_code_level10" AS "location_code_level10", 
                            "fact_equity_denormalized"."location_code_level11" AS "location_code_level11", 
                            "fact_equity_denormalized"."location_code_level12" AS "location_code_level12", 
                            "fact_equity_denormalized"."location_code_level13" AS "location_code_level13", 
                            "fact_equity_denormalized"."role_name_access_list" AS "role_name_access_list", 
                            SPLIT_TO_ARRAY(
                              "fact_equity_denormalized"."role_name_access_list", 
                              CAST(',' AS TEXT)
                            ) AS "login" 
                          FROM 
                            "gna_load_schema"."fact_equity_denormalized" AS "fact_equity_denormalized"
                        ) AS "derived_table9" UNPIVOT EXCLUDE NULLS (
                          "dim_value" FOR "dim_name" IN (
                            "derived_table9"."current_level11_emp_login" AS "current_level11_emp_login", 
                            "derived_table9"."cc_level1_value" AS "cc_level1_value", 
                            "derived_table9"."cc_level2_value" AS "cc_level2_value", 
                            "derived_table9"."cc_level3_value" AS "cc_level3_value", 
                            "derived_table9"."cc_level4_value" AS "cc_level4_value", 
                            "derived_table9"."cc_level5_value" AS "cc_level5_value", 
                            "derived_table9"."cc_level6_value" AS "cc_level6_value", 
                            "derived_table9"."cc_level7_value" AS "cc_level7_value", 
                            "derived_table9"."product_value1" AS "product_value1", 
                            "derived_table9"."product_value2" AS "product_value2", 
                            "derived_table9"."product_value3" AS "product_value3", 
                            "derived_table9"."product_value4" AS "product_value4", 
                            "derived_table9"."product_value5" AS "product_value5", 
                            "derived_table9"."location_code_level1" AS "location_code_level1", 
                            "derived_table9"."location_code_level2" AS "location_code_level2", 
                            "derived_table9"."location_code_level3" AS "location_code_level3", 
                            "derived_table9"."location_code_level4" AS "location_code_level4", 
                            "derived_table9"."location_code_level5" AS "location_code_level5", 
                            "derived_table9"."location_code_level6" AS "location_code_level6", 
                            "derived_table9"."location_code_level7" AS "location_code_level7", 
                            "derived_table9"."location_code_level8" AS "location_code_level8", 
                            "derived_table9"."location_code_level9" AS "location_code_level9", 
                            "derived_table9"."location_code_level10" AS "location_code_level10", 
                            "derived_table9"."location_code_level11" AS "location_code_level11", 
                            "derived_table9"."location_code_level12" AS "location_code_level12", 
                            "derived_table9"."location_code_level13" AS "location_code_level13"
                          )
                        ) AS "unnamed_unpivot10"
                    )
                ) 
                UNION ALL 
                  (
                    SELECT 
                      "unnamed_unpivot12"."role_name_access_list" AS "role_name_access_list", 
                      "unnamed_unpivot12"."login" AS "login", 
                      "unnamed_unpivot12"."dim_name" AS "dim_name", 
                      "unnamed_unpivot12"."dim_value" AS "dim_value" 
                    FROM 
                      (
                        SELECT 
                          DISTINCT "jd_2"."current_level11_emp_login" AS "current_level11_emp_login", 
                          "jd_2"."cc_level1_val" AS "cc_level1_val", 
                          "jd_2"."cc_level2_val" AS "cc_level2_val", 
                          "jd_2"."cc_level3_val" AS "cc_level3_val", 
                          "jd_2"."cc_level4_val" AS "cc_level4_val", 
                          "jd_2"."cc_level5_val" AS "cc_level5_val", 
                          "jd_2"."cc_level6_val" AS "cc_level6_val", 
                          "jd_2"."cc_level7_val" AS "cc_level7_val", 
                          "jd_2"."product_value1" AS "product_value1", 
                          "jd_2"."product_value2" AS "product_value2", 
                          "jd_2"."product_value3" AS "product_value3", 
                          "jd_2"."product_value4" AS "product_value4", 
                          "jd_2"."product_value5" AS "product_value5", 
                          "jd_2"."level1_val" AS "level1_val", 
                          "jd_2"."level2_val" AS "level2_val", 
                          "jd_2"."level3_val" AS "level3_val", 
                          "jd_2"."level4_val" AS "level4_val", 
                          "jd_2"."level5_val" AS "level5_val", 
                          "jd_2"."level6_val" AS "level6_val", 
                          "jd_2"."level7_val" AS "level7_val", 
                          "jd_2"."level8_val" AS "level8_val", 
                          "jd_2"."level9_val" AS "level9_val", 
                          "jd_2"."level10_val" AS "level10_val", 
                          "jd_2"."level11_val" AS "level11_val", 
                          "jd_2"."level12_val" AS "level12_val", 
                          "jd_2"."level13_val" AS "level13_val", 
                          "jd_2"."role_name_access_list" AS "role_name_access_list", 
                          SPLIT_TO_ARRAY(
                            "jd_2"."role_name_access_list", 
                            CAST(',' AS TEXT)
                          ) AS "login" 
                        FROM 
                          "gna_load_schema"."fact_employee_survey_denormalized" AS "jd_2"
                      ) AS "derived_table11" UNPIVOT EXCLUDE NULLS (
                        "dim_value" FOR "dim_name" IN (
                          "derived_table11"."current_level11_emp_login" AS "current_level11_emp_login", 
                          "derived_table11"."cc_level1_val" AS "cc_level1_val", 
                          "derived_table11"."cc_level2_val" AS "cc_level2_val", 
                          "derived_table11"."cc_level3_val" AS "cc_level3_val", 
                          "derived_table11"."cc_level4_val" AS "cc_level4_val", 
                          "derived_table11"."cc_level5_val" AS "cc_level5_val", 
                          "derived_table11"."cc_level6_val" AS "cc_level6_val", 
                          "derived_table11"."cc_level7_val" AS "cc_level7_val", 
                          "derived_table11"."product_value1" AS "product_value1", 
                          "derived_table11"."product_value2" AS "product_value2", 
                          "derived_table11"."product_value3" AS "product_value3", 
                          "derived_table11"."product_value4" AS "product_value4", 
                          "derived_table11"."product_value5" AS "product_value5", 
                          "derived_table11"."level1_val" AS "level1_val", 
                          "derived_table11"."level2_val" AS "level2_val", 
                          "derived_table11"."level3_val" AS "level3_val", 
                          "derived_table11"."level4_val" AS "level4_val", 
                          "derived_table11"."level5_val" AS "level5_val", 
                          "derived_table11"."level6_val" AS "level6_val", 
                          "derived_table11"."level7_val" AS "level7_val", 
                          "derived_table11"."level8_val" AS "level8_val", 
                          "derived_table11"."level9_val" AS "level9_val", 
                          "derived_table11"."level10_val" AS "level10_val", 
                          "derived_table11"."level11_val" AS "level11_val", 
                          "derived_table11"."level12_val" AS "level12_val", 
                          "derived_table11"."level13_val" AS "level13_val"
                        )
                      ) AS "unnamed_unpivot12"
                  )
              ) 
              UNION ALL 
                (
                  SELECT 
                    "unnamed_unpivot14"."role_name_access_list" AS "role_name_access_list", 
                    "unnamed_unpivot14"."login" AS "login", 
                    "unnamed_unpivot14"."dim_name" AS "dim_name", 
                    "unnamed_unpivot14"."dim_value" AS "dim_value" 
                  FROM 
                    (
                      SELECT 
                        DISTINCT "jd_3"."current_level11_emp_login" AS "current_level11_emp_login", 
                        "jd_3"."cc_hier_level1" AS "cc_hier_level1", 
                        "jd_3"."cc_hier_level2" AS "cc_hier_level2", 
                        "jd_3"."cc_hier_level3" AS "cc_hier_level3", 
                        "jd_3"."cc_hier_level4" AS "cc_hier_level4", 
                        "jd_3"."cc_hier_level5" AS "cc_hier_level5", 
                        "jd_3"."cc_hier_level6" AS "cc_hier_level6", 
                        "jd_3"."cc_hier_level7" AS "cc_hier_level7", 
                        "jd_3"."product_value1" AS "product_value1", 
                        "jd_3"."product_value2" AS "product_value2", 
                        "jd_3"."product_value3" AS "product_value3", 
                        "jd_3"."product_value4" AS "product_value4", 
                        "jd_3"."product_value5" AS "product_value5", 
                        "jd_3"."level1_val" AS "level1_val", 
                        "jd_3"."level2_val" AS "level2_val", 
                        "jd_3"."level3_val" AS "level3_val", 
                        "jd_3"."level4_val" AS "level4_val", 
                        "jd_3"."level5_val" AS "level5_val", 
                        "jd_3"."level6_val" AS "level6_val", 
                        "jd_3"."level7_val" AS "level7_val", 
                        "jd_3"."level8_val" AS "level8_val", 
                        "jd_3"."level9_val" AS "level9_val", 
                        "jd_3"."level10_val" AS "level10_val", 
                        "jd_3"."level11_val" AS "level11_val", 
                        "jd_3"."level12_val" AS "level12_val", 
                        "jd_3"."level13_val" AS "level13_val", 
                        "jd_3"."cc_owner_level11_emp_login" AS "cc_owner_level11_emp_login", 
                        "jd_3"."site_cc_level1_value" AS "site_cc_level1_value", 
                        "jd_3"."site_cc_level2_value" AS "site_cc_level2_value", 
                        "jd_3"."site_cc_level3_value" AS "site_cc_level3_value", 
                        "jd_3"."site_cc_level4_value" AS "site_cc_level4_value", 
                        "jd_3"."site_cc_level5_value" AS "site_cc_level5_value", 
                        "jd_3"."site_cc_level6_value" AS "site_cc_level6_value", 
                        "jd_3"."site_cc_level7_value" AS "site_cc_level7_value", 
                        "jd_3"."le_hier_level1_val" AS "le_hier_level1_val", 
                        "jd_3"."le_hier_level2_val" AS "le_hier_level2_val", 
                        "jd_3"."le_hier_level3_val" AS "le_hier_level3_val", 
                        "jd_3"."le_hier_level4_val" AS "le_hier_level4_val", 
                        "jd_3"."le_hier_level5_val" AS "le_hier_level5_val", 
                        "jd_3"."le_hier_level6_val" AS "le_hier_level6_val", 
                        "jd_3"."role_name_access_list" AS "role_name_access_list", 
                        SPLIT_TO_ARRAY(
                          "jd_3"."role_name_access_list", 
                          CAST(',' AS TEXT)
                        ) AS "login" 
                      FROM 
                        "gna_load_schema"."fact_rec_events_denormalized" AS "jd_3"
                    ) AS "derived_table13" UNPIVOT EXCLUDE NULLS (
                      "dim_value" FOR "dim_name" IN (
                        "derived_table13"."current_level11_emp_login" AS "current_level11_emp_login", 
                        "derived_table13"."cc_hier_level1" AS "cc_hier_level1", 
                        "derived_table13"."cc_hier_level2" AS "cc_hier_level2", 
                        "derived_table13"."cc_hier_level3" AS "cc_hier_level3", 
                        "derived_table13"."cc_hier_level4" AS "cc_hier_level4", 
                        "derived_table13"."cc_hier_level5" AS "cc_hier_level5", 
                        "derived_table13"."cc_hier_level6" AS "cc_hier_level6", 
                        "derived_table13"."cc_hier_level7" AS "cc_hier_level7", 
                        "derived_table13"."product_value1" AS "product_value1", 
                        "derived_table13"."product_value2" AS "product_value2", 
                        "derived_table13"."product_value3" AS "product_value3", 
                        "derived_table13"."product_value4" AS "product_value4", 
                        "derived_table13"."product_value5" AS "product_value5", 
                        "derived_table13"."level1_val" AS "level1_val", 
                        "derived_table13"."level2_val" AS "level2_val", 
                        "derived_table13"."level3_val" AS "level3_val", 
                        "derived_table13"."level4_val" AS "level4_val", 
                        "derived_table13"."level5_val" AS "level5_val", 
                        "derived_table13"."level6_val" AS "level6_val", 
                        "derived_table13"."level7_val" AS "level7_val", 
                        "derived_table13"."level8_val" AS "level8_val", 
                        "derived_table13"."level9_val" AS "level9_val", 
                        "derived_table13"."level10_val" AS "level10_val", 
                        "derived_table13"."level11_val" AS "level11_val", 
                        "derived_table13"."level12_val" AS "level12_val", 
                        "derived_table13"."level13_val" AS "level13_val", 
                        "derived_table13"."cc_owner_level11_emp_login" AS "cc_owner_level11_emp_login", 
                        "derived_table13"."site_cc_level1_value" AS "site_cc_level1_value", 
                        "derived_table13"."site_cc_level2_value" AS "site_cc_level2_value", 
                        "derived_table13"."site_cc_level3_value" AS "site_cc_level3_value", 
                        "derived_table13"."site_cc_level4_value" AS "site_cc_level4_value", 
                        "derived_table13"."site_cc_level5_value" AS "site_cc_level5_value", 
                        "derived_table13"."site_cc_level6_value" AS "site_cc_level6_value", 
                        "derived_table13"."site_cc_level7_value" AS "site_cc_level7_value", 
                        "derived_table13"."le_hier_level1_val" AS "le_hier_level1_val", 
                        "derived_table13"."le_hier_level2_val" AS "le_hier_level2_val", 
                        "derived_table13"."le_hier_level3_val" AS "le_hier_level3_val", 
                        "derived_table13"."le_hier_level4_val" AS "le_hier_level4_val", 
                        "derived_table13"."le_hier_level5_val" AS "le_hier_level5_val", 
                        "derived_table13"."le_hier_level6_val" AS "le_hier_level6_val"
                      )
                    ) AS "unnamed_unpivot14"
                )
            ) 
            UNION ALL 
              (
                SELECT 
                  "unnamed_unpivot16"."role_name_access_list" AS "role_name_access_list", 
                  "unnamed_unpivot16"."login" AS "login", 
                  "unnamed_unpivot16"."dim_name" AS "dim_name", 
                  "unnamed_unpivot16"."dim_value" AS "dim_value" 
                FROM 
                  (
                    SELECT 
                      DISTINCT "jd_4"."current_level11_emp_login" AS "cc_owner", 
                      "jd_4"."site_cc_level1_value" AS "site_cc_level1_value", 
                      "jd_4"."site_cc_level2_value" AS "site_cc_level2_value", 
                      "jd_4"."site_cc_level3_value" AS "site_cc_level3_value", 
                      "jd_4"."site_cc_level4_value" AS "site_cc_level4_value", 
                      "jd_4"."site_cc_level5_value" AS "site_cc_level5_value", 
                      "jd_4"."site_cc_level6_value" AS "site_cc_level6_value", 
                      "jd_4"."site_cc_level7_value" AS "site_cc_level7_value", 
                      "jd_4"."le_level1_val" AS "le_level1_val", 
                      "jd_4"."le_level2_val" AS "le_level2_val", 
                      "jd_4"."le_level3_val" AS "le_level3_val", 
                      "jd_4"."le_level4_val" AS "le_level4_val", 
                      "jd_4"."le_level5_val" AS "le_level5_val", 
                      "jd_4"."le_level6_val" AS "le_level6_val", 
                      "jd_4"."role_name_access_list" AS "role_name_access_list", 
                      SPLIT_TO_ARRAY(
                        "jd_4"."role_name_access_list", 
                        CAST(',' AS TEXT)
                      ) AS "login" 
                    FROM 
                      "gna_load_schema"."fact_hyperion_forecast_denormalized" AS "jd_4"
                  ) AS "derived_table15" UNPIVOT EXCLUDE NULLS (
                    "dim_value" FOR "dim_name" IN (
                      "derived_table15"."cc_owner" AS "cc_owner", 
                      "derived_table15"."site_cc_level1_value" AS "site_cc_level1_value", 
                      "derived_table15"."site_cc_level2_value" AS "site_cc_level2_value", 
                      "derived_table15"."site_cc_level3_value" AS "site_cc_level3_value", 
                      "derived_table15"."site_cc_level4_value" AS "site_cc_level4_value", 
                      "derived_table15"."site_cc_level5_value" AS "site_cc_level5_value", 
                      "derived_table15"."site_cc_level6_value" AS "site_cc_level6_value", 
                      "derived_table15"."site_cc_level7_value" AS "site_cc_level7_value", 
                      "derived_table15"."le_level1_val" AS "le_level1_val", 
                      "derived_table15"."le_level2_val" AS "le_level2_val", 
                      "derived_table15"."le_level3_val" AS "le_level3_val", 
                      "derived_table15"."le_level4_val" AS "le_level4_val", 
                      "derived_table15"."le_level5_val" AS "le_level5_val", 
                      "derived_table15"."le_level6_val" AS "le_level6_val"
                    )
                  ) AS "unnamed_unpivot16"
              )
          ) AS "t" 
          LEFT JOIN "t"."login" AS "role_name_access_list1" ON CAST(TRUE AS BOOL) 
        WHERE 
          "t"."dim_value" IS NOT NULL
      ) AS "derived_table18" 
    GROUP BY 
      "derived_table18"."dim_value", 
      "derived_table18"."dim_flag"
  ) AS "row_sec" ON (
    "row_sec"."dim_value" = "vw"."level1_val"
  ) 
  AND (
    "row_sec"."dim_flag" = "vw"."flag"
  )
;




-- pap_view_schema.dim_in_ex_rule_mobile source

CREATE OR REPLACE VIEW pap_view_schema.dim_in_ex_rule_mobile
AS SELECT derived_table1.worker_login, derived_table1.dim_type, pg_catalog.listagg(derived_table1.agg_list::text, ' '::text) WITHIN GROUP(
  ORDER BY derived_table1.record_type DESC) AS listagg
   FROM ( SELECT base.worker_login, base.record_type, base.dim_type, 
                CASE
                    WHEN base.record_type::text = 'Exclude'::text THEN (('(Exculding: '::text || pg_catalog.listagg(base.data_desc::text, ', '::text)::text) || ')'::text)::character varying
                    ELSE pg_catalog.listagg(base.data_desc::text, ', '::text)
                END AS agg_list
           FROM ( SELECT DISTINCT base.worker_login, base.record_type, base.dim_type, COALESCE(dlh1.level1_desc, dlh2.level2_desc, dlh3.level3_desc, dlh4.level4_desc, dlh5.level5_desc, dlh6.level6_desc, dlh7.level7_desc, dlh8.level8_desc, dlh9.level9_desc, dlh10.level10_desc, dlh11.level11_desc, dlh12.level12_desc, dlh13.level13_desc, dcch1.level1_desc, dcch2.level2_desc, dcch3.level3_desc, dcch4.level4_desc, dcch5.level5_desc, dcch6.level6_desc, dcch7.level7_desc) AS data_desc
                   FROM ( SELECT comma_position.worker_login, comma_position.dim_type, split_part(comma_position.data_values::text, ','::text, gn.num) AS data_value, comma_position.record_type
                           FROM ( SELECT dsur.worker_login, dsur.dim_type, dsur.data_values, dsur.record_type, regexp_count(dsur.data_values::text, ','::text) AS mn
                                   FROM gna_load_schema.dim_sec_user_resp dsur
                                  WHERE (dsur.role_name::text = 'General Manager (location)'::text OR dsur.role_name::text = 'General Manager (complex)'::text) AND (dsur.dim_type::text = 'Location'::text OR dsur.dim_type::text = 'Cost Center'::text)) comma_position
                      JOIN ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((( SELECT 1 AS num
                        UNION 
                                 SELECT 2 AS num)
                        UNION 
                                 SELECT 3 AS num)
                        UNION 
                                 SELECT 4 AS num)
                        UNION 
                                 SELECT 5 AS num)
                        UNION 
                                 SELECT 6 AS num)
                        UNION 
                                 SELECT 7 AS num)
                        UNION 
                                 SELECT 8 AS num)
                        UNION 
                                 SELECT 9 AS num)
                        UNION 
                                 SELECT 10 AS num)
                        UNION 
                                 SELECT 11 AS num)
                        UNION 
                                 SELECT 12 AS num)
                        UNION 
                                 SELECT 13 AS num)
                        UNION 
                                 SELECT 14 AS num)
                        UNION 
                                 SELECT 15 AS num)
                        UNION 
                                 SELECT 16 AS num)
                        UNION 
                                 SELECT 17 AS num)
                        UNION 
                                 SELECT 18 AS num)
                        UNION 
                                 SELECT 19 AS num)
                        UNION 
                                 SELECT 20 AS num)
                        UNION 
                                 SELECT 21 AS num)
                        UNION 
                                 SELECT 22 AS num)
                        UNION 
                                 SELECT 23 AS num)
                        UNION 
                                 SELECT 24 AS num)
                        UNION 
                                 SELECT 25 AS num)
                        UNION 
                                 SELECT 26 AS num)
                        UNION 
                                 SELECT 27 AS num)
                        UNION 
                                 SELECT 28 AS num)
                        UNION 
                                 SELECT 29 AS num)
                        UNION 
                                 SELECT 30 AS num)
                        UNION 
                                 SELECT 31 AS num)
                        UNION 
                                 SELECT 32 AS num)
                        UNION 
                                 SELECT 33 AS num)
                        UNION 
                                 SELECT 34 AS num)
                        UNION 
                                 SELECT 35 AS num)
                        UNION 
                                 SELECT 36 AS num)
                        UNION 
                                 SELECT 37 AS num)
                        UNION 
                                 SELECT 38 AS num)
                        UNION 
                                 SELECT 39 AS num)
                        UNION 
                                 SELECT 40 AS num)
                        UNION 
                                 SELECT 41 AS num)
                        UNION 
                                 SELECT 42 AS num)
                        UNION 
                                 SELECT 43 AS num)
                        UNION 
                                 SELECT 44 AS num)
                        UNION 
                                 SELECT 45 AS num)
                        UNION 
                                 SELECT 46 AS num)
                        UNION 
                                 SELECT 47 AS num)
                        UNION 
                                 SELECT 48 AS num)
                        UNION 
                                 SELECT 49 AS num)
                        UNION 
                                 SELECT 50 AS num)
                        UNION 
                                 SELECT 51 AS num)
                        UNION 
                                 SELECT 52 AS num)
                        UNION 
                                 SELECT 53 AS num)
                        UNION 
                                 SELECT 54 AS num)
                        UNION 
                                 SELECT 55 AS num)
                        UNION 
                                 SELECT 56 AS num)
                        UNION 
                                 SELECT 57 AS num)
                        UNION 
                                 SELECT 58 AS num)
                        UNION 
                                 SELECT 59 AS num)
                        UNION 
                                 SELECT 60 AS num)
                        UNION 
                                 SELECT 61 AS num)
                        UNION 
                                 SELECT 62 AS num)
                        UNION 
                                 SELECT 63 AS num)
                        UNION 
                                 SELECT 64 AS num)
                        UNION 
                                 SELECT 65 AS num)
                        UNION 
                                 SELECT 66 AS num)
                        UNION 
                                 SELECT 67 AS num)
                        UNION 
                                 SELECT 68 AS num)
                        UNION 
                                 SELECT 69 AS num)
                        UNION 
                                 SELECT 70 AS num)
                        UNION 
                                 SELECT 71 AS num)
                        UNION 
                                 SELECT 72 AS num)
                        UNION 
                                 SELECT 73 AS num)
                        UNION 
                                 SELECT 74 AS num)
                        UNION 
                                 SELECT 75 AS num)
                        UNION 
                                 SELECT 76 AS num)
                        UNION 
                                 SELECT 77 AS num)
                        UNION 
                                 SELECT 78 AS num)
                        UNION 
                                 SELECT 79 AS num)
                        UNION 
                                 SELECT 80 AS num)
                        UNION 
                                 SELECT 81 AS num)
                        UNION 
                                 SELECT 82 AS num)
                        UNION 
                                 SELECT 83 AS num)
                        UNION 
                                 SELECT 84 AS num)
                        UNION 
                                 SELECT 85 AS num)
                        UNION 
                                 SELECT 86 AS num)
                        UNION 
                                 SELECT 87 AS num)
                        UNION 
                                 SELECT 88 AS num)
                        UNION 
                                 SELECT 89 AS num)
                        UNION 
                                 SELECT 90 AS num)
                        UNION 
                                 SELECT 91 AS num)
                        UNION 
                                 SELECT 92 AS num)
                        UNION 
                                 SELECT 93 AS num)
                        UNION 
                                 SELECT 94 AS num)
                        UNION 
                                 SELECT 95 AS num)
                        UNION 
                                 SELECT 96 AS num)
                        UNION 
                                 SELECT 97 AS num)
                        UNION 
                                 SELECT 98 AS num)
                        UNION 
                                 SELECT 99 AS num)
                        UNION 
                                 SELECT 100 AS num) gn ON gn.num <= (comma_position.mn + 1)) base
              LEFT JOIN gna_load_schema.dim_location_hier dlh1 ON base.data_value = dlh1.level1_val::text AND base.dim_type::text = 'Location'::text AND dlh1.datasource_name::text = 'WORKDAY'::text
         LEFT JOIN gna_load_schema.dim_location_hier dlh2 ON base.data_value = dlh2.level2_val::text AND base.dim_type::text = 'Location'::text AND dlh2.datasource_name::text = 'WORKDAY'::text
    LEFT JOIN gna_load_schema.dim_location_hier dlh3 ON base.data_value = dlh3.level3_val::text AND base.dim_type::text = 'Location'::text AND dlh3.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh4 ON base.data_value = dlh4.level4_val::text AND base.dim_type::text = 'Location'::text AND dlh4.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh5 ON base.data_value = dlh5.level5_val::text AND base.dim_type::text = 'Location'::text AND dlh5.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh6 ON base.data_value = dlh6.level6_val::text AND base.dim_type::text = 'Location'::text AND dlh6.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh7 ON base.data_value = dlh7.level7_val::text AND base.dim_type::text = 'Location'::text AND dlh7.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh8 ON base.data_value = dlh8.level8_val::text AND base.dim_type::text = 'Location'::text AND dlh8.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh9 ON base.data_value = dlh9.level9_val::text AND base.dim_type::text = 'Location'::text AND dlh9.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh10 ON base.data_value = dlh10.level10_val::text AND base.dim_type::text = 'Location'::text AND dlh10.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh11 ON base.data_value = dlh11.level11_val::text AND base.dim_type::text = 'Location'::text AND dlh11.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh12 ON base.data_value = dlh12.level12_val::text AND base.dim_type::text = 'Location'::text AND dlh12.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_location_hier dlh13 ON base.data_value = dlh13.level13_val::text AND base.dim_type::text = 'Location'::text AND dlh13.datasource_name::text = 'WORKDAY'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch1 ON base.data_value = dcch1.level1_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch1.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch2 ON base.data_value = dcch2.level2_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch2.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch3 ON base.data_value = dcch3.level3_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch3.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch4 ON base.data_value = dcch4.level4_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch4.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch5 ON base.data_value = dcch5.level5_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch5.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch6 ON base.data_value = dcch6.level6_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch6.datasource_name::text = 'EHANA'::text
   LEFT JOIN gna_load_schema.dim_cost_center_hier dcch7 ON base.data_value = dcch7.level7_val::text AND base.dim_type::text = 'Cost Center'::text AND dcch7.datasource_name::text = 'EHANA'::text) base
          GROUP BY base.worker_login, base.dim_type, base.record_type) derived_table1
  GROUP BY derived_table1.worker_login, derived_table1.dim_type
;