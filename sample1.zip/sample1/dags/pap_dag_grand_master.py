###########################################################
###########################################################
####-       FILE NAME       : pap_dag_grand_master.py -####
####-       FILE CREATED    : 2022/08/01              -####
####-       FILE LAST EDITED: 2023/08/21              -####
###########################################################
###########################################################
import sys
sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime as dt
from airflow import DAG
from datetime import datetime,timedelta
import imp
import os
import ast
import urllib
import time
import requests
import random
from io import StringIO

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.configuration import conf as airflow_conf
import boto3
import pandas as pd
from botocore.exceptions import ClientError
import uuid
import pendulum
import json
import yaml
#from airflow.decorators import task
from airflow.operators.python import task, get_current_context
from string import Template
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.models import Variable
import ast
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from airflow.exceptions import AirflowSkipException

ENV_NAME = ''
try:   
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"

class OrchestatorUtils():
    # def send_email(self,email):
        # for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
            # if email.get(key) is None:
                # ValueError(f"Missing email parameter -{key}")
        
        # # Create a new SES resource and specify a region.
        # client = boto3.client('ses',region_name=email["aws_region"])
        # # Try to send the email.
        # try:
            # #Provide the contents of the email.
            # response = client.send_email(
                # Destination={
                    # 'ToAddresses': email["recipient_list"],
                # },
                # Message={
                    # 'Body': {
                        # 'Html': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_html"],
                        # },
                        # 'Text': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_text"],
                        # },
                    # },
                    # 'Subject': {
                        # 'Charset': email["msg_charset"],
                        # 'Data': email["msg_subject"],
                    # },
                # },
                # Source=email["sender"],
            # )
        # # Display an error if something goes wrong.	
        # except ClientError as e:
            # print(e.response['Error']['Message'])
        # else:
            # print("Email sent! Message ID:"),
            # print(response['MessageId'])
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg = MIMEMultipart('related')
            msg['Subject'] = email["msg_subject"]
            msg['From'] = email["sender"]
            msg['To'] = ','.join(email["recipient_list"])
            body = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")
    def log_batch_dtl(self, app_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket=app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        audit_batch_record['batch_date'] = batch_date
        #set the batch date
        '''if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()'''
            
        audit_batch_record['batch_id']=str(uuid.uuid4())
        audit_batch_record['batch_name']=app_config.get("APPLICATION_NAME")
        audit_batch_record['status']='STARTED'
        audit_batch_record['start_time']=pendulum.now()
        audit_batch_record['end_time']=''
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket=app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_bucket:{batch_bucket}")
        print(f"batch_object_key:{batch_object_key}")
        try:
            audit_batch_record=self.get_config(batch_bucket,batch_object_key)
        except Exception as err:
            print(str(err))
        print(str(audit_batch_record))
        print("Type:" +str(type(audit_batch_record)))
        audit_batch_record['status']='FINISHED'
        audit_batch_record['end_time']=pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(self, app_config, batch_date, msg):
        for key in ('LOGS_BUCKET','LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")                
        batch_bucket=app_config['LOGS_BUCKET']
        batch_object_key=app_config['LOGS_BATCH_PATH']+'batch_date='+batch_date+'/'+str(app_config.get("APPLICATION_NAME"))+'_log.json'
        print(f"batch_object_key:{batch_object_key}")
        audit_batch_record=self.get_config(batch_bucket,batch_object_key)
        audit_batch_record['status']=msg
        audit_batch_record['end_time']=pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
            

orch_handle=OrchestatorUtils()
app_config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/app_config.yml")
DAG_NAME='pap_dag_grand_master'
dag_tags=['PAP','Grand Master','RELEASE 1']
release=1

def s3_to_redshift_glue_job_execution():
    table_name = "pap_log_batch_dtl"
    redshift_glue_jobname= "pap-s3-to-redshift-load-job"
    glue_client = boto3.client('glue', region_name=region_name)
    response = glue_client.start_job_run(
    JobName=redshift_glue_jobname,
    Arguments={'--additional-python-modules': 'boto3==1.24.69,psycopg2-binary==2.9.3','--s3-path': f"s3://{app_config_yml['environment'].get('LOGS_BUCKET')}/audit-table/{table_name.replace('_','-')}/",'--schema-name': app_config_yml['environment'].get('REDSHIFT_LOAD_SCHEMA') ,'--table-name': table_name}
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    while isJobRunning:
        time.sleep(5)
        status_detail = glue_client.get_job_run(JobName=redshift_glue_jobname, RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    cloud_watch_url_output =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fpython-jobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{region_name}.console.aws.amazon.com/cloudwatch/home?region={region_name}#logsV2:log-groups/log-group/$252Faws-glue$252Fpython-jobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")    
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"

def dag_start_send_email(**kwargs):
        handle = OrchestatorUtils()
        context = get_current_context()
        Variable.set('ds_nodash',context.get('ds_nodash'))
        handle.init_log_batch_dtl(app_config_yml['environment'], str(Variable.get('ds_nodash')))
        s3_to_redshift_glue_job_execution()
        dict_email={}       
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_DATE_NODASH']=str(context['ds_nodash'])
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='STARTED'
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        dict_email['BATCH_DATE']=str(Variable.get('ds_nodash'))
        dict_email['MESSAGE']=''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_failure_send_email(context):
        try: 
            handle = OrchestatorUtils()
            #Variable.set('ds_nodash',context.get('ds_nodash'))
            handle.fail_log_batch_ditl(app_config_yml['environment'], str(Variable.get('ds_nodash')),'FAILED')
            s3_to_redshift_glue_job_execution()
            dict_email={}
            dict_email['ENV']= ENV_NAME['name'].upper()
            dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
            dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
            dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
            dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
            dict_email['PROCESS_RUN_STATE']='FAILED'
            dict_email['BATCH_DATE']=str(Variable.get('ds_nodash'))
            dict_email['EXECUTION_DATE']=context.get('execution_date')
            dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
            dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
            dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
            dict_email['MESSAGE']=''
            dag_id = context["dag"].dag_id
            execution_date = context["execution_date"].isoformat()
            dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
            email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
            print(email_template)
            enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            handle.send_email(json.loads(enriched_email))
        except Exception as err:
            handle.fail_log_batch_ditl(app_config_yml['environment'], str(Variable.get('ds_nodash')),'FAILED')


def update_batch_log_dtl_table(**kwargs):
    handle = OrchestatorUtils()
    context = get_current_context()
    #Variable.set('ds_nodash',context.get('ds_nodash'))
    handle.finish_log_batch_dtl(app_config_yml['environment'], str(Variable.get('ds_nodash')))
    s3_to_redshift_glue_job_execution()
    dict_email={}
    dict_email['ENV']= ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']= 'update_batch_log'
    dict_email['PROCESS_DATE_NODASH']=str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
    dict_email['BATCH_DATE']=str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE']='COMPLETED'
    dict_email['EXECUTION_DATE']=context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']=pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
    dict_email['MESSAGE']=''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))

def dag_end_send_email(**kwargs):
    handle = OrchestatorUtils()
    context = get_current_context()
    dict_email={}
    dict_email['ENV']= ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH']=str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
    dict_email['BATCH_DATE']=str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE']='COMPLETED'
    dict_email['EXECUTION_DATE']=context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']=pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
    dict_email['MESSAGE']=''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_recon_end_send_email(**kwargs):
    handle = OrchestatorUtils()
    context = get_current_context()
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH'] = str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE'] = 'COMPLETED'
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/dags/email/dag_recon_and_grand_master_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0,9)) # for giving delay in each job
    glue_client = boto3.client('glue', region_name=kwargs['region_name'])
    response = glue_client.start_job_run(
    JobName=kwargs["glue_job_name"],
    Arguments=kwargs["script_args"],
    WorkerType=kwargs["worker_type"],
    NumberOfWorkers=kwargs["no_of_workers"]
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    while isJobRunning:
        time.sleep(15)
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    cloud_watch_url_output =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    #print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"

#########################################
### FUNCTION TO TRIGGER GLUE CRALWER ####
#########################################
def trigger_crawler(**kwargs):
    handle                                  = OrchestatorUtils()
    context                                 = get_current_context()
    dict_email                              ={}       
    dict_email['ENV']                       = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME']          = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME']              = app_config_yml['environment'].get('PROCESSED_LAYER_RPD_CRAWLER')
    dict_email['PROCESS_DATE_NODASH']       =str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID']            =str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE']          =str(context['dag_run'].run_type)
    dict_email['EXECUTION_DATE']            =context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME']    =str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME']      =str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER']  =str(context['dag_run'].external_trigger)
    dict_email['BATCH_DATE']                =str(Variable.get('ds_nodash'))
    dict_email['MESSAGE']                   =''
    dag_id                                  = context["dag"].dag_id
    execution_date                          = context["execution_date"].isoformat()
    dict_email['PROCESS_URL']               =f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template                          =handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
    print(email_template)
    try:
        region_name                         = os.environ['AWS_REGION']
        glue_client                         = boto3.client('glue', region_name=region_name)
        glue_client.start_crawler(Name=app_config_yml['environment'].get('PROCESSED_LAYER_RPD_CRAWLER'))
        print('crawler is triggered and is running')
        dict_email['PROCESS_RUN_STATE']     ='TRIGGER STARTED'
        enriched_email                      =Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))
        isJobRunning                        = True
        state                               = ''
        while isJobRunning:
            time.sleep(15)
            response_get    = glue_client.get_crawler(Name=app_config_yml['environment'].get('PROCESSED_LAYER_RPD_CRAWLER'))
            state           = response_get["Crawler"]["State"]
            print(f"The crawler is in {str(state)} state")
            if state in ['READY']:
                isJobRunning = False
        print(f"The crawler's current state is: {str(state)}")
        latest_run_status                     = response_get["Crawler"]["LastCrawl"]["Status"]
        print(f"The crawler's latest run status is: {str(latest_run_status)}")
        if latest_run_status != 'SUCCEEDED':
            dict_email['PROCESS_RUN_STATE']     =f"TRIGGERED RUN {str(latest_run_status)}"
            enriched_email                      =Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            handle.send_email(json.loads(enriched_email))
        # will fail without retry
            raise Exception("Glue Crawler Failed")
        else:
            dict_email['PROCESS_RUN_STATE']     =f"TRIGGERED RUN {str(latest_run_status)}"
            enriched_email                      =Template(json.dumps(email_template)).safe_substitute(dict_email)
            print(enriched_email)
            handle.send_email(json.loads(enriched_email))
            return "OK"  
    except Exception as ex:
        print("ERROR: ",ex)
        print(traceback.format_exc())
        dict_email['PROCESS_RUN_STATE']     ='TRIGGER FAILED'
        enriched_email                      =Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))
        raise Exception(ex)
        

default_args = {
    "owner": "PAP Project Team",
    "start_date": pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
    "provide_context": True
}

batch_dt = Variable.get('ds_nodash')
glue_iam_role = "AWSGlueServiceRoleDefault"
region_name = "us-west-2"
script_args = {
                        '--config_bucket': CODE_ARTIFACTS_BUCKET,
                        '--batch_date': batch_dt
                    }

script_arg_mand_file_chk= {
                            '--config_bucket': CODE_ARTIFACTS_BUCKET,
                            '--batch_date': batch_dt,
                            '--config': f"s3://{app_config_yml['environment'].get('CODE_ARTIFACTS_BUCKET')}/configuration/mandatoryfile_config.csv",
                            '--folder_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/landing/",
                            '--archive_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/archive/",
                            '--env_name': ENV_NAME['name']
                            }

script_arg_file_header_chk= {
                            '--config_bucket': CODE_ARTIFACTS_BUCKET,
                            '--batch_date': batch_dt,
                            '--config': f"s3://{app_config_yml['environment'].get('CODE_ARTIFACTS_BUCKET')}/configuration/mandatoryfile_config.csv",
                            '--folder_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/landing/"
                            }      
with DAG(
    dag_id=DAG_NAME,
    start_date=pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
    catchup=False,
    schedule_interval="00 21 * * *",
    #schedule_interval=None,
    tags=dag_tags,
    default_args=default_args,
    max_active_runs= 1,
    on_failure_callback=dag_failure_send_email) as dag:
    start = PythonOperator(task_id="Start",
                           python_callable=dag_start_send_email, 
                           provide_context=True,
    )
    
    end = PythonOperator(task_id="End",
                         python_callable=dag_end_send_email, 
                         provide_context=True,
    )

    update_batch_log = PythonOperator(task_id="update_batch_log",
                                      python_callable=update_batch_log_dtl_table, 
                                      provide_context=True,
    )
                        
    pap_dag_ext_data_load = TriggerDagRunOperator(task_id="trigger_pap_dag_ext_data_load",
                                                  trigger_dag_id="pap_dag_ext_data_load",  # Ensure this equals the dag_id of the DAG to trigger
                                                  #conf={"batch_date": batch_dt },
                                                  conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                  wait_for_completion=True
                                                  #reset_dag_run=True
    )
    
    mandatory_file_check = AwsGlueJobOperator(task_id = 'pap-mandatory-file-check',
                                              job_name = 'pap-mandatory-file-checks',
                                              script_args=script_arg_mand_file_chk, 
                                              region_name = region_name,
                                              iam_role_name = glue_iam_role,
                                              dag = dag
    )
    pap_header_check = AwsGlueJobOperator(task_id = 'pap-header-check',
                                          job_name = 'pap-header-check',
                                          script_args=script_arg_file_header_chk, 
                                          region_name = region_name,
                                          iam_role_name = glue_iam_role,
                                          dag = dag
    )
    
    data_ingestion_r1 = TriggerDagRunOperator(task_id="trigger_pap_dag_ingestion_r1",
                                              trigger_dag_id="pap_dag_ingestion_r1",  # Ensure this equals the dag_id of the DAG to trigger
                                              conf={"message": "test_message"},
                                              wait_for_completion=True,
    )
    
    data_ingestion_r2 = TriggerDagRunOperator(task_id="trigger_pap_dag_ingestion_r2",
                                              trigger_dag_id="pap_dag_ingestion_r2",  # Ensure this equals the dag_id of the DAG to trigger
                                              conf={"message": "test_message"},
                                              wait_for_completion=True,
    )
    
    pap_dag_vfdata_ingestion = TriggerDagRunOperator(task_id="trigger_pap_dag_vfdata_ingestion",
                                                     trigger_dag_id="pap_dag_vfdata_ingestion",
                                                     #conf={"batch_date": batch_dt },
                                                     conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                     wait_for_completion=True
                                                     #reset_dag_run=True
    )
    
    pap_dag_history_cleanup = TriggerDagRunOperator(task_id="trigger_pap_dag_input_file_cleanup",
                                                     trigger_dag_id="pap_dag_history_cleanup",
                                                     #conf={"batch_date": batch_dt },
                                                     conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                     wait_for_completion=True
                                                     #reset_dag_run=True
    )
    
    dim_stage = TriggerDagRunOperator(task_id="trigger_pap_dag_load_incr_dim_stage",
                                      trigger_dag_id="pap_dag_load_incr_dim_stage",  # Ensure this equals the dag_id of the DAG to trigger
                                      #conf={"batch_date": batch_dt },
                                      conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                      wait_for_completion=True
                                      #reset_dag_run=True
    )
    
    modify_user_in_ad_grp = TriggerDagRunOperator(task_id="trigger_pap_dag_modify_users_in_ad_grp",
                                      trigger_dag_id="pap_dag_modify_users_in_ad_grp",  # Ensure this equals the dag_id of the DAG to trigger
                                      conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                      wait_for_completion=True
    )
    
    dim = TriggerDagRunOperator(task_id="trigger_pap_dag_load_incr_dim",
                                trigger_dag_id="pap_dag_load_incr_dim",  # Ensure this equals the dag_id of the DAG to trigger
                                conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                wait_for_completion=True,
    )
    
    fact_stage = TriggerDagRunOperator(task_id="trigger_pap_dag_load_incr_fact_stage",
                                       trigger_dag_id="pap_dag_load_incr_fact_stage",  # Ensure this equals the dag_id of the DAG to trigger
                                       conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                       wait_for_completion=True,
    )
    
    fact = TriggerDagRunOperator(task_id="trigger_pap_dag_load_incr_fact",
                                 trigger_dag_id="pap_dag_load_incr_fact",  # Ensure this equals the dag_id of the DAG to trigger
                                 conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                 wait_for_completion=True,
    )
    
    mv_and_denorm_fact = TriggerDagRunOperator(task_id="trigger_pap_dag_load_mv_and_denorm_fact",
                                               trigger_dag_id="pap_dag_load_mv_and_denorm_fact",
                                               conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                               wait_for_completion=True,
    )
    
    history_backup_dag = TriggerDagRunOperator(task_id              ="trigger_pap_dag_backup_history",
                                               trigger_dag_id       ="pap_dag_backup_history",
                                               conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                               wait_for_completion  =True,
    )
    
    dim_s3_to_redshift = TriggerDagRunOperator(task_id="trigger_pap_dag_load_dimension_to_redshift",
                                               trigger_dag_id="pap_dag_load_dimension_to_redshift",
                                               conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                wait_for_completion=True,
    )
    
    fact_s3_to_redshift = TriggerDagRunOperator(task_id="trigger_pap_dag_load_fact_to_redshift",
                                                trigger_dag_id="pap_dag_load_fact_to_redshift",
                                                conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                wait_for_completion=True,
    )
    
    mv_s3_to_redshift = TriggerDagRunOperator(task_id               ="trigger_pap_dag_load_mv_to_redshift",
                                              trigger_dag_id="pap_dag_load_mv_to_redshift",  # Ensure this equals the dag_id of the DAG to trigger
                                              conf                  ={"batch_date": "{{ var.value.ds_nodash }}"},
                                              wait_for_completion   =True,
    )
    
    denorm_s3_to_redshift = TriggerDagRunOperator(task_id               ="trigger_pap_dag_load_denorm_to_redshift",
                                                  trigger_dag_id        ="pap_dag_load_denorm_to_redshift",
                                                  conf                  ={"batch_date": "{{ var.value.ds_nodash }}"},
                                                  wait_for_completion   =True,
    )

    tableau_extract = TriggerDagRunOperator(task_id               ="trigger_pap_dag_tableau_extract",
                                            trigger_dag_id        ="pap_dag_tableau_extract",
                                            conf                  ={"batch_date": "{{ var.value.ds_nodash }}"},
                                            wait_for_completion   =True,
    )
    
    processed_bucket_rpd_trigger_crawler = PythonOperator(task_id        ="trigger_pap_processed_bucket_rpd_crawler",
                                                          python_callable=trigger_crawler,
                                                          provide_context=True,
    )
    pap_dag_recon_process = TriggerDagRunOperator(task_id="trigger_pap_dag_recon_process",
                                                  trigger_dag_id="pap_recon_validation",
                                                  # conf={"batch_date": batch_dt },
                                                  conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                                  wait_for_completion=True
                                                  # reset_dag_run=True
                                                  )

    recon_end = PythonOperator(task_id="recon_end",
                               python_callable=dag_recon_end_send_email,
                               provide_context=True,
                               )
    
    pap_dag_tableau_notify_users = TriggerDagRunOperator(task_id="trigger_pap_dag_tableau_notify_users",
                                      trigger_dag_id="pap_dag_tableau_notify_users",  # Ensure this equals the dag_id of the DAG to trigger
                                      conf={"batch_date": "{{ var.value.ds_nodash }}"},
                                      wait_for_completion=True
    )
    #perform_schema_swtich = DummyOperator(task_id='perform_schema_swtich')
    #publish_to_redshift_sync_schema = DummyOperator(task_id='publish_to_redshift_sync_schema')
    #glue_crawlers = DummyOperator(task_id='glue_crawlers')
    #vacuuming = DummyOperator(task_id='vacuuming')
    

start >> pap_dag_ext_data_load >> mandatory_file_check >> pap_header_check >> [data_ingestion_r1,data_ingestion_r2, pap_dag_vfdata_ingestion] >> dim_stage >> modify_user_in_ad_grp >> dim >> fact_stage >> fact >> [mv_and_denorm_fact,dim_s3_to_redshift]
mv_and_denorm_fact >> [mv_s3_to_redshift,denorm_s3_to_redshift,history_backup_dag]
fact >> pap_dag_recon_process >> pap_dag_history_cleanup >> recon_end
dim_s3_to_redshift >> fact_s3_to_redshift >> update_batch_log
denorm_s3_to_redshift >> update_batch_log
mv_s3_to_redshift >> update_batch_log
history_backup_dag>>processed_bucket_rpd_trigger_crawler >> update_batch_log
update_batch_log >> [tableau_extract, pap_dag_tableau_notify_users] >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################