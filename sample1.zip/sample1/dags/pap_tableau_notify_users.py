##############################################################
##############################################################
####-       FILE NAME       : pap_dag_tableau_extract.py -####
####-       FILE CREATED    : 2023/01/25                 -####
####-       FILE LAST EDITED: 2023/08/04                 -####
##############################################################
##############################################################
import sys

sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
from airflow import DAG
from datetime import datetime
import time
import random
import os
import io
import ast
import urllib

# Airflow level imports
from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.configuration import conf as airflow_conf
import boto3
import pandas as pd
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
import uuid
import pendulum
import json
import yaml
from airflow.operators.python import get_current_context
from string import Template
from airflow.models import Variable
import ast
from botocore.exceptions import ClientError
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib, ssl
from smtplib import SMTPException
from airflow.exceptions import AirflowSkipException

ENV_NAME = ''
try:
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET = f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"
PROCESSED_BUCKET = ""
CURATED_BUCKET = ""
PROD_ENV_NAME = 'PRD'
#PROD_ENV_NAME = 'TST'
class OrchestatorUtils():
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg             = MIMEMultipart('related')
            msg['Subject']  = email["msg_subject"]
            msg['From']     = email["sender"]
            msg['To']       = ','.join(email["recipient_list"])
            body            = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")

    '''def send_email(self, email):
        for key in (
                'aws_region', 'sender', 'recipient_list', 'msg_charset', 'msg_subject', 'msg_body_html',
                'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        # Create a new SES resource and specify a region.
        client = boto3.client('ses', region_name=email["aws_region"])
        # Try to send the email.
        try:
            # Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': email["recipient_list"],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_html"],
                        },
                        'Text': {
                            'Charset': email["msg_charset"],
                            'Data': email["msg_body_text"],
                        },
                    },
                    'Subject': {
                        'Charset': email["msg_charset"],
                        'Data': email["msg_subject"],
                    },
                },
                Source=email["sender"],
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])'''

    def log_batch_dtl(self, app_config, audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket = app_config['LOGS_BUCKET']
        batch_object_key = app_config['LOGS_BATCH_PATH'] + 'batch_date=' + audit_batch_record['batch_date'] + '/' + str(
            audit_batch_record["batch_name"]) + '_log.json'
        s3_object = s3_resource.Object(batch_bucket, batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record, default=str).encode('UTF-8'))))

    def init_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET', 'LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record = {}
        audit_batch_record['batch_date'] = batch_date
        # set the batch date
        '''if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()'''

        audit_batch_record['batch_id'] = str(uuid.uuid4())
        audit_batch_record['batch_name'] = app_config.get("APPLICATION_NAME")
        audit_batch_record['status'] = 'STARTED'
        audit_batch_record['start_time'] = pendulum.now()
        audit_batch_record['end_time'] = ''
        print(audit_batch_record)
        self.log_batch_dtl(app_config, audit_batch_record)
        return audit_batch_record

    def finish_log_batch_dtl(self, app_config, batch_date):
        for key in ('LOGS_BUCKET', 'LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        batch_bucket = app_config['LOGS_BUCKET']
        batch_object_key = app_config['LOGS_BATCH_PATH'] + 'batch_date=' + batch_date + '/' + str(
            app_config.get("APPLICATION_NAME")) + '_log.json'
        print(f"batch_bucket:{batch_bucket}")
        print(f"batch_object_key:{batch_object_key}")
        try:
            audit_batch_record = self.get_config(batch_bucket, batch_object_key)
        except Exception as err:
            print(str(err))
        print(str(audit_batch_record))
        print("Type:" + str(type(audit_batch_record)))
        audit_batch_record['status'] = 'FINISHED'
        audit_batch_record['end_time'] = pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config, audit_batch_record)
        return audit_batch_record

    def fail_log_batch_ditl(self, app_config, batch_date, msg):
        for key in ('LOGS_BUCKET', 'LOGS_BATCH_PATH'):
            if app_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        batch_bucket = app_config['LOGS_BUCKET']
        batch_object_key = app_config['LOGS_BATCH_PATH'] + 'batch_date=' + batch_date + '/' + str(
            app_config.get("APPLICATION_NAME")) + '_log.json'
        print(f"batch_object_key:{batch_object_key}")
        audit_batch_record = self.get_config(batch_bucket, batch_object_key)
        audit_batch_record['status'] = msg
        audit_batch_record['end_time'] = pendulum.now()
        print(audit_batch_record)
        self.log_batch_dtl(app_config, audit_batch_record)
        return audit_batch_record

    def get_config(self, bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket, object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content) == 0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')


orch_handle = OrchestatorUtils()
app_config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/app_config.yml")
config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/pap_tableau_user_notify.yml")
PROCESSED_BUCKET = app_config_yml['environment'].get("PROCESSED_BUCKET")
CURATED_BUCKET = app_config_yml['environment'].get("CURATED_BUCKET")
DAG_NAME = 'pap_dag_tableau_notify_users'
dag_tags = ['PAP', 'Tableau New Users Notify']
release = 1


# def to run glue job
def custom_glue_job_execution(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    time.sleep(random.randint(0, 9))
    glue_client = boto3.client('glue', region_name=config_yml['dag']['region_name'])
    response = glue_client.start_job_run(
        JobName=kwargs["glue_job_name"],
        Arguments=kwargs["script_args"],
        WorkerType=kwargs["worker_type"],
        NumberOfWorkers=kwargs["no_of_workers"]
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    cloud_watch_url_output = f"https://{config_yml['dag']['region_name']}.console.aws.amazon.com/cloudwatch/home?region={config_yml['dag']['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error = f"https://{config_yml['dag']['region_name']}.console.aws.amazon.com/cloudwatch/home?region={config_yml['dag']['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    while isJobRunning:
        time.sleep(config_yml['dag']['glue_job_poll_interval'])
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId=job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED', 'STOPPED', 'FAILED']:
            isJobRunning = False
    # print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"


def send_tableau_users_notify_email(email):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    
    for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
        if email.get(key) is None:
            ValueError(f"Missing email parameter -{key}")

    s3Resource = boto3.resource('s3')
    s3 = boto3.client('s3')
    obj = s3Resource.Object(CODE_ARTIFACTS_BUCKET, 'configuration/setup/People Analytics Portal - Quick Guide.pdf')
    fs = obj.get()['Body'].read()
    try:
        # Provide the contents of the email.
        try:
            file_key = "audit-table/pap-tableau-users/PAP_Tableau_Users_"+ str(Variable.get('ds_nodash')) +".txt"
            # file_key = "HRA/PAP_Tableau_Users_20230718.txt"
            print(file_key)
            data = s3.get_object(Bucket=CURATED_BUCKET, Key=file_key)

            pap_tableau_users_df = pd.read_csv(io.BytesIO(data['Body'].read()), sep='\|\|', engine='python')
            #print("pap_tableau_users_df", pap_tableau_users_df.shape)
        except (FileNotFoundError, ValueError, ClientError, Exception) as ex:
            print("exception occurred while reading pap-tableau-users text file", str(ex))
            raise ex

        msg = MIMEMultipart('related')
        msg['Subject'] = email["msg_subject"]
        msg['From'] = email["sender"]
        msg['To'] = email["sender"]
        msg['Bcc'] = ",".join(pap_tableau_users_df[(pap_tableau_users_df["ACTION"] == "add") & (pap_tableau_users_df["EMAIL"] != "")]["EMAIL"].values.tolist())
        print(msg['Bcc'])
        if len(msg['Bcc']) == 0:
            print("NO USERS FOUND. HENCE, NO EMAIL WILL BE SEND.")
        else:
            body = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)
            part = MIMEApplication(fs)
            part.add_header('Content-Disposition', 'attachment', filename="People Analytics Portal - Quick Guide.pdf")
            msg.attach(part)

            with smtplib.SMTP("mailrelay.gilead.com", 25) as server:
                server.ehlo()  # Can be omitted
                # UNCOMMENT BELOW WHILE GOING IN PRODUCTION ENV
                msg_out = server.send_message(msg)
                print(str(msg_out))
                print("Successfully sent email")
                server.close()

    # Display an error if something goes wrong.
    except (ClientError, Exception) as ex:
        print(ex)
        raise ex


def dag_start_send_email(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    handle = OrchestatorUtils()
    context = get_current_context()
    #Variable.set('ds_nodash', context.get('ds_nodash'))
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH'] = str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'STARTED'
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_failure_send_email(context):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    try:
        handle = OrchestatorUtils()
        #Variable.set('ds_nodash', context.get('ds_nodash'))
        dict_email = {}
        dict_email['ENV'] = ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME'] = app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE'] = 'FAILED'
        dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
        dict_email['EXECUTION_DATE'] = context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
        dict_email['MESSAGE'] = ''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email[
            'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        email_template = \
            handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")[
                'templates'][0]
        print(email_template)
        enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))
    except Exception as err:
        print(f"ERROR:{str(err)}")

def dag_retry_send_email(context):
        if ENV_NAME['name'].upper() != PROD_ENV_NAME:
            print(f"Skipping the task as it is running in {ENV_NAME} env")
            raise AirflowSkipException
        if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
            print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
            raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        handle = OrchestatorUtils()
        dict_email={}
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= app_config_yml['environment'].get("APPLICATION_NAME")
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='RETRY'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_end_send_email(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    handle = OrchestatorUtils()
    context = get_current_context()
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = app_config_yml['environment'].get("APPLICATION_NAME")
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_DATE_NODASH'] = str(context['ds_nodash'])
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['PROCESS_RUN_STATE'] = 'COMPLETED'
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = pendulum.now().to_iso8601_string()
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_new_users_send_mail(**kwargs):
    if ENV_NAME['name'].upper() != PROD_ENV_NAME:
        print(f"Skipping the task as it is running in {ENV_NAME} env")
        raise AirflowSkipException
    if app_config_yml['environment'].get("ENABLE_SEND_MAIL_TO_TABLEAU_USERS") != "TRUE":
        print("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
        raise AirflowSkipException("ENABLE_SEND_MAIL_TO_TABLEAU_USERS property is disabled. Hence, Skipping the task")
    handle = OrchestatorUtils()
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['MESSAGE'] = ''
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/tableau_notify_users_email.yml")[
            'templates'][0]
    print('email_template', email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print("enriched_email", enriched_email)
    send_tableau_users_notify_email(json.loads(enriched_email))

default_args = {
    "owner": "PAP Project Team",
    "start_date": datetime(2023, 1, 1),
    "provide_context": True,
    "retries": 2,
}

with DAG(
        dag_id=DAG_NAME,
        start_date=pendulum.datetime(2023, 1, 1, tz="America/Los_Angeles"),
        catchup=False,
        schedule_interval=None,
        tags=dag_tags,
        default_args=default_args,
        on_failure_callback=dag_failure_send_email) as dag:
    start = PythonOperator(task_id="Start",
                           python_callable=dag_start_send_email,
                           provide_context=True,
                           )
    end = PythonOperator(task_id="End",
                         python_callable=dag_end_send_email,
                         provide_context=True,
                         )

    notify_new_users = PythonOperator(task_id="Notify_New_Users",
                                      python_callable=dag_new_users_send_mail,
                                      provide_context=True,
                                      on_failure_callback=dag_failure_send_email 
                                      )

start >> notify_new_users >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################
