#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'ZS Associates'

# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.

######################################################Module Information################################################
#   Module Name         :   FTPMoveCopyUtility
#   Purpose             :   Copy data from FTP to s3
#   Input Parameters    :   NA
#   Output              :   NA
#   Execution Steps     :   Instantiate and object of this class and call the class functions
#   Predecessor module  :   This module is specific to FTP
#   Successor module    :   NA
#   Last changed on     :   22 April 2020
#   Last changed by     :   Sushmita Konar
#   Reason for change   :   NA
########################################################################################################################


import traceback
import pysftp
import os
import sys
import boto3
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None

sys.path.insert(0, os.getcwd())
from ExecutionContext import ExecutionContext
from ConfigUtility import JsonConfigUtility
from CommonUtils import CommonUtils
import CommonConstants as CommonConstants
from MySQLConnectionManager import MySQLConnectionManager
from LogSetup import logger

MODULE_NAME = "FTPMoveCopyUtility"

class FTPMoveCopyUtility():
    def __init__(self, execution_context=None):

        if execution_context is None:
            self.execution_context = ExecutionContext()
        else:
            self.execution_context = execution_context
        self.execution_context.set_context({"module_name": MODULE_NAME})
        self.configuration = JsonConfigUtility(
            CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)


    def copy_ftp_to_s3_with_boto3(self,connection_id, ftp_file_path, target_file_name):
        """
             Purpose   :   This method is used to read FTP data and copy that to s3
             Input     :   connection_id(for FTP connections), ftp_file_path, target_file_name
             Output    :   success message
         """

        status_message = ""
        try:
            status_message = "Started function to copy all the files from FTP : " + str(ftp_file_path) + " to s3 location : " \
                + str(target_file_name)
            ftp_conn_details = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY,
                                                                 "ftp_connection_details"])
            ftp_connection_details_for_conn_id = ftp_conn_details[str(connection_id)]
            ftp_cred_params = ftp_connection_details_for_conn_id
            ftp_server_details = ftp_cred_params[CommonConstants.FTP_SERVER]
            ftp_username = ftp_cred_params[CommonConstants.FTP_USERNAME]
            ftp_secret_name = ftp_cred_params[CommonConstants.FTP_SECRET_NAME]

            secret_password = MySQLConnectionManager().get_secret(ftp_secret_name,
                self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_region"]))
            ftp_password = secret_password['ftp_password_secret_name']

            conn = pysftp.Connection(ftp_server_details, username=ftp_username, password=ftp_password,
                                     cnopts=cnopts)

            status_message = "Created FTP connection object with provided connection details"
            logger.info(status_message, extra=self.execution_context.get_context())
            bucket_name = CommonUtils().get_s3_bucket_name(target_file_name)
            s3_folder_path = CommonUtils().get_s3_folder_path(target_file_name)

            file_content = conn.open(ftp_file_path)
            s3 = boto3.client('s3')
            s3.upload_fileobj(file_content, bucket_name, s3_folder_path)
            status_message = 'Executed FTP to s3 copy successfully '
            logger.info(status_message, extra=self.execution_context.get_context())

        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + \
                " ERROR MESSAGE: " + str(traceback.format_exc())
            self.execution_context.set_context({"traceback": error})
            logger.error(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": ""})
            raise e
