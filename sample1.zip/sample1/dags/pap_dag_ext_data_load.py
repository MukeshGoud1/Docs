############################################################
############################################################
####-       FILE NAME       : pap_dag_ext-data_load.py -####
####-       FILE CREATED    : 2022/08/01               -####
####-       FILE LAST EDITED: 2023/08/21               -####
############################################################
############################################################
import sys
sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime as dt
from airflow import DAG
from datetime import datetime,timedelta
import imp
import os
import ast
import urllib
import requests
import time
import random
from io import StringIO

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.configuration import conf as airflow_conf
import boto3
import pandas as pd
from botocore.exceptions import ClientError
import uuid
import pendulum
import json
import yaml
#from airflow.decorators import task
from airflow.operators.python import task, get_current_context
from string import Template
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.models import Variable
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
ENV_NAME = ''
try:   
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager',region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET=f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"
class OrchestatorUtils():
    # def send_email(self,email):
        # for key in ('aws_region', 'sender','recipient_list', 'msg_charset','msg_subject','msg_body_html','msg_body_text'):
            # if email.get(key) is None:
                # ValueError(f"Missing email parameter -{key}")
        
        # # Create a new SES resource and specify a region.
        # client = boto3.client('ses',region_name=email["aws_region"])
        # # Try to send the email.
        # try:
            # #Provide the contents of the email.
            # response = client.send_email(
                # Destination={
                    # 'ToAddresses': email["recipient_list"],
                # },
                # Message={
                    # 'Body': {
                        # 'Html': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_html"],
                        # },
                        # 'Text': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_text"],
                        # },
                    # },
                    # 'Subject': {
                        # 'Charset': email["msg_charset"],
                        # 'Data': email["msg_subject"],
                    # },
                # },
                # Source=email["sender"],
            # )
        # # Display an error if something goes wrong.	
        # except ClientError as e:
            # print(e.response['Error']['Message'])
        # else:
            # print("Email sent! Message ID:"),
            # print(response['MessageId'])
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg = MIMEMultipart('related')
            msg['Subject'] = email["msg_subject"]
            msg['From'] = email["sender"]
            msg['To'] = ','.join(email["recipient_list"])
            body = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")
    def log_batch_dtl(batch_config,audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+audit_batch_record['batch_date']+'/'+str(audit_batch_record["batch_name"])+'_log.json'
        s3_object = s3_resource.Object(batch_bucket,batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record,default=str).encode('UTF-8'))))
    
    def init_log_batch_dtl(batch_config):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record={}
        #set the batch date
        if batch_config['override_flag']=='Y':
            audit_batch_record['batch_date']=batch_config['batch_date']
        else:
            audit_batch_record['batch_date']=pendulum.now().to_date_string()
            
        audit_batch_record['batch_id']=str(uuid.uuid4())
        audit_batch_record['batch_name']='PAP'
        audit_batch_record['status']='RUNNING'
        audit_batch_record['st']=pendulum.now().to_string()
        audit_batch_record['et']=''
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
        
    def finish_log_batch_dtl(batch_config,batch_date,batch_name):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
                
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+batch_date+'/'+str(batch_name)+'_log.json'        
        audit_batch_record=get_config(batch_bucket,batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status']='FINISHED'
        audit_batch_record['et']=pendulum.now()
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
    
    def fail_log_batch_ditl(batch_config,batch_date,batch_name,error_msg):
        for key in ('batch_date','override_flag','BATCH_LOGS_BUCKET','BATCH_LOGS_TABLE_PATH','partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
                
        batch_bucket=batch_config['BATCH_LOGS_BUCKET']
        batch_object_key=batch_config['BATCH_LOGS_TABLE_PATH']+batch_config['partition_key']+'='+batch_date+'/'+str(batch_name)+'_log.json'        
        audit_batch_record=get_config(batch_bucket,batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status']='FAILED'
        audit_batch_record['et']=pendulum.now()
        audit_batch_record['msg']='error_msg'
        print(audit_batch_record)
        log_batch_dtl(batch_config,audit_batch_record)
        return audit_batch_record
    
    def get_config(self,bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket,object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content)==0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')
            

orch_handle=OrchestatorUtils()
app_config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/app_config.yml")

config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET,"configuration/dags/pap_dag_ext_data_load.yml")

#validation of all the keys in dag config yaml:
for key in ('dag_id','owner','start_date','time_zone','load_type','schedule','tags','retries','concurrency','namespace','region_name','glue_iam_role','on_failure_callback','on_retry_callback'):
    if config_yml['dag'].get(key) is None:
        ValueError(f"Missing DAG config parameter -{key}")
        
DAG_NAME=config_yml['dag']['dag_id']
dag_tags=['PAP','RELEASE 1 & RELEASE 2']
release=1


def check_nasdaq():
    try:
        # handle = OrchestatorUtils()
        # app_config = handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/app_config.yml")['environment']
        current_datetime_format = datetime.now().strftime('%m%d%Y%H%M%S')
        app_config = app_config_yml['environment']
        print(app_config)
        print(app_config['NASDAQ_API_URL'])
        print(app_config['NASDAQ_OUTPUT_FILE_BUCKET'])
        print(app_config['NASDAQ_OUTPUT_FILE_KEY'])

        s3 = boto3.resource('s3')

        r = requests.get(app_config['NASDAQ_API_URL'])
        print(r.status_code)
        data = r.json()
        # print("type of result:: ",type(data.json()))
        res = {'current_price': data['c'], 'prev_closing_price': data['pc'],
               'quote_date': datetime.utcfromtimestamp(data['t']).strftime('%Y%m%d')}
        csv_buffer = StringIO()
        df = pd.DataFrame([res])
        df.to_csv(csv_buffer, index=False)
        write_key = app_config['NASDAQ_OUTPUT_FILE_KEY'] + "_"+ current_datetime_format+".csv"
        s3.Object(app_config['NASDAQ_OUTPUT_FILE_BUCKET'],write_key).put(
            Body=csv_buffer.getvalue())
        print("complete - nasdaq write to file")

    except Exception as ex:
        print(ex)
        raise ex


def dag_start_send_email(**kwargs):
        print('inside start send email')
        handle = OrchestatorUtils()
      
        context = get_current_context()
        dict_email={}
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='STARTED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def dag_failure_send_email(context): 
        print("IN dag_failure_send_email")
        handle = OrchestatorUtils()
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        dict_email={}
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='FAILED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        dict_email['MESSAGE']=''
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))
def dag_end_send_email(**kwargs):
        handle = OrchestatorUtils()
        context = get_current_context()
        dict_email={}
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='COMPLETED'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=''
        dag_id = context["dag"].dag_id
        execution_date = context["execution_date"].isoformat()
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp 
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email)) 

def dag_retry_send_email(context):
        handle = OrchestatorUtils()
        dict_email={}
        dag_id = context["dag"].dag_id
        task_id = context['task'].task_id
        execution_date = context["execution_date"].isoformat()
        #parameterize env 
        dict_email['ENV']= ENV_NAME['name'].upper()
        dict_email['APPLICATION_NAME']= config_yml['dag']['namespace']
        dict_email['PROCESS_NAME']= str(context['dag_run'].dag_id)
        dict_email['PROCESS_RUN_ID']=str(context['dag_run'].run_id)
        dict_email['PROCESS_RUN_TYPE']=str(context['dag_run'].run_type)
        dict_email['PROCESS_RUN_STATE']='RETRY'
        dict_email['BATCH_DATE']=str(context['dag_run'].conf['batch_date'])
        dict_email['EXECUTION_DATE']=context.get('execution_date')
        dict_email['PROCESS_RUN_START_TIME']=str(context['dag_run'].start_date)
        dict_email['PROCESS_RUN_END_TIME']=str(context['dag_run'].end_date)
        dict_email['PROCESS_EXTERNAL_TRIGGER']=str(context['dag_run'].external_trigger)
        #needs to be populated message and process url
        dict_email['MESSAGE']=f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
        dict_email['PROCESS_URL']=f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
        #parameterize email temp
        email_template=handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
        print(email_template)
        enriched_email=Template(json.dumps(email_template)).safe_substitute(dict_email)
        print(enriched_email)
        handle.send_email(json.loads(enriched_email))

def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0,9)) # for giving delay in each job
    glue_client = boto3.client('glue', region_name=kwargs['region_name'])
    response = glue_client.start_job_run(
    JobName=kwargs["glue_job_name"],
    Arguments=kwargs["script_args"],
    WorkerType=kwargs["worker_type"],
    NumberOfWorkers=kwargs["no_of_workers"]
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    while isJobRunning:
        time.sleep(15)
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId = job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED','STOPPED','FAILED']:
            isJobRunning = False
    cloud_watch_url_output =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error =  f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    #print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"


default_args = {
    "owner": config_yml['dag']['owner'],
    "start_date": pendulum.parse(config_yml['dag']['start_date'], tz=config_yml['dag']['time_zone']),
    "provide_context": True,
    "max_active_runs": config_yml['dag']['max_active_runs'],
    "on_retry_callback": getattr(sys.modules[__name__],config_yml['dag']['on_retry_callback'])
}

batch_dt = Variable.get('ds_nodash')
glue_iam_role = config_yml['dag']['glue_iam_role']
region_name = config_yml['dag']['region_name']
script_args = {
                        '--config_bucket': app_config_yml['environment']['RAW_BUCKET'],
                        '--batch_date': batch_dt
                    }

script_arg_mand_file_chk= {
                            '--config_bucket': CODE_ARTIFACTS_BUCKET,
                            '--batch_date': batch_dt,
                            '--config': f"s3://{app_config_yml['environment'].get('CODE_ARTIFACTS_BUCKET')}/configuration/mandatoryfile_config.csv",
                            '--folder_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/landing/"
                            }
        
with DAG(
    dag_id=DAG_NAME,
    start_date=pendulum.datetime(2022, 12, 1, tz="America/Los_Angeles"),
    catchup=False,
    concurrency=config_yml['dag']['concurrency'],
    schedule_interval=None,
    tags=config_yml['dag']['tags'],
    default_args=default_args,
    on_failure_callback=dag_failure_send_email) as dag:
    start = PythonOperator(
                        task_id="Start",
                        python_callable=dag_start_send_email, 
                        provide_context=True,
                        )
    end = PythonOperator(
                        task_id="End",
                        python_callable=dag_end_send_email, 
                        provide_context=True,
                        )
    data_pull_denodo = PythonOperator(
                        task_id="pap-raw-denodo-worker",
                        python_callable=custom_glue_job_execution, 
                        provide_context=True,
                        on_failure_callback=dag_failure_send_email,
                        op_kwargs={'glue_job_name': 'pap-raw-denodo-worker', 
                                'no_of_workers':2,
                                'script_args':script_args,
                                'region_name' : region_name,
                                'worker_type':'G.1X' }
                        )
    data_pull_nasdaq = PythonOperator(task_id="pap-raw-nasdaq-api", python_callable=check_nasdaq, provide_context=True, dag=dag)

    

    #publish_to_redshift_load_schema = DummyOperator(task_id='publish_to_redshift_load_schema')
    #perform_schema_swtich = DummyOperator(task_id='perform_schema_swtich')
    #publish_to_redshift_sync_schema = DummyOperator(task_id='publish_to_redshift_sync_schema')
    #glue_crawlers = DummyOperator(task_id='glue_crawlers')
    #vacuuming = DummyOperator(task_id='vacuuming')
#ADD DATA PULL DENODO ONCE WE GET THE SERVICE ACCOUNT DETAILS
start >> [data_pull_denodo, data_pull_nasdaq ] >> end

#start >> [data_pull_nasdaq, pap_dag_vfdata_ingestion] >> end

#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################