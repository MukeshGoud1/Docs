############################################################
############################################################
####-       FILE NAME       : pap_dag_ext-data_load.py -####
####-       FILE CREATED    : 2022/08/01               -####
####-       FILE LAST EDITED: 2023/08/07               -####
############################################################
############################################################
import sys

sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime as dt
from airflow import DAG
from datetime import datetime, timedelta
import imp
import os
import ast
import urllib
import requests
import time
import random
from io import StringIO
import subprocess

# cleanup level imports
import boto3
import pandas as pd
import yaml
from io import StringIO
from pathlib import Path
from datetime import datetime
from botocore.exceptions import ClientError

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.configuration import conf as airflow_conf
import uuid
import pendulum
import json

# from airflow.decorators import task
from airflow.operators.python import task, get_current_context
from string import Template
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.models import Variable

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

ENV_NAME = ''
try:
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET = f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"


class OrchestatorUtils():
    # def send_email(self, email):
    # for key in (
    # 'aws_region', 'sender', 'recipient_list', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
    # if email.get(key) is None:
    # ValueError(f"Missing email parameter -{key}")

    # # Create a new SES resource and specify a region.
    # client = boto3.client('ses', region_name=email["aws_region"])
    # # Try to send the email.
    # try:
    # # Provide the contents of the email.
    # response = client.send_email(
    # Destination={
    # 'ToAddresses': email["recipient_list"],
    # },
    # Message={
    # 'Body': {
    # 'Html': {
    # 'Charset': email["msg_charset"],
    # 'Data': email["msg_body_html"],
    # },
    # 'Text': {
    # 'Charset': email["msg_charset"],
    # 'Data': email["msg_body_text"],
    # },
    # },
    # 'Subject': {
    # 'Charset': email["msg_charset"],
    # 'Data': email["msg_subject"],
    # },
    # },
    # Source=email["sender"],
    # )
    # # Display an error if something goes wrong.
    # except ClientError as e:
    # print(e.response['Error']['Message'])
    # else:
    # print("Email sent! Message ID:"),
    # print(response['MessageId'])
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg = MIMEMultipart('related')
            msg['Subject'] = email["msg_subject"]
            msg['From'] = email["sender"]
            msg['To'] = ','.join(email["recipient_list"])
            body = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")

    def log_batch_dtl(batch_config, audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config['partition_key'] + '=' + \
                           audit_batch_record['batch_date'] + '/' + str(audit_batch_record["batch_name"]) + '_log.json'
        s3_object = s3_resource.Object(batch_bucket, batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record, default=str).encode('UTF-8'))))

    def init_log_batch_dtl(batch_config):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record = {}
        # set the batch date
        if batch_config['override_flag'] == 'Y':
            audit_batch_record['batch_date'] = batch_config['batch_date']
        else:
            audit_batch_record['batch_date'] = pendulum.now().to_date_string()

        audit_batch_record['batch_id'] = str(uuid.uuid4())
        audit_batch_record['batch_name'] = 'PAP'
        audit_batch_record['status'] = 'RUNNING'
        audit_batch_record['st'] = pendulum.now().to_string()
        audit_batch_record['et'] = ''
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def finish_log_batch_dtl(batch_config, batch_date, batch_name):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")

        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config[
            'partition_key'] + '=' + batch_date + '/' + str(batch_name) + '_log.json'
        audit_batch_record = get_config(batch_bucket, batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status'] = 'FINISHED'
        audit_batch_record['et'] = pendulum.now()
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def fail_log_batch_ditl(batch_config, batch_date, batch_name, error_msg):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")

        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config[
            'partition_key'] + '=' + batch_date + '/' + str(batch_name) + '_log.json'
        audit_batch_record = get_config(batch_bucket, batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status'] = 'FAILED'
        audit_batch_record['et'] = pendulum.now()
        audit_batch_record['msg'] = 'error_msg'
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def get_config(self, bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket, object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content) == 0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')


orch_handle = OrchestatorUtils()
app_config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/app_config.yml")
config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/pap_dag_backup_history.yml")

# validation of all the keys in dag config yaml:
for key in (
        'dag_id', 'owner', 'start_date', 'time_zone', 'load_type', 'schedule', 'tags', 'retries', 'concurrency',
        'namespace',
        'region_name', 'glue_iam_role', 'on_failure_callback', 'on_retry_callback'):
    if config_yml['dag'].get(key) is None:
        ValueError(f"Missing DAG config parameter -{key}")

DAG_NAME = config_yml['dag']['dag_id']
dag_tags = config_yml['dag']['tags']
release = 1


def dag_start_send_email(**kwargs):
    print('inside start send email')
    handle = OrchestatorUtils()

    context = get_current_context()
    dict_email = {}
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'STARTED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_failure_send_email(context):
    print("IN dag_failure_send_email")
    handle = OrchestatorUtils()
    dag_id = context["dag"].dag_id
    task_id = context['task'].task_id
    execution_date = context["execution_date"].isoformat()
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'FAILED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    dict_email['MESSAGE'] = ''
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_end_send_email(**kwargs):
    handle = OrchestatorUtils()
    context = get_current_context()
    dict_email = {}
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'COMPLETED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_retry_send_email(context):
    handle = OrchestatorUtils()
    dict_email = {}
    dag_id = context["dag"].dag_id
    task_id = context['task'].task_id
    execution_date = context["execution_date"].isoformat()
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'RETRY'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
        handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def custom_glue_job_execution(**kwargs):
    time.sleep(random.randint(0, 9))  # for giving delay in each job
    glue_client = boto3.client('glue', region_name=kwargs['region_name'])
    response = glue_client.start_job_run(
        JobName=kwargs["glue_job_name"],
        Arguments=kwargs["script_args"]
    )
    job_run_id = response["JobRunId"]
    isJobRunning = True
    status = ''
    while isJobRunning:
        time.sleep(15)
        status_detail = glue_client.get_job_run(JobName=kwargs["glue_job_name"], RunId=job_run_id)
        print(str(status_detail))
        status = status_detail.get("JobRun").get("JobRunState")
        print(str(status))
        if status in ['SUCCEEDED', 'STOPPED', 'FAILED']:
            isJobRunning = False
    cloud_watch_url_output = f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Foutput$3FlogStreamNameFilter$3D{job_run_id}"
    cloud_watch_url_error = f"https://{kwargs['region_name']}.console.aws.amazon.com/cloudwatch/home?region={kwargs['region_name']}#logsV2:log-groups/log-group/$252Faws-glue$252Fjobs$252Ferror$3FlogStreamNameFilter$3D{job_run_id}"
    print(f"cloud_watch_url_OUTPUT: {cloud_watch_url_output}")
    print(f"cloud_watch_url_ERROR: {cloud_watch_url_error}")
    # print(json.dumps(response, indent=4, sort_keys=True, default=str))
    if status != 'SUCCEEDED':
        # will fail without retry
        raise Exception("Glue Job Failed")
    else:
        return "OK"


batch_dt = str(Variable.get('ds_nodash'))
glue_iam_role = config_yml['dag']['glue_iam_role']
region_name = config_yml['dag']['region_name']

default_args = {
    "owner": config_yml['dag']['owner'],
    "start_date": pendulum.parse(config_yml['dag']['start_date'], tz=config_yml['dag']['time_zone']),
    "provide_context": True,
    "max_active_runs": config_yml['dag']['max_active_runs'],
    "on_retry_callback": getattr(sys.modules[__name__], config_yml['dag']['on_retry_callback'])
}

script_arg_pap_data_bkp = {
                            '--config_bucket': CODE_ARTIFACTS_BUCKET,
                            '--BATCH_DATE': batch_dt,
                            '--source_bucket': app_config_yml['environment']['PROCESSED_BUCKET'],
                            '--PROCESSED_TARGET_KEY': app_config_yml['processed_bucket_data_backup']['PROCESSED_TARGET_KEY'],
                            '--EXCLUDED_PREFIXES' :app_config_yml['processed_bucket_data_backup']['EXCLUDED_PREFIXES'],
                            '--ARCHIVE_LOCATION' : app_config_yml['processed_bucket_data_backup']['ARCHIVE_LOCATION']
                            }



with DAG(
        dag_id=DAG_NAME,
        start_date=pendulum.datetime(2022, 12, 1, tz="America/Los_Angeles"),
        catchup=False,
        concurrency=config_yml['dag']['concurrency'],
        schedule_interval=None,
        tags=config_yml['dag']['tags'],
        default_args=default_args,
        on_failure_callback=dag_failure_send_email) as dag:
    start = PythonOperator(
        task_id="Start",
        python_callable=dag_start_send_email,
        provide_context=True,
    )
    end = PythonOperator(
        task_id="End",
        python_callable=dag_end_send_email,
        provide_context=True,
    )
    # copy_s3_object_history = PythonOperator(task_id="pap-processed-backup-api", python_callable=copy_s3_object,
    #                                         provide_context=True, dag=dag)

    copy_s3_object_history = PythonOperator(
                        task_id="pap-backup-processed-data",
                        python_callable=custom_glue_job_execution,
                        provide_context=True,
                        on_failure_callback=dag_failure_send_email,
                        op_kwargs={'glue_job_name': 'pap-backup-processed-data',
                                'script_args':script_arg_pap_data_bkp,
                                'region_name' : region_name
                                   }
                        )

start >> copy_s3_object_history >> end



#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################
