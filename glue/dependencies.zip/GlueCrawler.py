import os
import sys
import boto3
import logging
import traceback
import time

import CommonConstants
from ConfigUtility import JsonConfigUtility
from MySQLConnectionManager import MySQLConnectionManager
from ExecutionContext import ExecutionContext
from PySparkUtility import PySparkUtility



MODULE_NAME = "GlueCrawler"

logger = logging.getLogger(__name__)
hndlr = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
hndlr.setFormatter(formatter)

class GlueCrawler():

    def __init__(self,process_id,dataset_id,step,batch_id=None,cycle_id=None):
        self.execution_context = ExecutionContext()
        self.process_id = process_id
        self.execution_context.set_context({"process_id": self.process_id})
        self.dataset_id = dataset_id
        self.step = step
        self.batch_id = batch_id
        self.cycle_id = cycle_id
        self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
        self.audit_db = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        self.spark = PySparkUtility().get_spark_context(dataset_id)



    def get_table_details(self):
        try:
            status_message = "Starting Glue Table Creation method for process id:" + str(self.process_id) + " " \
                             + "and step:" + str(self.step)
            logger.info(status_message, extra=self.execution_context.get_context())
            step = self.step



            get_dataset_details_query = "Select * from {audit_db}.{dataset_master_table} where " \
                                        "dataset_id={dataset_id}".format(audit_db=self.audit_db,
                                         dataset_master_table=CommonConstants.DATASOURCE_INFORMATION_TABLE_NAME,
                                         dataset_id=self.dataset_id
            )

            get_dataset_details_query_result = MySQLConnectionManager(self.execution_context).execute_query_mysql \
                (get_dataset_details_query, True)

            target_table_location = None
            target_table_name = None
            staging_table_name = None
            staging_db = None
            db = None

            row_id_exclusion_flag = get_dataset_details_query_result["row_id_exclusion_flag"]

            # if step == "pre_landing":
            #     target_table_location = get_dataset_details_query_result["pre_landing_location"]
            #     target_table_name = get_dataset_details_query_result["pre_landing_table"]
            ddl_query_template = CommonConstants.DDL_TABLE_QUERY_TEMPLATE

            if step in CommonConstants.TABLE_NAME_LOCATION_DICT.keys():
                target_table_location = get_dataset_details_query_result[CommonConstants.TABLE_NAME_LOCATION_DICT[step][0]]
                target_table_name_db = get_dataset_details_query_result[CommonConstants.TABLE_NAME_LOCATION_DICT[step][1]]
                db = target_table_name_db.split(".")[0]
                target_table_name = target_table_name_db.split(".")[1]
                table_partition = get_dataset_details_query_result["table_partition_by"]
                table_partition_sql_str = None
                if table_partition:
                    table_partition =table_partition.split(',')
                    table_partition_sql_str = 'PARTITIONED BY ( '
                    for partition in table_partition:
                        table_partition_sql_str = table_partition_sql_str+"pt_"+partition+" "+"string,"
                    table_partition_sql_str = table_partition_sql_str.rstrip(',')
                    table_partition_sql_str = table_partition_sql_str + ")"

                view_name_full = None
                view_name_latest = None
            else:
                raise Exception("Invalid Step name provided")

            if step in ["publish"]:
                ddl_query_template = CommonConstants.DDL_VIEW_QUERY_TEMPLATE
                view_name_full = target_table_name + "_full"
                view_name_latest = target_table_name + "_latest"
                staging_table_name_db = get_dataset_details_query_result[CommonConstants.TABLE_NAME_LOCATION_DICT["staging"][1]]
                staging_db = staging_table_name_db.split(".")[0]
                staging_table_name = staging_table_name_db.split(".")[1]
                if not staging_table_name:
                    raise Exception("Staging Table name was not provided")

            if step in ["publish_dw"]:
                ddl_query_template = CommonConstants.DDL_VIEW_QUERY_DW_TEMPLATE
                view_name_full = target_table_name + "_full"
                view_name_latest = target_table_name + "_latest"
                staging_table_name_db = get_dataset_details_query_result["table_name"]
                staging_db = staging_table_name_db.split(".")[0]
                staging_table_name = staging_table_name_db.split(".")[1]
                if not staging_table_name:
                    raise Exception("Staging Table name was not provided")

            if (not target_table_name):
                raise Exception("Table name for step: {step} is not configured in {dataset_master}".format(
                    step=self.step,
                    dataset_master=CommonConstants.DATASOURCE_INFORMATION_TABLE_NAME
                ))

            if (step not in ["publish"] and not target_table_location):
                raise Exception("S3 Path for step: {step} is not configured in {dataset_master}".format(
                    step=self.step,
                    dataset_master=CommonConstants.DATASOURCE_INFORMATION_TABLE_NAME
                ))

            replace_dict = {"$$table_name":target_table_name,
                            "$$columns":'',
                            "$$target_table_location":target_table_location,
                            "$$view_name_full":view_name_full if view_name_full else '',
                            "$$view_name_latest":view_name_latest if view_name_latest else '',
                            "$$latest_batch_id": self.batch_id if self.batch_id else '',
                            '$$latest_cycle_id': self.cycle_id if self.cycle_id else '',
                            "$$staging_table_name": staging_table_name if staging_table_name else '',
                            "$$db": db,
                            "$$staging_db": staging_db if staging_db else '',
                            "$$partition": table_partition_sql_str if table_partition_sql_str else ''}

            if step not in ["publish","publish_dw"]:
                column_name_dict = self.get_column_details()

                ddl_column_str = ''
                for name in column_name_dict.keys():
                    ddl_column_str = ddl_column_str + name + ' ' + column_name_dict[name] + ','

                if row_id_exclusion_flag.upper() == "N":
                    ddl_column_str = ddl_column_str + CommonConstants.ROW_ID + ' ' + 'bigint' + ','

                ddl_column_str = ddl_column_str.rstrip(',')

                replace_dict["$$columns"] = ddl_column_str

                for replace_value in replace_dict.keys():
                    ddl_query_template = ddl_query_template.replace(replace_value,replace_dict[replace_value])

                logger.info("Query after replacing parameters:"+ddl_query_template)

                self.create_and_refresh_hive_table(db=db,
                                                   table=target_table_name,
                                                   query=ddl_query_template)
                # self.spark.sql(ddl_query_template)
                # refresh_table_s3_spark_query = "Refresh table {table_name}".format(table_name=target_table_name)
                # self.spark.sql(refresh_table_s3_spark_query)

            else:
                for replace_value in replace_dict.keys():
                    ddl_query_template = ddl_query_template.replace(replace_value,replace_dict[replace_value])
                ddl_query_template = ddl_query_template.split(";")
                logger.info("Splitted query list:"+str(ddl_query_template))

                for query in ddl_query_template:
                    query = query.lstrip('\n')
                    logger.info(query)
                    if query.startswith("CREATE") and (view_name_latest in query):
                        self.create_cross_platform_view(db,view_name_latest,query)
                    elif query.startswith("CREATE"):
                        self.create_cross_platform_view(db, view_name_full, query)
                    elif query.startswith("DROP"):
                        self.spark.sql(query)
        except Exception as exc:
            logger.error(str(exc))
            logger.error(traceback.format_exc())
            raise Exception(exc)

    def get_column_details(self):
        status_message = "Starting to get column details for dataset_id id:" + str(self.dataset_id) + " " \
                         + "and step:" + str(self.step)
        logger.info(status_message, extra=self.execution_context.get_context())

        get_column_details_query = "Select * from {audit_db}.{column_metadata} where dataset_id={dataset_id}".format(
            audit_db=self.audit_db,
            column_metadata=CommonConstants.COLUMN_METADATA_TABLE,
            dataset_id=self.dataset_id
        )

        column_name_dict = {}

        get_column_details_query_result = MySQLConnectionManager(self.execution_context).execute_query_mysql \
            (get_column_details_query)

        if self.step in ["landing","pre_dqm"]:
            for column_result in get_column_details_query_result:
                column_name_dict[column_result['column_name']] = "string"

        if self.step in ["staging"]:
            for column_result in get_column_details_query_result:
                column_name_dict[column_result['column_name']] = column_result['column_data_type']

        return column_name_dict

    def execute_blocking_athena_query(self,query):
        try:
            logger.info("Creating table on athena for query: {0}".format(query))
            athena = boto3.client("athena")
            res = athena.start_query_execution(QueryString=query,ResultConfiguration={
        'OutputLocation': 's3://aws-a9018-use1-00-d-s3b-bpod-bdp-data01/athena_results/'
        })
            execution_id = res["QueryExecutionId"]
            while True:
                res = athena.get_query_execution(QueryExecutionId=execution_id)
                state = res["QueryExecution"]["Status"]["State"]
                if state == "SUCCEEDED":
                    return
                if state in ["FAILED", "CANCELLED"]:
                    raise Exception(res["QueryExecution"]["Status"]["StateChangeReason"])
                time.sleep(1)
        except Exception as exc:
            logger.error(str(exc))
            raise exc

    def create_cross_platform_view(self,db, table, query):
        try:
            logger.info("Starting function to create cross-platform view")
            logger.info("database:{0}".format(db))
            logger.info("view_name:{0}".format(table))
            logger.info("query:{0}".format(query))
            glue = boto3.client("glue")
            #glue.delete_table(DatabaseName=db, Name=table)
            create_view_sql = query
            self.spark.sql("CREATE DATABASE IF NOT EXISTS {db}".format(db=db))
            self.execute_blocking_athena_query(create_view_sql)
            presto_schema = glue.get_table(DatabaseName=db, Name=table)["Table"][
                "ViewOriginalText"
            ]
            glue.delete_table(DatabaseName=db, Name=table)

            self.spark.sql(create_view_sql).show()
            spark_view = glue.get_table(DatabaseName=db, Name=table)["Table"]
            for key in [
                "DatabaseName",
                "CreateTime",
                "UpdateTime",
                "CreatedBy",
                "IsRegisteredWithLakeFormation",
                "CatalogId",
            ]:
                if key in spark_view:
                    del spark_view[key]
            spark_view["ViewOriginalText"] = presto_schema
            spark_view["Parameters"]["presto_view"] = "true"
            spark_view = glue.update_table(DatabaseName=db, TableInput=spark_view)
            return
        except Exception as exc:
            logger.error(str(exc))
            raise exc

    def create_and_refresh_hive_table(self, db, table, query):
        try:
            logger.info("Executing query for database:{0},table:{1},query:{2}".format(db,table,query))
            self.spark.sql("CREATE database IF NOT EXISTS {db}".format(db=db))
            self.spark.sql(query)
            self.spark.sql("Refresh table {0}.{1}".format(db,table))
            self.spark.sql("MSCK REPAIR TABLE {0}.{1}".format(db,table))
            logger.info("Successfully created/refreshed table")
        except Exception as exc:
            logger.error(str(exc))
            raise exc




if __name__ == "__main__":
    try:
        args = sys.argv

        process_id = args[1]
        dataset_id = args[2]
        step = args[3]
        batch_id = None
        if len(args) == 5:
            batch_id = sys.argv[4]

        glueObj = GlueCrawler(process_id=process_id,dataset_id=dataset_id,step=step,batch_id=batch_id)
        glueObj.get_table_details()

    except Exception as exc:
        logger.error(str(exc))
        logger.error(traceback.format_exc())


