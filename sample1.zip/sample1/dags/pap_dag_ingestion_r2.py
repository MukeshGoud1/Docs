#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

sys.path.insert(0, "/usr/local/airflow/plugins/code")
from datetime import datetime
import imp
import DagUtils

dagutils = imp.reload(DagUtils)

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from pendulum import datetime, duration

# Name of the Dag

FILE_MASTER_IDS = ["1000001185", "1000001184", "1000001170", "1000001129", "1000001128", "1000001127", "1000001126",
                   "1000001116", "1000001115", "1000001114", "1000001113", "1000001112", "1000001111", "1000001110",
                   "1000001104", "1000001097", "1000001096", "1000001095", "1000001094", "1000001093", "1000001092",
                   "1000001091", "1000001090", "1000001089", "1000001088", "1000001087", "1000001086"]
PROCESS_ID = 2022050914513278547167
# "1000001121","1000001124","1000001125", -- removed hier files now loading directly through athena table
SOURCE_TYPE = 's3'

DAG_NAME = "pap_dag_ingestion_r2"
dag_tags = ['PAP', 'Ingestion', 'release1']

# Set default dag properties
default_args = {
    "owner": "PAP Project Team",
    "start_date": datetime(2022, 5, 10),
    "provide_context": True,
    "retries": 3,
    "retry_delay": duration(seconds=300)
}

# Define the dag object
dag = DAG(
    DAG_NAME,
    default_args=default_args,
    concurrency=10,
    schedule_interval=None,
    tags=dag_tags,
)

# This is to avoid or bypass error because of added security to restrict multithreading
disable_fork_safety = BashOperator(
    task_id='disable_fork_safety', bash_command='export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES', dag=dag)

# verify_disable_fork_safety = BashOperator(
#    task_id='verify_disable_fork_safety', bash_command='echo $OBJC_DISABLE_INITIALIZE_FORK_SAFETY', dag=dag)

start = PythonOperator(
    task_id="start",
    python_callable=dagutils.trigger_notification_utility, provide_context=True,
    op_kwargs={"email_type": "batch_status", "process_id": PROCESS_ID, "dag_name": DAG_NAME},
    dag=dag)

end = PythonOperator(
    task_id="end",
    python_callable=dagutils.trigger_notification_utility, provide_context=True,
    op_kwargs={"email_type": "batch_status", "process_id": PROCESS_ID, "dag_name": DAG_NAME, "emr_status": "SUCCEEDED"},
    dag=dag)

emr_launch = PythonOperator(
    task_id="launch_cluster",
    python_callable=dagutils.launch_emr, provide_context=True,
    op_kwargs={"process_id": PROCESS_ID},
    dag=dag)

# emr_terminate = PythonOperator(
#    task_id="terminate_cluster",
#    trigger_rule="all_done",
#    python_callable=dagutils.terminate_emr, provide_context=True,
#    op_kwargs={"email_type": "batch_status", "process_id": PROCESS_ID, "dag_name": DAG_NAME},
#    dag=dag)

emr_launch.set_upstream(start)

# pre_ingestion = PythonOperator(
#        task_id="pre_ingestion_" + str(PROCESS_ID),
#        python_callable=dagutils.call_pre_ingestion, provide_context=True,
#        op_kwargs={"source_type": SOURCE_TYPE, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
#        dag=dag)

# pre_ingestion.set_upstream(emr_launch)

for file_master_id in FILE_MASTER_IDS:
    pre_landing = PythonOperator(
        task_id="pre_landing_" + str(file_master_id),
        python_callable=dagutils.call_pre_landing, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    file_check = PythonOperator(
        task_id="file_check_" + str(file_master_id),
        python_callable=dagutils.call_file_check, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    landing = PythonOperator(
        task_id="landing_" + str(file_master_id),
        python_callable=dagutils.call_landing, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    # pre_dqm = PythonOperator(
    #    task_id="pre_dqm_" + str(file_master_id),
    #    python_callable=dagutils.call_pre_dqm, provide_context=True,
    #    op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
    #    dag=dag)
    #
    # dqm = PythonOperator(
    #    task_id="dqm_" + str(file_master_id),
    #    python_callable=dagutils.call_dqm, provide_context=True,
    #    op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
    #    dag=dag)
    #
    # dqm_filter = PythonOperator(
    #    task_id="dqm_filter_" + str(file_master_id),
    #    python_callable=dagutils.call_dqm_filter, provide_context=True,
    #    op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
    #    dag=dag)

    publish = PythonOperator(
        task_id="publish_" + str(file_master_id),
        python_callable=dagutils.publish, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    archive = PythonOperator(
        task_id="archive_" + str(file_master_id),
        python_callable=dagutils.archive, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    update_catalog = PythonOperator(
        task_id="update_catalog_" + str(file_master_id),
        python_callable=dagutils.update_catalog_data, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    update_status = PythonOperator(
        task_id="update_status_" + str(file_master_id),
        python_callable=dagutils.call_staging, provide_context=True,
        op_kwargs={"file_master_id": file_master_id, "dag_name": DAG_NAME, "process_id": PROCESS_ID},
        dag=dag)

    # generate_lineage = PythonOperator(
    #    task_id="generate_lineage_" + str(file_master_id),
    #    python_callable=dagutils.get_dataset_lineage, provide_context=True,
    #    op_kwargs={"file_master_id": file_master_id,"dag_name": DAG_NAME},
    #    dag=dag)

    # Set task ordering
    pre_landing.set_upstream(emr_launch)
    file_check.set_upstream(pre_landing)
    landing.set_upstream(file_check)
    # pre_dqm.set_upstream(landing)
    # dqm.set_upstream(pre_dqm)
    # dqm_filter.set_upstream(dqm)
    publish.set_upstream(landing)
    archive.set_upstream(publish)

    update_catalog.set_upstream(archive)
    update_status.set_upstream(update_catalog)
    # update_status.set_upstream(update_catalog)
    # generate_lineage.set_upstream(update_status)
    # emr_terminate.set_upstream(update_status)
    end.set_upstream(update_status)

disable_fork_safety >> start
