###############################################################
###############################################################
####-       FILE NAME        : pap_dag_cleanup_history.py -####
####-       FILE CREATED     : 2022/08/01                 -####
####-       FILE LAST EDITED : 2023/11/14                 -####
####-       PROJECT NAME     : PAP                        -####
####-       AUTHOR           : Deloitte                   -####
###############################################################
###############################################################
import sys

sys.path.insert(0, "/usr/local/airflow/plugins/etlcore")
import datetime as dt
from airflow import DAG
from datetime import datetime, timedelta
import subprocess
import os
import ast
import urllib
import requests
import time
import random
from io import StringIO
import concurrent.futures
# cleanup level imports
import boto3
import pandas as pd
import yaml
from io import StringIO
from pathlib import Path
from datetime import datetime
from botocore.exceptions import ClientError

# Airflow level imports
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain
from airflow.configuration import conf as airflow_conf
import uuid
import pendulum
import json

# from airflow.decorators import task
from airflow.operators.python import task, get_current_context
from string import Template
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
from airflow.models import Variable

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

ENV_NAME = ''
try:
    region_name = os.environ['AWS_REGION']
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_role_secret = client.get_secret_value(SecretId='pap-secret-env-name')
    ENV_NAME = ast.literal_eval(get_role_secret['SecretString'])
except Exception as e:
    print("Error While Fetching secrets")
    raise e

CODE_ARTIFACTS_BUCKET = f"gilead-gna-hr-{ENV_NAME['name']}-us-west-2-code-artifacts"


class OrchestatorUtils():
    # def send_email(self, email):
        # for key in (
        # 'aws_region', 'sender', 'recipient_list', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            # if email.get(key) is None:
                # ValueError(f"Missing email parameter -{key}")

        # # Create a new SES resource and specify a region.
        # client = boto3.client('ses', region_name=email["aws_region"])
        # # Try to send the email.
        # try:
            # # Provide the contents of the email.
            # response = client.send_email(
                # Destination={
                    # 'ToAddresses': email["recipient_list"],
                # },
                # Message={
                    # 'Body': {
                        # 'Html': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_html"],
                        # },
                        # 'Text': {
                            # 'Charset': email["msg_charset"],
                            # 'Data': email["msg_body_text"],
                        # },
                    # },
                    # 'Subject': {
                        # 'Charset': email["msg_charset"],
                        # 'Data': email["msg_subject"],
                    # },
                # },
                # Source=email["sender"],
            # )
        # # Display an error if something goes wrong.
        # except ClientError as e:
            # print(e.response['Error']['Message'])
        # else:
            # print("Email sent! Message ID:"),
            # print(response['MessageId'])
    def send_email(self, email):
        for key in ('sender', 'msg_charset', 'msg_subject', 'msg_body_html', 'msg_body_text'):
            if email.get(key) is None:
                ValueError(f"Missing email parameter -{key}")

        try:
            # Provide the contents of the email.
            msg = MIMEMultipart('related')
            msg['Subject'] = email["msg_subject"]
            msg['From'] = email["sender"]
            msg['To'] = ','.join(email["recipient_list"])
            body = MIMEText(email["msg_body_html"], 'html')
            msg.attach(body)

            with smtplib.SMTP(app_config_yml['environment'].get("SMTP_SERVER"), 25) as server:
                server.send_message(msg)
                print("Successfully sent email")
                server.close()
        except (ClientError, Exception) as ex:
            print(ex)
            raise ex
        else:
            print(f"Email sent to: {str(email['recipient_list'])}")
        
    def log_batch_dtl(batch_config, audit_batch_record):
        """
        write audit batch log record to s3
        """
        s3_resource = boto3.resource('s3')
        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config['partition_key'] + '=' + \
                           audit_batch_record['batch_date'] + '/' + str(audit_batch_record["batch_name"]) + '_log.json'
        s3_object = s3_resource.Object(batch_bucket, batch_object_key)
        s3_object.put(Body=(bytes(json.dumps(audit_batch_record, default=str).encode('UTF-8'))))

    def init_log_batch_dtl(batch_config):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")
        audit_batch_record = {}
        # set the batch date
        if batch_config['override_flag'] == 'Y':
            audit_batch_record['batch_date'] = batch_config['batch_date']
        else:
            audit_batch_record['batch_date'] = pendulum.now().to_date_string()

        audit_batch_record['batch_id'] = str(uuid.uuid4())
        audit_batch_record['batch_name'] = 'PAP'
        audit_batch_record['status'] = 'RUNNING'
        audit_batch_record['st'] = pendulum.now().to_string()
        audit_batch_record['et'] = ''
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def finish_log_batch_dtl(batch_config, batch_date, batch_name):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")

        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config[
            'partition_key'] + '=' + batch_date + '/' + str(batch_name) + '_log.json'
        audit_batch_record = get_config(batch_bucket, batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status'] = 'FINISHED'
        audit_batch_record['et'] = pendulum.now()
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def fail_log_batch_ditl(batch_config, batch_date, batch_name, error_msg):
        for key in ('batch_date', 'override_flag', 'BATCH_LOGS_BUCKET', 'BATCH_LOGS_TABLE_PATH', 'partition_key'):
            if batch_config.get(key) is None:
                ValueError(f"Missing batch config parameter -{key}")

        batch_bucket = batch_config['BATCH_LOGS_BUCKET']
        batch_object_key = batch_config['BATCH_LOGS_TABLE_PATH'] + batch_config[
            'partition_key'] + '=' + batch_date + '/' + str(batch_name) + '_log.json'
        audit_batch_record = get_config(batch_bucket, batch_object_key)
        print(audit_batch_record)
        audit_batch_record['status'] = 'FAILED'
        audit_batch_record['et'] = pendulum.now()
        audit_batch_record['msg'] = 'error_msg'
        print(audit_batch_record)
        log_batch_dtl(batch_config, audit_batch_record)
        return audit_batch_record

    def get_config(self, bucket, object_key):
        s3_resource = boto3.resource('s3')
        try:
            obj = s3_resource.Object(bucket, object_key)
            content = (obj.get()['Body']).read().decode('utf-8')
            if content is None or len(content) == 0 or not content:
                ValueError('Missing configuration file')
            config = yaml.safe_load(content)
            return config
        except ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                ValueError("Config file does not exist or cannot be accessed!!!")
        except yaml.YAMLError as e:
            ValueError('Parsing YAML configuration file failed!!!')


orch_handle = OrchestatorUtils()
app_config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/app_config.yml")
config_yml = orch_handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/pap_dag_cleanup_history.yml")

# validation of all the keys in dag config yaml:
for key in (
'dag_id', 'owner', 'start_date', 'time_zone', 'load_type', 'schedule', 'tags', 'retries', 'concurrency', 'namespace',
'region_name', 'glue_iam_role', 'on_failure_callback', 'on_retry_callback'):
    if config_yml['dag'].get(key) is None:
        ValueError(f"Missing DAG config parameter -{key}")

DAG_NAME = config_yml['dag']['dag_id']
dag_tags = config_yml['dag']['tags']
release = 1


def clear_raw_landing():
    try:
        s3_client = boto3.client('s3')

        app_config = app_config_yml['environment']
        archive_location = app_config['RAW_HISTORY_FILES_LOCATION_KEY'] + str(Variable.get('ds_nodash')) + '/'
        source_file_bucket, source_file_key = app_config['RAW_BUCKET'], app_config['RAW_LANDING_KEY']

        try:
            objects = s3_client.list_objects(Bucket=source_file_bucket, Prefix=source_file_key)
            for obj in objects.get('Contents', []):
                source_key = obj['Key']
                print(source_key)
                target_key = source_key.replace(source_file_key, archive_location, 1)
                print(target_key)
                copy_source = {'Bucket': source_file_bucket, 'Key': source_key}
                copy_resp = s3_client.copy_object(CopySource=copy_source, Bucket=app_config['RAW_HISTORY_FILES_BUCKET'], Key=target_key)
                print(copy_resp['ResponseMetadata']['HTTPStatusCode'])
                if copy_resp['ResponseMetadata']['HTTPStatusCode']==200:
                    delete_resp = s3_client.delete_object(Bucket=source_file_bucket, Key=source_key)
                    print(delete_resp['ResponseMetadata']['HTTPStatusCode'])

            print(f"complete - All files move to archive location - s3://{app_config['RAW_HISTORY_FILES_BUCKET']}/{archive_location} ")

        except Exception as ex:
            print("ERROR: ", ex)
            raise Exception(ex)
    except Exception as ex:
        print("ERROR: ", ex)
        raise Exception(ex)


def clear_raw_pap():
    try:
        s3_client                           = boto3.client('s3')
        app_config                          = app_config_yml['environment']
        archive_location                    = app_config['RAW_HISTORY_FILES_LOCATION_KEY'] + str(Variable.get('ds_nodash')) + '/' \
                           + 'PAP/'
        print("archive_location = ", archive_location)
        source_file_bucket, source_file_key = app_config['RAW_BUCKET'], app_config['RAW_PAP_LANDING_KEY']
        print("source_file_bucket, source_file_key = ", source_file_bucket, source_file_key)

        try:
            objects = s3_client.list_objects(Bucket=source_file_bucket, Prefix=source_file_key)
            for obj in objects.get('Contents', []):
                source_key  = obj['Key']
                print(source_key)
                target_key  = source_key.replace(source_file_key, archive_location, 1)
                print(target_key)
                copy_source = {'Bucket': source_file_bucket, 'Key': source_key}
                copy_resp   = s3_client.copy_object(CopySource=copy_source, Bucket=app_config['RAW_HISTORY_FILES_BUCKET'], Key=target_key)
                print(copy_resp['ResponseMetadata']['HTTPStatusCode'])
                if copy_resp['ResponseMetadata']['HTTPStatusCode']==200:
                    delete_resp = s3_client.delete_object(Bucket=source_file_bucket, Key=source_key)
                    print(delete_resp['ResponseMetadata']['HTTPStatusCode'])

            print(f"complete - All files move to archive location - s3://{app_config['RAW_HISTORY_FILES_BUCKET']}/{archive_location} ")

        except Exception as ex:
            print("ERROR: ", ex)
            raise Exception(ex)
    except Exception as ex:
        print("ERROR: ", ex)
        raise Exception(ex)



def recon_validation_archiving():
    try:
        s3_client                           = boto3.client('s3')
        date_folder                         = int(Variable.get('ds_nodash'))-1
        app_config                          = app_config_yml['environment']
        archive_location                    = app_config['RAW_HISTORY_FILES_LOCATION_KEY'] + str(date_folder) + '/' + 'Validation_Files/'
        print("archive_location = ", archive_location)
        source_file_bucket, source_file_key = app_config['RAW_BUCKET'], app_config['RECON_VALIDATION_KEY']
        print("source_file_bucket, source_file_key = ", source_file_bucket, source_file_key)

        try:
            object_list     = s3_client.list_objects(Bucket=source_file_bucket, Prefix=source_file_key)
            file_key_pair   = {}    #MAKING A DICTIONARY WITH KEYS AS THE DATE AS THE KEY AND FILES OF THAT DATE AS THE VALUES
            for obj in object_list['Contents']:
                file_key = obj['Key']
                # print(file_key_pair)
                split_in = file_key.strip('/').split('_')
                # print(split_in)
                if len(split_in) > 1:
                    date_extract = split_in[-1].split('.')[0]
                    #print(date_extract)
                    if date_extract in file_key_pair:
                        file_key_pair[date_extract].append(file_key)
                    else:
                        file_key_pair[date_extract] = [file_key]
            latest_date = max(file_key_pair.keys())
            for date, files in file_key_pair.items():
                if date == latest_date:
                    print(f"Kept files for latest date {date} : {files}")
                else:
                    for files_key in files:
                        try:
                            target_key  = files_key.replace(source_file_key,archive_location,1)
                            copy_source = {'Bucket': source_file_bucket, 'Key': files_key}
                            copy_resp   = s3_client.copy_object(CopySource=copy_source, Bucket=app_config['RAW_HISTORY_FILES_BUCKET'], Key=target_key)
                            print(copy_resp['ResponseMetadata']['HTTPStatusCode'])
                            if copy_resp['ResponseMetadata']['HTTPStatusCode']==200:
                                delete_resp = s3_client.delete_object(Bucket=source_file_bucket, Key=files_key)
                                print(delete_resp['ResponseMetadata']['HTTPStatusCode'])
                        except Exception as ex:
                            print("ERROR: ", ex)
                            raise Exception(ex)
            print(f"complete - All files move to archive location - s3://{app_config['RAW_HISTORY_FILES_BUCKET']}/{archive_location} ")

        except Exception as ex:
            print("ERROR: ", ex)
            raise Exception(ex)
    except Exception as ex:
        print("ERROR: ", ex)
        raise Exception(ex)

def dag_start_send_email(**kwargs):
    print('inside start send email')
    handle = OrchestatorUtils()

    context = get_current_context()
    dict_email = {}
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'STARTED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
    handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_start_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_failure_send_email(context):
    print("IN dag_failure_send_email")
    handle = OrchestatorUtils()
    dag_id = context["dag"].dag_id
    task_id = context['task'].task_id
    execution_date = context["execution_date"].isoformat()
    dict_email = {}
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'FAILED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    dict_email['MESSAGE'] = ''
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
    email_template = \
    handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_failure_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_end_send_email(**kwargs):
    handle = OrchestatorUtils()
    context = get_current_context()
    dict_email = {}
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'COMPLETED'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = ''
    dag_id = context["dag"].dag_id
    execution_date = context["execution_date"].isoformat()
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/graph?dag_id={dag_id}&root=&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
    handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_complete_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


def dag_retry_send_email(context):
    handle = OrchestatorUtils()
    dict_email = {}
    dag_id = context["dag"].dag_id
    task_id = context['task'].task_id
    execution_date = context["execution_date"].isoformat()
    # parameterize env
    dict_email['ENV'] = ENV_NAME['name'].upper()
    dict_email['APPLICATION_NAME'] = config_yml['dag']['namespace']
    dict_email['PROCESS_NAME'] = str(context['dag_run'].dag_id)
    dict_email['PROCESS_RUN_ID'] = str(context['dag_run'].run_id)
    dict_email['PROCESS_RUN_TYPE'] = str(context['dag_run'].run_type)
    dict_email['PROCESS_RUN_STATE'] = 'RETRY'
    dict_email['BATCH_DATE'] = str(Variable.get('ds_nodash'))
    dict_email['EXECUTION_DATE'] = context.get('execution_date')
    dict_email['PROCESS_RUN_START_TIME'] = str(context['dag_run'].start_date)
    dict_email['PROCESS_RUN_END_TIME'] = str(context['dag_run'].end_date)
    dict_email['PROCESS_EXTERNAL_TRIGGER'] = str(context['dag_run'].external_trigger)
    # needs to be populated message and process url
    dict_email['MESSAGE'] = f'Task {task_id} has failed in dag {dag_id} and will now re-run.'
    dict_email[
        'PROCESS_URL'] = f"{airflow_conf.get('webserver', 'base_url')}/log?dag_id={dag_id}&task_id={task_id}&execution_date={urllib.parse.quote(execution_date)}"
    # parameterize email temp
    email_template = \
    handle.get_config(CODE_ARTIFACTS_BUCKET, "configuration/dags/email/dag_retry_send_email.yml")['templates'][0]
    print(email_template)
    enriched_email = Template(json.dumps(email_template)).safe_substitute(dict_email)
    print(enriched_email)
    handle.send_email(json.loads(enriched_email))


default_args = {
    "owner": config_yml['dag']['owner'],
    "start_date": pendulum.parse(config_yml['dag']['start_date'], tz=config_yml['dag']['time_zone']),
    "provide_context": True,
    "max_active_runs": config_yml['dag']['max_active_runs'],
    "on_retry_callback": getattr(sys.modules[__name__], config_yml['dag']['on_retry_callback'])
}

batch_dt = Variable.get('ds_nodash')
glue_iam_role = config_yml['dag']['glue_iam_role']
region_name = config_yml['dag']['region_name']
script_args = {
    '--config_bucket': app_config_yml['environment']['RAW_BUCKET'],
    '--batch_date': batch_dt
}

script_arg_mand_file_chk = {
    '--config_bucket': CODE_ARTIFACTS_BUCKET,
    '--batch_date': batch_dt,
    '--config': f"s3://{app_config_yml['environment'].get('CODE_ARTIFACTS_BUCKET')}/configuration/mandatoryfile_config.csv",
    '--folder_path': f"s3://{app_config_yml['environment'].get('RAW_BUCKET')}/landing/"
}

with DAG(
        dag_id=DAG_NAME,
        start_date=pendulum.datetime(2022, 12, 1, tz="America/Los_Angeles"),
        catchup=False,
        concurrency=config_yml['dag']['concurrency'],
        schedule_interval=None,
        tags=config_yml['dag']['tags'],
        default_args=default_args,
        on_failure_callback=dag_failure_send_email) as dag:
    start = PythonOperator(
        task_id="Start",
        python_callable=dag_start_send_email,
        provide_context=True,
    )
    end = PythonOperator(
        task_id="End",
        python_callable=dag_end_send_email,
        provide_context=True,
    )
    clear_raw_landing_history   = PythonOperator(task_id        ="pap-raw-cleanup-api",
                                                python_callable =clear_raw_landing,
                                                provide_context =True,
                                                dag             =dag)
    clear_raw_pap_history       = PythonOperator(task_id        ="pap-raw-recon-cleanup-api",
                                                python_callable =clear_raw_pap,
                                                provide_context =True,
                                                dag             =dag)
    clear_recon_val_history     = PythonOperator(task_id        ="pap-recon-validation-cleanup-api",
                                                python_callable =recon_validation_archiving,
                                                provide_context =True,
                                                dag             =dag)
start >> [clear_raw_landing_history , clear_raw_pap_history , clear_recon_val_history] >> end



#####################################################################################################################################
####-----------------------------------------------------------------------------------------------------------------------------####
####--------------------- $$$$$$  $$$    $$  $$$$          $$$$    $$$$$      $$$$$  $$$$$$   $$     $$$$$$ ---------------------####
####--------------------- $$      $$$$   $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$    $$ $$  $$  $$   $$      $$  $$   $$$$       $$$$     $$     $$     $$$$   ---------------------####
####--------------------- $$      $$  $$ $$  $$  $$       $$  $$   $$         $$       $$     $$     $$     ---------------------####
####--------------------- $$$$$$  $$   $$$$  $$$$          $$$$    $$         $$     $$$$$$   $$$$$  $$$$$$ ---------------------####
####-----------------------------------------------------------------------------------------------------------------------------####
#####################################################################################################################################