#!/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.
__AUTHOR__ = 'ZS Associates'

import os
import sys
import traceback
from CommonUtils import CommonUtils
import CommonConstants as CommonConstants
from MySQLConnectionManager import MySQLConnectionManager
from ExecutionContext import ExecutionContext
from ConfigUtility import JsonConfigUtility
from GlueCrawler import GlueCrawler
from LogSetup import logger
from FileTransferUtility import FileTransferUtility
from awsglue.utils import getResolvedOptions

sys.path.insert(0, os.getcwd())

MODULE_NAME = "PublishDWHandler"

"""
Module Name         :   PublishDWHandler
Purpose             :   This module will be used for publishing data as part of DW Step
Input Parameters    :   process id, frequency, data date, cycle id
Output Value        :   None
Pre-requisites      :   None
Last changed on     :   02-07-2018
Last changed by     :   Sushant Choudhary
Reason for change   :   DW Publish Development
"""


class PublishDWHandler(object):
    def __init__(self, parent_execution_context=None):
        args = getResolvedOptions(sys.argv,
                                  ['process_id', 'frequency', 'data_date','cycle_id'])
        self.process_id = args["process_id"]
        self.frequency = args["frequency"]
        self.data_date = args["data_date"]
        self.cycle_id = args["cycle_id"]

        self.step_name = None
        if (os.path.exists(CommonConstants.AIRFLOW_CODE_PATH)):
            self.configuration = JsonConfigUtility(CommonConstants.AIRFLOW_CODE_PATH + '/' +
                                                   CommonConstants.ENVIRONMENT_CONFIG_FILE)
        else:
            self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
        self.audit_db = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])

        if parent_execution_context is None:
            self.execution_context = ExecutionContext()
        else:
            self.execution_context = parent_execution_context
        self.execution_context.set_context({"module_name": MODULE_NAME})
        self.execution_context.set_context({"process_id": self.process_id})
        self.execution_context.set_context({"frequency": self.frequency})
        self.execution_context.set_context({"data_date": self.data_date})
        self.execution_context.set_context({"cycle_id": self.cycle_id})

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def publish_data_handler(self):
        """
            Purpose :   Driver handler method for calling helper functions required for publish copy
            Input   :   NA
            Output  :   NA
        """
        try:
            status_message = "Starting publish step for process_id:" + str(self.process_id) + " " \
                             + "and frequency:" + self.frequency + " " + "and data_date:" + str(self.data_date) \
                             + " " + "and cycle id:" + str(self.cycle_id)
            logger.info(status_message, extra=self.execution_context.get_context())
            self.step_name = CommonConstants.PUBLISH_STEP
            self.execution_context.set_context({"step_name": self.step_name})
            CommonUtils(self.execution_context).create_step_audit_entry(self.process_id, self.frequency, self.step_name,
                                                  self.data_date,
                                                  self.cycle_id)
            status_message = "Started preparing query to fetch target table details to be published for process_id:" \
                             + str(self.process_id) + " " + "and frequency:" + str(self.frequency) + \
                             " " + "and data_date:" + str(self.data_date) + " " + "and cycle id:" + str(self.cycle_id)
            logger.info(status_message, extra=self.execution_context.get_context())
            fetch_publish_table_details_query = "Select {dataset_table}.dataset_id,table_s3_path,publish_s3_path, " \
                                                "publish_type from {audit_db}.{process_dependency_master_table} " \
                                                "INNER JOIN {audit_db}.{dataset_table} ON {dataset_table}.dataset_id=" \
                                                "{process_dependency_master_table}.dataset_id where " \
                                                "process_id={process_id}  and frequency='{frequency}' and " \
                                                "{process_dependency_master_table}.table_type='{table_type}' and " \
                                                "dataset_publish_flag='{publish_flag_value}'"\
                .format(
                audit_db=self.audit_db, process_dependency_master_table=CommonConstants.PROCESS_DEPENDENCY_MASTER_TABLE,
                dataset_table=CommonConstants.DATASOURCE_INFORMATION_TABLE_NAME, process_id=self.process_id,
                frequency=self.frequency, table_type=CommonConstants.TARGET_TABLE_TYPE,
                publish_flag_value=CommonConstants.ACTIVE_IND_VALUE
            )
            logger.info(fetch_publish_table_details_query, extra=self.execution_context.get_context())
            publish_table_resultset = MySQLConnectionManager(self.execution_context).execute_query_mysql\
                (fetch_publish_table_details_query)
            status_message = "Completed query to fetch target table details to be published for process_id:" \
                             + str(self.process_id) + " " + "and frequency:" + str(self.frequency) + \
                             " " + "and data_date:" + str(self.data_date) + " " + "and cycle id:" + str(self.cycle_id)
            logger.info(status_message, extra=self.execution_context.get_context())
            logger.info(publish_table_resultset, extra=self.execution_context.get_context())
            if publish_table_resultset:
                status_message = "starting to create views for cycle id {cycle_id} and process id {process_id}".format(
                    cycle_id=str(self.cycle_id),
                    process_id=str(self.process_id)
                )
                logger.info(status_message, extra=self.execution_context.get_context())
                for table_details in publish_table_resultset:
                    status_message = "Dataset result dict:" + str(table_details)
                    logger.info(status_message, extra=self.execution_context.get_context())
                    dataset_id = table_details['dataset_id']
                    self.execution_context.set_context({"dataset_id": dataset_id})
                    table_source_path = table_details['table_s3_path']
                    table_publish_path = table_details['publish_s3_path']
                    table_publish_type = table_details['publish_type']
                    self.validate_dataset_details(dataset_id, table_source_path, table_publish_path)
                    status_message = "Dataset id is:" + str(dataset_id)
                    logger.info(status_message, extra=self.execution_context.get_context())
                    if table_publish_type is None or table_publish_type == CommonConstants.FULL_LOAD_TYPE or table_publish_type == CommonConstants.LATEST_LOAD_TYPE:
                        # code started to create table on glue if not exist else refresh
                        logger.info("starting to refresh dw publish views in glue metastore for dataset id {dataset_id}".format(dataset_id=str(dataset_id)))
                        crawler_obj=GlueCrawler(process_id=self.process_id,dataset_id=dataset_id,step="publish_dw",cycle_id=self.cycle_id)
                        crawler_obj.get_table_details()
                        logger.info("glue table updated for dataset_id {dataset_id}".format(dataset_id=str(dataset_id)))
                        # code ended to create table on glue if not exist else refresh
                    else:
                        status_message = "Publish type is incorrectly configured for dataset_id:" + str(dataset_id)
                        logger.error(status_message, extra=self.execution_context.get_context())
                        raise Exception(status_message)

            else:
                status_message = "There are no datasets to publish for process_id:" + str(self.process_id) + " " \
                                 + "and frequency:" + self.frequency + " " + "and data_date:" + str(self.data_date) \
                                 + " " + "cycle id:" + str(self.cycle_id)
                logger.warn(status_message, extra=self.execution_context.get_context())
            status = CommonConstants.STATUS_SUCCEEDED
        except Exception as exception:
            status = CommonConstants.STATUS_FAILED
            status_message = "Exception in publish data step for process_id:" + str(self.process_id) + " " \
                             + "and frequency:" + self.frequency + " " + "and data_date:" + str(self.data_date) \
                             + " " + "and cycle id:" + str(self.cycle_id)
            error = "ERROR in " + self.execution_context.get_context_param("current_module") + \
                    " ERROR MESSAGE: " + str(traceback.format_exc())
            self.execution_context.set_context({"traceback": error})
            logger.error(status_message, extra=self.execution_context.get_context())
            raise exception
        finally:
            CommonUtils(self.execution_context).update_step_audit_entry(self.process_id, self.frequency,
                                                                        self.step_name, self.data_date,
                                                  self.cycle_id, status)
            if status == CommonConstants.STATUS_FAILED:
                CommonUtils(self.execution_context).update_cycle_audit_entry(self.process_id, self.frequency, self.data_date,
                                                            self.cycle_id, status)
            status_message = "Completed publish data step for process_id:" + str(self.process_id) + " " \
                             + "and frequency:" + self.frequency + " " + "and data_date:" + str(self.data_date) \
                             + " " + "and cycle id:" + str(self.cycle_id)
            logger.info(status_message, extra=self.execution_context.get_context())

    def validate_dataset_details(self, dataset_id, table_source_path, table_publish_path):
        """
            Purpose :   This method invokes validates dataset related attributes
            Input   :   Dataset Id, Table Source Path, Table Publish Path
            Output  :   NA
        """
        if table_source_path is None:
            status_message = "Table source path is not provided for dataset_id:" + str(dataset_id)
            logger.error(status_message, extra=self.execution_context.get_context())
            raise Exception(status_message)
        if table_publish_path is None:
            status_message = "Publish path is not provided for dataset_id:" + str(dataset_id)
            logger.error(status_message, extra=self.execution_context.get_context())
            raise Exception(status_message)



if __name__ == '__main__':
    try:

        PUBLISH_HANDLER = PublishDWHandler()
        PUBLISH_HANDLER.publish_data_handler()
        STATUS_MESSAGE = "Completed execution for PublishDWHandler"
        sys.stdout.write(STATUS_MESSAGE)
    except Exception as exception:
        raise exception

