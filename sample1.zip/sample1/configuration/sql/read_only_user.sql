CREATE USER gnahr_read WITH PASSWORD ''; --Update Password here
GRANT USAGE ON SCHEMA gna_load_schema TO gnahr_read;
GRANT SELECT ON ALL TABLES IN SCHEMA gna_load_schema TO gnahr_read;
GRANT USAGE ON SCHEMA pap_view_schema TO gnahr_read;
GRANT SELECT ON ALL TABLES IN SCHEMA pap_view_schema TO gnahr_read;