-- DROP SCHEMA gna_load_schema;

CREATE SCHEMA gna_load_schema;
-- gna_load_schema.dim_age_band definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_age_band;

--DROP TABLE gna_load_schema.dim_age_band;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_age_band
(
	age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_code VARCHAR(300)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,band_min_months NUMERIC(15,5)   ENCODE az64
	,band_max_months NUMERIC(15,5)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sort_age_band_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_age_band owner to dbadmin;


-- gna_load_schema.dim_award_plan definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_award_plan;

--DROP TABLE gna_load_schema.dim_award_plan;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_award_plan
(
	award_plan_key NUMERIC(10,0)   ENCODE az64
	,plan_id VARCHAR(765)   ENCODE lzo
	,plan_name VARCHAR(765)   ENCODE lzo
	,plan_desc VARCHAR(765)   ENCODE lzo
	,plan_type VARCHAR(765)   ENCODE lzo
	,currency_cd VARCHAR(9)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hist_integration_id VARCHAR(240)   ENCODE lzo
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_award_plan owner to dbadmin;


-- gna_load_schema.dim_budget definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_budget;

--DROP TABLE gna_load_schema.dim_budget;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_budget
(
	budget_key NUMERIC(10,0)   ENCODE az64
	,budget_name VARCHAR(765)   ENCODE lzo
	,budget_desc VARCHAR(765)   ENCODE lzo
	,budget_status VARCHAR(765)   ENCODE lzo
	,budget_status_name VARCHAR(765)   ENCODE lzo
	,budget_type VARCHAR(765)   ENCODE lzo
	,budget_type_name VARCHAR(765)   ENCODE lzo
	,budget_class_code VARCHAR(300)   ENCODE lzo
	,budget_class_name VARCHAR(765)   ENCODE lzo
	,first_budget_period VARCHAR(90)   ENCODE lzo
	,start_date_active TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,end_date_active TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,baseline_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,budget_version VARCHAR(300)   ENCODE lzo
	,application_source VARCHAR(765)   ENCODE lzo
	,version_type_code VARCHAR(300)   ENCODE lzo
	,version_type_name VARCHAR(765)   ENCODE lzo
	,fin_plan_level_code VARCHAR(300)   ENCODE lzo
	,fin_plan_level_name VARCHAR(765)   ENCODE lzo
	,w_time_phased_code VARCHAR(300)   ENCODE lzo
	,w_time_phased_name VARCHAR(765)   ENCODE lzo
	,change_reason_code VARCHAR(300)   ENCODE lzo
	,change_reason_name VARCHAR(765)   ENCODE lzo
	,current_version_flg VARCHAR(3)   ENCODE lzo
	,current_original_version_flg VARCHAR(3)   ENCODE lzo
	,approved_cost_plan_type_flg VARCHAR(3)   ENCODE lzo
	,approved_rev_plan_type_flg VARCHAR(3)   ENCODE lzo
	,primary_cost_forecast_flg VARCHAR(3)   ENCODE lzo
	,primary_rev_forecast_flg VARCHAR(3)   ENCODE lzo
	,last_amt_gen_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,forecast_plan_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,etc_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hist_integration_id VARCHAR(240)   ENCODE lzo
	,hashdiff VARCHAR(600)   ENCODE lzo
	,src_w_update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_budget owner to dbadmin;


-- gna_load_schema.dim_calendar definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_calendar;

--DROP TABLE gna_load_schema.dim_calendar;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_calendar
(
	cal_date_key NUMERIC(19,0)   ENCODE az64
	,month_key NUMERIC(10,0)   ENCODE az64
	,calendar_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,julian_date NUMERIC(10,0)   ENCODE az64
	,day_num_of_week SMALLINT   ENCODE az64
	,day_num_of_month SMALLINT   ENCODE az64
	,day_num_of_quarter SMALLINT   ENCODE az64
	,day_num_of_year SMALLINT   ENCODE az64
	,day_of_week_name VARCHAR(90)   ENCODE lzo
	,is_weekday VARCHAR(3)   ENCODE lzo
	,julian_day_num_of_year NUMERIC(10,0)   ENCODE az64
	,day_num SMALLINT   ENCODE az64
	,week_num SMALLINT   ENCODE az64
	,month_num SMALLINT   ENCODE az64
	,quarter_num SMALLINT   ENCODE az64
	,year_num SMALLINT   ENCODE az64
	,is_last_day_of_week VARCHAR(3)   ENCODE lzo
	,is_last_day_of_month VARCHAR(3)   ENCODE lzo
	,is_last_day_of_quarter VARCHAR(3)   ENCODE lzo
	,is_last_day_of_year VARCHAR(3)   ENCODE lzo
	,is_first_day_of_week VARCHAR(3)   ENCODE lzo
	,is_first_day_of_month VARCHAR(3)   ENCODE lzo
	,is_first_day_of_quarter VARCHAR(3)   ENCODE lzo
	,is_first_day_of_year VARCHAR(3)   ENCODE lzo
	,week_begin_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,week_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,week_num_of_month SMALLINT   ENCODE az64
	,week_num_of_quarter SMALLINT   ENCODE az64
	,week_num_of_year SMALLINT   ENCODE az64
	,month_num_of_year SMALLINT   ENCODE az64
	,month_name VARCHAR(90)   ENCODE lzo
	,month_name_caps VARCHAR(90)   ENCODE lzo
	,month_name_abbreviation VARCHAR(90)   ENCODE lzo
	,month_name_abbreviation_caps VARCHAR(90)   ENCODE lzo
	,month_begin_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,month_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,qtr_key NUMERIC(10,0)   ENCODE az64
	,year_key NUMERIC(10,0)   ENCODE az64
	,quarter_num_of_year SMALLINT   ENCODE az64
	,quarter_begin_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,quarter_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,per_name_half VARCHAR(150)   ENCODE lzo
	,per_name_month VARCHAR(150)   ENCODE lzo
	,per_name_qtr VARCHAR(150)   ENCODE lzo
	,per_name_ter VARCHAR(150)   ENCODE lzo
	,per_name_year VARCHAR(150)   ENCODE lzo
	,year_begin_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,year_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,weekday_num_of_month NUMERIC(10,0)   ENCODE az64
	,weekday_num_of_quarter NUMERIC(10,0)   ENCODE az64
	,current_week_ind NUMERIC(10,0)   ENCODE az64
	,current_month_ind NUMERIC(10,0)   ENCODE az64
	,current_qtr_ind NUMERIC(10,0)   ENCODE az64
	,current_year_ind NUMERIC(10,0)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key VARCHAR(30)   ENCODE lzo
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,day_ago_key NUMERIC(10,0)   ENCODE az64
	,current_day_ind NUMERIC(10,0)   ENCODE az64
	,year_number NUMERIC(10,0)   ENCODE az64
	,year_ago_key NUMERIC(38,10)   ENCODE az64
	,qtr_ago_key NUMERIC(38,10)   ENCODE az64
	,mnth_ago_key NUMERIC(38,10)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_calendar owner to dbadmin;


-- gna_load_schema.dim_cost_center_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_cost_center_hier;

--DROP TABLE gna_load_schema.dim_cost_center_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_cost_center_hier
(
	cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_nodeval VARCHAR(240)   ENCODE lzo
	,cc_nodename VARCHAR(240)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE lzo
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,level6_desc VARCHAR(720)   ENCODE lzo
	,level6_val VARCHAR(720)   ENCODE lzo
	,level7_desc VARCHAR(720)   ENCODE lzo
	,level7_val VARCHAR(720)   ENCODE lzo
	,cc_desc VARCHAR(720)   ENCODE lzo
	,cc_legal_entity VARCHAR(720)   ENCODE lzo
	,cc_owner VARCHAR(720)   ENCODE lzo
	,functional_area VARCHAR(720)   ENCODE lzo
	,currency VARCHAR(720)   ENCODE lzo
	,product_link VARCHAR(720)   ENCODE lzo
	,market_associated VARCHAR(720)   ENCODE lzo
	,level8_val VARCHAR(720)   ENCODE lzo
	,level8_desc VARCHAR(720)   ENCODE lzo
	,hryid VARCHAR(720)   ENCODE lzo
	,active_flag VARCHAR(10)   ENCODE lzo
	,cc_master_name VARCHAR(720)   ENCODE lzo
	,effective_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,functional_area_desc VARCHAR(720)   ENCODE lzo
	,company VARCHAR(720)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_cost_center_hier owner to dbadmin;


-- gna_load_schema.dim_department definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_department;

--DROP TABLE gna_load_schema.dim_department;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_department
(
	dept_key NUMERIC(10,0)   ENCODE az64
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	,dept_desc VARCHAR(765)   ENCODE lzo
	,"type" VARCHAR(765)   ENCODE lzo
	,mgr_name VARCHAR(765)   ENCODE lzo
	,legal_entity VARCHAR(765)   ENCODE lzo
	,cost_center VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,hr_org_flg VARCHAR(3)   ENCODE lzo
	,workday_org_desc VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hist_integration_id VARCHAR(300)   ENCODE lzo
	,hashdiff VARCHAR(600)   ENCODE lzo
	,dept_owner VARCHAR(765)   ENCODE lzo
	,dept_owner_hris_id VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_department owner to dbadmin;


-- gna_load_schema.dim_department_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_department_hier;

--DROP TABLE gna_load_schema.dim_department_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_department_hier
(
	dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_owner VARCHAR(240)   ENCODE lzo
	,fpa_owner VARCHAR(240)   ENCODE lzo
	,dept_nodeval VARCHAR(240)   ENCODE lzo
	,dept_nodename VARCHAR(240)   ENCODE lzo
	,legal_entity VARCHAR(765)   ENCODE lzo
	,cost_center VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,func_area_code VARCHAR(300)   ENCODE lzo
	,func_area_name VARCHAR(765)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE lzo
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,level6_val VARCHAR(720)   ENCODE lzo
	,level6_desc VARCHAR(720)   ENCODE lzo
	,level7_val VARCHAR(720)   ENCODE lzo
	,level7_desc VARCHAR(720)   ENCODE lzo
	,level8_val VARCHAR(720)   ENCODE lzo
	,level8_desc VARCHAR(720)   ENCODE lzo
	,level9_val VARCHAR(720)   ENCODE lzo
	,level9_desc VARCHAR(720)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,hr_org_flg VARCHAR(3)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_department_hier owner to dbadmin;


-- gna_load_schema.dim_disposition_reasons definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_disposition_reasons;

--DROP TABLE gna_load_schema.dim_disposition_reasons;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_disposition_reasons
(
	disposition_rsn_key NUMERIC(10,0)   ENCODE az64
	,disposition_code VARCHAR(765)   ENCODE lzo
	,disposition_reason VARCHAR(1500)   ENCODE lzo
	,disposition_type VARCHAR(765)   ENCODE lzo
	,disposition_category VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_disposition_reasons owner to dbadmin;


-- gna_load_schema.dim_diversity_goals definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_diversity_goals;

--DROP TABLE gna_load_schema.dim_diversity_goals;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_diversity_goals
(
	category VARCHAR(765)   ENCODE lzo
	,goal NUMERIC(10,5)   ENCODE az64
	,kpi_category VARCHAR(765)   ENCODE lzo
	,"year" VARCHAR(765)   ENCODE lzo
	,yearly_increase_target VARCHAR(765)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,hashdiff VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,datasource_name VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_diversity_goals owner to dbadmin;


-- gna_load_schema.dim_emp_demographics definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_emp_demographics;

--DROP TABLE gna_load_schema.dim_emp_demographics;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_emp_demographics
(
	emp_demographic_key NUMERIC(10,0)   ENCODE az64
	,demographic_code VARCHAR(765)   ENCODE lzo
	,demographic_desc VARCHAR(765)   ENCODE lzo
	,demographic_type VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,demographic_desc_custom VARCHAR(765)   ENCODE lzo
	,demographic_desc_custom_sort NUMERIC(38,10)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_emp_demographics owner to dbadmin;


-- gna_load_schema.dim_employee_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_employee_hier;

--DROP TABLE gna_load_schema.dim_employee_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_employee_hier
(
	employee_hier_key NUMERIC(10,0)   ENCODE az64
	,member_full_name VARCHAR(765)   ENCODE lzo
	,member_key DOUBLE PRECISION   ENCODE RAW
	,ancestor_key DOUBLE PRECISION   ENCODE RAW
	,ancestor_full_name VARCHAR(765)   ENCODE lzo
	,distance NUMERIC(10,0)   ENCODE az64
	,is_leaf NUMERIC(10,0)   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(20,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_employee_hier owner to dbadmin;


-- gna_load_schema.dim_equity_cancelled definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_equity_cancelled;

--DROP TABLE gna_load_schema.dim_equity_cancelled;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_equity_cancelled
(
	participant_id VARCHAR(765)   ENCODE lzo
	,name_1 VARCHAR(765)   ENCODE lzo
	,number_1 VARCHAR(765)   ENCODE lzo
	,grant_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,plan_1 VARCHAR(765)   ENCODE lzo
	,cancel_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,cancel_reason VARCHAR(765)   ENCODE lzo
	,shares NUMERIC(10,0)   ENCODE az64
	,price NUMERIC(10,4)   ENCODE az64
	,total_price NUMERIC(15,4)   ENCODE az64
	,location_1 VARCHAR(765)   ENCODE lzo
	,grade VARCHAR(240)   ENCODE lzo
	,insider_status VARCHAR(765)   ENCODE lzo
	,title VARCHAR(765)   ENCODE lzo
	,pr_location VARCHAR(765)   ENCODE lzo
	,class_1 VARCHAR(765)   ENCODE lzo
	,grant_type VARCHAR(765)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(38,10)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_equity_cancelled owner to dbadmin;


-- gna_load_schema.dim_gl_account definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_gl_account;

--DROP TABLE gna_load_schema.dim_gl_account;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_gl_account
(
	gl_account_key NUMERIC(10,0)   ENCODE az64
	,gl_account_num VARCHAR(300)   ENCODE lzo
	,gl_account_name VARCHAR(765)   ENCODE lzo
	,gl_account_desc VARCHAR(765)   ENCODE lzo
	,gl_account_text VARCHAR(765)   ENCODE lzo
	,gl_account_cat_code VARCHAR(300)   ENCODE lzo
	,gl_account_cat_name VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,src_w_update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_gl_account owner to dbadmin;


-- gna_load_schema.dim_gl_departments_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_gl_departments_hier;

--DROP TABLE gna_load_schema.dim_gl_departments_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_gl_departments_hier
(
	dept_key NUMERIC(10,0)   ENCODE az64
	,parent VARCHAR(768)   ENCODE lzo
	,source_id VARCHAR(300)   ENCODE lzo
	,member VARCHAR(768)   ENCODE lzo
	,alias VARCHAR(768)   ENCODE lzo
	,dept_path VARCHAR(3000)   ENCODE lzo
	,dept_level NUMERIC(38,10)   ENCODE az64
	,dept_lvl_0_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_0_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_1_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_1_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_2_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_2_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_3_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_3_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_4_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_4_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_5_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_5_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_6_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_6_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_7_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_7_desc VARCHAR(768)   ENCODE lzo
	,dept_lvl_8_cd VARCHAR(768)   ENCODE lzo
	,dept_lvl_8_desc VARCHAR(768)   ENCODE lzo
	,data_source_name VARCHAR(30)   ENCODE lzo
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,active VARCHAR(30)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_gl_departments_hier owner to dbadmin;


-- gna_load_schema.dim_intl_assign definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_intl_assign;

--DROP TABLE gna_load_schema.dim_intl_assign;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_intl_assign
(
	intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_type_code VARCHAR(300)   ENCODE lzo
	,intl_assgn_type_name VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,home_host_class_code VARCHAR(300)   ENCODE lzo
	,home_host_class_name VARCHAR(300)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_intl_assign owner to dbadmin;


-- gna_load_schema.dim_job definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_job;

--DROP TABLE gna_load_schema.dim_job;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_job
(
	job_key NUMERIC(10,0)   ENCODE az64
	,job_code VARCHAR(300)   ENCODE lzo
	,job_name VARCHAR(765)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,job_family_code VARCHAR(300)   ENCODE lzo
	,job_family_name VARCHAR(765)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_level VARCHAR(300)   ENCODE lzo
	,flsa_stat_desc VARCHAR(765)   ENCODE lzo
	,hist_job_code VARCHAR(300)   ENCODE lzo
	,hist_job_name VARCHAR(765)   ENCODE lzo
	,hist_job_desc VARCHAR(765)   ENCODE lzo
	,hist_job_family_code VARCHAR(300)   ENCODE lzo
	,hist_job_family_name VARCHAR(765)   ENCODE lzo
	,hist_job_family_desc VARCHAR(765)   ENCODE lzo
	,hist_job_function_code VARCHAR(450)   ENCODE lzo
	,hist_job_function_name VARCHAR(765)   ENCODE lzo
	,hist_job_function_desc VARCHAR(765)   ENCODE lzo
	,hist_job_sub_func_code VARCHAR(765)   ENCODE lzo
	,hist_job_sub_func_name VARCHAR(450)   ENCODE lzo
	,hist_job_sub_func_desc VARCHAR(765)   ENCODE lzo
	,hist_job_level VARCHAR(300)   ENCODE lzo
	,hist_flsa_stat_desc VARCHAR(765)   ENCODE lzo
	,hist_integration_id VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,status VARCHAR(45)   ENCODE lzo
	,active_flg VARCHAR(90)   ENCODE lzo
	,job_family_group VARCHAR(750)   ENCODE lzo
	,start_dt_wid NUMERIC(10,0)   ENCODE az64
	,end_dt_wid NUMERIC(10,0)   ENCODE az64
	,scd2_active_flg VARCHAR(90)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_job owner to dbadmin;


-- gna_load_schema.dim_job_grade_salranges definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_job_grade_salranges;

--DROP TABLE gna_load_schema.dim_job_grade_salranges;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_job_grade_salranges
(
	job_grade_salranges_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_profile_id VARCHAR(240)   ENCODE lzo
	,job_code VARCHAR(240)   ENCODE lzo
	,base_salary_25th NUMERIC(15,5)   ENCODE az64
	,base_salary_50th NUMERIC(15,5)   ENCODE az64
	,base_salary_75th NUMERIC(15,5)   ENCODE az64
	,salary_midpoint NUMERIC(15,5)   ENCODE az64
	,sector_a_from NUMERIC(15,5)   ENCODE az64
	,sector_a_to NUMERIC(15,5)   ENCODE az64
	,sector_b_from NUMERIC(15,5)   ENCODE az64
	,sector_b_to NUMERIC(15,5)   ENCODE az64
	,sector_c_from NUMERIC(15,5)   ENCODE az64
	,sector_c_to NUMERIC(15,5)   ENCODE az64
	,structure_code VARCHAR(60)   ENCODE lzo
	,loc_curr_code VARCHAR(90)   ENCODE lzo
	,location_code VARCHAR(90)   ENCODE lzo
	,salary_plan_code VARCHAR(90)   ENCODE lzo
	,tier_code VARCHAR(15)   ENCODE lzo
	,baseline_effective_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,snapshot_dt_key NUMERIC(10,0)   ENCODE az64
	,comments VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hist_sal_admin_plan VARCHAR(12)   ENCODE lzo
	,hist_x_pay_grade INTEGER   ENCODE az64
	,hist_payline VARCHAR(195)   ENCODE lzo
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,job_family_group VARCHAR(1500)   ENCODE lzo
	,delete_flg VARCHAR(3)   ENCODE lzo
	,sector_2b_from NUMERIC(15,5)   ENCODE az64
	,sector_3b_from NUMERIC(15,5)   ENCODE az64
	,sector_1b_to NUMERIC(15,5)   ENCODE az64
	,sector_2b2_to NUMERIC(15,5)   ENCODE az64
	,sector_2b_to NUMERIC(15,5)   ENCODE az64
	,sector_3b_to NUMERIC(15,5)   ENCODE az64
	,start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_job_grade_salranges owner to dbadmin;


-- gna_load_schema.dim_learning_course_vw definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_learning_course_vw;

--DROP TABLE gna_load_schema.dim_learning_course_vw;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_learning_course_vw
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,course_flag VARCHAR(12000)   ENCODE lzo
	,complettion_date VARCHAR(12000)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_learning_course_vw owner to dbadmin;


-- gna_load_schema.dim_legal_entity_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_legal_entity_hier;

--DROP TABLE gna_load_schema.dim_legal_entity_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_legal_entity_hier
(
	le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_nodeval VARCHAR(240)   ENCODE lzo
	,le_nodename VARCHAR(240)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE lzo
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,level6_val VARCHAR(720)   ENCODE lzo
	,level6_desc VARCHAR(720)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,"location" VARCHAR(720)   ENCODE lzo
	,country VARCHAR(720)   ENCODE lzo
	,company VARCHAR(720)   ENCODE lzo
	,currency VARCHAR(720)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_legal_entity_hier owner to dbadmin;


-- gna_load_schema.dim_location_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_location_hier;

--DROP TABLE gna_load_schema.dim_location_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_location_hier
(
	loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_nodeval VARCHAR(240)   ENCODE lzo
	,loc_nodename VARCHAR(240)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE lzo
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,level6_val VARCHAR(720)   ENCODE lzo
	,level6_desc VARCHAR(720)   ENCODE lzo
	,level7_val VARCHAR(720)   ENCODE lzo
	,level7_desc VARCHAR(720)   ENCODE lzo
	,level8_val VARCHAR(720)   ENCODE lzo
	,level8_desc VARCHAR(720)   ENCODE lzo
	,level9_val VARCHAR(720)   ENCODE lzo
	,level9_desc VARCHAR(720)   ENCODE lzo
	,level10_val VARCHAR(720)   ENCODE lzo
	,level10_desc VARCHAR(720)   ENCODE lzo
	,level11_val VARCHAR(720)   ENCODE lzo
	,level11_desc VARCHAR(720)   ENCODE lzo
	,level12_val VARCHAR(720)   ENCODE lzo
	,level12_desc VARCHAR(720)   ENCODE lzo
	,level13_val VARCHAR(720)   ENCODE lzo
	,level13_desc VARCHAR(720)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,level1_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level2_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level3_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level4_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level5_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level6_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,level7_desc_no_mgr VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_location_hier owner to dbadmin;


-- gna_load_schema.dim_market_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_market_hier;

--DROP TABLE gna_load_schema.dim_market_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_market_hier
(
	mkt_hier_key NUMERIC(10,0)   ENCODE az64
	,mkt_node_val VARCHAR(240)   ENCODE lzo
	,mkt_node_name VARCHAR(240)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE lzo
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,indication_code VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_market_hier owner to dbadmin;


-- gna_load_schema.dim_misc_attributes definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_misc_attributes;

--DROP TABLE gna_load_schema.dim_misc_attributes;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_misc_attributes
(
	attribute_key NUMERIC(10,0)   ENCODE az64
	,attribute_type VARCHAR(765)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_misc_attributes owner to dbadmin;


-- gna_load_schema.dim_mobility_demographics definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_mobility_demographics;

--DROP TABLE gna_load_schema.dim_mobility_demographics;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_mobility_demographics
(
	demographics_key NUMERIC(10,0)   ENCODE az64
	,customer_id VARCHAR(240)   ENCODE lzo
	,company_name VARCHAR(765)   ENCODE lzo
	,division_name VARCHAR(765)   ENCODE lzo
	,department_name VARCHAR(765)   ENCODE lzo
	,file_num VARCHAR(765)   ENCODE lzo
	,employee_name VARCHAR(765)   ENCODE lzo
	,employee_email VARCHAR(765)   ENCODE lzo
	,authorization_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,candidate_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,requisition_key NUMERIC(10,0)   ENCODE az64
	,cost_center VARCHAR(765)   ENCODE lzo
	,department_code VARCHAR(765)   ENCODE lzo
	,gl_code VARCHAR(765)   ENCODE lzo
	,grade_level VARCHAR(765)   ENCODE lzo
	,legal_entity VARCHAR(765)   ENCODE lzo
	,location_code VARCHAR(765)   ENCODE lzo
	,product_number VARCHAR(765)   ENCODE lzo
	,purchase_ord_number VARCHAR(765)   ENCODE lzo
	,employment_type VARCHAR(765)   ENCODE lzo
	,move_type VARCHAR(765)   ENCODE lzo
	,relocation_type VARCHAR(765)   ENCODE lzo
	,policy_type VARCHAR(765)   ENCODE lzo
	,departure_work_city VARCHAR(765)   ENCODE lzo
	,departure_work_state VARCHAR(765)   ENCODE lzo
	,departure_work_country VARCHAR(765)   ENCODE lzo
	,destination_work_city VARCHAR(765)   ENCODE lzo
	,destination_work_state VARCHAR(765)   ENCODE lzo
	,destination_work_country VARCHAR(765)   ENCODE lzo
	,relocation_counselor VARCHAR(765)   ENCODE lzo
	,move_type_status VARCHAR(240)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,received_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(38,10)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,subsidy_type VARCHAR(765)   ENCODE lzo
	,subsidy_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,subsidy_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,total_subsidy_amount VARCHAR(765)   ENCODE lzo
	,worker_email VARCHAR(765)   ENCODE lzo
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,file_type VARCHAR(240)   ENCODE lzo
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,assignment_type VARCHAR(765)   ENCODE lzo
	,assignment_sub_type VARCHAR(765)   ENCODE lzo
	,worker_type VARCHAR(765)   ENCODE lzo
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,candidate_id VARCHAR(765)   ENCODE lzo
	,employee_id VARCHAR(765)   ENCODE lzo
	,requisition_num VARCHAR(765)   ENCODE lzo
	,worker_type_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_mobility_demographics owner to dbadmin;


-- gna_load_schema.dim_mobility_glaccount definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_mobility_glaccount;

--DROP TABLE gna_load_schema.dim_mobility_glaccount;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_mobility_glaccount
(
	acct_id NUMERIC(10,0)   ENCODE az64
	,acct_num VARCHAR(765)   ENCODE lzo
	,acct_desc VARCHAR(765)   ENCODE lzo
	,tax_status_usa VARCHAR(765)   ENCODE lzo
	,tax_status_cad VARCHAR(765)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num NUMERIC(10,0)   ENCODE az64
	,received_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(38,10)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,file_type VARCHAR(240)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_mobility_glaccount owner to dbadmin;


-- gna_load_schema.dim_mobility_servicescores definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_mobility_servicescores;

--DROP TABLE gna_load_schema.dim_mobility_servicescores;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_mobility_servicescores
(
	customer_id VARCHAR(765)   ENCODE lzo
	,customer_number VARCHAR(765)   ENCODE lzo
	,survey_key VARCHAR(3000)   ENCODE lzo
	,date_distributed TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,date_received TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_section VARCHAR(765)   ENCODE lzo
	,survey_question VARCHAR(3000)   ENCODE lzo
	,survey_question_answer VARCHAR(64512)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num NUMERIC(10,0)   ENCODE az64
	,received_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(38,10)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,question_id VARCHAR(765)   ENCODE lzo
	,file_type VARCHAR(240)   ENCODE lzo
						  
)
DISTSTYLE AUTO
 DISTKEY (survey_key)
;
ALTER TABLE gna_load_schema.dim_mobility_servicescores owner to dbadmin;


-- gna_load_schema.dim_numofdirects_vw definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_numofdirects_vw;

--DROP TABLE gna_load_schema.dim_numofdirects_vw;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_numofdirects_vw
(
	cal_date_key NUMERIC(19,0)   ENCODE az64
	,supervisor_key NUMERIC(20,0)   ENCODE az64
	,worker_id VARCHAR(300)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_numofdirects_vw owner to dbadmin;


-- gna_load_schema.dim_pay_grade definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_pay_grade;

--DROP TABLE gna_load_schema.dim_pay_grade;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_pay_grade
(
	pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_name VARCHAR(765)   ENCODE lzo
	,pay_grade_profile VARCHAR(240)   ENCODE lzo
	,payline_code VARCHAR(240)   ENCODE lzo
	,pg_max_yrly_amt NUMERIC(18,6)   ENCODE az64
	,pg_mid_yrly_amt NUMERIC(18,6)   ENCODE az64
	,pg_min_yrly_amt NUMERIC(18,6)   ENCODE az64
	,loc_curr_code VARCHAR(60)   ENCODE lzo
	,sal_admin_plan VARCHAR(750)   ENCODE lzo
	,psft_max_hrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_mid_hrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_min_hrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_max_mthly_amt NUMERIC(18,6)   ENCODE az64
	,psft_mid_mthly_amt NUMERIC(18,6)   ENCODE az64
	,psft_min_mthly_amt NUMERIC(18,6)   ENCODE az64
	,psft_max_yrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_mid_yrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_min_yrly_amt NUMERIC(18,6)   ENCODE az64
	,psft_pay_grade_name VARCHAR(750)   ENCODE lzo
	,psft_pay_grade_code VARCHAR(240)   ENCODE lzo
	,psft_pay_region_code VARCHAR(240)   ENCODE lzo
	,psft_pay_grade INTEGER   ENCODE az64
	,psft_source_id VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,pay_grade_group2 VARCHAR(600)   ENCODE lzo
	,pay_grade_group3 VARCHAR(600)   ENCODE lzo
	,country VARCHAR(765)   ENCODE lzo
	,segment_min_2 NUMERIC(18,6)   ENCODE az64
	,segment_min_3 NUMERIC(18,6)   ENCODE az64
	,segment_min_4 NUMERIC(18,6)   ENCODE az64
	,segment_min_5 NUMERIC(18,6)   ENCODE az64
	,start_dt_wid NUMERIC(10,0)   ENCODE az64
	,end_dt_wid NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_pay_grade owner to dbadmin;


-- gna_load_schema.dim_people_manager_vw definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_people_manager_vw;

--DROP TABLE gna_load_schema.dim_people_manager_vw;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_people_manager_vw
(
	supervisor_key NUMERIC(20,0)   ENCODE az64
	,reportee_key NUMERIC(20,0)   ENCODE az64
	,start_dt_wid VARCHAR(24)   ENCODE lzo
	,end_dt_wid VARCHAR(24)   ENCODE lzo
	,people_manager_flg VARCHAR(3)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_people_manager_vw owner to dbadmin;


-- gna_load_schema.dim_perf_band definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_perf_band;

--DROP TABLE gna_load_schema.dim_perf_band;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_perf_band
(
	perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_code VARCHAR(240)   ENCODE lzo
	,perf_band_desc VARCHAR(765)   ENCODE lzo
	,hist_perf_band_code VARCHAR(240)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,hist_source_id VARCHAR(240)   ENCODE lzo
	,hist_datasource_name VARCHAR(240)   ENCODE lzo
	,hist_datasource_num_id NUMERIC(10,5)   ENCODE az64
	,sort_perf_band_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_perf_band owner to dbadmin;


-- gna_load_schema.dim_position definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_position;

--DROP TABLE gna_load_schema.dim_position;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_position
(
	position_key NUMERIC(10,0)   ENCODE az64
	,position_desc VARCHAR(765)   ENCODE lzo
	,position_status VARCHAR(300)   ENCODE lzo
	,dept_id VARCHAR(300)   ENCODE lzo
	,job_posting_title VARCHAR(765)   ENCODE lzo
	,available_for_hire_flg VARCHAR(3)   ENCODE lzo
	,available_for_rcrt_flg VARCHAR(3)   ENCODE lzo
	,hiring_freeze_flg VARCHAR(3)   ENCODE lzo
	,availability_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,earliest_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_code VARCHAR(300)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,worker_type VARCHAR(765)   ENCODE lzo
	,time_type VARCHAR(765)   ENCODE lzo
	,worker_subtype VARCHAR(765)   ENCODE lzo
	,job_title VARCHAR(600)   ENCODE lzo
	,job_profile_summary VARCHAR(765)   ENCODE lzo
	,job_family_name VARCHAR(765)   ENCODE lzo
	,job_classification VARCHAR(9000)   ENCODE lzo
	,job_exempt_flg VARCHAR(3)   ENCODE lzo
	,company_insider_type VARCHAR(300)   ENCODE lzo
	,effective_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,entry_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,requsition_id VARCHAR(300)   ENCODE lzo
	,pay_grade_profile_id VARCHAR(300)   ENCODE lzo
	,supervisor_worker_id VARCHAR(300)   ENCODE lzo
	,budget_id VARCHAR(300)   ENCODE lzo
	,worker_id VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,position_reason VARCHAR(765)   ENCODE lzo
	,management_level VARCHAR(600)   ENCODE lzo
	,filled_by_worker VARCHAR(600)   ENCODE lzo
	,job_exempt_loc_context VARCHAR(600)   ENCODE lzo
	,pay_grade NUMERIC(10,0)   ENCODE az64
	,custom_position_reason VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_position owner to dbadmin;


-- gna_load_schema.dim_product_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_product_hier;

--DROP TABLE gna_load_schema.dim_product_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_product_hier
(
	prod_hier_key NUMERIC(10,0)   ENCODE az64
	,node_name VARCHAR(765)   ENCODE lzo
	,prod_value VARCHAR(765)   ENCODE lzo
	,level1_value VARCHAR(765)   ENCODE lzo
	,level1_desc VARCHAR(765)   ENCODE lzo
	,level2_value VARCHAR(765)   ENCODE lzo
	,level2_desc VARCHAR(765)   ENCODE lzo
	,level3_value VARCHAR(765)   ENCODE lzo
	,level3_desc VARCHAR(765)   ENCODE lzo
	,level4_value VARCHAR(765)   ENCODE lzo
	,level4_desc VARCHAR(765)   ENCODE lzo
	,level5_value VARCHAR(765)   ENCODE lzo
	,level5_desc VARCHAR(765)   ENCODE lzo
	,active_flg VARCHAR(3)   ENCODE lzo
	,indication_code VARCHAR(45)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,hryid VARCHAR(720)   ENCODE lzo
	,level6_value VARCHAR(765)   ENCODE lzo
	,level6_desc VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_product_hier owner to dbadmin;


-- gna_load_schema.dim_review_category definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_review_category;

--DROP TABLE gna_load_schema.dim_review_category;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_review_category
(
	rvw_cat_key NUMERIC(10,0)   ENCODE az64
	,rvw_type VARCHAR(240)   ENCODE lzo
	,rvw_cycle VARCHAR(240)   ENCODE lzo
	,rvw_cat VARCHAR(240)   ENCODE lzo
	,rvw_cat_desc VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_review_category owner to dbadmin;


-- gna_load_schema.dim_rqstn definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_rqstn;

--DROP TABLE gna_load_schema.dim_rqstn;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_rqstn
(
	rqstn_key NUMERIC(10,0)   ENCODE az64
	,rqstn_name VARCHAR(240)   ENCODE lzo
	,rqstn_desc VARCHAR(765)   ENCODE lzo
	,status_code VARCHAR(240)   ENCODE lzo
	,status_desc VARCHAR(765)   ENCODE lzo
	,category_code VARCHAR(240)   ENCODE lzo
	,category_desc VARCHAR(765)   ENCODE lzo
	,replacement_code VARCHAR(240)   ENCODE lzo
	,replacement_name VARCHAR(765)   ENCODE lzo
	,field_state VARCHAR(240)   ENCODE lzo
	,field_country VARCHAR(240)   ENCODE lzo
	,field_city VARCHAR(240)   ENCODE lzo
	,budget_id VARCHAR(240)   ENCODE lzo
	,jobseeker_id VARCHAR(240)   ENCODE lzo
	,js_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,field_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,eeo_code VARCHAR(240)   ENCODE lzo
	,aap_code VARCHAR(240)   ENCODE lzo
	,offr_acpt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_extd_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_rjct_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_cancelled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_opened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_rescinded_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_filled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_posting_title VARCHAR(600)   ENCODE lzo
	,rqstn_reopened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,rqstn_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_off_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,recruiter_first_name VARCHAR(750)   ENCODE lzo
	,recruiter_last_name VARCHAR(750)   ENCODE lzo
	,recruiter_worker_id VARCHAR(240)   ENCODE lzo
	,department VARCHAR(240)   ENCODE lzo
	,reporting_location VARCHAR(240)   ENCODE lzo
	,job_code VARCHAR(240)   ENCODE lzo
	,job_location VARCHAR(750)   ENCODE lzo
	,job_family VARCHAR(750)   ENCODE lzo
	,position_id VARCHAR(240)   ENCODE lzo
	,position_desc VARCHAR(750)   ENCODE lzo
	,position_type VARCHAR(240)   ENCODE lzo
	,grade_profile VARCHAR(240)   ENCODE lzo
	,census VARCHAR(240)   ENCODE lzo
	,exempt_nonexempt VARCHAR(750)   ENCODE lzo
	,fulltime_parttime VARCHAR(750)   ENCODE lzo
	,interest_category VARCHAR(750)   ENCODE lzo
	,area_of_interest VARCHAR(750)   ENCODE lzo
	,hiring_mgr_firstname VARCHAR(750)   ENCODE lzo
	,hiring_mgr_lastname VARCHAR(750)   ENCODE lzo
	,hiring_mgr_worker_id VARCHAR(240)   ENCODE lzo
	,job_hits VARCHAR(30)   ENCODE lzo
	,replacement_worker_id VARCHAR(240)   ENCODE lzo
	,worker_id VARCHAR(240)   ENCODE lzo
	,workertype VARCHAR(240)   ENCODE lzo
	,workersubtype VARCHAR(240)   ENCODE lzo
	,hist_source_id VARCHAR(240)   ENCODE lzo
	,hist_datasource_name VARCHAR(240)   ENCODE lzo
	,unapproved_reqs_flg VARCHAR(3)   ENCODE lzo
	,prv_dept_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,prv_pay_grade_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,prv_position_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,prv_job_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,prv_hm_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,primary_sourcer1 VARCHAR(765)   ENCODE lzo
	,primary_sourcer2 VARCHAR(765)   ENCODE lzo
	,primary_sourcer3 VARCHAR(765)   ENCODE lzo
	,primary_sourcer4 VARCHAR(765)   ENCODE lzo
	,primary_sourcer5 VARCHAR(765)   ENCODE lzo
	,primary_sourcer1_name VARCHAR(765)   ENCODE lzo
	,primary_sourcer2_name VARCHAR(765)   ENCODE lzo
	,primary_sourcer3_name VARCHAR(765)   ENCODE lzo
	,primary_sourcer4_name VARCHAR(765)   ENCODE lzo
	,primary_sourcer5_name VARCHAR(765)   ENCODE lzo
	,primary_recruiter VARCHAR(765)   ENCODE lzo
	,primary_coordinator1 VARCHAR(765)   ENCODE lzo
	,primary_coordinator2 VARCHAR(765)   ENCODE lzo
	,primary_coordinator3 VARCHAR(765)   ENCODE lzo
	,primary_coordinator4 VARCHAR(765)   ENCODE lzo
	,primary_coordinator5 VARCHAR(765)   ENCODE lzo
	,job_req_comments VARCHAR(765)   ENCODE lzo
	,job_req_comments_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_req_comments_author VARCHAR(765)   ENCODE lzo
	,primary_coordinator1_name VARCHAR(765)   ENCODE lzo
	,primary_coordinator2_name VARCHAR(765)   ENCODE lzo
	,primary_coordinator3_name VARCHAR(765)   ENCODE lzo
	,primary_coordinator4_name VARCHAR(765)   ENCODE lzo
	,primary_coordinator5_name VARCHAR(765)   ENCODE lzo
	,primary_recruiter_name VARCHAR(765)   ENCODE lzo
	,job_req_comments_author_name VARCHAR(765)   ENCODE lzo
	,job_req_tag1 VARCHAR(765)   ENCODE lzo
	,job_req_tag2 VARCHAR(765)   ENCODE lzo
	,job_req_tag3 VARCHAR(765)   ENCODE lzo
	,job_req_tag4 VARCHAR(765)   ENCODE lzo
	,job_req_tag5 VARCHAR(765)   ENCODE lzo
	,job_req_tag6 VARCHAR(765)   ENCODE lzo
	,job_req_tag7 VARCHAR(765)   ENCODE lzo
	,job_req_tag8 VARCHAR(765)   ENCODE lzo
	,job_req_tag9 VARCHAR(765)   ENCODE lzo
	,job_req_tag10 VARCHAR(765)   ENCODE lzo
	,job_req_functional_category VARCHAR(765)   ENCODE lzo
	,officetype VARCHAR(765)   ENCODE lzo
	,confidential_job VARCHAR(100)   ENCODE lzo
	,recruiting_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_rqstn owner to dbadmin;


-- gna_load_schema.dim_sec_gm_exception definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_sec_gm_exception;

--DROP TABLE gna_load_schema.dim_sec_gm_exception;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_sec_gm_exception
(
	login VARCHAR(765)   ENCODE lzo
	,employee_num VARCHAR(765)   ENCODE lzo
	,pref_full_name VARCHAR(765)   ENCODE lzo
	,dim_type VARCHAR(150)   ENCODE lzo
	,dim_id VARCHAR(765)   ENCODE lzo
	,dim_desc VARCHAR(765)   ENCODE lzo
	,dim_level VARCHAR(6)   ENCODE lzo
	,include_exclude VARCHAR(30)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_sec_gm_exception owner to dbadmin;


											   

			 

												

											   
															
 
									   
									  
									 
										
								   
									  
									 
											   
										   
											  
											
													  
											
													  
 
			  
 
															   


												 

			 

												  

												 
															  
 
									   
											   
									 
											
										
											   
									  
									 
											   
										   
											  
											
													  
											
													  
 
			  
 
																 


											  

			 

											   

											  
														   
 
									   
										  
									 
										
										 
									  
									 
											   
										   
											  
											
													  
											
													  
 
			  
 
															  


-- gna_load_schema.dim_sec_user_resp definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_sec_user_resp;

--DROP TABLE gna_load_schema.dim_sec_user_resp;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_sec_user_resp
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,role_name VARCHAR(750)   ENCODE lzo
	,worker_id VARCHAR(240)   ENCODE lzo
	,worker_login VARCHAR(300)   ENCODE lzo
	,dim_type VARCHAR(300)   ENCODE lzo
	,data_values VARCHAR(65535)   ENCODE lzo
	,record_type VARCHAR(300)   ENCODE lzo
	,record_order VARCHAR(300)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,worker_name VARCHAR(765)   ENCODE lzo
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_sec_user_resp owner to dbadmin;


-- gna_load_schema.dim_sec_user_resp_vw definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_sec_user_resp_vw;

--DROP TABLE gna_load_schema.dim_sec_user_resp_vw;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_sec_user_resp_vw
(
	role_name VARCHAR(750)   ENCODE lzo
	,worker_login VARCHAR(300)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_sec_user_resp_vw owner to dbadmin;


-- gna_load_schema.dim_service_band definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_service_band;

--DROP TABLE gna_load_schema.dim_service_band;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_service_band
(
	ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_code VARCHAR(765)   ENCODE lzo
	,ser_pow_band_desc VARCHAR(765)   ENCODE lzo
	,ser_band_min_months NUMERIC(15,5)   ENCODE az64
	,ser_band_max_months NUMERIC(15,5)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sort_ser_band_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_service_band owner to dbadmin;


-- gna_load_schema.dim_source definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_source;

--DROP TABLE gna_load_schema.dim_source;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_source
(
	datasource_num_id NUMERIC(10,0)   ENCODE az64
	,source_name VARCHAR(240)   ENCODE lzo
	,source_type VARCHAR(240)   ENCODE lzo
	,source_full_name VARCHAR(300)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_source owner to dbadmin;


-- gna_load_schema.dim_status definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_status;

--DROP TABLE gna_load_schema.dim_status;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_status
(
	status_key NUMERIC(10,0)   ENCODE az64
	,status_class_key NUMERIC(10,0)   ENCODE az64
	,status_class VARCHAR(765)   ENCODE lzo
	,status_code VARCHAR(765)   ENCODE lzo
	,status_name VARCHAR(765)   ENCODE lzo
	,status_desc VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_status owner to dbadmin;


-- gna_load_schema.dim_stock_price definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_stock_price;

--DROP TABLE gna_load_schema.dim_stock_price;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_stock_price
(
	stock_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,close_mkt_val NUMERIC(10,4)   ENCODE az64
	,col_comment VARCHAR(1500)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_stock_price owner to dbadmin;


-- gna_load_schema.dim_sup_hier_rcrt definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_sup_hier_rcrt;

--DROP TABLE gna_load_schema.dim_sup_hier_rcrt;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_sup_hier_rcrt
(
	sup_hier_rcrt_key NUMERIC(10,0)   ENCODE az64
	,level1_worker_id VARCHAR(300)   ENCODE lzo
	,level1_full_name VARCHAR(720)   ENCODE lzo
	,level1_title VARCHAR(720)   ENCODE lzo
	,level2_worker_id VARCHAR(300)   ENCODE lzo
	,level2_full_name VARCHAR(720)   ENCODE lzo
	,level2_title VARCHAR(720)   ENCODE lzo
	,level3_worker_id VARCHAR(300)   ENCODE lzo
	,level3_full_name VARCHAR(720)   ENCODE lzo
	,level3_title VARCHAR(720)   ENCODE lzo
	,level4_worker_id VARCHAR(300)   ENCODE lzo
	,level4_full_name VARCHAR(720)   ENCODE lzo
	,level4_title VARCHAR(720)   ENCODE lzo
	,level5_worker_id VARCHAR(300)   ENCODE lzo
	,level5_full_name VARCHAR(720)   ENCODE lzo
	,level5_title VARCHAR(720)   ENCODE lzo
	,level6_worker_id VARCHAR(300)   ENCODE lzo
	,level6_full_name VARCHAR(720)   ENCODE lzo
	,level6_title VARCHAR(720)   ENCODE lzo
	,level7_worker_id VARCHAR(300)   ENCODE lzo
	,level7_full_name VARCHAR(720)   ENCODE lzo
	,level7_title VARCHAR(720)   ENCODE lzo
	,level8_worker_id VARCHAR(300)   ENCODE lzo
	,level8_full_name VARCHAR(720)   ENCODE lzo
	,level8_title VARCHAR(720)   ENCODE lzo
	,level9_worker_id VARCHAR(300)   ENCODE lzo
	,level9_full_name VARCHAR(720)   ENCODE lzo
	,level9_title VARCHAR(720)   ENCODE lzo
	,level10_worker_id VARCHAR(300)   ENCODE lzo
	,level10_full_name VARCHAR(720)   ENCODE lzo
	,level10_title VARCHAR(720)   ENCODE lzo
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,file_rec_flg VARCHAR(3)   ENCODE lzo
	,missing_rec_flg VARCHAR(3)   ENCODE lzo
	,received_file_name VARCHAR(768)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_sup_hier_rcrt owner to dbadmin;


-- gna_load_schema.dim_supervisor_hier definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_supervisor_hier;

--DROP TABLE gna_load_schema.dim_supervisor_hier;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_supervisor_hier
(
	sup_hier_key NUMERIC(10,0)   ENCODE az64
	,base_worker_id VARCHAR(300)   ENCODE lzo
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,base_full_name VARCHAR(720)   ENCODE lzo
	,base_login VARCHAR(720)   ENCODE lzo
	,position_id VARCHAR(300)   ENCODE lzo
	,hierarchy_level NUMERIC(10,0)   ENCODE az64
	,leaf_node NUMERIC(10,0)   ENCODE az64
	,status VARCHAR(720)   ENCODE lzo
	,"type" VARCHAR(720)   ENCODE lzo
	,manager_worker_id VARCHAR(75)   ENCODE lzo
	,manager_full_name VARCHAR(720)   ENCODE lzo
	,manager_login VARCHAR(720)   ENCODE lzo
	,level1_emp_login VARCHAR(720)   ENCODE lzo
	,level1_emp_full_name VARCHAR(720)   ENCODE lzo
	,level1_position VARCHAR(720)   ENCODE lzo
	,level1_worker_id VARCHAR(720)   ENCODE lzo
	,level2_emp_login VARCHAR(720)   ENCODE lzo
	,level2_emp_full_name VARCHAR(720)   ENCODE lzo
	,level2_position VARCHAR(720)   ENCODE lzo
	,level2_worker_id VARCHAR(720)   ENCODE lzo
	,level3_emp_login VARCHAR(720)   ENCODE lzo
	,level3_emp_full_name VARCHAR(720)   ENCODE lzo
	,level3_position VARCHAR(720)   ENCODE lzo
	,level3_worker_id VARCHAR(720)   ENCODE lzo
	,level4_emp_login VARCHAR(720)   ENCODE lzo
	,level4_emp_full_name VARCHAR(720)   ENCODE lzo
	,level4_position VARCHAR(720)   ENCODE lzo
	,level4_worker_id VARCHAR(720)   ENCODE lzo
	,level5_emp_login VARCHAR(720)   ENCODE lzo
	,level5_emp_full_name VARCHAR(720)   ENCODE lzo
	,level5_position VARCHAR(720)   ENCODE lzo
	,level5_worker_id VARCHAR(720)   ENCODE lzo
	,level6_emp_login VARCHAR(720)   ENCODE lzo
	,level6_emp_full_name VARCHAR(720)   ENCODE lzo
	,level6_position VARCHAR(720)   ENCODE lzo
	,level6_worker_id VARCHAR(720)   ENCODE lzo
	,level7_emp_login VARCHAR(720)   ENCODE lzo
	,level7_emp_full_name VARCHAR(720)   ENCODE lzo
	,level7_position VARCHAR(720)   ENCODE lzo
	,level7_worker_id VARCHAR(720)   ENCODE lzo
	,level8_emp_login VARCHAR(720)   ENCODE lzo
	,level8_emp_full_name VARCHAR(720)   ENCODE lzo
	,level8_position VARCHAR(720)   ENCODE lzo
	,level8_worker_id VARCHAR(720)   ENCODE lzo
	,level9_emp_login VARCHAR(720)   ENCODE lzo
	,level9_emp_full_name VARCHAR(720)   ENCODE lzo
	,level9_position VARCHAR(720)   ENCODE lzo
	,level9_worker_id VARCHAR(720)   ENCODE lzo
	,level10_emp_login VARCHAR(720)   ENCODE lzo
	,level10_emp_full_name VARCHAR(720)   ENCODE lzo
	,level10_position VARCHAR(720)   ENCODE lzo
	,level10_worker_id VARCHAR(720)   ENCODE lzo
	,level11_emp_login VARCHAR(720)   ENCODE lzo
	,level11_emp_full_name VARCHAR(720)   ENCODE lzo
	,level11_position VARCHAR(720)   ENCODE lzo
	,level11_worker_id VARCHAR(720)   ENCODE lzo
	,current_level1_emp_login VARCHAR(720)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level1_position VARCHAR(720)   ENCODE lzo
	,current_level1_worker_id VARCHAR(720)   ENCODE lzo
	,current_level2_emp_login VARCHAR(720)   ENCODE lzo
	,current_level2_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level2_position VARCHAR(720)   ENCODE lzo
	,current_level2_worker_id VARCHAR(720)   ENCODE lzo
	,current_level3_emp_login VARCHAR(720)   ENCODE lzo
	,current_level3_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level3_position VARCHAR(720)   ENCODE lzo
	,current_level3_worker_id VARCHAR(720)   ENCODE lzo
	,current_level4_emp_login VARCHAR(720)   ENCODE lzo
	,current_level4_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level4_position VARCHAR(720)   ENCODE lzo
	,current_level4_worker_id VARCHAR(720)   ENCODE lzo
	,current_level5_emp_login VARCHAR(720)   ENCODE lzo
	,current_level5_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level5_position VARCHAR(720)   ENCODE lzo
	,current_level5_worker_id VARCHAR(720)   ENCODE lzo
	,current_level6_emp_login VARCHAR(720)   ENCODE lzo
	,current_level6_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level6_position VARCHAR(720)   ENCODE lzo
	,current_level6_worker_id VARCHAR(720)   ENCODE lzo
	,current_level7_emp_login VARCHAR(720)   ENCODE lzo
	,current_level7_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level7_position VARCHAR(720)   ENCODE lzo
	,current_level7_worker_id VARCHAR(720)   ENCODE lzo
	,current_level8_emp_login VARCHAR(720)   ENCODE lzo
	,current_level8_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level8_position VARCHAR(720)   ENCODE lzo
	,current_level8_worker_id VARCHAR(720)   ENCODE lzo
	,current_level9_emp_login VARCHAR(720)   ENCODE lzo
	,current_level9_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level9_position VARCHAR(720)   ENCODE lzo
	,current_level9_worker_id VARCHAR(720)   ENCODE lzo
	,current_level10_emp_login VARCHAR(720)   ENCODE lzo
	,current_level10_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level10_position VARCHAR(720)   ENCODE lzo
	,current_level10_worker_id VARCHAR(720)   ENCODE lzo
	,current_level11_emp_login VARCHAR(720)   ENCODE lzo
	,current_level11_emp_full_name VARCHAR(720)   ENCODE lzo
	,current_level11_position VARCHAR(720)   ENCODE lzo
	,current_level11_worker_id VARCHAR(720)   ENCODE lzo
	,current_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,reporting_level NUMERIC(10,0)   ENCODE az64
	,active_flg VARCHAR(6)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_supervisor_hier owner to dbadmin;


													  

			 

													   

													  
																   
 
										 
										  
 
			  
 
																	  


-- gna_load_schema.dim_survey_questions definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_survey_questions;

--DROP TABLE gna_load_schema.dim_survey_questions;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_survey_questions
(
	survey_key NUMERIC(10,0)   ENCODE az64
	,ques_cat_item_id VARCHAR(300)   ENCODE lzo
	,ques_cat_type VARCHAR(300)   ENCODE lzo
	,survey_type VARCHAR(300)   ENCODE lzo
	,survey_ques_short_descr VARCHAR(765)   ENCODE lzo
	,survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,psft_ques_cat_item_id VARCHAR(300)   ENCODE lzo
	,psft_ques_cat_type VARCHAR(300)   ENCODE lzo
	,psft_survey_type VARCHAR(300)   ENCODE lzo
	,psft_survey_ques_short_descr VARCHAR(765)   ENCODE lzo
	,psft_survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,psft_source_id VARCHAR(300)   ENCODE lzo
	,question_level VARCHAR(3)   ENCODE lzo
	,lvl3_survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,lvl2_survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,lvl1_survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,lvl3_survey_ques_short_descr VARCHAR(1200)   ENCODE lzo
	,lvl2_survey_ques_short_descr VARCHAR(1200)   ENCODE lzo
	,lvl1_survey_ques_short_descr VARCHAR(1200)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_survey_questions owner to dbadmin;


-- gna_load_schema.dim_term_theme definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_term_theme;

--DROP TABLE gna_load_schema.dim_term_theme;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_term_theme
(
	theme_key NUMERIC(38,10)   ENCODE az64
	,theme_level1 VARCHAR(12000)   ENCODE lzo
	,theme_level2 VARCHAR(12000)   ENCODE lzo
	,theme_level3 VARCHAR(12000)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_term_theme owner to dbadmin;


-- gna_load_schema.dim_upd_feedback_comm definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_upd_feedback_comm;

--DROP TABLE gna_load_schema.dim_upd_feedback_comm;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_upd_feedback_comm
(
	mgr_worker_key NUMERIC(20,0)   ENCODE az64
	,worker_key NUMERIC(20,0)   ENCODE az64
	,survey_ques_key NUMERIC(10,0)   ENCODE az64
	,survey_ques_ans VARCHAR(64512)   ENCODE lzo
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(12000)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(12000)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,mgr_worker_id VARCHAR(240)   ENCODE lzo
	,worker_id VARCHAR(240)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_upd_feedback_comm owner to dbadmin;


-- gna_load_schema.dim_upd_feedback_survey definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_upd_feedback_survey;

--DROP TABLE gna_load_schema.dim_upd_feedback_survey;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_upd_feedback_survey
(
	survey_ques_key NUMERIC(10,0)   ENCODE az64
	,survey_ques VARCHAR(12000)   ENCODE lzo
	,bus_survey_ques VARCHAR(12000)   ENCODE lzo
	,hashdiff VARCHAR(12000)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(12000)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sort_key NUMERIC(3,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_upd_feedback_survey owner to dbadmin;


-- gna_load_schema.dim_upward_feedback definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_upward_feedback;

--DROP TABLE gna_load_schema.dim_upward_feedback;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_upward_feedback
(
	survey_key NUMERIC(10,0)   ENCODE az64
	,survey_id VARCHAR(240)   ENCODE lzo
	,survey_name VARCHAR(240)   ENCODE lzo
	,survey_defn_id VARCHAR(240)   ENCODE lzo
	,survey_version NUMERIC(10,0)   ENCODE az64
	,survey_status VARCHAR(240)   ENCODE lzo
	,survey_status_descr VARCHAR(30)   ENCODE lzo
	,survey_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_due_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_close_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_upward_feedback owner to dbadmin;


-- gna_load_schema.dim_worker definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_worker;

--DROP TABLE gna_load_schema.dim_worker;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_worker
(
	worker_key NUMERIC(20,0)   ENCODE az64
	,employee_num VARCHAR(765)   ENCODE lzo
	,gnetid_worker_num VARCHAR(765)   ENCODE lzo
	,applicant_num VARCHAR(765)   ENCODE lzo
	,rqstn_num VARCHAR(765)   ENCODE lzo
	,applicant_flg VARCHAR(3)   ENCODE lzo
	,fst_name VARCHAR(765)   ENCODE lzo
	,mid_name VARCHAR(765)   ENCODE lzo
	,last_name VARCHAR(765)   ENCODE lzo
	,full_name VARCHAR(765)   ENCODE lzo
	,login VARCHAR(765)   ENCODE lzo
	,pref_full_name VARCHAR(765)   ENCODE lzo
	,pref_first_name VARCHAR(765)   ENCODE lzo
	,alt_name VARCHAR(765)   ENCODE lzo
	,job_title VARCHAR(765)   ENCODE lzo
	,religion_name VARCHAR(765)   ENCODE lzo
	,age NUMERIC(20,2)   ENCODE az64
	,marital_status VARCHAR(765)   ENCODE lzo
	,sex_code VARCHAR(765)   ENCODE lzo
	,sex_desc VARCHAR(765)   ENCODE lzo
	,emp_active_flg VARCHAR(3)   ENCODE lzo
	,emp_flg VARCHAR(3)   ENCODE lzo
	,emp_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,birth_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,country_of_birth VARCHAR(765)   ENCODE lzo
	,country_region VARCHAR(765)   ENCODE lzo
	,email_addr VARCHAR(765)   ENCODE lzo
	,orig_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ethnic_grp_desc VARCHAR(765)   ENCODE lzo
	,mobile_num VARCHAR(765)   ENCODE lzo
	,home_phone VARCHAR(765)   ENCODE lzo
	,home_address VARCHAR(765)   ENCODE lzo
	,work_address VARCHAR(765)   ENCODE lzo
	,office_ph_num VARCHAR(765)   ENCODE lzo
	,extn VARCHAR(450)   ENCODE lzo
	,position_id VARCHAR(765)   ENCODE lzo
	,department_code VARCHAR(765)   ENCODE lzo
	,department_name VARCHAR(765)   ENCODE lzo
	,effective_from_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,func_area_desc VARCHAR(765)   ENCODE lzo
	,func_area VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,room VARCHAR(765)   ENCODE lzo
	,floor VARCHAR(765)   ENCODE lzo
	,building VARCHAR(765)   ENCODE lzo
	,country VARCHAR(765)   ENCODE lzo
	,state_name VARCHAR(765)   ENCODE lzo
	,zipcode VARCHAR(765)   ENCODE lzo
	,work_duration_in_days NUMERIC(20,2)   ENCODE az64
	,work_duration_in_years NUMERIC(20,2)   ENCODE az64
	,work_auth_status VARCHAR(765)   ENCODE lzo
	,work_auth_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,work_auth_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,school_country VARCHAR(765)   ENCODE lzo
	,school_name VARCHAR(765)   ENCODE lzo
	,hiest_edu_deg_code VARCHAR(765)   ENCODE lzo
	,hiest_edu_deg_name VARCHAR(765)   ENCODE lzo
	,hiest_deg_attained_sch_loc VARCHAR(765)   ENCODE lzo
	,non_major_other_degrees VARCHAR(12000)   ENCODE lzo
	,major_other_degrees VARCHAR(765)   ENCODE lzo
	,school_other_degrees VARCHAR(765)   ENCODE lzo
	,school_loc_other_degrees VARCHAR(765)   ENCODE lzo
	,graduation_date_other_degrees VARCHAR(765)   ENCODE lzo
	,graduation_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,hiest_degree_major VARCHAR(765)   ENCODE lzo
	,visa_status VARCHAR(765)   ENCODE lzo
	,nationality VARCHAR(765)   ENCODE lzo
	,native_lang_name VARCHAR(765)   ENCODE lzo
	,other_languages VARCHAR(765)   ENCODE lzo
	,sec_flu_lang_name VARCHAR(765)   ENCODE lzo
	,assignment_num NUMERIC(20,0)   ENCODE az64
	,rehire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,contractor_to_hire_flg VARCHAR(3)   ENCODE lzo
	,anniversary_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,years_since_last_promotion NUMERIC(20,2)   ENCODE az64
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,relocation VARCHAR(765)   ENCODE lzo
	,pay_grade VARCHAR(765)   ENCODE lzo
	,job_code VARCHAR(765)   ENCODE lzo
	,worker_type VARCHAR(765)   ENCODE lzo
	,referrer VARCHAR(765)   ENCODE lzo
	,referrer_job_code VARCHAR(765)   ENCODE lzo
	,referrer_pay_grade VARCHAR(765)   ENCODE lzo
	,supervisor_flg VARCHAR(3)   ENCODE lzo
	,supervisor_key NUMERIC(20,0)   ENCODE az64
	,supervisor_num VARCHAR(765)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,supervisor_gender VARCHAR(765)   ENCODE lzo
	,supervisor_ethnicity VARCHAR(765)   ENCODE lzo
	,emp_manager_gender VARCHAR(765)   ENCODE lzo
	,prev_employer VARCHAR(765)   ENCODE lzo
	,prev_employer_job_title VARCHAR(765)   ENCODE lzo
	,prev_employer_ppl_mgr_status VARCHAR(765)   ENCODE lzo
	,prev_employer_location VARCHAR(765)   ENCODE lzo
	,last_promotion_date_1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_promotion_date_10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_insert_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_active_flg VARCHAR(30)   ENCODE lzo
	,awr_onsite_offsite VARCHAR(750)   ENCODE lzo
	,awr_pay_rate NUMERIC(20,5)   ENCODE az64
	,product_code VARCHAR(600)   ENCODE lzo
	,product_desc VARCHAR(765)   ENCODE lzo
	,awr_purchase_order_num VARCHAR(765)   ENCODE lzo
	,awr_purpose_of_engagement VARCHAR(765)   ENCODE lzo
	,awr_requistion_num VARCHAR(765)   ENCODE lzo
	,awr_security_bdg_access_num VARCHAR(750)   ENCODE lzo
	,awr_space_required_flg VARCHAR(750)   ENCODE lzo
	,awr_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_vendor_agency VARCHAR(765)   ENCODE lzo
	,awr_temp_assignment_length VARCHAR(765)   ENCODE lzo
	,awr_work_type VARCHAR(750)   ENCODE lzo
	,awr_multiple_times VARCHAR(765)   ENCODE lzo
	,awr_bill_rate NUMERIC(20,6)   ENCODE az64
	,awr_billing_currency VARCHAR(300)   ENCODE lzo
	,awr_extended_times NUMERIC(20,0)   ENCODE az64
	,awr_gilead_tenure NUMERIC(20,0)   ENCODE az64
	,awr_hours_per_week VARCHAR(540)   ENCODE lzo
	,awr_created_by_user VARCHAR(765)   ENCODE lzo
	,awr_deployed_to_site VARCHAR(750)   ENCODE lzo
	,awr_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,total_experience_in_years NUMERIC(30,0)   ENCODE az64
	,total_pharma_exp_years NUMERIC(30,0)   ENCODE az64
	,total_specific_role_exp_years NUMERIC(30,0)   ENCODE az64
	,tot_role_relevant_experience NUMERIC(30,0)   ENCODE az64
	,no_of_years_per_promotion NUMERIC(20,2)   ENCODE az64
	,days_since_last_promotion NUMERIC(20,2)   ENCODE az64
	,worker_perf_rating VARCHAR(765)   ENCODE lzo
	,field_employee_flg VARCHAR(300)   ENCODE lzo
	,last_date_worked TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(20,0)   ENCODE az64
	,source_id VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(20,0)   ENCODE az64
	,datasource_name VARCHAR(765)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(20,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(20,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hist_source_id VARCHAR(765)   ENCODE lzo
	,hist_employee_num VARCHAR(765)   ENCODE lzo
	,hist_contingent_employee_num VARCHAR(765)   ENCODE lzo
	,hist_applicant_num VARCHAR(765)   ENCODE lzo
	,hist_gnetid_worker_num VARCHAR(765)   ENCODE lzo
	,hiest_deg_attained VARCHAR(765)   ENCODE lzo
	,adjusted_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,race VARCHAR(765)   ENCODE lzo
	,candidate_type VARCHAR(765)   ENCODE lzo
	,source_type_name VARCHAR(765)   ENCODE lzo
	,acquisition_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rescind_status VARCHAR(765)   ENCODE lzo
	,veteran_status VARCHAR(765)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,home_city VARCHAR(765)   ENCODE lzo
	,payroll_status VARCHAR(765)   ENCODE lzo
	,leave_status VARCHAR(765)   ENCODE lzo
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,benefits_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,seniority_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,acquired_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,vms_security_id VARCHAR(765)   ENCODE lzo
	,work_order VARCHAR(765)   ENCODE lzo
	,task_name VARCHAR(765)   ENCODE lzo
	,hashdiff VARCHAR(765)   ENCODE lzo
	,degree_rank NUMERIC(20,0)   ENCODE az64
	,native_langname VARCHAR(600)   ENCODE lzo
	,adjusted_service_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,total_biopharma_exp_in_years NUMERIC(20,2)   ENCODE az64
	,total_spec_role_exp_in_years NUMERIC(20,2)   ENCODE az64
	,seniority_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,winner_worker_key NUMERIC(10,0)   ENCODE az64
	,vms_applicant_id VARCHAR(300)   ENCODE lzo
	,vms_worker_id VARCHAR(300)   ENCODE lzo
	,vms_person_id VARCHAR(300)   ENCODE lzo
	,vms_contr_on_multi_assgn VARCHAR(30)   ENCODE lzo
	,vms_days_on_site_per_wk NUMERIC(15,0)   ENCODE az64
	,vms_employee_to_contractor VARCHAR(30)   ENCODE lzo
	,vms_erp_access VARCHAR(30)   ENCODE lzo
	,vms_glearn_access VARCHAR(30)   ENCODE lzo
	,vms_gxp_access VARCHAR(30)   ENCODE lzo
	,vms_system_access VARCHAR(30)   ENCODE lzo
	,vms_billable_per_diem NUMERIC(15,0)   ENCODE az64
	,vms_buyer_code VARCHAR(240)   ENCODE lzo
	,vms_job_posting_owner VARCHAR(765)   ENCODE lzo
	,vms_rate_category VARCHAR(765)   ENCODE lzo
	,vms_remit_to_address_code VARCHAR(300)   ENCODE lzo
	,vms_site_code VARCHAR(300)   ENCODE lzo
	,vms_wo_original_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,vms_worker_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,vms_fte NUMERIC(15,2)   ENCODE az64
	,vms_vendor_number VARCHAR(75)   ENCODE lzo
	,vms_revision_owner VARCHAR(300)   ENCODE lzo
	,vms_revision_owner_emp_id VARCHAR(300)   ENCODE lzo
	,vms_category_type VARCHAR(300)   ENCODE lzo
	,task_code VARCHAR(300)   ENCODE lzo
	,buddy_id VARCHAR(240)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,worker_type_id VARCHAR(765)   ENCODE lzo
	,suggested_ethnicity VARCHAR(765)   ENCODE lzo
	,suggested_ethnicity_man VARCHAR(765)   ENCODE lzo
	,role_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,perf_band2 VARCHAR(300)   ENCODE lzo
	,perf_band3 VARCHAR(300)   ENCODE lzo
	,manager_rating1 VARCHAR(300)   ENCODE lzo
	,manager_rating2 VARCHAR(300)   ENCODE lzo
	,manager_rating3 VARCHAR(300)   ENCODE lzo
	,midyear_rating1 VARCHAR(300)   ENCODE lzo
	,midyear_rating2 VARCHAR(300)   ENCODE lzo
	,long_term_relocation_flg VARCHAR(3)   ENCODE lzo
	,long_term_relocation_areas VARCHAR(12000)   ENCODE lzo
	,short_term_relocation_flg VARCHAR(3)   ENCODE lzo
	,shor_term_relocation_areas VARCHAR(12000)   ENCODE lzo
	,relocation_addtnl_comments VARCHAR(12000)   ENCODE lzo
	,willing_to_travel_flg VARCHAR(5)   ENCODE lzo
	,travel_percent VARCHAR(300)   ENCODE lzo
	,travel_additional_information VARCHAR(12000)   ENCODE lzo
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,ethnic_group_custom_sort_order NUMERIC(5,0)   ENCODE az64
	,last_job_change_date1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_job_change_date10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,suggested_gender_manual VARCHAR(30)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_3 VARCHAR(6)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,key_performer_year_1 VARCHAR(3)   ENCODE lzo
	,key_performer_year_2 VARCHAR(3)   ENCODE lzo
	,key_performer_year_3 VARCHAR(3)   ENCODE lzo
	,legal_local_name VARCHAR(765)   ENCODE lzo
	,preferred_local_name VARCHAR(765)   ENCODE lzo
	,last_rehire_date6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,private_hire_ind VARCHAR(765)   ENCODE lzo
	,acq_comp_name VARCHAR(765)   ENCODE lzo
	,military_status VARCHAR(12000)   ENCODE lzo
	,military_status_1 VARCHAR(12000)   ENCODE lzo
	,military_status_2 VARCHAR(12000)   ENCODE lzo
	,military_status_3 VARCHAR(12000)   ENCODE lzo
	,military_status_4 VARCHAR(12000)   ENCODE lzo
	,military_status_5 VARCHAR(12000)   ENCODE lzo
	,military_status_6 VARCHAR(12000)   ENCODE lzo
	,military_status_7 VARCHAR(12000)   ENCODE lzo
	,military_status_8 VARCHAR(12000)   ENCODE lzo
	,military_status_9 VARCHAR(12000)   ENCODE lzo
	,military_status_10 VARCHAR(12000)   ENCODE lzo
	,curr_org_size NUMERIC(20,0)   ENCODE az64
	,curr_indirect_org NUMERIC(20,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_worker owner to dbadmin;


-- gna_load_schema.dim_worker_desk_loc definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_worker_desk_loc;

--DROP TABLE gna_load_schema.dim_worker_desk_loc;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_worker_desk_loc
(
	surr_key NUMERIC(20,0)   ENCODE az64
	,worker_key NUMERIC(20,0)   ENCODE az64
	,worker_id VARCHAR(765)   ENCODE lzo
	,building_nr VARCHAR(765)   ENCODE lzo
	,floor VARCHAR(765)   ENCODE lzo
	,space_1 VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(765)   ENCODE lzo
	,start_date_wid NUMERIC(10,0)   ENCODE az64
	,end_date_wid NUMERIC(10,0)   ENCODE az64
	,src_flag VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_worker_desk_loc owner to dbadmin;


-- gna_load_schema.dim_worker_ethnicity definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_worker_ethnicity;

--DROP TABLE gna_load_schema.dim_worker_ethnicity;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_worker_ethnicity
(
	surr_key NUMERIC(20,0)   ENCODE az64
	,worker_key NUMERIC(20,0)   ENCODE az64
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,start_dt_wid NUMERIC(10,0)   ENCODE az64
	,end_dt_wid NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_worker_ethnicity owner to dbadmin;


-- gna_load_schema.dim_worker_term_themes definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_worker_term_themes;

--DROP TABLE gna_load_schema.dim_worker_term_themes;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_worker_term_themes
(
	employee_id VARCHAR(12000)   ENCODE lzo
	,value NUMERIC(38,10)   ENCODE az64
	,theme_key NUMERIC(38,10)   ENCODE az64
	,worker_key NUMERIC(38,10)   ENCODE az64
	,term_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_worker_term_themes owner to dbadmin;


-- gna_load_schema.dim_worker_type definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_worker_type;

--DROP TABLE gna_load_schema.dim_worker_type;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_worker_type
(
	worker_type_key NUMERIC(10,0)   ENCODE az64
	,employee_type_code VARCHAR(240)   ENCODE lzo
	,employee_type_name VARCHAR(765)   ENCODE lzo
	,employment_sub_stat_code VARCHAR(240)   ENCODE lzo
	,employment_sub_stat_name VARCHAR(765)   ENCODE lzo
	,fullpart_time_code VARCHAR(240)   ENCODE lzo
	,fullpart_time_name VARCHAR(765)   ENCODE lzo
	,pay_cycle_code VARCHAR(240)   ENCODE lzo
	,pay_cycle_name VARCHAR(765)   ENCODE lzo
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,employee_cat_desc VARCHAR(765)   ENCODE lzo
	,employee_sub_cat_code VARCHAR(240)   ENCODE lzo
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,employment_stat_code VARCHAR(240)   ENCODE lzo
	,employment_stat_desc VARCHAR(765)   ENCODE lzo
	,assignment_type_code VARCHAR(765)   ENCODE lzo
	,active_flg VARCHAR(150)   ENCODE lzo
	,exempt_flg VARCHAR(150)   ENCODE lzo
	,full_time_flg VARCHAR(150)   ENCODE lzo
	,hourly_flg VARCHAR(150)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_worker_type owner to dbadmin;


-- gna_load_schema.dim_wrkfc_event_type definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_wrkfc_event_type;

--DROP TABLE gna_load_schema.dim_wrkfc_event_type;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_wrkfc_event_type
(
	wrkr_event_type_key NUMERIC(10,0)   ENCODE az64
	,business_process VARCHAR(600)   ENCODE lzo
	,event_reason_name VARCHAR(765)   ENCODE lzo
	,event_category VARCHAR(765)   ENCODE lzo
	,comments VARCHAR(750)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_wrkfc_event_type owner to dbadmin;


-- gna_load_schema.fact_award definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_award;

--DROP TABLE gna_load_schema.fact_award;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_award
(
	award_plan_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,award_dt_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,payout_prd_key NUMERIC(10,0)   ENCODE az64
	,award_tier_name VARCHAR(765)   ENCODE lzo
	,actual_awd_amt NUMERIC(18,6)   ENCODE az64
	,actual_awd_unit NUMERIC(10,0)   ENCODE az64
	,currency_cd VARCHAR(9)   ENCODE lzo
	,employment_key NUMERIC(10,0)   ENCODE az64
	,active_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(600)   ENCODE lzo
	,worker_id VARCHAR(240)   ENCODE lzo
	,award_id VARCHAR(240)   ENCODE lzo
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_award owner to dbadmin;


-- gna_load_schema.fact_awards_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_awards_denormalized;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_awards_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE RAW
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,plan_id VARCHAR(765)   ENCODE lzo
	,plan_name VARCHAR(765)   ENCODE lzo
	,actual_awd_amt NUMERIC(18,6)   ENCODE az64
	,actual_awd_unit NUMERIC(10,0)   ENCODE az64
	,award_id VARCHAR(240)   ENCODE lzo
	,award_tier_name VARCHAR(765)   ENCODE lzo
	,award_dt_key NUMERIC(10,0)   ENCODE az64
	,calendar_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE RAW
	,cal_date_key NUMERIC(19,0)   ENCODE az64
	,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE RAW
	,cc_level7_value VARCHAR(720)   ENCODE RAW
	,cost_center_level6_desc VARCHAR(720)   ENCODE lzo
	,cost_center_level2_desc VARCHAR(720)   ENCODE lzo
	,le_level1_val VARCHAR(720)   ENCODE RAW
	,le_level2_val VARCHAR(720)   ENCODE RAW
	,le_level3_val VARCHAR(720)   ENCODE RAW
	,le_level4_val VARCHAR(720)   ENCODE RAW
	,le_level5_val VARCHAR(720)   ENCODE RAW
	,le_level6_val VARCHAR(720)   ENCODE lzo
	,le_level6_desc VARCHAR(720)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_desc VARCHAR(765)   ENCODE lzo
	,location_code_level1 VARCHAR(720)   ENCODE RAW
	,location_code_level2 VARCHAR(720)   ENCODE RAW
	,location_code_level3 VARCHAR(720)   ENCODE RAW
	,location_code_level4 VARCHAR(720)   ENCODE RAW
	,location_code_level5 VARCHAR(720)   ENCODE RAW
	,location_code_level6 VARCHAR(720)   ENCODE RAW
	,location_code_level7 VARCHAR(720)   ENCODE RAW
	,location_code_level8 VARCHAR(720)   ENCODE RAW
	,location_code_level9 VARCHAR(720)   ENCODE RAW
	,location_code_level10 VARCHAR(720)   ENCODE RAW
	,location_code_level11 VARCHAR(720)   ENCODE RAW
	,location_code_level12 VARCHAR(720)   ENCODE RAW
	,location_code_level13 VARCHAR(720)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,last_promotion_date_1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,school_name VARCHAR(765)   ENCODE lzo
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,worker_id VARCHAR(765)   ENCODE lzo
	,worker_pref_name VARCHAR(765)   ENCODE lzo
	,login VARCHAR(765)   ENCODE lzo
	,sex_desc VARCHAR(765)   ENCODE lzo
	,emp_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,orig_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"location" VARCHAR(765)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,job_family_group VARCHAR(750)   ENCODE lzo
	,supervisor_id VARCHAR(765)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,full_time_flg VARCHAR(150)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,CURRENCY_CD VARCHAR(20)   ENCODE lzo
	,MOST_RECENT_ADVANCEMENT_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,Most_Recent_Termination_Date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LEVEL2_DESC_NO_MGR VARCHAR(765)   ENCODE lzo
	,PERF_BAND1 VARCHAR(300)   ENCODE lzo
	,PERF_BAND2 VARCHAR(300)   ENCODE lzo
	,TALENT_QUADRANT_1 VARCHAR(6)   ENCODE lzo
	,TALENT_QUADRANT_2 VARCHAR(6)   ENCODE lzo
	,DISABILITY_STATUS VARCHAR(765)   ENCODE lzo
	,VETERAN_STATUS_DESC VARCHAR(765)   ENCODE lzo
	,DEPT_ID VARCHAR(240)   ENCODE lzo
	,DEPT_NAME VARCHAR(765)   ENCODE lzo
	,ETHNIC_GROUP_CUSTOM_DESC VARCHAR(765)   ENCODE lzo
	,CC_NODEVAL VARCHAR(765)   ENCODE lzo
	,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,EMPLOYEE_CAT_CODE VARCHAR(765)   ENCODE lzo
	,EMPLOYEE_CAT_DESC VARCHAR(765)   ENCODE lzo
	,Country VARCHAR(765)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,JS_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,OFFICE_TYPE VARCHAR(450)   ENCODE lzo
	,EXCH_RATE NUMERIC(38,10)   ENCODE az64 --NUMERIC(22,7)   ENCODE az64
	,FROM_CURCY_CD VARCHAR(360)   ENCODE lzo
	
	,SUP_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,SUP_HIER_PIT_KEY NUMERIC(10,0)   ENCODE az64
	,EMPLOYMENT_KEY NUMERIC(10,0)   ENCODE az64
	,PAYOUT_PRD_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,MGRLEAD_PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,AGE_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,CC_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,LE_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_KEY NUMERIC(10,0)   ENCODE az64
	,JOB_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_KEY NUMERIC(10,0)   ENCODE az64
	,WORKER_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,LOC_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
	,PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,SER_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,AWARD_PLAN_KEY NUMERIC(10,0)   ENCODE az64
	,JOB_REQ_TAG1 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG2 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG3 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG4 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG5 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG6 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG7 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG8 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG9 VARCHAR(765)   ENCODE lzo
	,JOB_REQ_TAG10 VARCHAR(765)   ENCODE lzo
	,CC_LEVEL1_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL2_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL3_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL4_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL5_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL6_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL7_DESC VARCHAR(765)   ENCODE lzo
	,le_level1_desc VARCHAR(765)   ENCODE lzo
	,le_level2_desc VARCHAR(765)   ENCODE lzo
	,le_level3_desc VARCHAR(765)   ENCODE lzo
	,le_level4_desc VARCHAR(765)   ENCODE lzo
	,le_level5_desc VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_LEVEL1 VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_LEVEL2 VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_LEVEL3 VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_LEVEL4 VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_LEVEL5 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL1 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL2 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL3 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL4 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL5 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL6 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL7 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL8 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL9 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL10 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL11 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL12 VARCHAR(765)   ENCODE lzo
	,LOCATION_DESC_LEVEL13 VARCHAR(765)   ENCODE lzo
	,ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,FULLTIME_PARTTIME VARCHAR(765)   ENCODE lzo
	,BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64 
	,AWARD_AMOUNT_US NUMERIC(38,6) ENCODE az64
	,PAYLINE_CODE VARCHAR(765)   ENCODE lzo
	,LOC_CURR_CODE VARCHAR(765)   ENCODE lzo
	,SECTOR_POSITION VARCHAR(300)   ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,MOST_RECENT_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,CONTRACT_START_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,CONTRACT_END_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,COMPANY VARCHAR(765)  ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
	
)
DISTSTYLE AUTO
 SORTKEY (
	worker_key
	, calendar_dt
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_level1_val
	, le_level2_val
	, le_level3_val
	, le_level4_val
	, le_level5_val
	, location_code_level1
	, location_code_level2
	, location_code_level3
	, location_code_level4
	, location_code_level5
	, location_code_level6
	, location_code_level7
	, location_code_level8
	, location_code_level9
	, location_code_level10
	, location_code_level11
	, location_code_level12
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	, cc_level1_value
	, cc_level2_value
	, cc_level3_value
	, cc_level4_value
	, cc_level5_value
	, cc_level6_value
	, cc_level7_value
	)
;
ALTER TABLE gna_load_schema.fact_awards_denormalized owner to dbadmin;

-- gna_load_schema.fact_cohorts definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_cohorts;

--DROP TABLE gna_load_schema.fact_cohorts;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_cohorts
(
	worker_key NUMERIC(20,0)   ENCODE az64
	,mentorship_type VARCHAR(750)   ENCODE lzo
	,cohorts VARCHAR(750)   ENCODE lzo
	,start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,worker_id VARCHAR(750)   ENCODE lzo
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,leave_status NUMERIC(1,0)   ENCODE az64
	,payroll_status NUMERIC(1,0)   ENCODE az64
	,office_type VARCHAR(450)   ENCODE lzo
	,length_of_service NUMERIC(15,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_key NUMERIC(10,0)   ENCODE az64
	,supervisor_employment_key NUMERIC(10,0)   ENCODE az64
	,supervisor_job_key NUMERIC(10,0)   ENCODE az64
	,supervisor_loc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_pay_grade_key NUMERIC(10,0)   ENCODE az64
	,supervisor_perf_band_key NUMERIC(10,0)   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_cohorts owner to dbadmin;


-- gna_load_schema.fact_empl_upward_feedback definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_empl_upward_feedback;

--DROP TABLE gna_load_schema.fact_empl_upward_feedback;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_empl_upward_feedback
(
	survey_key NUMERIC(10,0)   ENCODE az64
	,worker_id VARCHAR(765)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,survey_resp_dt_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,buddy_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,survey_ques_id VARCHAR(765)   ENCODE lzo
	,survey_ques_long_descr VARCHAR(765)   ENCODE lzo
	,survey_ques_short_descr VARCHAR(765)   ENCODE lzo
	,survey_rating VARCHAR(765)   ENCODE lzo
	,survey_resp_status VARCHAR(765)   ENCODE lzo
	,survey_resp_status_descr VARCHAR(765)   ENCODE lzo
	,survey_comments VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(765)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(765)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_empl_upward_feedback owner to dbadmin;


-- gna_load_schema.fact_employee_review definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_employee_review;

--DROP TABLE gna_load_schema.fact_employee_review;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_employee_review
(
	reviewer_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,worker_id VARCHAR(240)   ENCODE lzo
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,period_begin_dt_key NUMERIC(10,0)   ENCODE az64
	,period_end_dt_key NUMERIC(10,0)   ENCODE az64
	,rvw_cat_key NUMERIC(10,0)   ENCODE az64
	,period_begin_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,period_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,review_type VARCHAR(300)   ENCODE lzo
	,review_status VARCHAR(300)   ENCODE lzo
	,review_rating VARCHAR(300)   ENCODE lzo
	,review_year VARCHAR(12)   ENCODE lzo
	,hashdiff VARCHAR(765)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,employee_comment VARCHAR(64512)   ENCODE lzo
	,manager_comment VARCHAR(64512)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_employee_review owner to dbadmin;


-- gna_load_schema.fact_employee_survey definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_employee_survey;

--DROP TABLE gna_load_schema.fact_employee_survey;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_employee_survey
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,worker_id VARCHAR(240)   ENCODE lzo
	,survey_id VARCHAR(240)   ENCODE lzo
	,survey_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,survey_sent_date_key NUMERIC(10,0)   ENCODE az64
	,survey_submitted_date_key NUMERIC(10,0)   ENCODE az64
	,survey_closed_date_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,buddy_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,survey_submitted_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_resp_status VARCHAR(1200)   ENCODE lzo
	,survey_sent_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_closed_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,reason_for_leaving VARCHAR(64512)   ENCODE lzo
	,company_employee_leaving_to VARCHAR(750)   ENCODE lzo
	,survey_resp_comments VARCHAR(64512)   ENCODE lzo
	,hashdiff VARCHAR(600)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,survey_rating VARCHAR(64512)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_employee_survey owner to dbadmin;


-- gna_load_schema.fact_employee_survey_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_employee_survey_denormalized;

--DROP TABLE gna_load_schema.fact_employee_survey_denormalized;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_employee_survey_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,worker_id VARCHAR(765)   ENCODE lzo
	,worker_name VARCHAR(765)   ENCODE lzo
	,survey_id VARCHAR(240)   ENCODE lzo
	,survey_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,survey_sent_date_key NUMERIC(10,0)   ENCODE az64
	,survey_submitted_date_key NUMERIC(10,0)   ENCODE az64
	,survey_closed_date_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,buddy_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,survey_submitted_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_resp_status VARCHAR(765)   ENCODE lzo
	,survey_sent_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_closed_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,reason_for_leaving VARCHAR(64512)   ENCODE lzo
	,company_employee_leaving_to VARCHAR(750)   ENCODE lzo
	,survey_resp_comments VARCHAR(64512)   ENCODE lzo
	--,hashdiff VARCHAR(600)   ENCODE lzo
	--,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	--,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	--,receieved_file_id NUMERIC(10,0)   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,survey_rating VARCHAR(64512)   ENCODE lzo
	,survey_type VARCHAR(300)   ENCODE lzo
	,survey_ques_long_descr VARCHAR(12000)   ENCODE lzo
	,current_level1_emp_login VARCHAR(720)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE lzo
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE lzo
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE lzo
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE lzo
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE lzo
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE lzo
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE lzo
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE lzo
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE lzo
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE lzo
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,level10_desc VARCHAR(720)   ENCODE lzo
	,level10_val VARCHAR(720)   ENCODE RAW
	,level11_desc VARCHAR(720)   ENCODE lzo
	,level11_val VARCHAR(720)   ENCODE RAW
	,level12_desc VARCHAR(720)   ENCODE lzo
	,level12_val VARCHAR(720)   ENCODE RAW
	,level13_desc VARCHAR(720)   ENCODE lzo
	,level13_val VARCHAR(720)   ENCODE RAW
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE RAW
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level2_val VARCHAR(720)   ENCODE RAW
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level3_val VARCHAR(720)   ENCODE RAW
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level4_val VARCHAR(720)   ENCODE RAW
	,level5_desc VARCHAR(720)   ENCODE lzo
	,level5_val VARCHAR(720)   ENCODE RAW
	,level6_desc VARCHAR(720)   ENCODE lzo
	,level6_val VARCHAR(720)   ENCODE RAW
	,level7_desc VARCHAR(720)   ENCODE lzo
	,level7_val VARCHAR(720)   ENCODE RAW
	,level8_desc VARCHAR(720)   ENCODE lzo
	,level8_val VARCHAR(720)   ENCODE RAW
	,level9_desc VARCHAR(720)   ENCODE lzo
	,level9_val VARCHAR(720)   ENCODE RAW
	,cc_level1_val VARCHAR(720)   ENCODE RAW
	,cc_level2_val VARCHAR(720)   ENCODE RAW
	,cc_level3_val VARCHAR(720)   ENCODE RAW
	,cc_level4_val VARCHAR(720)   ENCODE RAW
	,cc_level5_val VARCHAR(720)   ENCODE RAW
	,cc_level6_val VARCHAR(720)   ENCODE RAW
	,cc_level7_val VARCHAR(720)   ENCODE RAW
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,employee_cat_desc VARCHAR(765)   ENCODE lzo
	,calendar_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE RAW
	,cal_date_key NUMERIC(19,0)   ENCODE az64
	,le_level1_val VARCHAR(720)   ENCODE lzo
	,le_level2_val VARCHAR(720)   ENCODE lzo
	,le_level3_val VARCHAR(720)   ENCODE lzo
	,le_level4_val VARCHAR(720)   ENCODE lzo
	,le_level5_val VARCHAR(720)   ENCODE lzo
	,le_level6_val VARCHAR(720)   ENCODE lzo
	,sex_desc VARCHAR(765)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_title VARCHAR(765)   ENCODE lzo
	,supervisor_id VARCHAR(765)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,age NUMERIC(20,2)   ENCODE az64
	,veteran_status VARCHAR(765)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,worker_type_sub_category_desc VARCHAR(765)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,school_name VARCHAR(765)   ENCODE lzo
	,full_time_flg VARCHAR(150)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,kcs_short_item VARCHAR(765)   ENCODE lzo
	,candidate_type VARCHAR(765)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,survey_ques_short_descr VARCHAR(765)   ENCODE lzo
	,PAY_GRADE_CODE VARCHAR(240)   ENCODE lzo
	,DEPT_ID   VARCHAR(240)   ENCODE lzo
	,DEPT_NAME VARCHAR(765)   ENCODE lzo
	,EMP_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LEVEL2_DESC_NO_MGR VARCHAR(765)   ENCODE lzo
	,MOST_RECENT_ADVANCEMENT_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TALENT_QUADRANT_2 VARCHAR(6)   ENCODE lzo
	,PERF_BAND2 VARCHAR(300)   ENCODE lzo
	,ASSIGNED_HR_BUSINESS_PARTNER VARCHAR(765)   ENCODE lzo
	,COST_CENTER_LEVEL2_NAME VARCHAR(720)   ENCODE lzo
	,SURVEY_QUESTION VARCHAR(12000)   ENCODE lzo
	,Employment_Status VARCHAR(300)   ENCODE lzo
	,ETHNIC_GROUP_CUSTOM_DESC VARCHAR(765)   ENCODE lzo
	,CC_NODEVAL VARCHAR(760)   ENCODE lzo
    ,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,SOURCE_TYPE_NAME VARCHAR(765)   ENCODE lzo
	,RQSTN_KEY NUMERIC(10,0)   ENCODE az64
	,CC_LEVEL1_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL2_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL3_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL4_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL5_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL6_DESC  VARCHAR(765)   ENCODE lzo
	,CC_LEVEL7_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL1_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL2_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL3_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL4_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL5_DESC  VARCHAR(765)   ENCODE lzo
    ,LE_LEVEL6_DESC  VARCHAR(765)   ENCODE lzo
	,BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ORIG_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,VETERAN_STATUS_US VARCHAR(765)   ENCODE lzo
	,DISABILITY_STATUS_US VARCHAR(765)   ENCODE lzo
	,ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,job_req_tag1 VARCHAR(765)   ENCODE lzo
    ,job_req_tag2 VARCHAR(765)   ENCODE lzo
    ,job_req_tag3 VARCHAR(765)   ENCODE lzo
    ,job_req_tag4 VARCHAR(765)   ENCODE lzo
    ,job_req_tag5 VARCHAR(765)   ENCODE lzo
    ,job_req_tag6 VARCHAR(765)   ENCODE lzo
    ,job_req_tag7 VARCHAR(765)   ENCODE lzo
    ,job_req_tag8 VARCHAR(765)   ENCODE lzo
    ,job_req_tag9 VARCHAR(765)   ENCODE lzo
    ,job_req_tag10 VARCHAR(765)   ENCODE lzo
	,FULLTIME_PARTTIME VARCHAR(765)   ENCODE lzo
	,primary_sourcer1 VARCHAR(765)   ENCODE lzo
	,primary_sourcer1_name VARCHAR(765)   ENCODE lzo
	,JOB_REQ_ID VARCHAR(300)   ENCODE lzo
	,TIME_TO_FILL NUMERIC(10,0)   ENCODE az64
	,TIME_TO_HIRE NUMERIC(10,0)   ENCODE az64
	,OFFR_ACPT_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,RQSTN_OPENED_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,JS_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,RQSTN_OFF_HOLD_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,RQSTN_HOLD_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,PRODUCT_DESC_1 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_2 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_3 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_4 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_5 VARCHAR(765)   ENCODE lzo
    ,product_value1 VARCHAR(765)   ENCODE lzo
    ,product_value2 VARCHAR(765)   ENCODE lzo
    ,product_value3 VARCHAR(765)   ENCODE lzo
    ,product_value4 VARCHAR(765)   ENCODE lzo
    ,product_value5 VARCHAR(765)   ENCODE lzo
	,POSITION_TYPE VARCHAR(765)   ENCODE lzo
	,QUANTATIVE_SURVEY VARCHAR(765)   ENCODE lzo
	,QUALITATIVE_SURVEY VARCHAR(64512)   ENCODE lzo
	,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,PRODUCT_NODE_NAME VARCHAR(765)   ENCODE lzo
	,LOGIN VARCHAR(765)   ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,MOST_RECENT_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,MOST_RECENT_TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MANAGER_ID VARCHAR(765)  ENCODE lzo
	,MANAGER_NAME VARCHAR(765)  ENCODE lzo
	,MANAGER_PAY_GRADE VARCHAR(765)  ENCODE lzo
	,MANAGER_JOB_TITLE VARCHAR(765)  ENCODE lzo
	,MANAGER_WORKER_KEY  NUMERIC(20,0)   ENCODE az64
	,MANAGER_EMP_HIRE_DT  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MANAGER_TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MANAGER_CONTINUOUS_SERVICE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MANAGER_OFFICE_TYPE VARCHAR(765)  ENCODE lzo
	,MANAGER_REHIRE_FLAG VARCHAR(3)   ENCODE lzo
	,MANAGER_EMPLOYMENT_STATUS VARCHAR(765)  ENCODE lzo
	,MANAGER_BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MANAGER_SEX_DESC VARCHAR(765)  ENCODE lzo
	,MANAGER_ETHNICITY_US VARCHAR(765)  ENCODE lzo
	,COMPANY VARCHAR(765)  ENCODE lzo
	,MANAGER_VETERAN_STATUS VARCHAR(765)  ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
	
)
DISTSTYLE AUTO
 SORTKEY (
	calendar_dt
	, level13_val
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, level1_val
	, level2_val
	, level3_val
	, level4_val
	, level5_val
	, level6_val
	, level7_val
	, level8_val
	, level9_val
	, level10_val
	, level11_val
	, level12_val
	, cc_level1_val
	, cc_level2_val
	, cc_level3_val
	, cc_level4_val
	, cc_level5_val
	, cc_level6_val
	, cc_level7_val
	)
;
ALTER TABLE gna_load_schema.fact_employee_survey_denormalized owner to dbadmin;

-- gna_load_schema.fact_equity definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_equity;

--DROP TABLE gna_load_schema.fact_equity;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_equity
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,worker_id VARCHAR(240)   ENCODE lzo
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,snapshot_dt_key NUMERIC(10,0)   ENCODE az64
	,assumed_value NUMERIC(10,2)   ENCODE az64
	,grant_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,stock_plan_type VARCHAR(30)   ENCODE lzo
	,plan VARCHAR(30)   ENCODE lzo
	,plan_type VARCHAR(240)   ENCODE lzo
	,price NUMERIC(15,4)   ENCODE az64
	,shares NUMERIC(10,0)   ENCODE az64
	,units_cancelled NUMERIC(10,0)   ENCODE az64
	,units_exercisable_releasable NUMERIC(10,0)   ENCODE az64
	,units_exercised_released NUMERIC(10,0)   ENCODE az64
	,units_ostunreleased NUMERIC(10,0)   ENCODE az64
	,units_unvested NUMERIC(10,0)   ENCODE az64
	,units_vested NUMERIC(10,0)   ENCODE az64
	,value_exercisable_releasable NUMERIC(18,6)   ENCODE az64
	,value_tocost NUMERIC(18,6)   ENCODE az64
	,value_unvested NUMERIC(18,6)   ENCODE az64
	,stock_plan_grp VARCHAR(300)   ENCODE lzo
	,tenant_id VARCHAR(300)   ENCODE lzo
	,grant_num VARCHAR(300)   ENCODE lzo
	,grant_record_type VARCHAR(240)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,"class" VARCHAR(300)   ENCODE lzo
	,retirement_eligible_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,x_vest_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,x_shares NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_equity owner to dbadmin;


CREATE TABLE IF NOT EXISTS gna_load_schema.fact_equity_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,x_shares NUMERIC(10,0)   ENCODE az64
	,stock_plan_type VARCHAR(30)   ENCODE lzo
	,plan_type VARCHAR(240)   ENCODE lzo
	,price NUMERIC(15,4)   ENCODE az64
	,x_vest_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"class" VARCHAR(300)   ENCODE lzo
	,assumed_value NUMERIC(10,2)   ENCODE az64
	,grant_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,grant_num VARCHAR(300)   ENCODE lzo
	,shares NUMERIC(10,0)   ENCODE az64
	,units_cancelled NUMERIC(10,0)   ENCODE az64
	,units_exercisable_releasable NUMERIC(10,0)   ENCODE az64
	,plan VARCHAR(30)   ENCODE lzo
	,units_unvested NUMERIC(10,0)   ENCODE az64
	,units_exercised_released NUMERIC(10,0)   ENCODE az64
	,units_ostunreleased NUMERIC(10,0)   ENCODE az64
	,stock_plan_grp VARCHAR(300)   ENCODE lzo
	,grant_record_type VARCHAR(240)   ENCODE lzo
	,source_id VARCHAR(300)   ENCODE lzo
	,retirement_eligible_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,vest_year INT   ENCODE az64
	,pref_full_name VARCHAR(765)   ENCODE lzo
	,worker_key NUMERIC(20,0)   ENCODE az64
	,employee_num VARCHAR(765)   ENCODE lzo
	,job_title VARCHAR(765)   ENCODE lzo
	,most_recent_advancement_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,EMP_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,CONTINUOUS_SERVICE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,location VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(450)   ENCODE lzo
	,SUPERVISOR_FLG VARCHAR(3)   ENCODE lzo
	,REHIRE_FLAG VARCHAR(3)   ENCODE lzo
	,HIEST_DEGREE VARCHAR(765)   ENCODE lzo
	,SCHOOL_NAME VARCHAR(765)   ENCODE lzo
	,age NUMERIC(20,2)   ENCODE az64
	,SEX_DESC VARCHAR(765)   ENCODE lzo
	,ETHNIC_GROUP_CUSTOM_DESC VARCHAR(765)   ENCODE lzo
	,VETERAN_STATUS_DESC VARCHAR(765)   ENCODE lzo
	,DISABILITY_STATUS VARCHAR(765)   ENCODE lzo
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,perf_band2 VARCHAR(300)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,LEVEL10_DESC VARCHAR(720)   ENCODE lzo
	,LEVEL13_VAL VARCHAR(720)   ENCODE lzo
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	,JOB_CODE VARCHAR(300)   ENCODE lzo
	,JOB_family_desc VARCHAR(765)   ENCODE lzo
	,FULL_TIME_FLG VARCHAR(150)   ENCODE lzo
	,EMPLOYEE_SUB_CAT_DESC VARCHAR(765)   ENCODE lzo
	,AGE_BAND_DESC VARCHAR(765)   ENCODE lzo
	,LEVEL2_VAL VARCHAR(720)   ENCODE lzo
	,CC_LEVEL2_NAME VARCHAR(720)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,cancelled_shares NUMERIC(10,0)   ENCODE az64
	,cancel_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,cancel_reason VARCHAR(765)   ENCODE lzo
	,CC_NODEVAL VARCHAR(765)   ENCODE lzo
    ,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,location_code_level1 VARCHAR(720)   ENCODE RAW
	,location_code_level2 VARCHAR(720)   ENCODE RAW
	,location_code_level3 VARCHAR(720)   ENCODE RAW
	,location_code_level4 VARCHAR(720)   ENCODE RAW
	,location_code_level5 VARCHAR(720)   ENCODE RAW
	,location_code_level6 VARCHAR(720)   ENCODE RAW
	,location_code_level7 VARCHAR(720)   ENCODE RAW
	,location_code_level8 VARCHAR(720)   ENCODE RAW
	,location_code_level9 VARCHAR(720)   ENCODE RAW
	,location_code_level10 VARCHAR(720)  ENCODE RAW
	,location_code_level11 VARCHAR(720)  ENCODE RAW
	,location_code_level12 VARCHAR(720)  ENCODE RAW
	,location_code_level13 VARCHAR(720)  ENCODE RAW
	,location_desc_level1 VARCHAR(720)   ENCODE lzo
	,location_desc_level2 VARCHAR(720)   ENCODE lzo
	,location_desc_level3 VARCHAR(720)   ENCODE lzo
	,location_desc_level4 VARCHAR(720)   ENCODE lzo
	,location_desc_level5 VARCHAR(720)   ENCODE lzo
	,location_desc_level6 VARCHAR(720)   ENCODE lzo
	,location_desc_level7 VARCHAR(720)   ENCODE lzo
	,location_desc_level8 VARCHAR(720)   ENCODE lzo
	,location_desc_level9 VARCHAR(720)   ENCODE lzo
	,location_desc_level10 VARCHAR(720)   ENCODE lzo
	,location_desc_level11 VARCHAR(720)   ENCODE lzo
	,location_desc_level12 VARCHAR(720)   ENCODE lzo
	,location_desc_level13 VARCHAR(720)   ENCODE lzo
    ,cc_desc VARCHAR(720)   ENCODE lzo
	,cc_legal_entity VARCHAR(720)   ENCODE lzo
	,cc_owner VARCHAR(720)   ENCODE lzo
	,functional_area VARCHAR(720)   ENCODE lzo
	,currency VARCHAR(720)   ENCODE lzo
	,product_link VARCHAR(720)   ENCODE lzo
	,market_associated VARCHAR(720)   ENCODE lzo
    ,HRYID VARCHAR(720)   ENCODE lzo
    ,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE RAW
	,cc_level7_value VARCHAR(720)   ENCODE RAW
	,base_cost_center_desc VARCHAR(720)   ENCODE lzo
	,cost_center_level2_desc VARCHAR(720)   ENCODE lzo
    ,CC_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL2_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL3_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL4_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL5_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL6_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL7_DESC VARCHAR(720)   ENCODE lzo
    ,le_level1_val VARCHAR(720)     ENCODE RAW
	,le_level2_val VARCHAR(720)     ENCODE RAW
	,le_level3_val VARCHAR(720)     ENCODE RAW
	,le_level4_val VARCHAR(720)     ENCODE RAW
	,le_level5_val VARCHAR(720)     ENCODE RAW
	,le_level6_val VARCHAR(720)     ENCODE RAW
	,LE_LEVEL1_DESC VARCHAR(720)    ENCODE lzo
	,LE_LEVEL2_DESC VARCHAR(720)    ENCODE lzo
	,LE_LEVEL3_DESC VARCHAR(720)    ENCODE lzo
	,LE_LEVEL4_DESC VARCHAR(720)    ENCODE lzo
	,LE_LEVEL5_DESC VARCHAR(720)    ENCODE lzo
	,le_level6_desc VARCHAR(720)    ENCODE lzo
    ,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_desc1 VARCHAR(765)   ENCODE lzo
	,product_desc2 VARCHAR(765)   ENCODE lzo
	,product_desc3 VARCHAR(765)   ENCODE lzo
	,product_desc4 VARCHAR(765)   ENCODE lzo
	,product_desc5 VARCHAR(765)   ENCODE lzo

    ,SUP_HIER_PIT_KEY NUMERIC(10,0)   ENCODE az64
    ,SNAPSHOT_DT_KEY NUMERIC(10,0)   ENCODE az64
    ,AGE_BAND_KEY NUMERIC(10,0)   ENCODE az64
    ,CC_HIER_KEY NUMERIC(10,0)   ENCODE az64
    ,WORKER_TYPE_KEY NUMERIC(10,0)   ENCODE az64
    ,DEPT_KEY NUMERIC(10,0)   ENCODE az64
    ,PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
    ,JOB_KEY NUMERIC(10,0)   ENCODE az64
    ,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
    ,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
    ,LOC_HIER_KEY NUMERIC(10,0)   ENCODE az64
    ,LE_HIER_KEY NUMERIC(10,0)   ENCODE az64
    ,SER_BAND_KEY NUMERIC(10,0)   ENCODE az64
    ,SUP_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,VETERAN_STATUS_US VARCHAR(765)   ENCODE lzo
	,DISABILITY_STATUS_US VARCHAR(765)   ENCODE lzo
	,LOGIN VARCHAR(765)   ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,JOB_DESC VARCHAR(765)  ENCODE lzo
	,SUPERVISOR_NUM VARCHAR(765)  ENCODE lzo
	,SUPERVISOR_NAME VARCHAR(765)  ENCODE lzo
	,LEVEL2_DESC_NO_MGR VARCHAR(765)  ENCODE lzo
	,job_req_tag  VARCHAR(12000)   ENCODE lzo
	,job_req_tag1  VARCHAR(765)  ENCODE lzo
	,job_req_tag2  VARCHAR(765)  ENCODE lzo
	,job_req_tag3  VARCHAR(765)  ENCODE lzo
	,job_req_tag4  VARCHAR(765)  ENCODE lzo
	,job_req_tag5  VARCHAR(765)  ENCODE lzo
	,job_req_tag6  VARCHAR(765)  ENCODE lzo
	,job_req_tag7  VARCHAR(765)  ENCODE lzo
	,job_req_tag8  VARCHAR(765)  ENCODE lzo
	,job_req_tag9  VARCHAR(765)  ENCODE lzo
	,job_req_tag10 VARCHAR(765)  ENCODE lzo
	,FULLTIME_PARTTIME VARCHAR(765)  ENCODE lzo
	,BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,AWR_START_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,AWR_END_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,RQSTN_KEY NUMERIC(10,0)   ENCODE az64
	,UNITS_VESTED NUMERIC(10,0)   ENCODE az64
	,SEXUAL_ORIENTATION VARCHAR(765)  ENCODE lzo
	,MOST_RECENT_TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ORIG_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,SECTOR_A_FROM NUMERIC(15,5)   ENCODE az64
	,SECTOR_A_TO NUMERIC(15,5)   ENCODE az64
	,SECTOR_B_FROM NUMERIC(15,5)   ENCODE az64
	,SECTOR_B_TO NUMERIC(15,5)   ENCODE az64
	,SECTOR_1B_TO NUMERIC(15,5)   ENCODE az64
	,SECTOR_2B_FROM NUMERIC(15,5)   ENCODE az64
	,SALARY_MIDPOINT NUMERIC(15,5)   ENCODE az64
	,SECTOR_2B_TO NUMERIC(15,5)   ENCODE az64
	,SECTOR_3B_FROM NUMERIC(15,5)   ENCODE az64
	,SECTOR_3B_TO NUMERIC(15,5)   ENCODE az64
	,SECTOR_C_FROM NUMERIC(15,5)   ENCODE az64
	,SECTOR_C_TO NUMERIC(15,5)   ENCODE az64 
	,PAY_GRADE_PROFILE VARCHAR(240)   ENCODE lzo
	,JOB_FAMILY_GROUP VARCHAR(750)   ENCODE lzo
	,CURRENCY_CODE VARCHAR(20) ENCODE lzo
	,PAYLINE_CODE VARCHAR(240)   ENCODE lzo
	,EMPLOYEE_CAT_CODE VARCHAR(750)   ENCODE lzo
	,COMPANY VARCHAR(765)  ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
)
DISTSTYLE AUTO
SORTKEY (
    worker_key
   ,plan_type
   ,class
   ,current_level1_emp_full_name 
   ,current_level2_emp_full_name 
   ,current_level3_emp_full_name 
   ,current_level4_emp_full_name 
   ,current_level5_emp_full_name 
   ,current_level6_emp_full_name 
   ,current_level7_emp_full_name 
   ,current_level8_emp_full_name 
   ,current_level9_emp_full_name 
   ,current_level10_emp_full_name
   ,current_level11_emp_full_name
   ,current_level1_emp_login 
   ,current_level2_emp_login 
   ,current_level3_emp_login 
   ,current_level4_emp_login 
   ,current_level5_emp_login 
   ,current_level6_emp_login 
   ,current_level7_emp_login 
   ,current_level8_emp_login 
   ,current_level9_emp_login 
   ,current_level10_emp_login
   ,current_level11_emp_login
   ,location_code_level1
   ,location_code_level2
   ,location_code_level3
   ,location_code_level4
   ,location_code_level5
   ,location_code_level6
   ,location_code_level7
   ,location_code_level8
   ,location_code_level9
   ,location_code_level10
   ,location_code_level11
   ,location_code_level12
   ,le_level1_val
   ,le_level2_val
   ,le_level3_val
   ,le_level4_val
   ,le_level5_val
   ,product_value1
   ,product_value2
   ,product_value3
   ,product_value4
   ,product_value5
   ,cc_level1_value
   ,cc_level2_value
   ,cc_level3_value
   ,cc_level4_value
   ,cc_level5_value
   ,cc_level6_value
   ,cc_level7_value
)
;
ALTER TABLE gna_load_schema.fact_equity_denormalized owner to dbadmin;

-- gna_load_schema.fact_hyperion_forecast definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_hyperion_forecast;

--DROP TABLE gna_load_schema.fact_hyperion_forecast;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_hyperion_forecast
(
	companycode VARCHAR(150)   ENCODE lzo
	,costcenter VARCHAR(150)   ENCODE lzo
	,emptyp VARCHAR(150)   ENCODE lzo
	,hcunits VARCHAR(150)   ENCODE lzo
	,mandt VARCHAR(150)   ENCODE lzo
	,market VARCHAR(150)   ENCODE lzo
	,paygrade VARCHAR(150)   ENCODE lzo
	,profitcenter VARCHAR(150)   ENCODE lzo
	,scenario VARCHAR(150)   ENCODE lzo
	,"time" VARCHAR(150)   ENCODE lzo
	,month_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,budget_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,market_key NUMERIC(10,0)   ENCODE az64
	,row_id NUMERIC(10,0)   ENCODE az64
	,le_hier_key VARCHAR(250)   ENCODE lzo
	,received_file_name VARCHAR(650)   ENCODE lzo
	,hc_type VARCHAR(650)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_hyperion_forecast owner to dbadmin;


-- gna_load_schema.fact_hyperion_forecast_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_hyperion_forecast_denormalized;

CREATE TABLE IF NOT EXISTS gna_load_schema.fact_hyperion_forecast_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,COMPANYCODE VARCHAR(765)   ENCODE lzo
	,COSTCENTER VARCHAR(765)   ENCODE lzo
	,EMPTYP VARCHAR(765)   ENCODE lzo
	,HCUNITS VARCHAR(765)   ENCODE lzo
	,MANDT VARCHAR(765)   ENCODE lzo
	,MARKET VARCHAR(765)   ENCODE lzo
	,PAYGRADE VARCHAR(765)   ENCODE lzo
	,PROFITCENTER VARCHAR(765)   ENCODE lzo
	,SCENARIO VARCHAR(765)   ENCODE lzo
	,time VARCHAR(765)   ENCODE lzo
	,MONTH_KEY NUMERIC(10,0)   ENCODE az64
	,CREATED_DT  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,CREATED_BY_KEY NUMERIC(10,0)   ENCODE az64
	,CC_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,BUDGET_KEY NUMERIC(10,0)   ENCODE az64
	,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,MARKET_KEY NUMERIC(10,0)   ENCODE az64
	,ROW_ID NUMERIC(10,0)   ENCODE az64
	,LE_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,HC_TYPE VARCHAR(765)   ENCODE lzo
	,cc_level1_value VARCHAR(765)   ENCODE RAW
	,cc_level2_value VARCHAR(765)   ENCODE RAW
	,cc_level3_value VARCHAR(765)   ENCODE RAW
	,cc_level4_value VARCHAR(765)   ENCODE RAW
	,cc_level5_value VARCHAR(765)   ENCODE RAW
	,cc_level6_value VARCHAR(765)   ENCODE RAW
	,cc_level7_value VARCHAR(765)   ENCODE RAW
	,cc_level8_value VARCHAR(765)   ENCODE RAW
	,CC_LEVEL1_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL2_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL3_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL4_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL5_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL6_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL7_DESC VARCHAR(765)   ENCODE lzo
	,CC_LEVEL8_DESC VARCHAR(765)   ENCODE lzo
	,base_cost_center_desc  VARCHAR(765)   ENCODE lzo
	,Cost_center_level2_desc VARCHAR(765)   ENCODE lzo
	,cc_desc VARCHAR(765)   ENCODE lzo
	,cc_legal_entity VARCHAR(765)   ENCODE lzo
	,cc_owner VARCHAR(765)   ENCODE lzo
	,functional_area VARCHAR(765)   ENCODE lzo
	,currency VARCHAR(765)   ENCODE lzo
	,product_link VARCHAR(765)   ENCODE lzo
	,market_associated VARCHAR(765)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,le_level1_val VARCHAR(765)   ENCODE RAW
	,le_level2_val VARCHAR(765)   ENCODE RAW
	,le_level3_val VARCHAR(765)   ENCODE RAW
	,le_level4_val VARCHAR(765)   ENCODE RAW
	,le_level5_val VARCHAR(765)   ENCODE RAW
	,le_level6_val VARCHAR(765)   ENCODE RAW
	,le_level1_desc VARCHAR(765)   ENCODE lzo
	,le_level2_desc VARCHAR(765)   ENCODE lzo
	,le_level3_desc VARCHAR(765)   ENCODE lzo
	,le_level4_desc VARCHAR(765)   ENCODE lzo
	,le_level5_desc VARCHAR(765)   ENCODE lzo
	,le_level6_desc VARCHAR(765)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_DESC1 VARCHAR(765)   ENCODE lzo
	,product_DESC2 VARCHAR(765)   ENCODE lzo
	,product_DESC3 VARCHAR(765)   ENCODE lzo
	,product_DESC4 VARCHAR(765)   ENCODE lzo
	,product_DESC5 VARCHAR(765)   ENCODE lzo
	,product_desc VARCHAR(765)   ENCODE lzo
	,site_cc_level1_value VARCHAR(765)   ENCODE RAW
	,site_cc_level2_value VARCHAR(765)   ENCODE RAW
	,site_cc_level3_value VARCHAR(765)   ENCODE RAW
	,site_cc_level4_value VARCHAR(765)   ENCODE RAW
	,site_cc_level5_value VARCHAR(765)   ENCODE RAW
	,site_cc_level6_value VARCHAR(765)   ENCODE RAW
	,site_cc_level7_value VARCHAR(765)   ENCODE RAW
	,site_CC_LEVEL1_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL2_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL3_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL4_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL5_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL6_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL7_DESC VARCHAR(765)   ENCODE lzo
	,FUNCTIONAL_AREA_DESC VARCHAR(765)   ENCODE lzo
	,COST_CENTER_OWNER VARCHAR(765)   ENCODE lzo
	,LOGIN VARCHAR(765)   ENCODE lzo
	,BUDGET_DESC VARCHAR(765)   ENCODE lzo
	,BUDGET_NAME VARCHAR(765)   ENCODE lzo
	,cc_nodeval VARCHAR(765)   ENCODE lzo
	,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,COMPANY VARCHAR(765)   ENCODE lzo
	,COST_CENTER_OWNER_ID VARCHAR(765)   ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
	
	
)
DISTSTYLE AUTO
 SORTKEY (
	  current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level6_emp_login
	, current_level7_emp_login
	, current_level8_emp_login
	, current_level9_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_level1_val
	, le_level2_val
	, le_level3_val
	, le_level4_val
	, le_level5_val
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	, cc_level1_value
	, cc_level2_value
	, cc_level3_value
	, cc_level4_value
	, cc_level5_value
	, cc_level6_value
	, cc_level7_value
	, cc_level8_value
	)
;
ALTER TABLE gna_load_schema.fact_hyperion_forecast_denormalized owner to dbadmin;

-- gna_load_schema.fact_job_events definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_job_events;

--DROP TABLE gna_load_schema.fact_job_events;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_job_events
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,worker_evt_ind NUMERIC(1,0)   ENCODE az64
	,supervisor_evt_ind NUMERIC(1,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,assignment_id VARCHAR(240)   ENCODE lzo
	,assignment_num VARCHAR(240)   ENCODE lzo
	,worker_event_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_ind NUMERIC(1,0)   ENCODE az64
	,prom_event_ind NUMERIC(1,0)   ENCODE az64
	,hire_event_ind NUMERIC(1,0)   ENCODE az64
	,term_event_ind NUMERIC(1,0)   ENCODE az64
	,event_ind NUMERIC(1,0)   ENCODE az64
	,bldg_change_ind NUMERIC(1,0)   ENCODE az64
	,scheduled_reviewcycle_ind NUMERIC(1,0)   ENCODE az64
	,outofcycle_review_ind NUMERIC(1,0)   ENCODE az64
	,annual_compensation_ind NUMERIC(1,0)   ENCODE az64
	,midyear_compensation_ind NUMERIC(1,0)   ENCODE az64
	,le_change_ind NUMERIC(1,0)   ENCODE az64
	,cc_change_ind NUMERIC(1,0)   ENCODE az64
	,employment_change_ind NUMERIC(1,0)   ENCODE az64
	,position_change_ind NUMERIC(1,0)   ENCODE az64
	,rehire_event_ind NUMERIC(1,0)   ENCODE az64
	,job_change_ind NUMERIC(1,0)   ENCODE az64
	,location_change_ind NUMERIC(1,0)   ENCODE az64
	,dept_change_ind NUMERIC(1,0)   ENCODE az64
	,supervisor_change_ind NUMERIC(1,0)   ENCODE az64
	,internal_filled_req_ind NUMERIC(1,0)   ENCODE az64
	,grade_change_ind NUMERIC(1,0)   ENCODE az64
	,movement_ind VARCHAR(3)   ENCODE lzo
	,snapshot_ind NUMERIC(1,0)   ENCODE az64
	,snapshot_month_start_ind NUMERIC(1,0)   ENCODE az64
	,snapshot_month_end_ind NUMERIC(1,0)   ENCODE az64
	,last_month_in_qtr_ind NUMERIC(1,0)   ENCODE az64
	,last_month_in_year_ind NUMERIC(1,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,last_date_of_month_key NUMERIC(10,0)   ENCODE az64
	,orig_perf_rating VARCHAR(120)   ENCODE lzo
	,orig_perf_rating_prv VARCHAR(120)   ENCODE lzo
	,mgrlead_orig_perf_rating NUMERIC(10,3)   ENCODE az64
	,mgrlead_orig_perf_rating_prv NUMERIC(10,3)   ENCODE az64
	,worker_buddy_perf_rating NUMERIC(10,3)   ENCODE az64
	,regrettable_or_not VARCHAR(75)   ENCODE lzo
	,workday_record_entry_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,position_status VARCHAR(765)   ENCODE lzo
	,change_event_type VARCHAR(300)   ENCODE lzo
	,wrkfc_event_type VARCHAR(300)   ENCODE lzo
	,loc_curr_code VARCHAR(30)   ENCODE lzo
	,evt_change_reason VARCHAR(6000)   ENCODE lzo
	,emp_ind NUMERIC(1,0)   ENCODE az64
	,max_seq_ind NUMERIC(1,0)   ENCODE az64
	,event_seq NUMERIC(10,0)   ENCODE az64
	,headcount NUMERIC(10,3)   ENCODE az64
	,std_hours NUMERIC(10,3)   ENCODE az64
	,salary_annl NUMERIC(18,6)   ENCODE az64
	,salary_hour NUMERIC(18,6)   ENCODE az64
	,fte NUMERIC(10,9)   ENCODE az64
	,number_of_direct_reports NUMERIC(10,0)   ENCODE az64
	,salary_change_percent NUMERIC(10,3)   ENCODE az64
	,volunatry_turnover_cnt NUMERIC(10,0)   ENCODE az64
	,volunatry_turnover_rate NUMERIC(10,3)   ENCODE az64
	,global1_exchange_rate NUMERIC(10,3)   ENCODE az64
	,total_subordinate_cnt NUMERIC(10,0)   ENCODE az64
	,worker_buddy_same_dept_flg VARCHAR(3)   ENCODE lzo
	,worker_buddy_same_loc_flg VARCHAR(3)   ENCODE lzo
	,worker_buddy_grade_diff NUMERIC(10,0)   ENCODE az64
	,"region" VARCHAR(450)   ENCODE lzo
	,action_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_date_worked TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,pay_through_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,resignation_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,supervisor_cc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_key NUMERIC(10,0)   ENCODE az64
	,supervisor_employment_key NUMERIC(10,0)   ENCODE az64
	,supervisor_job_key NUMERIC(10,0)   ENCODE az64
	,supervisor_le_key NUMERIC(10,0)   ENCODE az64
	,supervisor_loc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_pay_grade_key NUMERIC(10,0)   ENCODE az64
	,supervisor_perf_band_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prod_hier_key NUMERIC(10,0)   ENCODE az64
	,buddy_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,annual_bonus_amount NUMERIC(18,6)   ENCODE az64
	,stock_amount NUMERIC(18,6)   ENCODE az64
	,pay_frequency VARCHAR(60)   ENCODE lzo
	,recruiter_hier_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,time_in_position NUMERIC(10,2)   ENCODE az64
	,time_in_job_profile NUMERIC(10,2)   ENCODE az64
	,contractor_conversion_flg VARCHAR(3)   ENCODE lzo
	,time_type_change_flg VARCHAR(3)   ENCODE lzo
	,worker_type_change_flg VARCHAR(3)   ENCODE lzo
	,grade_increase_flg VARCHAR(3)   ENCODE lzo
	,grade_decrease_flg VARCHAR(3)   ENCODE lzo
	,no_grade_change_flag VARCHAR(3)   ENCODE lzo
	,compensation_plan VARCHAR(60)   ENCODE lzo
	,actual_bonus_individual_share NUMERIC(18,6)   ENCODE az64
	,actual_bonus_company_share NUMERIC(18,6)   ENCODE az64
	,talent_quadrant VARCHAR(30)   ENCODE lzo
	,performance VARCHAR(300)   ENCODE lzo
	,potential VARCHAR(300)   ENCODE lzo
	,length_of_service NUMERIC(15,0)   ENCODE az64
	,gilead_tenure NUMERIC(15,0)   ENCODE az64
	,true_days_at_gilead NUMERIC(15,0)   ENCODE az64
	,days_onsite_per_week VARCHAR(30)   ENCODE lzo
	,emp_convesion_to_contractor VARCHAR(30)   ENCODE lzo
	,revision_owner VARCHAR(300)   ENCODE lzo
	,revision_owner_emp_id VARCHAR(30)   ENCODE lzo
	,purchase_order_num VARCHAR(300)   ENCODE lzo
	,purpose_of_engagement VARCHAR(300)   ENCODE lzo
	,rehire_flag VARCHAR(30)   ENCODE lzo
	,requisition_id VARCHAR(300)   ENCODE lzo
	,job_posting_owner VARCHAR(300)   ENCODE lzo
	,job_posting_title VARCHAR(300)   ENCODE lzo
	,task_name VARCHAR(300)   ENCODE lzo
	,task_code VARCHAR(300)   ENCODE lzo
	,company_name VARCHAR(600)   ENCODE lzo
	,vendor_number VARCHAR(600)   ENCODE lzo
	,business_process VARCHAR(750)   ENCODE lzo
	,event_category VARCHAR(450)   ENCODE lzo
	,event_reason VARCHAR(750)   ENCODE lzo
	,leave_status NUMERIC(1,0)   ENCODE az64
	,office_type VARCHAR(450)   ENCODE lzo
	,payroll_status NUMERIC(1,0)   ENCODE az64
	,secondment_position_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_wid VARCHAR(600)   ENCODE lzo
	,grade_decrease_flag NUMERIC(1,0)   ENCODE az64
	,term_status_ind NUMERIC(1,0)   ENCODE az64
	,corrected VARCHAR(3)   ENCODE lzo
	,rescinded VARCHAR(3)   ENCODE lzo
	,orig_wid_for_correct_or_rescnd VARCHAR(765)   ENCODE lzo
	,employee_emplbuddy_grade VARCHAR(765)   ENCODE lzo
	,hr_dept_prv_key VARCHAR(765)   ENCODE lzo
	,is_data_available VARCHAR(765)   ENCODE lzo
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,business_title VARCHAR(765)   ENCODE lzo
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,total_salary_and_allowances VARCHAR(256)   ENCODE lzo
	,target_bonus_percent VARCHAR(256)   ENCODE lzo
	,annual_bonus_target_amount VARCHAR(256)   ENCODE lzo
	,stock_target_amount VARCHAR(256)   ENCODE lzo
	,stock_actual_rsu VARCHAR(765)   ENCODE lzo
	,stock_actual_psu VARCHAR(765)   ENCODE lzo
	,stock_actual_nq VARCHAR(765)   ENCODE lzo
	,stock_actual_promotion_psu VARCHAR(765)   ENCODE lzo
	,stock_currency VARCHAR(765)   ENCODE lzo
	,priority_number NUMERIC(10,4)   ENCODE az64
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_job_events owner to dbadmin;


-- gna_load_schema.fact_job_events_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_job_events_denormalized;


CREATE TABLE IF NOT EXISTS gna_load_schema.fact_job_events_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,headcount NUMERIC(10,3)   ENCODE az64
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_3 VARCHAR(6)   ENCODE lzo
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	--,level2_val VARCHAR(720)   ENCODE lzo
	--,level2_desc VARCHAR(720)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,sex_desc VARCHAR(765)   ENCODE lzo
	,veteran_status VARCHAR(765)   ENCODE lzo
	,leave_status INT   ENCODE az64
	,payroll_status INT   ENCODE az64
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,level2_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,perf_band2 VARCHAR(300)   ENCODE lzo
	,perf_band3 VARCHAR(300)   ENCODE lzo
	,position_id VARCHAR(300)   ENCODE lzo
	,emp_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,orig_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,key_performer_year_1 VARCHAR(3)   ENCODE lzo
	,key_performer_year_2 VARCHAR(3)   ENCODE lzo
	,key_performer_year_3 VARCHAR(3)   ENCODE lzo
	,supervisor_id VARCHAR(765)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)  ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)  ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE lzo
	,current_level7_emp_login VARCHAR(720)   ENCODE lzo
	,current_level8_emp_login VARCHAR(720)   ENCODE lzo
	,current_level9_emp_login VARCHAR(720)   ENCODE lzo
	,current_level10_emp_login VARCHAR(720)   ENCODE lzo
	,current_level11_emp_login VARCHAR(720)   ENCODE lzo
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,worker_id VARCHAR(765)   ENCODE lzo
	,worker_pref_name VARCHAR(765)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,total_annl_sal NUMERIC(38,10)   ENCODE az64
	,total_unvested_value NUMERIC(38,10)   ENCODE az64
	,login VARCHAR(765)   ENCODE lzo
	,level13_val VARCHAR(720)   ENCODE RAW
	,le_level1_val VARCHAR(720)     ENCODE RAW
	,le_level2_val VARCHAR(720)     ENCODE RAW
	,le_level3_val VARCHAR(720)     ENCODE RAW
	,le_level4_val VARCHAR(720)     ENCODE RAW
	,le_level5_val VARCHAR(720)     ENCODE RAW
	,le_level6_val VARCHAR(720)     ENCODE RAW
	,le_level6_desc VARCHAR(720)    ENCODE RAW
	,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE RAW
	,cc_level7_value VARCHAR(720)   ENCODE RAW
	,base_cost_center_desc VARCHAR(720)   ENCODE lzo
	,cost_center_level2_desc VARCHAR(720)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_desc VARCHAR(765)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE RAW
	,event_month_key NUMERIC(10,0)   ENCODE RAW
	,start_dt_wid NUMERIC(19,0)   ENCODE RAW
	,end_dt_wid NUMERIC(19,0)   ENCODE RAW
	,assignment_num VARCHAR(240)   ENCODE lzo
	,supervisor_evt_ind INT   ENCODE az64
	,movement_ind INT   ENCODE az64
	,grade_increase_flg VARCHAR(3)   ENCODE lzo
	,change_event_type VARCHAR(300)   ENCODE lzo
	,term_status_ind NUMERIC(1,0)   ENCODE az64
	,location_code_level1 VARCHAR(720)   ENCODE RAW
	,location_code_level2 VARCHAR(720)   ENCODE RAW
	,location_code_level3 VARCHAR(720)   ENCODE RAW
	,location_code_level4 VARCHAR(720)   ENCODE RAW
	,location_code_level5 VARCHAR(720)   ENCODE RAW
	,location_code_level6 VARCHAR(720)   ENCODE RAW
	,location_code_level7 VARCHAR(720)   ENCODE RAW
	,location_code_level8 VARCHAR(720)   ENCODE RAW
	,location_code_level9 VARCHAR(720)   ENCODE RAW
	,location_code_level10 VARCHAR(720)  ENCODE RAW
	,location_code_level11 VARCHAR(720)  ENCODE RAW
	,location_code_level12 VARCHAR(720)  ENCODE RAW
	,location_desc_level1 VARCHAR(720)   ENCODE lzo
	,location_desc_level2 VARCHAR(720)   ENCODE lzo
	,location_desc_level3 VARCHAR(720)   ENCODE lzo
	,location_desc_level4 VARCHAR(720)   ENCODE lzo
	,location_desc_level5 VARCHAR(720)   ENCODE lzo
	,location_desc_level6 VARCHAR(720)   ENCODE lzo
	,location_desc_level7 VARCHAR(720)   ENCODE lzo
	,location_desc_level8 VARCHAR(720)   ENCODE lzo
	,location_desc_level9 VARCHAR(720)   ENCODE lzo
	,location_desc_level10 VARCHAR(720)   ENCODE lzo
	,location_desc_level11 VARCHAR(720)   ENCODE lzo
	,location_desc_level12 VARCHAR(720)   ENCODE lzo
	,location_desc_level13 VARCHAR(720)   ENCODE lzo
	,event_reason_name VARCHAR(765)   ENCODE lzo
	,event_category VARCHAR(765)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,snapshot_month_end_ind INT   ENCODE az64
	,job_code VARCHAR(300)   ENCODE lzo
	,job_exempt_flg VARCHAR(3)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(450)   ENCODE lzo
	,last_promotion_date_1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,school_name VARCHAR(765)   ENCODE lzo
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,length_of_service NUMERIC(15,0)   ENCODE az64
	,people_manager_flg VARCHAR(100)   ENCODE lzo
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,source_id VARCHAR(300) NOT NULL  ENCODE lzo
	,replacement_code VARCHAR(240)   ENCODE lzo
	,category_desc VARCHAR(765)   ENCODE lzo
	,position_reason VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,attribute_type VARCHAR(765)   ENCODE lzo
	,full_time_flg VARCHAR(150)   ENCODE lzo
	,employment_status VARCHAR(48)   ENCODE lzo
	,ia_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_ind INT   ENCODE az64
	,source_type_name VARCHAR(765)   ENCODE lzo
	,max_seq_ind INT   ENCODE az64
	,snapshot_ind INT   ENCODE az64
	,grade_change_ind INT   ENCODE az64
	,employee_cat_desc VARCHAR(765)   ENCODE lzo
	,age NUMERIC(20,2)   ENCODE az64
	,building VARCHAR(765)   ENCODE lzo
	,ser_pow_band_desc VARCHAR(765)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,floor VARCHAR(765)   ENCODE lzo
	,room VARCHAR(765)   ENCODE lzo
	,awr_gilead_tenure NUMERIC(20,0)   ENCODE az64
	,salary_annl NUMERIC(18,6)   ENCODE az64
	,salary_change_percent NUMERIC(10,3)   ENCODE az64
	,salary_hour NUMERIC(18,6)   ENCODE az64
	,emp_active_flg VARCHAR(3)   ENCODE lzo
	--,"year" NUMERIC(10,0)   ENCODE az64
	--,kpi_category VARCHAR(765)   ENCODE lzo
	--,yearly_increase_target VARCHAR(765)   ENCODE lzo
	--,goal NUMERIC(10,0)   ENCODE az64
	--,gender_ethnicity VARCHAR(765)   ENCODE lzo
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,prev_pay_grade_code VARCHAR(240)   ENCODE lzo
	,prev_pay_grade_group VARCHAR(600)   ENCODE lzo
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,grade_decrease_flg VARCHAR(3)   ENCODE lzo
	,hire_event_ind INT   ENCODE az64
	,dept_change_ind INT   ENCODE az64
	,cc_change_ind INT   ENCODE az64
	,le_change_ind INT   ENCODE az64
	,location_change_ind INT   ENCODE az64
	,internal_filled_req_ind INT   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,custom_position_reason VARCHAR(600)   ENCODE lzo
	,position_key NUMERIC(10,0)   ENCODE az64
	,replacement_worker_id VARCHAR(240)   ENCODE lzo
	,annual_bonus_amount NUMERIC(18,6)   ENCODE az64
	,actual_bonus_company_share NUMERIC(18,6)   ENCODE az64
	,actual_bonus_individual_share NUMERIC(18,6)   ENCODE az64
	,stock_amount NUMERIC(18,6)   ENCODE az64
	,base_salary_50th NUMERIC(15,5)   ENCODE az64
	,current_employment_status VARCHAR(48)   ENCODE lzo
	,sector_a_from NUMERIC(15,5)   ENCODE az64
	,sector_a_to NUMERIC(15,5)   ENCODE az64
	,sector_b_from NUMERIC(15,5)   ENCODE az64
	,sector_b_to NUMERIC(15,5)   ENCODE az64
	,sector_1b_to NUMERIC(15,5)   ENCODE az64
	,sector_2b_from NUMERIC(15,5)   ENCODE az64
	,salary_midpoint NUMERIC(15,5)   ENCODE az64
	,sector_2b_to NUMERIC(15,5)   ENCODE az64
	,sector_3b_from NUMERIC(15,5)   ENCODE az64
	,sector_3b_to NUMERIC(15,5)   ENCODE az64
	,sector_c_from NUMERIC(15,5)   ENCODE az64
	,sector_c_to NUMERIC(15,5)   ENCODE az64
	,pay_grade_profile VARCHAR(240)   ENCODE lzo
	,business_title VARCHAR(765)   ENCODE lzo
	,job_family_group VARCHAR(750)   ENCODE lzo
	,payline_code VARCHAR(240)   ENCODE lzo
	,supervisor_flg VARCHAR(3)   ENCODE lzo
	,highest_degree_major VARCHAR(765)   ENCODE lzo
	,previous_job_code VARCHAR(300)   ENCODE lzo
	,previous_job_title VARCHAR(765)   ENCODE lzo
	,previous_job_family VARCHAR(765)   ENCODE lzo
	,previous_supervisor_id VARCHAR(765)   ENCODE lzo
	,previous_supervisor_name VARCHAR(765)   ENCODE lzo
	,previous_level1_emp_full_name VARCHAR(720)   ENCODE lzo
	,previous_level2_emp_full_name VARCHAR(720)   ENCODE lzo
	,previous_level3_emp_full_name VARCHAR(720)   ENCODE lzo
	,previous_level4_emp_full_name VARCHAR(720)   ENCODE lzo
	,previous_level5_emp_full_name VARCHAR(720)   ENCODE lzo
	,unvested_equity NUMERIC(10,0)   ENCODE az64
	,merit_stock_target VARCHAR(100)   ENCODE lzo
	,individual_bonus_target NUMERIC(10,0)   ENCODE az64
	,role_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,prev_position_key NUMERIC(10,0)   ENCODE az64
	,prev_position_reason VARCHAR(765)   ENCODE lzo
	,prev_job_exempt_flg VARCHAR(10)   ENCODE lzo
	,prev_cost_center_level2_desc VARCHAR(720)   ENCODE lzo
	,prev_cc_level2_value VARCHAR(720)   ENCODE lzo
	,prev_le_level2_val VARCHAR(720)   ENCODE lzo
	,prev_le_level6_desc VARCHAR(720)   ENCODE lzo
	,prev_location_code_level2 VARCHAR(720)   ENCODE lzo
	,prev_location_desc_level2 VARCHAR(765)   ENCODE lzo
	,most_recent_advancement_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,assigned_hr_business_partner VARCHAR(2295)   ENCODE lzo
	,organization_size NUMERIC(20,0)   ENCODE az64
	--,organization_size VARCHAR(2295)   ENCODE lzo
	,number_of_direct_reports NUMERIC(10,0)   ENCODE az64
	,number_of_indirect_reports NUMERIC(20,0)   ENCODE az64
	--,number_of_indirect_reports VARCHAR(2295)   ENCODE lzo
	,worker_category VARCHAR(2295)   ENCODE lzo
	,awr_work_type VARCHAR(750)   ENCODE lzo
	,vms_security_id VARCHAR(765)   ENCODE lzo
	,contract_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,contract_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,earliest_contract_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,earliest_contract_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_vendor_agency VARCHAR(765)   ENCODE lzo
	,work_order VARCHAR(765)   ENCODE lzo
	,task_name VARCHAR(765)   ENCODE lzo
	,awr_purchase_order_num VARCHAR(765)   ENCODE lzo
	,awr_requistion_num VARCHAR(765)   ENCODE lzo
	,awr_pay_rate NUMERIC(20,5)   ENCODE az64
	,awr_bill_rate NUMERIC(20,6)   ENCODE az64
	,awr_billing_currency VARCHAR(300)   ENCODE lzo
	,pay_bill_rate_frequency VARCHAR(765)   ENCODE lzo --NUMERIC(20,6)   ENCODE az64 
	,"space" VARCHAR(300)   ENCODE lzo
	,badge VARCHAR(300)   ENCODE lzo
	,awr_security_bdg_access_num VARCHAR(750)   ENCODE lzo
	,length_of_service_group VARCHAR(750)   ENCODE lzo
	,length_of_service_years NUMERIC(15,1)   ENCODE az64
	--,days_survived INTEGER   ENCODE az64
	,Official_Turnover_Reason VARCHAR(255) ENCODE lzo
	,EmpChosen_Termination_Reason VARCHAR(255) ENCODE lzo
	--,exit_survey_comments_theme VARCHAR(765) ENCODE lzo
	,Currency_Code VARCHAR(20) ENCODE lzo
	,Movement_Date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,Most_Recent_New_Role INTEGER   ENCODE az64
	,Most_Recent_Termination_Date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_rehire_date1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,term_event_ind INT   ENCODE az64
	,PREVIOUS_POSITION_ID VARCHAR(300)   ENCODE lzo
	,Previous_Cost_Center_ID  VARCHAR(240)   ENCODE lzo
	,Previous_Cost_Center_Name VARCHAR(765)   ENCODE lzo
	,Prev_Geo_Loc_Lvl_2_Name VARCHAR(720)   ENCODE lzo
	,Previous_Location_Name VARCHAR(720)   ENCODE lzo
	,PREVIOUS_COUNTRY_NAME VARCHAR(765)   ENCODE lzo
	,cc_desc VARCHAR(720)   ENCODE lzo
	,cc_legal_entity VARCHAR(720)   ENCODE lzo
	,cc_owner VARCHAR(720)   ENCODE lzo
	,functional_area VARCHAR(720)   ENCODE lzo
	,currency VARCHAR(720)   ENCODE lzo
	,product_link VARCHAR(720)   ENCODE lzo
	,market_associated VARCHAR(720)   ENCODE lzo
    ,HRYID VARCHAR(720)   ENCODE lzo
	,CC_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL2_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL3_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL4_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL5_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL6_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL7_DESC VARCHAR(720)   ENCODE lzo
	,LE_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LEVEL2_DESC_NO_MGR VARCHAR(765)   ENCODE lzo
	,prev_le_level1_val VARCHAR(720)   ENCODE lzo
	,PREV_LE_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,PREV_LE_LEVEL2_DESC VARCHAR(720)   ENCODE lzo
	,prev_le_level3_val VARCHAR(720)   ENCODE lzo
	,PREV_LE_LEVEL3_DESC VARCHAR(720)   ENCODE lzo
	,prev_le_level4_val VARCHAR(720)   ENCODE lzo
	,PREV_LE_LEVEL4_DESC VARCHAR(720)   ENCODE lzo
	,prev_le_level5_val VARCHAR(720)   ENCODE lzo
	,PREV_LE_LEVEL5_DESC VARCHAR(720)   ENCODE lzo
	,prev_le_level6_val VARCHAR(720)   ENCODE lzo
	,PREV_CC_OWNER VARCHAR(720)   ENCODE lzo
	,PAY_GRADE_NAME VARCHAR(720)   ENCODE lzo
	,TIER_CODE VARCHAR(100)   ENCODE lzo
    ,FTE NUMERIC(10,9)   ENCODE az64
    ,RESCIND_STATUS VARCHAR(255)   ENCODE lzo
    ,EXCH_RATE NUMERIC(38,10)   ENCODE az64 --NUMERIC(22,7)   ENCODE az64
	,Job_Exempt VARCHAR(10)   ENCODE lzo
	,Skills_First_or_OneTen_Emp VARCHAR(240)   ENCODE lzo
	,ETHNIC_GROUP_CUSTOM_DESC VARCHAR(720)   ENCODE lzo
	,CC_NODEVAL VARCHAR(720)   ENCODE lzo
	,CC_NODENAME VARCHAR(720)   ENCODE lzo
	,TERMINATION_DT1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	
	,VETERAN_STS_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,SNAPSHOT_KEY NUMERIC(10,0)   ENCODE az64
	,WORKER_EVENT_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,WORKER_TYPE_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,LE_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,LOC_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,PROD_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,PERF_BAND_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,SER_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,SER_BAND_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,JOB_KEY NUMERIC(10,0)   ENCODE az64
	,JOB_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,AGE_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,AGE_BAND_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,INTL_ASSGN_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,POSITION_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,MGRLEAD_PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,MGRLEAD_PERF_BAND_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,LAST_DATE_OF_MONTH_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_CC_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_DEPT_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_EMPLOYMENT_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_JOB_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_LE_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_LOC_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,BUDDY_KEY NUMERIC(10,0)   ENCODE az64
	,REFERRER_KEY NUMERIC(10,0)   ENCODE az64
	,APPLICANT_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_YEAR_KEY NUMERIC(10,0)   ENCODE az64
	,HR_DEPT_PRV_KEY VARCHAR(765)   ENCODE lzo
	,SUP_HIER_PIT_KEY NUMERIC(10,0)   ENCODE az64
	
	,JS_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TARGET_BONUS_PERCENT VARCHAR(100)   ENCODE lzo
	,STOCK_TARGET_AMOUNT VARCHAR(100)   ENCODE lzo
	,ANNUAL_BONUS_TARGET_AMOUNT VARCHAR(100)   ENCODE lzo
	,LAST_MONTH_IN_YEAR_IND INT   ENCODE az64
	--,ANNUAL_COMPENSATION_IND INT   ENCODE az64
	--,MIDYEAR_COMPENSATION_IND INT   ENCODE az64
	--,COMPENSATION_PLAN VARCHAR(100)   ENCODE lzo
	--,TOTAL_SALARY_AND_ALLOWANCES VARCHAR(100)   ENCODE lzo
	--,STOCK_ACTUAL_RSU VARCHAR(765)   ENCODE lzo
	--,STOCK_ACTUAL_PSU VARCHAR(765)   ENCODE lzo
	--,STOCK_ACTUAL_NQ  VARCHAR(765)   ENCODE lzo
	--,STOCK_ACTUAL_PROMOTION_PSU VARCHAR(765)   ENCODE lzo
	--,STOCK_CURRENCY VARCHAR(765)   ENCODE lzo
	
	,BUSINESS_PROCESS VARCHAR(765)   ENCODE lzo
	,MOST_RECENT_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,VETERAN_STATUS_US VARCHAR(765)   ENCODE lzo
	,DISABILITY_STATUS_US VARCHAR(765)   ENCODE lzo
	,HOME_SUPERVISOR_ID VARCHAR(765)   ENCODE lzo
	,HOME_SUPERVISOR_NAME VARCHAR(765)   ENCODE lzo
	,TERMINATION_CATEGORY VARCHAR(765)   ENCODE lzo
	,ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,ORIG_PERF_RATING VARCHAR(765)   ENCODE lzo
	,ORIG_PERF_RATING_PRV VARCHAR(765)   ENCODE lzo
	,talent_quadrant VARCHAR(765)   ENCODE lzo
	,talent_quadrant_prv VARCHAR(765)   ENCODE lzo
	,DAYS_SURVIVED INT   ENCODE az64
	,INTL_ASSGN_TYPE_NAME VARCHAR(765)   ENCODE lzo
	,LE_LEVEL2_DESC VARCHAR(720)   ENCODE lzo
	,LE_LEVEL3_DESC VARCHAR(720)   ENCODE lzo
	,LE_LEVEL4_DESC VARCHAR(720)   ENCODE lzo
	,LE_LEVEL5_DESC VARCHAR(720)   ENCODE lzo
	,PRODUCT_DESC_1 VARCHAR(720)   ENCODE lzo
	,PRODUCT_DESC_2 VARCHAR(720)   ENCODE lzo
	,PRODUCT_DESC_3 VARCHAR(720)   ENCODE lzo
	,PRODUCT_DESC_4 VARCHAR(720)   ENCODE lzo
	,PRODUCT_DESC_5 VARCHAR(720)   ENCODE lzo
	,BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LOCATION_CODE_LEVEL13 VARCHAR(720)   ENCODE lzo
	,job_req_tag1 VARCHAR(765)   ENCODE lzo
    ,job_req_tag2 VARCHAR(765)   ENCODE lzo
    ,job_req_tag3 VARCHAR(765)   ENCODE lzo
    ,job_req_tag4 VARCHAR(765)   ENCODE lzo
    ,job_req_tag5 VARCHAR(765)   ENCODE lzo
    ,job_req_tag6 VARCHAR(765)   ENCODE lzo
    ,job_req_tag7 VARCHAR(765)   ENCODE lzo
    ,job_req_tag8 VARCHAR(765)   ENCODE lzo
    ,job_req_tag9 VARCHAR(765)   ENCODE lzo
    ,job_req_tag10 VARCHAR(765)   ENCODE lzo
	,FULLTIME_PARTTIME VARCHAR(765)   ENCODE lzo
	,TIME_TO_FILL NUMERIC(10,0)   ENCODE az64
	,TIME_TO_HIRE NUMERIC(10,0)   ENCODE az64
	,COST_CENTER_OWNER VARCHAR(765)   ENCODE lzo
	,site_cc_level1_value VARCHAR(765)   ENCODE RAW
	,site_cc_level2_value VARCHAR(765)   ENCODE RAW
	,site_cc_level3_value VARCHAR(765)   ENCODE RAW
	,site_cc_level4_value VARCHAR(765)   ENCODE RAW
	,site_cc_level5_value VARCHAR(765)   ENCODE RAW
	,site_cc_level6_value VARCHAR(765)   ENCODE RAW
	,site_cc_level7_value VARCHAR(765)   ENCODE RAW
	,site_CC_LEVEL1_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL2_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL3_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL4_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL5_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL6_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL7_DESC VARCHAR(765)   ENCODE lzo
	,FUNCTIONAL_AREA_DESC VARCHAR(765)   ENCODE lzo
	,CC_OWNER_LEVEL1_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL2_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL3_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL4_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL5_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL6_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL7_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL8_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL9_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL10_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL11_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL1_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL2_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL3_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL4_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL5_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL6_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL7_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL8_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL9_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL10_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL11_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_LEVEL8_DESC  VARCHAR(720)   ENCODE lzo
	,cc_level8_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL1_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level1_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL2_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level2_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL3_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level3_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL4_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level4_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL5_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level5_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL6_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level6_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL7_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level7_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_CC_LEVEL8_DESC  VARCHAR(720)   ENCODE lzo
	,Previous_cc_level8_value VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL1	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL2	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL3	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL4	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL5	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL6	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL7	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL8	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL9	VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL10 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL11 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL12 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_CODE_LEVEL13 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL1  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL2  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL3  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL4  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL5  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL6  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL7  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL8  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL9  VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL10 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL11 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL12 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LOCATION_DESC_LEVEL13 VARCHAR(720)   ENCODE lzo
	,PREVIOUS_COST_CENTER_OWNER  VARCHAR(720)   ENCODE lzo
	,NEXT_TERMINATION_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_REHIRE_DATE2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE2 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE3 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE4 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE5 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE6 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE7 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE8 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE9 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LAST_JOB_CHANGE_DATE10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,PERF_BAND_DESC VARCHAR(765)  ENCODE lzo
	,PREVIOUS_PERF_BAND_DESC VARCHAR(765)  ENCODE lzo
	,EFFECTIVE_END_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MOST_RECENT_TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MOST_RECENT_NEW_ROLE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,EVENT_REASON VARCHAR(765)  ENCODE lzo
	,ACQ_COMP_NAME VARCHAR(765)  ENCODE lzo
	,WORKER_SUBTYPE VARCHAR(765)  ENCODE lzo
	,OFFR_ACPT_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,WRKFC_EVENT_CATEGORY VARCHAR(765)  ENCODE lzo
	,event_seq NUMERIC(10,0)   ENCODE az64
	,POINT_TIME_ORG_SIZE NUMERIC(20,0)   ENCODE az64
	,POINT_TIME_DIRECT_REPORTEE NUMERIC(20,0)   ENCODE az64
	,POINT_TIME_INDIRECT_ORG NUMERIC(20,0)   ENCODE az64
	,POSITION_DESC VARCHAR(765)  ENCODE lzo
	,PREVIOUS_POSITION_DESC VARCHAR(765)  ENCODE lzo
	,TALENT_ACQUISITION_HR_EXCEPTION bool
	,POSITION_CHANGE_IND BIGINT   ENCODE az64
	,JOB_CHANGE_IND BIGINT   ENCODE az64
	,SUPERVISOR_CHANGE_IND BIGINT   ENCODE az64
	,WRKFC_EVENT_REASON_NAME VARCHAR(765)   ENCODE lzo
	,WRKFC_BUSINESS_PROCESS VARCHAR(765)   ENCODE lzo
	,PROM_EVENT_IND BIGINT   ENCODE az64
	,COMPANY VARCHAR(765)   ENCODE lzo
	,OFFICE_TYPE_PRV_KEY BIGINT   ENCODE az64
	,FACT_LOC_CURR_CODE VARCHAR(100) ENCODE lzo
	,COST_CENTER_OWNER_ID VARCHAR(765)   ENCODE lzo
	,HOME_LOCATION VARCHAR(720)   ENCODE lzo
	,PREVIOUS_LEVEL1_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL2_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL3_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL4_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL5_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL6_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL7_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL8_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL9_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL10_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LEVEL11_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_PRODUCT_VALUE1 VARCHAR(765)   ENCODE lzo
	,PREVIOUS_PRODUCT_VALUE2 VARCHAR(765)   ENCODE lzo
	,PREVIOUS_PRODUCT_VALUE3 VARCHAR(765)   ENCODE lzo
	,PREVIOUS_PRODUCT_VALUE4 VARCHAR(765)   ENCODE lzo
	,PREVIOUS_PRODUCT_VALUE5 VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL1_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL2_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL3_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL4_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL5_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL6_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_SITE_CC_LEVEL7_VALUE VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL1_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL2_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL3_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL4_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL5_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL6_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL7_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL8_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL9_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL10_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_CC_OWNER_LEVEL11_EMP_LOGIN VARCHAR(765)   ENCODE lzo
	,PREVIOUS_LOC_NODEVAL VARCHAR(765)   ENCODE lzo
	,PREVIOUS_FUNCTIONAL_AREA_DESC VARCHAR(765)   ENCODE lzo
	,PREVIOUS_COMPANY VARCHAR(765)   ENCODE lzo
	,ROLE_NAME_ACCESS_LIST_PREVIOUS VARCHAR(65535)   ENCODE zstd
	,PREVIOUS_OFFICE_TYPE VARCHAR(765)  ENCODE lzo 
	,PREVIOUS_COST_CENTER_OWNER_ID VARCHAR(765)  ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,PREVIOUS_MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,PREVIOUS_MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,PREVIOUS_MKT_NODE_NAME  VARCHAR(765) ENCODE lzo	
	
)
DISTSTYLE AUTO
SORTKEY (
	start_dt_wid
	, end_dt_wid
	, level13_val
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_level1_val
	, le_level2_val
	, le_level3_val
	, le_level4_val
	, le_level5_val
	, location_code_level1
	, location_code_level2
	, location_code_level3
	, location_code_level4
	, location_code_level5
	, location_code_level6
	, location_code_level7
	, location_code_level8
	, location_code_level9
	, location_code_level10
	, location_code_level11
	, location_code_level12
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	, cc_level1_value
	, cc_level2_value
	, cc_level3_value
	, cc_level4_value
	, cc_level5_value
	, cc_level6_value
	, cc_level7_value
	)
;
ALTER TABLE gna_load_schema.fact_job_events_denormalized owner to dbadmin;

-- gna_load_schema.fact_job_events_snapshot definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_job_events_snapshot;

--DROP TABLE gna_load_schema.fact_job_events_snapshot;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_job_events_snapshot
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,worker_evt_ind NUMERIC(1,0)   ENCODE az64
	,supervisor_evt_ind NUMERIC(1,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,assignment_id VARCHAR(240)   ENCODE lzo
	,assignment_num VARCHAR(240)   ENCODE lzo
	,worker_event_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_ind NUMERIC(1,0)   ENCODE az64
	,prom_event_ind NUMERIC(1,0)   ENCODE az64
	,hire_event_ind NUMERIC(1,0)   ENCODE az64
	,term_event_ind NUMERIC(1,0)   ENCODE az64
	,event_ind NUMERIC(1,0)   ENCODE az64
	,bldg_change_ind NUMERIC(1,0)   ENCODE az64
	,scheduled_reviewcycle_ind NUMERIC(1,0)   ENCODE az64
	,outofcycle_review_ind NUMERIC(1,0)   ENCODE az64
	,annual_compensation_ind NUMERIC(1,0)   ENCODE az64
	,midyear_compensation_ind NUMERIC(1,0)   ENCODE az64
	,le_change_ind NUMERIC(1,0)   ENCODE az64
	,cc_change_ind NUMERIC(1,0)   ENCODE az64
	,employment_change_ind NUMERIC(1,0)   ENCODE az64
	,position_change_ind NUMERIC(1,0)   ENCODE az64
	,rehire_event_ind NUMERIC(1,0)   ENCODE az64
	,job_change_ind NUMERIC(1,0)   ENCODE az64
	,location_change_ind NUMERIC(1,0)   ENCODE az64
	,dept_change_ind NUMERIC(1,0)   ENCODE az64
	,supervisor_change_ind NUMERIC(1,0)   ENCODE az64
	,internal_filled_req_ind NUMERIC(1,0)   ENCODE az64
	,grade_change_ind NUMERIC(1,0)   ENCODE az64
	,movement_ind NUMERIC(1,0)   ENCODE az64
	,snapshot_ind NUMERIC(1,0)   ENCODE az64
	,snapshot_month_start_ind NUMERIC(1,0)   ENCODE az64
	,snapshot_month_end_ind NUMERIC(1,0)   ENCODE az64
	,last_month_in_qtr_ind NUMERIC(1,0)   ENCODE az64
	,last_month_in_year_ind NUMERIC(1,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,last_date_of_month_key NUMERIC(10,0)   ENCODE az64
	,orig_perf_rating VARCHAR(120)   ENCODE lzo
	,orig_perf_rating_prv VARCHAR(120)   ENCODE lzo
	,mgrlead_orig_perf_rating NUMERIC(10,3)   ENCODE az64
	,mgrlead_orig_perf_rating_prv NUMERIC(10,3)   ENCODE az64
	,worker_buddy_perf_rating NUMERIC(10,3)   ENCODE az64
	,regrettable_or_not VARCHAR(75)   ENCODE lzo
	,workday_record_entry_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,position_status VARCHAR(765)   ENCODE lzo
	,change_event_type VARCHAR(300)   ENCODE lzo
	,wrkfc_event_type VARCHAR(300)   ENCODE lzo
	,loc_curr_code VARCHAR(30)   ENCODE lzo
	,evt_change_reason VARCHAR(6000)   ENCODE lzo
	,emp_ind NUMERIC(1,0)   ENCODE az64
	,max_seq_ind NUMERIC(1,0)   ENCODE az64
	,event_seq NUMERIC(10,0)   ENCODE az64
	,headcount NUMERIC(10,3)   ENCODE az64
	,std_hours NUMERIC(10,3)   ENCODE az64
	,salary_annl NUMERIC(18,6)   ENCODE az64
	,salary_hour NUMERIC(18,6)   ENCODE az64
	,fte NUMERIC(10,9)   ENCODE az64
	,number_of_direct_reports NUMERIC(10,0)   ENCODE az64
	,salary_change_percent NUMERIC(10,3)   ENCODE az64
	,volunatry_turnover_cnt NUMERIC(10,0)   ENCODE az64
	,volunatry_turnover_rate NUMERIC(10,3)   ENCODE az64
	,global1_exchange_rate NUMERIC(10,3)   ENCODE az64
	,total_subordinate_cnt NUMERIC(10,0)   ENCODE az64
	,worker_buddy_same_dept_flg VARCHAR(3)   ENCODE lzo
	,worker_buddy_same_loc_flg VARCHAR(3)   ENCODE lzo
	,worker_buddy_grade_diff NUMERIC(10,0)   ENCODE az64
	,"region" VARCHAR(450)   ENCODE lzo
	,action_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,last_date_worked TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,pay_through_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,resignation_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,termination_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,supervisor_cc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_key NUMERIC(10,0)   ENCODE az64
	,supervisor_employment_key NUMERIC(10,0)   ENCODE az64
	,supervisor_job_key NUMERIC(10,0)   ENCODE az64
	,supervisor_le_key NUMERIC(10,0)   ENCODE az64
	,supervisor_loc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_pay_grade_key NUMERIC(10,0)   ENCODE az64
	,supervisor_perf_band_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prod_hier_key NUMERIC(10,0)   ENCODE az64
	,buddy_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,annual_bonus_amount NUMERIC(18,6)   ENCODE az64
	,stock_amount NUMERIC(18,6)   ENCODE az64
	,pay_frequency VARCHAR(60)   ENCODE lzo
	,recruiter_hier_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,time_in_position NUMERIC(10,2)   ENCODE az64
	,time_in_job_profile NUMERIC(10,2)   ENCODE az64
	,contractor_conversion_flg NUMERIC(1,0)   ENCODE az64
	,time_type_change_flg VARCHAR(3)   ENCODE lzo
	,worker_type_change_flg VARCHAR(3)   ENCODE lzo
	,grade_increase_flg VARCHAR(3)   ENCODE lzo
	,grade_decrease_flg VARCHAR(3)   ENCODE lzo
	,no_grade_change_flag VARCHAR(3)   ENCODE lzo
	,compensation_plan VARCHAR(60)   ENCODE lzo
	,actual_bonus_individual_share NUMERIC(18,6)   ENCODE az64
	,actual_bonus_company_share NUMERIC(18,6)   ENCODE az64
	,talent_quadrant VARCHAR(30)   ENCODE lzo
	,performance VARCHAR(300)   ENCODE lzo
	,potential VARCHAR(300)   ENCODE lzo
	,length_of_service NUMERIC(15,0)   ENCODE az64
	,gilead_tenure NUMERIC(15,0)   ENCODE az64
	,true_days_at_gilead NUMERIC(15,0)   ENCODE az64
	,days_onsite_per_week VARCHAR(30)   ENCODE lzo
	,emp_convesion_to_contractor VARCHAR(30)   ENCODE lzo
	,revision_owner VARCHAR(300)   ENCODE lzo
	,revision_owner_emp_id VARCHAR(30)   ENCODE lzo
	,purchase_order_num VARCHAR(300)   ENCODE lzo
	,purpose_of_engagement VARCHAR(300)   ENCODE lzo
	,rehire_flag VARCHAR(30)   ENCODE lzo
	,requisition_id VARCHAR(300)   ENCODE lzo
	,job_posting_owner VARCHAR(300)   ENCODE lzo
	,job_posting_title VARCHAR(300)   ENCODE lzo
	,task_name VARCHAR(300)   ENCODE lzo
	,task_code VARCHAR(300)   ENCODE lzo
	,company_name VARCHAR(600)   ENCODE lzo
	,vendor_number VARCHAR(600)   ENCODE lzo
	,business_process VARCHAR(750)   ENCODE lzo
	,event_category VARCHAR(450)   ENCODE lzo
	,event_reason VARCHAR(750)   ENCODE lzo
	,leave_status NUMERIC(1,0)   ENCODE az64
	,office_type VARCHAR(450)   ENCODE lzo
	,payroll_status NUMERIC(1,0)   ENCODE az64
	,secondment_position_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_wid VARCHAR(600)   ENCODE lzo
	,grade_decrease_flag NUMERIC(1,0)   ENCODE az64
	,term_status_ind NUMERIC(1,0)   ENCODE az64
	,corrected VARCHAR(3)   ENCODE lzo
	,rescinded VARCHAR(3)   ENCODE lzo
	,orig_wid_for_correct_or_rescnd VARCHAR(765)   ENCODE lzo
	,employee_emplbuddy_grade VARCHAR(765)   ENCODE lzo
	,hr_dept_prv_key VARCHAR(765)   ENCODE lzo
	,ia_update VARCHAR(3)   ENCODE lzo
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,talent_quadrant_prv VARCHAR(30)   ENCODE lzo
	,is_movement_flg VARCHAR(3)   ENCODE lzo
	,sup_hier_key_curr NUMERIC(10,0)   ENCODE az64
	,sup_hier_key_prv NUMERIC(10,0)   ENCODE az64
	,mdp_course_ind VARCHAR(30)   ENCODE lzo
	,ddp_course_ind VARCHAR(30)   ENCODE lzo
	,sdlp1_course_ind VARCHAR(30)   ENCODE lzo
	,sdlp2_course_ind VARCHAR(30)   ENCODE lzo
	,start_dt_wid NUMERIC(19,0)   ENCODE az64
	,end_dt_wid NUMERIC(19,0)   ENCODE az64
	,people_manager_flg VARCHAR(6)   ENCODE lzo
	,ia_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,home_location NUMERIC(10,0)   ENCODE az64
	,home_supervisor NUMERIC(10,0)   ENCODE az64
	,business_title VARCHAR(765)   ENCODE lzo
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,total_salary_and_allowances VARCHAR(60)   ENCODE lzo
	,target_bonus_percent VARCHAR(60)   ENCODE lzo
	,annual_bonus_target_amount VARCHAR(60)   ENCODE lzo
	,stock_target_amount VARCHAR(60)   ENCODE lzo
	,stock_actual_rsu VARCHAR(765)   ENCODE lzo
	,stock_actual_psu VARCHAR(765)   ENCODE lzo
	,stock_actual_nq VARCHAR(765)   ENCODE lzo
	,stock_actual_promotion_psu VARCHAR(765)   ENCODE lzo
	,stock_currency VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_job_events_snapshot owner to dbadmin;


-- gna_load_schema.fact_learning_course definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_learning_course;

--DROP TABLE gna_load_schema.fact_learning_course;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_learning_course
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,ld_course_name VARCHAR(750)   ENCODE lzo
	,ld_course_id VARCHAR(750)   ENCODE lzo
	,completion_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,worker_id VARCHAR(750)   ENCODE lzo
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,leave_status NUMERIC(1,0)   ENCODE az64
	,payroll_status NUMERIC(1,0)   ENCODE az64
	,office_type VARCHAR(450)   ENCODE lzo
	,length_of_service NUMERIC(15,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_dept_key NUMERIC(10,0)   ENCODE az64
	,supervisor_employment_key NUMERIC(10,0)   ENCODE az64
	,supervisor_job_key NUMERIC(10,0)   ENCODE az64
	,supervisor_loc_key NUMERIC(10,0)   ENCODE az64
	,supervisor_pay_grade_key NUMERIC(10,0)   ENCODE az64
	,supervisor_perf_band_key NUMERIC(10,0)   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,course_completed_ind VARCHAR(3)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_learning_course owner to dbadmin;


-- gna_load_schema.fact_mobility_expenses definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_mobility_expenses;

--DROP TABLE gna_load_schema.fact_mobility_expenses;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_mobility_expenses
(
	customer_id VARCHAR(765)   ENCODE lzo
	,expense_id VARCHAR(765)   ENCODE lzo
	,expense_key VARCHAR(765)   ENCODE lzo
	,service VARCHAR(765)   ENCODE lzo
	,benefit VARCHAR(765)   ENCODE lzo
	,acct_id VARCHAR(765)   ENCODE lzo
	,acct_desc VARCHAR(765)   ENCODE lzo
	,acct_num VARCHAR(765)   ENCODE lzo
	,taxstatus_usa VARCHAR(765)   ENCODE lzo
	,description VARCHAR(765)   ENCODE lzo
	,reference_num VARCHAR(765)   ENCODE lzo
	,company_paid VARCHAR(765)   ENCODE lzo
	,payee_name VARCHAR(765)   ENCODE lzo
	,payee_number VARCHAR(765)   ENCODE lzo
	,payee_type VARCHAR(765)   ENCODE lzo
	,financial_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,invoice_num NUMERIC(10,0)   ENCODE az64
	,invoice_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,billed_amount NUMERIC(10,2)   ENCODE az64
	,billed_currency VARCHAR(240)   ENCODE lzo
	,client_amount NUMERIC(10,2)   ENCODE az64
	,client_currency VARCHAR(240)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num NUMERIC(10,0)   ENCODE az64
	,receieved_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(10,0)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,file_type VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_mobility_expenses owner to dbadmin;


-- gna_load_schema.fact_position_events definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_position_events;

--DROP TABLE gna_load_schema.fact_position_events;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_position_events
(
	position_key NUMERIC(10,0)   ENCODE az64
	,hiring_mgr_key NUMERIC(10,0)   ENCODE az64
	,hiring_mgr_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,rqstn_prv_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,worker_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,worker_subtype VARCHAR(450)   ENCODE lzo
	,available_for_hire_flg VARCHAR(3)   ENCODE lzo
	,available_for_rcrt_flg VARCHAR(3)   ENCODE lzo
	,hiring_freeze_flg VARCHAR(3)   ENCODE lzo
	,availability_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,earliest_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,time_type VARCHAR(300)   ENCODE lzo
	,company_insider_type VARCHAR(300)   ENCODE lzo
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,position_id VARCHAR(240)   ENCODE lzo
	,worker_id VARCHAR(240)   ENCODE lzo
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,position_status VARCHAR(300)   ENCODE lzo
	,hashdiff VARCHAR(765)   ENCODE lzo
	,pay_grade NUMERIC(10,0)   ENCODE az64
	,worker_type VARCHAR(450)   ENCODE lzo
	,sup_hier_key NUMERIC(10,0)   ENCODE az64
	,rqstn_status VARCHAR(765)   ENCODE lzo
	,offr_acpt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_extd_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_rjct_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_cancelled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_off_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_opened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_reopened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_rescinded_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_filled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,unapproved_reqs_flg VARCHAR(30)   ENCODE lzo
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,event_seq NUMERIC(10,0)   ENCODE az64
	,source VARCHAR(300)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_position_events owner to dbadmin;


-- gna_load_schema.fact_rcrtmnt_events definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_rcrtmnt_events;

--DROP TABLE gna_load_schema.fact_rcrtmnt_events;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_rcrtmnt_events
(
	rqstn_key NUMERIC(10,0)   ENCODE az64
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,rqstn_id VARCHAR(240)   ENCODE lzo
	,applicant_id VARCHAR(240)   ENCODE lzo
	,event_class VARCHAR(300)   ENCODE lzo
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_cnt NUMERIC(10,0)   ENCODE az64
	,event_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_seq NUMERIC(10,0)   ENCODE az64
	,rcrtmnt_event_type_key NUMERIC(10,0)   ENCODE az64
	,status_key NUMERIC(10,0)   ENCODE az64
	,rcrtmnt_source_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(20,0)   ENCODE az64
	,rqstn_created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_opened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_opened_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_open_stg_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_hold_stg_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_offhold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_offhold_stg_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_cancelled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_cancelled_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_filled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_closed_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,strt_pndg_stg_cnt NUMERIC(10,0)   ENCODE az64
	,appln_strt_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,appln_term_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,appln_term_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,appln_term_invol_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,interview_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_extd_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_extd_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,offr_extd_stg_cnt NUMERIC(10,0)   ENCODE az64
	,offr_rescinded_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_rjct_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_rjct_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,offr_acpt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_acpt_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hire_evnt_cnt NUMERIC(10,0)   ENCODE az64
	,hire_stg_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_open_to_hire_days NUMERIC(10,0)   ENCODE az64
	,rqstn_open_to_offr_acpt_days NUMERIC(10,0)   ENCODE az64
	,applicant_status VARCHAR(300)   ENCODE lzo
	,appl_cnt NUMERIC(10,0)   ENCODE az64
	,appl_cwk_cnt NUMERIC(10,0)   ENCODE az64
	,appl_emp_cnt NUMERIC(10,0)   ENCODE az64
	,appl_ex_emp_cnt NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,replacement_worker_key NUMERIC(20,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,disposition_code VARCHAR(300)   ENCODE lzo
	,disposition_reason VARCHAR(765)   ENCODE lzo
	,signon_bonus NUMERIC(18,6)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,recruiter_sup_hier_key NUMERIC(10,0)   ENCODE az64
	,review_candidate_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,review_decision_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,manager_resume_review_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,recruiter_phone_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,manager_phone_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,assessment_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,additional_interview_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,reference_check_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,disposition_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,disposition_category VARCHAR(765)   ENCODE lzo
	,applicant_status_key NUMERIC(10,0)   ENCODE az64
	,employment_agreement_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,appln_strt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,disposition_flg VARCHAR(3)   ENCODE lzo
	,appl_sex_code_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_sex_desc_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_veteran_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_disability_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_race_on_rqstn VARCHAR(765)   ENCODE lzo
	,ready_for_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,fabricated_event_flg VARCHAR(3)   ENCODE lzo
	,prev_event_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,diff_in_days_prev_step NUMERIC(10,0)   ENCODE az64
	,disposition_rsn_key NUMERIC(10,0)   ENCODE az64
	,disposition_type VARCHAR(765)   ENCODE lzo
	,sup_hier_rcrt_key NUMERIC(10,0)   ENCODE az64
	,start_dt_wid NUMERIC(19,0)   ENCODE az64
	,end_dt_wid NUMERIC(19,0)   ENCODE az64
	,ta_resume_review_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,manager_resume_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,addl_interview_step_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,interview_assessment_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,genderidentity VARCHAR(765)   ENCODE lzo
	,sexualorientation VARCHAR(765)   ENCODE lzo
	,recruiting_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64 
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_rcrtmnt_events owner to dbadmin;


-- gna_load_schema.fact_rcrtmnt_events_slates definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_rcrtmnt_events_slates;

--DROP TABLE gna_load_schema.fact_rcrtmnt_events_slates;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_rcrtmnt_events_slates
(
	us_score NUMERIC(1,0)   ENCODE az64
	,nonus_score NUMERIC(1,0)   ENCODE az64
	,female_score NUMERIC(1,0)   ENCODE az64
	,ethnic_group_score NUMERIC(1,0)   ENCODE az64
	,ethnic_hispanic_score NUMERIC(1,0)   ENCODE az64
	,ethnic_black_score NUMERIC(1,0)   ENCODE az64
	,ethnic_asian_score NUMERIC(1,0)   ENCODE az64
	,disability_score NUMERIC(1,0)   ENCODE az64
	,veteranstatus_score NUMERIC(1,0)   ENCODE az64
	,ethnic_group_final VARCHAR(765)   ENCODE lzo
	,veteran_status_final VARCHAR(765)   ENCODE lzo
	,disability_final VARCHAR(765)   ENCODE lzo
	,gender_final VARCHAR(765)   ENCODE lzo
	,event_dt_key VARCHAR(24)   ENCODE lzo
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_cnt NUMERIC(10,0)   ENCODE az64
	,event_seq NUMERIC(10,0)   ENCODE az64
	,rcrtmnt_event_type_key NUMERIC(10,0)   ENCODE az64
	,status_key NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_prv_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,replacement_worker_key NUMERIC(20,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,recruiter_sup_hier_key NUMERIC(10,0)   ENCODE az64
	,applicant_id VARCHAR(765)   ENCODE lzo
	,rcrtmnt_source_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,referrer_key NUMERIC(10,0)   ENCODE az64
	,disposition_rsn_key NUMERIC(10,0)   ENCODE az64
	,fabricated_event_flg VARCHAR(3)   ENCODE lzo
	,disposition_flg VARCHAR(3)   ENCODE lzo
	,event_class VARCHAR(300)   ENCODE lzo
	,disposition_code VARCHAR(300)   ENCODE lzo
	,disposition_reason VARCHAR(765)   ENCODE lzo
	,disposition_category VARCHAR(765)   ENCODE lzo
	,appl_sex_code_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_sex_desc_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_veteran_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_disability_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_race_on_rqstn VARCHAR(765)   ENCODE lzo
	,worker_key NUMERIC(20,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,employee_disability VARCHAR(765)   ENCODE lzo
	,employee_ethinicity VARCHAR(765)   ENCODE lzo
	,employee_gender VARCHAR(765)   ENCODE lzo
	,employee_veteran VARCHAR(765)   ENCODE lzo
	,employee_id NUMERIC(10,0)   ENCODE az64
	,employee_name VARCHAR(765)   ENCODE lzo
	,empl_rqstn_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_rcrtmnt_events_slates owner to dbadmin;


-- gna_load_schema.fact_rcrtmnt_events_slates_t1 definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_rcrtmnt_events_slates_t1;

--DROP TABLE gna_load_schema.fact_rcrtmnt_events_slates_t1;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_rcrtmnt_events_slates_t1
(
	"WORKER_TYPE_KEY" NUMERIC(10,0)   ENCODE az64
	,"REPLACEMENT_WORKER_KEY" NUMERIC(20,0)   ENCODE az64
	,"US_SCORE" NUMERIC(1,0)   ENCODE az64
	,"NONUS_SCORE" NUMERIC(1,0)   ENCODE az64
	,"FEMALE_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_GROUP_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_HISPANIC_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_BLACK_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_ASIAN_SCORE" NUMERIC(1,0)   ENCODE az64
	,"DISABILITY_SCORE" NUMERIC(1,0)   ENCODE az64
	,"VETERANSTATUS_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_AMIND_AKNAT_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_NATHI_OTHPACISN_SCORE" NUMERIC(1,0)   ENCODE az64
	,"ETHNIC_TWO_OR_MORE_RACES_SCORE" NUMERIC(1,0)   ENCODE az64
	,"LESBIAN_SCORE" NUMERIC(1,0)   ENCODE az64
	,"GAY_SCORE" NUMERIC(1,0)   ENCODE az64
	,"BISEXUAL_SCORE" NUMERIC(1,0)   ENCODE az64
	,"TRANSGENDER_SCORE" NUMERIC(1,0)   ENCODE az64
	,"RQSTN_KEY_APP" NUMERIC(10,0)   ENCODE az64
	,"APPLICANT_KEY" NUMERIC(10,0)   ENCODE az64
	,"APPLICANT_ID" VARCHAR(240)   ENCODE lzo
	,"DISPOSITION_RSN_KEY" NUMERIC(10,0)   ENCODE az64
	,"RCRTMNT_EVENT_TYPE_KEY" NUMERIC(10,0)   ENCODE az64
	,"EVENT_CLASS" VARCHAR(300)   ENCODE lzo
	,"DISPOSITION_CODE" VARCHAR(300)   ENCODE lzo
	,"DISPOSITION_REASON" VARCHAR(765)   ENCODE lzo
	,"APPL_RACE_ON_RQSTN" VARCHAR(765)   ENCODE lzo
	,"APPL_SEX_DESC_ON_RQSTN" VARCHAR(765)   ENCODE lzo
	,"APPL_VETERAN_STS_ON_RQSTN" VARCHAR(765)   ENCODE lzo
	,"APPL_DISABILITY_STS_ON_RQSTN" VARCHAR(765)   ENCODE lzo
	,"GENDERIDENTITY" VARCHAR(765)   ENCODE lzo
	,"SEXUALORIENTATION" VARCHAR(765)   ENCODE lzo
	,"RCRTMNT_SOURCE_KEY" NUMERIC(10,0)   ENCODE az64
	,"DISABILITY_DEMOGRAPHIC_KEY" NUMERIC(10,0)   ENCODE az64
	,"VETERAN_STS_DEMOGRAPHIC_KEY" NUMERIC(10,0)   ENCODE az64
	,"RQSTN_KEY" NUMERIC(10,0)   ENCODE az64
	,"RQSTN_ID" VARCHAR(240)   ENCODE lzo
	,"EFFECTIVE_START_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"EFFECTIVE_END_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"STATUS_KEY" NUMERIC(10,0)   ENCODE az64
	,"WORKER_KEY" NUMERIC(10,0)   ENCODE az64
	,"RECRUITER_KEY" NUMERIC(10,0)   ENCODE az64
	,"SUPERVISOR_KEY" NUMERIC(10,0)   ENCODE az64
	,"SUPERVISOR_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"DEPT_KEY" NUMERIC(10,0)   ENCODE az64
	,"DEPT_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"LOC_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"CC_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"LE_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"PROD_HIER_KEY" NUMERIC(10,0)   ENCODE az64
	,"JOB_KEY" NUMERIC(10,0)   ENCODE az64
	,"PAY_GRADE_KEY" NUMERIC(10,0)   ENCODE az64
	,"POSITION_KEY" NUMERIC(10,0)   ENCODE az64
	,"EVENT_DT_KEY" NUMERIC(10,0)   ENCODE az64
	,"START_DT_WID" NUMERIC(19,0)   ENCODE az64
	,"END_DT_WID" NUMERIC(19,0)   ENCODE az64
	,"SUP_HIER_RCRT_KEY" NUMERIC(10,0)   ENCODE az64
	,"RQSTN_CREATED_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"RQSTN_OPENED_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"RQSTN_HOLD_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"RQSTN_OFFHOLD_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"RQSTN_FILLED_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"HIRE_DT" TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,"ETHNIC_GROUP_PREFINAL" VARCHAR(765)   ENCODE lzo
	,"VETERAN_STATUS_PREFINAL" VARCHAR(765)   ENCODE lzo
	,"DISABILITY_PREFINAL" VARCHAR(765)   ENCODE lzo
	,"GENDER_PREFINAL" VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_rcrtmnt_events_slates_t1 owner to dbadmin;


-- gna_load_schema.fact_rec_events_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_rec_events_denormalized;

--DROP TABLE gna_load_schema.fact_rec_events_denormalized;


CREATE TABLE IF NOT EXISTS gna_load_schema.fact_rec_events_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,event_class VARCHAR(300)   ENCODE lzo
	,applicant_id VARCHAR(765)   ENCODE lzo
	,applicant_name VARCHAR(765)   ENCODE lzo
	,source_code VARCHAR(765)   ENCODE lzo
	,source_type_name VARCHAR(765)   ENCODE lzo
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	--,dept_hier_level2_code VARCHAR(720)   ENCODE lzo
	--,dept_hier_level2_desc VARCHAR(720)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,rqstn_created_dt TIMESTAMP WITHOUT TIME ZONE ENCODE az64
	,offr_acpt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,offr_extd_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,req_filled_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_posting_title VARCHAR(600)   ENCODE lzo
	,js_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_id VARCHAR(300)   ENCODE lzo
	,req_status VARCHAR(48)   ENCODE lzo
	,replacement_code VARCHAR(240)   ENCODE lzo
	,rqstn_opened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_off_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,replacement_worker_id VARCHAR(240)   ENCODE lzo
	,replacement_name VARCHAR(765)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,level2_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,position_id VARCHAR(300)   ENCODE lzo
	,custom_position_reason VARCHAR(600)   ENCODE lzo
	,recruiter_num VARCHAR(765)   ENCODE lzo
	,recruiter_name VARCHAR(765)   ENCODE lzo
	,x_custom VARCHAR(30)   ENCODE lzo
	,supervisor_num VARCHAR(765)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,pending_approval NUMERIC(38,10)   ENCODE az64
	,rqstn_open NUMERIC(38,10)   ENCODE az64
	,on_hold NUMERIC(38,10)   ENCODE az64
	,country_code VARCHAR(765)   ENCODE lzo
	,job_key NUMERIC(10,0)   ENCODE az64
	,w_event_code VARCHAR(150)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE  RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE  RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,level1_desc VARCHAR(720)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,level3_desc VARCHAR(720)   ENCODE lzo
	,level4_desc VARCHAR(720)   ENCODE lzo
	,level5_desc VARCHAR(720)   ENCODE lzo
	,level6_desc VARCHAR(720)   ENCODE lzo
	,level7_desc VARCHAR(720)   ENCODE lzo
	,level8_desc VARCHAR(720)   ENCODE lzo
	,level9_desc VARCHAR(720)   ENCODE lzo
	,level10_desc VARCHAR(720)   ENCODE lzo
	,level11_desc VARCHAR(720)   ENCODE lzo
	,level12_desc VARCHAR(720)   ENCODE lzo
	,level13_desc VARCHAR(720)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE  RAW
	,level2_val VARCHAR(720)   ENCODE  RAW
	,level3_val VARCHAR(720)   ENCODE  RAW
	,level4_val VARCHAR(720)   ENCODE  RAW
	,level5_val VARCHAR(720)   ENCODE  RAW
	,level6_val VARCHAR(720)   ENCODE  RAW
	,level7_val VARCHAR(720)   ENCODE  RAW
	,level8_val VARCHAR(720)   ENCODE  RAW
	,level9_val VARCHAR(720)   ENCODE  RAW
	,level10_val VARCHAR(720)   ENCODE RAW
	,level11_val VARCHAR(720)   ENCODE RAW
	,level12_val VARCHAR(720)   ENCODE RAW
	,level13_val VARCHAR(720)   ENCODE RAW
	,cc_hier_level1 VARCHAR(720)   ENCODE RAW
	,cc_hier_level2 VARCHAR(720)   ENCODE RAW
	,cc_hier_level3 VARCHAR(720)   ENCODE RAW
	,cc_hier_level4 VARCHAR(720)   ENCODE RAW
	,cc_hier_level5 VARCHAR(720)   ENCODE RAW
	,cc_hier_level6 VARCHAR(720)   ENCODE RAW
	,cc_hier_level7 VARCHAR(720)   ENCODE lzo
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,le_hier_level1_val VARCHAR(720)   ENCODE RAW
	,le_hier_level2_val VARCHAR(720)   ENCODE RAW
	,le_hier_level3_val VARCHAR(720)   ENCODE RAW
	,le_hier_level4_val VARCHAR(720)   ENCODE RAW
	,le_hier_level5_val VARCHAR(720)   ENCODE RAW
	,le_hier_level6_val VARCHAR(720)   ENCODE RAW
	,le_hier_level1_desc VARCHAR(720)   ENCODE lzo
	,le_hier_level2_desc VARCHAR(720)   ENCODE lzo
	,le_hier_level3_desc VARCHAR(720)   ENCODE lzo
	,le_hier_level4_desc VARCHAR(720)   ENCODE lzo
	,le_hier_level5_desc VARCHAR(720)   ENCODE lzo
	,le_hier_level6_desc VARCHAR(720)   ENCODE lzo
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,rqstn_name VARCHAR(240)   ENCODE lzo
	,event_cnt NUMERIC(10,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,w_stage_code VARCHAR(150)   ENCODE lzo
	,hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,w_sub_stage_code VARCHAR(150)   ENCODE lzo
	,start_dt_wid NUMERIC(19,0)   ENCODE RAW
	,end_dt_wid NUMERIC(19,0)   ENCODE RAW
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,SEX_DESC VARCHAR(765)   ENCODE lzo
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,candidate_type VARCHAR(765)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,DEMOGRAPHIC_DESC_CUSTOM VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,disposition_reason VARCHAR(765)   ENCODE lzo
	,disposition_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,disposition_category VARCHAR(765)   ENCODE lzo
	,disposition_code VARCHAR(300)   ENCODE lzo
	,disposition_flg VARCHAR(3)   ENCODE lzo
	,manager_resume_review_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,recruiter_phone_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ta_resume_review_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,assessment_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,manager_phone_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,manager_resume_screen_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,review_decision_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,referrer_worker_id VARCHAR(765)   ENCODE lzo
	,referrer_name VARCHAR(765)   ENCODE lzo
	,ADDL_INTERVIEW_STEP_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ADDITIONAL_INTERVIEW_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,INTERVIEW_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_family_code VARCHAR(300)   ENCODE lzo
	,status_desc VARCHAR(765)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_exempt_flg VARCHAR(10)   ENCODE lzo
	--,full_time_flg VARCHAR(150)   ENCODE lzo
	,fulltime_parttime VARCHAR(150)   ENCODE lzo
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,rqstn_reopened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,total_applicants INT8   ENCODE lzo
	,total_active_applicants INT8   ENCODE lzo
	,total_diverse_applicants VARCHAR(60)   ENCODE lzo
	,time_to_fill VARCHAR(765)   ENCODE lzo
	--,time_to_fill  NUMERIC(10,0)  ENCODE az64
	,job_req_comments VARCHAR(765)   ENCODE lzo
	,job_req_comments_author_name VARCHAR(765)   ENCODE lzo
	,job_req_comments_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,attribute_type VARCHAR(765)   ENCODE lzo
	,worker_key NUMERIC(38,10)   ENCODE az64
	,hire_evnt_cnt NUMERIC(38,10)   ENCODE az64
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,appl_race_on_rqstn VARCHAR(765)   ENCODE lzo
	,dim_rcrtmnt_evt_key NUMERIC(10,0)   ENCODE az64
	,appl_veteran_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_disability_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appln_strt_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,reference_check_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,interview_assessment_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,appl_stage_wd VARCHAR(765)   ENCODE lzo
	,appl_step_wd VARCHAR(765)   ENCODE lzo
	,appl_sex_desc_on_rqstn VARCHAR(765)   ENCODE lzo
	,budget_id VARCHAR(240)   ENCODE lzo
	,rqstn_filled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_closed_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,status_code VARCHAR(240)   ENCODE lzo
	,awr_gilead_tenure NUMERIC(38,10)   ENCODE az64
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,assignment_num NUMERIC(38,10)   ENCODE az64
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,perf_band2 VARCHAR(300)   ENCODE lzo
	,perf_band3 VARCHAR(300)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_3 VARCHAR(6)   ENCODE lzo
	,job_title VARCHAR(765)   ENCODE lzo
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	--,time_to_hire_req VARCHAR(720)   ENCODE lzo
	,time_to_hire_req NUMERIC(10,0)   ENCODE az64
	,cost_center_name VARCHAR(720)   ENCODE lzo
	,primary_sourcer1 VARCHAR(765)   ENCODE lzo
	,primary_sourcer1_name VARCHAR(765)   ENCODE lzo
	,school_name VARCHAR(765)   ENCODE lzo
	,age NUMERIC(38,10)   ENCODE az64
	,orig_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hiest_edu_deg_name VARCHAR(765)   ENCODE lzo
	,employment_stat_desc VARCHAR(765)   ENCODE lzo
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,sup_supervisor_flg VARCHAR(3)   ENCODE lzo
	,applicant_supervisor_flg VARCHAR(3)   ENCODE lzo
	,offer_accepted NUMERIC(38,10)   ENCODE az64
	,total_no_of_offer NUMERIC(38,10)   ENCODE az64
	,birth_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,DAYS_OPEN NUMERIC(10,0)   ENCODE az64
	,Offer_Acceptance_Rate VARCHAR(765)   ENCODE lzo
	,Has_Diverse_Slate VARCHAR(765)   ENCODE lzo
	,Skills_First_Qualified_Req VARCHAR(765)   ENCODE lzo
	,assigned_hr_business_partner VARCHAR(765)   ENCODE lzo
	,rqstn_open_stg_cnt NUMERIC(10,0)   ENCODE az64
	,position_reason VARCHAR(255)   ENCODE lzo
	,hiring_manager_name VARCHAR(765)   ENCODE lzo
	,hiring_mgr_worker_id VARCHAR(100)   ENCODE lzo
	,recruiter_worker_id VARCHAR(100)   ENCODE lzo
	,hired_applicant_id VARCHAR(100)   ENCODE lzo
	,location VARCHAR(765)   ENCODE lzo
	,Hired_Applicant_Worker_ID VARCHAR(765)   ENCODE lzo
	,cc_desc VARCHAR(720)   ENCODE lzo
	,cc_legal_entity VARCHAR(720)   ENCODE lzo
	,cc_owner VARCHAR(720)   ENCODE lzo
	,functional_area VARCHAR(720)   ENCODE lzo
	,currency VARCHAR(720)   ENCODE lzo
	,product_link VARCHAR(720)   ENCODE lzo
	,market_associated VARCHAR(720)   ENCODE lzo
    ,HRYID VARCHAR(720)   ENCODE lzo
	,EFFECTIVE_START_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,CC_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL2_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL3_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL4_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL5_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL6_DESC VARCHAR(720)   ENCODE lzo
	,CC_LEVEL7_DESC VARCHAR(720)   ENCODE lzo
	,LE_LEVEL1_DESC VARCHAR(720)   ENCODE lzo
	,APPLIACNT_DISABILITY_STATUS VARCHAR(765)   ENCODE lzo
	,APPLICANT_VETERAN_STATUS VARCHAR(765)   ENCODE lzo
	,APPLICANT_NUM VARCHAR(765)   ENCODE lzo
	,POSITION_TYPE VARCHAR(765)   ENCODE lzo
	,DISPOSITION_STAGE VARCHAR(765)   ENCODE lzo
	,status_key NUMERIC(10,0)   ENCODE az64
	,CC_NODEVAL VARCHAR(765)   ENCODE lzo
	,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,WORKER_ID VARCHAR(765)   ENCODE lzo
	,WORKER_NAME VARCHAR(765)   ENCODE lzo
	,RECRUITER_ETHNICITY VARCHAR(765)   ENCODE lzo
	,APPLICANT_ETHNICITY VARCHAR(765)   ENCODE lzo
	
	,RCRTMNT_EVENT_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,RCRTMNT_SOURCE_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,LOC_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,CC_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,LE_HIER_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,JOB_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,POSITION_KEY NUMERIC(10,0)   ENCODE az64
	,POSITION_PRV_KEY NUMERIC(10,0)   ENCODE az64
	,REPLACEMENT_WORKER_KEY NUMERIC(20,0)   ENCODE az64
	,SNAPSHOT_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_MONTH_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_QTR_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_YEAR_KEY NUMERIC(10,0)   ENCODE az64
	,DISABILITY_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,VETERAN_STS_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,REFERRER_KEY NUMERIC(10,0)   ENCODE az64
	,SUP_HIER_PIT_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_SUP_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,APPLICANT_STATUS_KEY NUMERIC(10,0)   ENCODE az64
	,DISPOSITION_RSN_KEY NUMERIC(10,0)   ENCODE az64
	,SUP_HIER_RCRT_KEY NUMERIC(10,0)   ENCODE az64
	,PRODUCT_DESC_1 VARCHAR(765)   ENCODE lzo
	,PRODUCT_DESC_2 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_3 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_4 VARCHAR(765)   ENCODE lzo
    ,PRODUCT_DESC_5 VARCHAR(765)   ENCODE lzo
	,job_req_tag1 VARCHAR(765)   ENCODE lzo
    ,job_req_tag2 VARCHAR(765)   ENCODE lzo
    ,job_req_tag3 VARCHAR(765)   ENCODE lzo
    ,job_req_tag4 VARCHAR(765)   ENCODE lzo
    ,job_req_tag5 VARCHAR(765)   ENCODE lzo
    ,job_req_tag6 VARCHAR(765)   ENCODE lzo
    ,job_req_tag7 VARCHAR(765)   ENCODE lzo
    ,job_req_tag8 VARCHAR(765)   ENCODE lzo
    ,job_req_tag9 VARCHAR(765)   ENCODE lzo
    ,job_req_tag10 VARCHAR(765)  ENCODE lzo
	,MOST_RECENT_ADVANCEMENT_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,EVENT_SEQ NUMERIC(10,0)   ENCODE az64
	,LOGIN VARCHAR(765)  ENCODE lzo
	,COST_CENTER_OWNER VARCHAR(765)   ENCODE lzo
	,site_cc_level1_value VARCHAR(765)   ENCODE RAW
	,site_cc_level2_value VARCHAR(765)   ENCODE RAW
	,site_cc_level3_value VARCHAR(765)   ENCODE RAW
	,site_cc_level4_value VARCHAR(765)   ENCODE RAW
	,site_cc_level5_value VARCHAR(765)   ENCODE RAW
	,site_cc_level6_value VARCHAR(765)   ENCODE RAW
	,site_cc_level7_value VARCHAR(765)   ENCODE RAW
	,site_CC_LEVEL1_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL2_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL3_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL4_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL5_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL6_DESC VARCHAR(765)   ENCODE lzo
	,site_CC_LEVEL7_DESC VARCHAR(765)   ENCODE lzo
	,FUNCTIONAL_AREA_DESC VARCHAR(765)   ENCODE lzo
	,CC_OWNER_LEVEL1_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL2_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL3_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL4_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL5_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL6_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL7_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL8_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL9_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL10_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL11_EMP_FULL_NAME VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL1_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL2_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL3_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL4_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL5_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL6_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL7_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL8_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL9_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL10_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,CC_OWNER_LEVEL11_EMP_LOGIN VARCHAR(720)   ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,JOB_REQ_STAGE VARCHAR(765)  ENCODE lzo
	,FACT_OFFR_EXTD_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,FACT_OFFR_ACPT_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,WORKER_SEX_DESC VARCHAR(765)  ENCODE lzo
	,WORKER_SEXUAL_ORIENTATION VARCHAR(765)  ENCODE lzo
	,WORKER_VETERAN_STATUS VARCHAR(765)  ENCODE lzo
	,WORKER_DISABILITY_STATUS VARCHAR(765)  ENCODE lzo
	,WORKER_GENDER_IDENTITY VARCHAR(765)  ENCODE lzo
	,WORKER_ORIG_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,COMPANY VARCHAR(765)  ENCODE lzo
	,COST_CENTER_OWNER_ID VARCHAR(765)   ENCODE lzo
	,CONFIDENTIAL_JOB VARCHAR(765)  ENCODE lzo
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
)
DISTSTYLE AUTO
 SORTKEY (
	start_dt_wid
	, end_dt_wid
	, level13_val
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level6_emp_login
	, current_level7_emp_login
	, current_level8_emp_login
	, current_level9_emp_login
	, current_level10_emp_login
	, current_level11_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_hier_level1_val
	, le_hier_level2_val
	, le_hier_level3_val
	, le_hier_level4_val
	, le_hier_level5_val
	, level1_val
	, level2_val
	, level3_val
	, level4_val
	, level5_val
	, level6_val
	, level7_val
	, level8_val
	, level9_val
	, level10_val
	, level11_val
	, level12_val
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	, cc_hier_level1
	, cc_hier_level2
	, cc_hier_level3
	, cc_hier_level4
	, cc_hier_level5
	, cc_hier_level6
	)
;
ALTER TABLE gna_load_schema.fact_rec_events_denormalized owner to dbadmin;

-- gna_load_schema.fact_rec_events_slates_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_rec_events_slates_denormalized;

--DROP TABLE gna_load_schema.fact_rec_events_slates_denormalized;


CREATE TABLE IF NOT EXISTS gna_load_schema.fact_rec_events_slates_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	,dept_hier_level2_code VARCHAR(720)   ENCODE lzo
	,dept_hier_level2_desc VARCHAR(720)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,job_posting_title VARCHAR(600)   ENCODE lzo
	,replacement_code VARCHAR(240)   ENCODE lzo
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,level1_val VARCHAR(720)   ENCODE RAW
	,level2_val VARCHAR(720)   ENCODE RAW
	,level3_val VARCHAR(720)   ENCODE RAW
	,level4_val VARCHAR(720)   ENCODE RAW
	,level5_val VARCHAR(720)   ENCODE RAW
	,level6_val VARCHAR(720)   ENCODE RAW
	,level7_val VARCHAR(720)   ENCODE RAW
	,level8_val VARCHAR(720)   ENCODE RAW
	,level9_val VARCHAR(720)   ENCODE RAW
	,level10_val VARCHAR(720)   ENCODE RAW
	,level11_val VARCHAR(720)   ENCODE RAW
	,level12_val VARCHAR(720)   ENCODE RAW
	,level13_val VARCHAR(720)   ENCODE RAW
	,loc_hier_level2_desc VARCHAR(765)   ENCODE lzo
	,loc_hier_level8_desc VARCHAR(720)   ENCODE lzo
	,custom_position_reason VARCHAR(600)   ENCODE lzo
	,employee_num VARCHAR(765)   ENCODE lzo
	,pref_full_name VARCHAR(765)   ENCODE lzo
	,recruiter_emp_num VARCHAR(765)   ENCODE lzo
	,recruiter_name VARCHAR(765)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,le_level1_val VARCHAR(720)   ENCODE RAW
	,le_level2_val VARCHAR(720)   ENCODE RAW
	,le_level3_val VARCHAR(720)   ENCODE RAW
	,le_level4_val VARCHAR(720)   ENCODE RAW
	,le_level5_val VARCHAR(720)   ENCODE RAW
	,le_level6_val VARCHAR(720)   ENCODE RAW
	,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE lzo
	,cc_level7_value VARCHAR(720)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,attr_misc_code VARCHAR(765)   ENCODE lzo
	,job_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,start_dt_wid NUMERIC(19,0)   ENCODE RAW
	,end_dt_wid NUMERIC(19,0)   ENCODE RAW
	,veteranstatus_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,ethnic_hispanic_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,female_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,disability_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,ethnic_asian_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,ethnic_black_score NUMERIC(1,0)   ENCODE az64 --NUMERIC(38,10)   ENCODE az64
	,appl_veteran_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,appl_disability_sts_on_rqstn VARCHAR(765)   ENCODE lzo
	,sexualorientation VARCHAR(765)   ENCODE lzo
	,req_status VARCHAR(48)   ENCODE lzo
	,rqstn_id VARCHAR(300) NOT NULL  ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,minority_applicant INTEGER   ENCODE az64
	,female_applicant INTEGER   ENCODE az64
	,job_title VARCHAR(765)   ENCODE lzo
	,candidate_type VARCHAR(765)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,SEX_DESC VARCHAR(765)   ENCODE lzo
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,cost_center_name VARCHAR(720)   ENCODE lzo
	,job_family_code VARCHAR(300)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,w_stage_code VARCHAR(150)   ENCODE lzo
	,w_sub_stage_code VARCHAR(150)   ENCODE lzo
	,total_applicants VARCHAR(60)   ENCODE lzo
	,rqstn_created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_opened_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_hold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_offhold_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,rqstn_filled_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,cc_nodeval VARCHAR(765)   ENCODE lzo
	,cc_nodename VARCHAR(765)   ENCODE lzo
	,SUP_HIER_RCRT_KEY NUMERIC(10,0)   ENCODE az64
	,POSITION_KEY NUMERIC(10,0)   ENCODE az64
	,PAY_GRADE_KEY NUMERIC(10,0)   ENCODE az64
	,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_KEY NUMERIC(10,0)   ENCODE az64
	,SUPERVISOR_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_KEY NUMERIC(10,0)   ENCODE az64
	,WORKER_KEY NUMERIC(10,0)   ENCODE az64
	,STATUS_KEY NUMERIC(10,0)   ENCODE az64
	,RQSTN_KEY NUMERIC(10,0)   ENCODE az64
	,VETERAN_STS_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,DISABILITY_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,RCRTMNT_SOURCE_KEY NUMERIC(10,0)   ENCODE az64
	,RCRTMNT_EVENT_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,DISPOSITION_RSN_KEY NUMERIC(10,0)   ENCODE az64
	,APPLICANT_KEY NUMERIC(10,0)   ENCODE az64
	,REPLACEMENT_WORKER_KEY NUMERIC(20,0)   ENCODE az64
	,WORKER_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,LOGIN VARCHAR(765)   ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	
)
DISTSTYLE AUTO
 SORTKEY (
	start_dt_wid
	, end_dt_wid
	, level13_val
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level6_emp_login
	, current_level7_emp_login
	, current_level8_emp_login
	, current_level9_emp_login
	, current_level10_emp_login
	, current_level11_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_level1_val
	, le_level2_val
	, le_level3_val
	, le_level4_val
	, le_level5_val
	, level1_val
	, level2_val
	, level3_val
	, level4_val
	, level5_val
	, level6_val
	, level7_val
	, level8_val
	, level9_val
	, level10_val
	, level11_val
	, level12_val
	, cc_level1_value
	, cc_level2_value
	, cc_level3_value
	, cc_level4_value
	, cc_level5_value
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	)
;
ALTER TABLE gna_load_schema.fact_rec_events_slates_denormalized owner to dbadmin;

-- gna_load_schema.fact_succession_plan_dtl definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_succession_plan_dtl;

--DROP TABLE gna_load_schema.fact_succession_plan_dtl;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_succession_plan_dtl
(
	succession_plan_id VARCHAR(765)   ENCODE lzo
	,position_key NUMERIC(10,0)   ENCODE az64
	,nominated_by_worker_key NUMERIC(10,0)   ENCODE az64
	,nominee_worker_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,succession_strategy VARCHAR(12000)   ENCODE lzo
	,readiness VARCHAR(12000)   ENCODE lzo
	,succession_last_updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,top_candidate_flg VARCHAR(3)   ENCODE lzo
	,temp_fill_flg VARCHAR(3)   ENCODE lzo
	,inactive_flg VARCHAR(3)   ENCODE lzo
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,position_id VARCHAR(765)   ENCODE lzo
	,nominated_by_worker_id VARCHAR(765)   ENCODE lzo
	,nominee_worker_id VARCHAR(765)   ENCODE lzo
	,nb_dept_key NUMERIC(10,0)   ENCODE az64
	,nb_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,nb_loc_hier_key NUMERIC(10,0)   ENCODE az64
	,nb_cc_hier_key NUMERIC(10,0)   ENCODE az64
	,nb_le_hier_key NUMERIC(10,0)   ENCODE az64
	,nw_dept_key NUMERIC(10,0)   ENCODE az64
	,nw_dept_hier_key NUMERIC(10,0)   ENCODE az64
	,nw_loc_hier_key NUMERIC(10,0)   ENCODE az64
	,nw_cc_hier_key NUMERIC(10,0)   ENCODE az64
	,nw_le_hier_key NUMERIC(10,0)   ENCODE az64
	,nominee_position_id VARCHAR(765)   ENCODE lzo
	,nominee_position_key NUMERIC(15,0)   ENCODE az64
	,notes VARCHAR(12000)   ENCODE lzo
	,nb_job_key NUMERIC(15,0)   ENCODE az64
	,nb_pay_grade_key NUMERIC(15,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_succession_plan_dtl owner to dbadmin;


-- gna_load_schema.fact_upd_feedback_survey definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_upd_feedback_survey;

--DROP TABLE gna_load_schema.fact_upd_feedback_survey;
CREATE TABLE IF NOT EXISTS gna_load_schema.fact_upd_feedback_survey
(
	mgr_worker_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,effective_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,survey_ques_key NUMERIC(10,0)   ENCODE az64
	,survey_ques_ans VARCHAR(12000)   ENCODE lzo
	,record_type VARCHAR(765)   ENCODE lzo
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,mgr_sup_hier_key NUMERIC(10,0)   ENCODE az64
	,mgr_sup_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,mgr_sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,worker_event_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,load_key NUMERIC(10,0)   ENCODE az64
	,source_id VARCHAR(300)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,datasource_name VARCHAR(240)   ENCODE lzo
	,received_file_name VARCHAR(765)   ENCODE lzo
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,worker_id VARCHAR(240)   ENCODE lzo
	,mgr_worker_id VARCHAR(240)   ENCODE lzo
	,number_of_invites VARCHAR(765)   ENCODE lzo
	,number_of_responses VARCHAR(765)   ENCODE lzo
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,self_rating VARCHAR(3)   ENCODE lzo
	,delta_direct_rpts_flag VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.fact_upd_feedback_survey owner to dbadmin;


-- gna_load_schema.fact_upd_feedback_survey_denormalized definition

-- Drop table

-- DROP TABLE gna_load_schema.fact_upd_feedback_survey_denormalized;

CREATE TABLE IF NOT EXISTS gna_load_schema.fact_upd_feedback_survey_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,strengths_opportunities VARCHAR(39)   ENCODE lzo
	,survey_ans VARCHAR(64512)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,employee_num NUMERIC(9,0)   ENCODE az64
	,pref_full_name VARCHAR(765)   ENCODE lzo
	,le_level1_val VARCHAR(720)   ENCODE RAW
	,le_level2_val VARCHAR(720)   ENCODE RAW
	,le_level3_val VARCHAR(720)   ENCODE RAW
	,le_level4_val VARCHAR(720)   ENCODE RAW
	,le_level5_val VARCHAR(720)   ENCODE RAW
	,le_level6_val VARCHAR(720)   ENCODE RAW
	,le_level6_desc VARCHAR(720)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_desc VARCHAR(765)   ENCODE lzo
	,location_code_level1 VARCHAR(720)   ENCODE RAW
	,location_code_level2 VARCHAR(720)   ENCODE RAW
	,location_code_level3 VARCHAR(720)   ENCODE RAW
	,location_code_level4 VARCHAR(720)   ENCODE RAW
	,location_code_level5 VARCHAR(720)   ENCODE RAW
	,location_code_level6 VARCHAR(720)   ENCODE RAW
	,location_code_level7 VARCHAR(720)   ENCODE RAW
	,location_code_level8 VARCHAR(720)   ENCODE RAW
	,location_code_level9 VARCHAR(720)   ENCODE RAW
	,location_code_level10 VARCHAR(720)   ENCODE RAW
	,location_code_level11 VARCHAR(720)   ENCODE RAW
	,location_code_level12 VARCHAR(720)   ENCODE RAW
	,location_code_level13 VARCHAR(720)   ENCODE RAW
	,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE RAW
	,cc_level7_value VARCHAR(720)   ENCODE RAW
	,base_cost_center_desc VARCHAR(720)   ENCODE lzo
	,cost_center_level2_desc VARCHAR(720)   ENCODE lzo
	,calendar_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE RAW
	,dim_survey_ques_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,effective_start_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,number_of_responses VARCHAR(765)   ENCODE lzo
	,mgr_sup_hier_key NUMERIC(10,0)   ENCODE az64
	,mgr_worker_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,number_of_invites VARCHAR(765)   ENCODE lzo
	,fact_survey_ques_key NUMERIC(10,0)   ENCODE az64
	,record_type VARCHAR(765)   ENCODE lzo
	,fact_survey_ques_ans VARCHAR(12000)   ENCODE lzo
	,mgr_worker_id VARCHAR(240)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE RAW
	,current_level7_emp_login VARCHAR(720)   ENCODE RAW
	,current_level8_emp_login VARCHAR(720)   ENCODE RAW
	,current_level9_emp_login VARCHAR(720)   ENCODE RAW
	,current_level10_emp_login VARCHAR(720)   ENCODE RAW
	,current_level11_emp_login VARCHAR(720)   ENCODE RAW
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,cal_date_key NUMERIC(19,0)   ENCODE az64
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,dept_id VARCHAR(240)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_exempt_flg VARCHAR(10)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	,emp_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,level2_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,full_time_flg VARCHAR(150)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,perf_band2 VARCHAR(300)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,sex_desc VARCHAR(765)   ENCODE lzo
	,ethnic_group_custom_desc VARCHAR(765)   ENCODE lzo
	,source_id VARCHAR(300)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,school_name VARCHAR(765)   ENCODE lzo
	,rehire_flag VARCHAR(3)   ENCODE lzo
	,attribute_type VARCHAR(765)   ENCODE lzo
	,continuous_service_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,attr_misc_desc VARCHAR(765)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,business_question VARCHAR(765)   ENCODE lzo
	,category VARCHAR(765)   ENCODE lzo
	,last_rehire_date1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,most_recent_advancement_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,bus_survey_ques VARCHAR(12000)   ENCODE lzo
	,cc_nodeval VARCHAR(765)   ENCODE lzo
	,cc_nodename VARCHAR(765)   ENCODE lzo
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,snapshot_key NUMERIC(10,0)   ENCODE az64
	,mgr_sup_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,mgr_sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
	,worker_event_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,le_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_prv_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,position_prv_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,fulltime_parttime VARCHAR(765)   ENCODE lzo
	,ethnicity_us VARCHAR(765)   ENCODE lzo
	,most_recent_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,orig_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,birth_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,sort_key NUMERIC(10,0)   ENCODE az64
	,le_level1_desc VARCHAR(765)   ENCODE lzo
	,le_level2_desc VARCHAR(765)   ENCODE lzo
	,le_level3_desc VARCHAR(765)   ENCODE lzo
	,le_level4_desc VARCHAR(765)   ENCODE lzo
	,le_level5_desc VARCHAR(765)   ENCODE lzo
	,product_desc_1 VARCHAR(765)   ENCODE lzo
	,product_desc_2 VARCHAR(765)   ENCODE lzo
	,product_desc_3 VARCHAR(765)   ENCODE lzo
	,product_desc_4 VARCHAR(765)   ENCODE lzo
	,product_desc_5 VARCHAR(765)   ENCODE lzo
	,location_desc_level1 VARCHAR(765)   ENCODE lzo
	,location_desc_level2 VARCHAR(765)   ENCODE lzo
	,location_desc_level3 VARCHAR(765)   ENCODE lzo
	,location_desc_level4 VARCHAR(765)   ENCODE lzo
	,location_desc_level5 VARCHAR(765)   ENCODE lzo
	,location_desc_level6 VARCHAR(765)   ENCODE lzo
	,location_desc_level7 VARCHAR(765)   ENCODE lzo
	,location_desc_level8 VARCHAR(765)   ENCODE lzo
	,location_desc_level9 VARCHAR(765)   ENCODE lzo
	,location_desc_level10 VARCHAR(765)   ENCODE lzo
	,location_desc_level11 VARCHAR(765)   ENCODE lzo
	,location_desc_level12 VARCHAR(765)   ENCODE lzo
	,location_desc_level13 VARCHAR(765)   ENCODE lzo
	,cc_level1_desc VARCHAR(765)   ENCODE lzo
	,cc_level2_desc VARCHAR(765)   ENCODE lzo
	,cc_level3_desc VARCHAR(765)   ENCODE lzo
	,cc_level4_desc VARCHAR(765)   ENCODE lzo
	,cc_level5_desc VARCHAR(765)   ENCODE lzo
	,cc_level6_desc VARCHAR(765)   ENCODE lzo
	,cc_level7_desc VARCHAR(765)   ENCODE lzo
	,login VARCHAR(765)   ENCODE lzo
	,loc_nodeval VARCHAR(765)   ENCODE lzo
	,veteran_status_us VARCHAR(765)   ENCODE lzo
	,disability_status_us VARCHAR(765)   ENCODE lzo
	,company VARCHAR(765)   ENCODE lzo
	,hiest_degree_major VARCHAR(765)   ENCODE lzo
	,employee_cat_code VARCHAR(765)   ENCODE lzo
	,awr_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,awr_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,WORKER_ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,STRENGTH_COMMENTS VARCHAR(65535)   ENCODE lzo
	,OPPORTUNITIES_COMMENTS VARCHAR(65535)   ENCODE lzo
	,EFFECTIVE_END_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,NEXT_TERMINATION_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
)
DISTSTYLE KEY
 DISTKEY (worker_key)
 SORTKEY (
	calendar_dt
	, current_level1_emp_login
	, current_level2_emp_login
	, current_level3_emp_login
	, current_level4_emp_login
	, current_level5_emp_login
	, current_level6_emp_login
	, current_level7_emp_login
	, current_level8_emp_login
	, current_level9_emp_login
	, current_level10_emp_login
	, current_level11_emp_login
	, current_level10_emp_full_name
	, current_level11_emp_full_name
	, current_level2_emp_full_name
	, current_level3_emp_full_name
	, current_level4_emp_full_name
	, current_level5_emp_full_name
	, current_level6_emp_full_name
	, current_level7_emp_full_name
	, current_level8_emp_full_name
	, current_level9_emp_full_name
	, current_level1_emp_full_name
	, le_level1_val
	, le_level2_val
	, le_level3_val
	, le_level4_val
	, le_level5_val
	, location_code_level1
	, location_code_level2
	, location_code_level3
	, location_code_level4
	, location_code_level5
	, location_code_level6
	, location_code_level7
	, location_code_level8
	, location_code_level9
	, location_code_level10
	, location_code_level11
	, location_code_level12
	, location_code_level13
	, product_value1
	, product_value2
	, product_value3
	, product_value4
	, product_value5
	, cc_level1_value
	, cc_level2_value
	, cc_level3_value
	, cc_level4_value
	, cc_level5_value
	, cc_level6_value
	, cc_level7_value
	)
;
ALTER TABLE gna_load_schema.fact_upd_feedback_survey_denormalized owner to dbadmin;

-- gna_load_schema.fact_vfw_badge_dtl_denormalized definition


-- DROP TABLE gna_load_schema.fact_vfw_badge_dtl_denormalized;


CREATE TABLE IF NOT EXISTS gna_load_schema.fact_vfw_badge_dtl_denormalized
(
	role_name_access_list VARCHAR(65535)   ENCODE zstd
	,rank1 BIGINT   ENCODE az64
	,employee_cat_code VARCHAR(240)   ENCODE lzo
	,employee_cat_desc VARCHAR(765)   ENCODE lzo
	,employee_sub_cat_desc VARCHAR(765)   ENCODE lzo
	,level2_desc VARCHAR(720)   ENCODE lzo
	,worker_key NUMERIC(20,0)   ENCODE RAW
	,employee_num VARCHAR(765)   ENCODE lzo
	,access_dt_key VARCHAR(24)   ENCODE lzo
	,doorname VARCHAR(765)   ENCODE lzo
	,access_datime_local VARCHAR(765)   ENCODE lzo
	,age NUMERIC(20,2)   ENCODE az64
	,building VARCHAR(765)   ENCODE lzo
	,ATTR_MISC_DESC VARCHAR(765)   ENCODE lzo
	,disability_status VARCHAR(765)   ENCODE lzo
	,gender VARCHAR(765)   ENCODE lzo
	,gender_identity VARCHAR(300)   ENCODE lzo
	,hiest_degree VARCHAR(765)   ENCODE lzo
	,job_req_tag VARCHAR(12000)   ENCODE lzo
	,ser_pow_band_desc VARCHAR(765)   ENCODE lzo
	,perf_band1 VARCHAR(300)   ENCODE lzo
	,office_type VARCHAR(300)   ENCODE lzo
	,sexual_orientation VARCHAR(300)   ENCODE lzo
	,Supervisor_ID VARCHAR(300)   ENCODE lzo
	,CONTINUOUS_SERVICE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,Rehire_Flag VARCHAR(10)   ENCODE lzo
	,supervisor_name VARCHAR(765)   ENCODE lzo
	,veteran_status VARCHAR(765)   ENCODE lzo
	,product_value1 VARCHAR(765)   ENCODE RAW
	,product_value2 VARCHAR(765)   ENCODE RAW
	,product_value3 VARCHAR(765)   ENCODE RAW
	,product_value4 VARCHAR(765)   ENCODE RAW
	,product_value5 VARCHAR(765)   ENCODE RAW
	,product_desc VARCHAR(765)   ENCODE RAW
	,le_level1_val VARCHAR(720)   ENCODE RAW
	,le_level2_val VARCHAR(720)   ENCODE RAW
	,le_level3_val VARCHAR(720)   ENCODE RAW
	,le_level4_val VARCHAR(720)   ENCODE RAW
	,le_level5_val VARCHAR(720)   ENCODE RAW
	,le_level6_val VARCHAR(720)   ENCODE RAW
	,le_level6_desc VARCHAR(720)   ENCODE RAW
	,cc_level1_value VARCHAR(720)   ENCODE RAW
	,cc_level2_value VARCHAR(720)   ENCODE RAW
	,cc_level3_value VARCHAR(720)   ENCODE RAW
	,cc_level4_value VARCHAR(720)   ENCODE RAW
	,cc_level5_value VARCHAR(720)   ENCODE RAW
	,cc_level6_value VARCHAR(720)   ENCODE RAW
	,cc_level7_value VARCHAR(720)   ENCODE RAW
	,base_cost_center_desc VARCHAR(720)   ENCODE lzo
	,cost_center_level2_desc VARCHAR(720)   ENCODE lzo
	,location_code_level1 VARCHAR(720)   ENCODE RAW
	,location_code_level2 VARCHAR(720)   ENCODE RAW
	,location_code_level3 VARCHAR(720)   ENCODE RAW
	,location_code_level4 VARCHAR(720)   ENCODE RAW
	,location_code_level5 VARCHAR(720)   ENCODE RAW
	,location_code_level6 VARCHAR(720)   ENCODE RAW
	,location_code_level7 VARCHAR(720)   ENCODE RAW
	,location_code_level8 VARCHAR(720)   ENCODE RAW
	,location_code_level9 VARCHAR(720)   ENCODE RAW
	,location_code_level10 VARCHAR(720)   ENCODE RAW
	,location_code_level11 VARCHAR(720)   ENCODE RAW
	,location_code_level12 VARCHAR(720)   ENCODE RAW
	,level13_val VARCHAR(720)   ENCODE RAW
	,location_desc_level1 VARCHAR(720)   ENCODE lzo
	,location_desc_level2 VARCHAR(720)   ENCODE lzo
	,location_desc_level3 VARCHAR(720)   ENCODE lzo
	,location_desc_level4 VARCHAR(720)   ENCODE lzo
	,location_desc_level5 VARCHAR(720)   ENCODE lzo
	,location_desc_level6 VARCHAR(720)   ENCODE lzo
	,location_desc_level7 VARCHAR(720)   ENCODE lzo
	,location_desc_level8 VARCHAR(720)   ENCODE lzo
	,location_desc_level9 VARCHAR(720)   ENCODE lzo
	,location_desc_level10 VARCHAR(720)   ENCODE lzo
	,location_desc_level11 VARCHAR(720)   ENCODE lzo
	,location_desc_level12 VARCHAR(720)   ENCODE lzo
	,location_desc_level13 VARCHAR(720)   ENCODE lzo
	,current_level1_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level2_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level3_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level4_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level5_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level6_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level7_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level8_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level9_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level10_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level11_emp_full_name VARCHAR(720)   ENCODE RAW
	,current_level1_emp_login VARCHAR(720)   ENCODE RAW
	,current_level2_emp_login VARCHAR(720)   ENCODE RAW
	,current_level3_emp_login VARCHAR(720)   ENCODE RAW
	,current_level4_emp_login VARCHAR(720)   ENCODE RAW
	,current_level5_emp_login VARCHAR(720)   ENCODE RAW
	,current_level6_emp_login VARCHAR(720)   ENCODE lzo
	,current_level7_emp_login VARCHAR(720)   ENCODE lzo
	,current_level8_emp_login VARCHAR(720)   ENCODE lzo
	,current_level9_emp_login VARCHAR(720)   ENCODE lzo
	,current_level10_emp_login VARCHAR(720)   ENCODE lzo
	,current_level11_emp_login VARCHAR(720)   ENCODE lzo
	,position_id VARCHAR(300)   ENCODE lzo
	,worker_id VARCHAR(765)   ENCODE lzo
	,worker_pref_name VARCHAR(765)   ENCODE lzo
	,pay_grade_code VARCHAR(240)   ENCODE lzo
	,pay_grade_group VARCHAR(600)   ENCODE lzo
	,job_code VARCHAR(300)   ENCODE lzo
	,job_exempt_flg VARCHAR(10)   ENCODE lzo
	,job_family_desc VARCHAR(765)   ENCODE lzo
	,job_desc VARCHAR(765)   ENCODE lzo
	,dept_id VARCHAR(240)   ENCODE lzo
	,dept_name VARCHAR(765)   ENCODE lzo
	,emp_hire_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,level2_desc_no_mgr VARCHAR(765)   ENCODE lzo
	,attribute_type VARCHAR(765)   ENCODE lzo
	,"location" VARCHAR(765)   ENCODE lzo
	,worker_ethnicity VARCHAR(765)   ENCODE lzo
	,veteran_status_desc VARCHAR(765)   ENCODE lzo
	,KEY_PERFORMER_YEAR_1 VARCHAR(3)   ENCODE lzo
	,key_performer_year_2 VARCHAR(3)   ENCODE lzo
	,key_performer_year_3 VARCHAR(3)   ENCODE lzo
	,talent_quadrant_1 VARCHAR(6)   ENCODE lzo
	,talent_quadrant_2 VARCHAR(6)   ENCODE lzo
	,timezone VARCHAR(765)   ENCODE lzo
	,sitename VARCHAR(765)   ENCODE lzo
	,cardnumber VARCHAR(765)   ENCODE lzo
	,floor VARCHAR(765)   ENCODE lzo
	,room VARCHAR(765)   ENCODE lzo
	,age_band_desc VARCHAR(765)   ENCODE lzo
	,PEOPLE_MANAGER_FLG VARCHAR(10)   ENCODE lzo
	,LENGTH_OF_SERVICE VARCHAR(10)   ENCODE lzo
	,LAST_PROMOTION_DATE_1 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,role_change_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,Most_Recent_Advancement_Date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,SCHOOL_NAME VARCHAR(765)   ENCODE lzo
	,ETHNIC_GROUP_CUSTOM_DESC VARCHAR(765)   ENCODE lzo
	,CC_NODEVAL VARCHAR(765)   ENCODE lzo
	,CC_NODENAME VARCHAR(765)   ENCODE lzo
	,EVENT_YEAR_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,RECRUITER_KEY NUMERIC(10,0)   ENCODE az64
	,APPLICANT_KEY NUMERIC(10,0)   ENCODE az64
	,LAST_DATE_OF_MONTH_KEY NUMERIC(10,0)   ENCODE az64
	,RQSTN_KEY NUMERIC(10,0)   ENCODE az64
	,MGRLEAD_PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,INTL_ASSGN_KEY NUMERIC(10,0)   ENCODE az64
	,SER_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,PERF_BAND_KEY NUMERIC(10,0)   ENCODE az64
	,WORKER_EVENT_TYPE_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_QTR_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_MONTH_KEY NUMERIC(10,0)   ENCODE az64
	,EVENT_DT_KEY NUMERIC(10,0)   ENCODE az64
	,ORIG_HIRE_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,BIRTH_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,ETHNICITY_US VARCHAR(765)   ENCODE lzo
	,VETERAN_STATUS_US VARCHAR(765)   ENCODE lzo
	,DISABILITY_STATUS_US VARCHAR(765)   ENCODE lzo
	,le_level1_desc  VARCHAR(765)   ENCODE lzo
	,le_level2_desc  VARCHAR(765)   ENCODE lzo
	,le_level3_desc  VARCHAR(765)   ENCODE lzo
	,le_level4_desc  VARCHAR(765)   ENCODE lzo
	,le_level5_desc  VARCHAR(765)   ENCODE lzo
	,cc_level1_desc  VARCHAR(765)   ENCODE lzo
	,cc_level2_desc  VARCHAR(765)   ENCODE lzo
	,cc_level3_desc  VARCHAR(765)   ENCODE lzo
	,cc_level4_desc  VARCHAR(765)   ENCODE lzo
	,cc_level5_desc  VARCHAR(765)   ENCODE lzo
	,cc_level6_desc  VARCHAR(765)   ENCODE lzo
	,cc_level7_desc  VARCHAR(765)   ENCODE lzo
	,product_desc1  VARCHAR(765)   ENCODE lzo
	,product_desc2  VARCHAR(765)   ENCODE lzo
	,product_desc3  VARCHAR(765)   ENCODE lzo
	,product_desc4  VARCHAR(765)   ENCODE lzo
	,product_desc5  VARCHAR(765)   ENCODE lzo
	,DISABILITY_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,VETERAN_STS_DEMOGRAPHIC_KEY NUMERIC(10,0)   ENCODE az64
	,ACCESS_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,job_req_tag1 VARCHAR(765)   ENCODE lzo
    ,job_req_tag2 VARCHAR(765)   ENCODE lzo
    ,job_req_tag3 VARCHAR(765)   ENCODE lzo
    ,job_req_tag4 VARCHAR(765)   ENCODE lzo
    ,job_req_tag5 VARCHAR(765)   ENCODE lzo
    ,job_req_tag6 VARCHAR(765)   ENCODE lzo
    ,job_req_tag7 VARCHAR(765)   ENCODE lzo
    ,job_req_tag8 VARCHAR(765)   ENCODE lzo
    ,job_req_tag9 VARCHAR(765)   ENCODE lzo
    ,job_req_tag10 VARCHAR(765)  ENCODE lzo
	,FULLTIME_PARTTIME VARCHAR(765)  ENCODE lzo
	,SUPERVISOR_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,DEPT_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,LOC_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,CC_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,PROD_HIER_KEY NUMERIC(10,0)   ENCODE az64
	,LOGIN VARCHAR(765)  ENCODE lzo
	,LOC_NODEVAL VARCHAR(765)  ENCODE lzo
	,EMP_ACTIVE_FLG VARCHAR(10)  ENCODE lzo
	,TERMINATION_DT10 TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT9  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT8  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT7  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT6  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT5  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT4  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT3  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT2  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT1  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,TERMINATION_DT   TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,AWR_START_DATE TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,AWR_END_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,COMPANY VARCHAR(765)  ENCODE lzo
	,MOST_RECENT_TERMINATION_DT TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,MARKET_LEVEL1_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_VAL  VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL1_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL2_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL3_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL4_DESC VARCHAR(765) ENCODE lzo
	,MARKET_LEVEL5_DESC VARCHAR(765) ENCODE lzo
	,MKT_NODE_VAL  VARCHAR(765) ENCODE lzo
	,MKT_NODE_NAME  VARCHAR(765) ENCODE lzo
)
DISTSTYLE AUTO
DISTKEY (worker_key)
SORTKEY (
	worker_key
	,product_value1 
	,product_value2 
	,product_value3 
	,product_value4 
	,product_value5 
	,product_desc  
	,le_level1_val 
	,le_level2_val 
	,le_level3_val 
	,le_level4_val 
	,le_level5_val 
	,le_level6_val 
	,le_level6_desc
	,cc_level1_value 
	,cc_level2_value 
	,cc_level3_value 
	,cc_level4_value 
	,cc_level5_value 
	,cc_level6_value 
	,cc_level7_value 
	,location_code_level1
	,location_code_level2
	,location_code_level3
	,location_code_level4
	,location_code_level5
	,location_code_level6
	,location_code_level7
	,location_code_level8
	,location_code_level9
	,location_code_level10 
	,location_code_level11 
	,location_code_level12 
	,level13_val 
	,current_level1_emp_full_name 
	,current_level2_emp_full_name 
	,current_level3_emp_full_name 
	,current_level4_emp_full_name 
	,current_level5_emp_full_name 
	,current_level6_emp_full_name 
	,current_level7_emp_full_name 
	,current_level8_emp_full_name 
	,current_level9_emp_full_name 
	,current_level10_emp_full_name
	,current_level11_emp_full_name
	,current_level1_emp_login 
	,current_level2_emp_login 
	,current_level3_emp_login 
	,current_level4_emp_login 
	,current_level5_emp_login 
	)
;
ALTER TABLE gna_load_schema.fact_vfw_badge_dtl_denormalized owner to dbadmin;

-- gna_load_schema.lnk_dim_rcrtmnt_event_type definition

-- Drop table

-- DROP TABLE gna_load_schema.lnk_dim_rcrtmnt_event_type;

--DROP TABLE gna_load_schema.lnk_dim_rcrtmnt_event_type;
CREATE TABLE IF NOT EXISTS gna_load_schema.lnk_dim_rcrtmnt_event_type
(
	dim_rcrtmnt_evt_key NUMERIC(10,0)   ENCODE az64
	,row_wid NUMERIC(10,0)   ENCODE az64
	,status_code VARCHAR(765)   ENCODE lzo
	,status_name VARCHAR(765)   ENCODE lzo
	,reason_code VARCHAR(765)   ENCODE lzo
	,reason_name VARCHAR(765)   ENCODE lzo
	,w_event_code VARCHAR(150)   ENCODE lzo
	,w_event_desc VARCHAR(765)   ENCODE lzo
	,w_sub_stage_code VARCHAR(150)   ENCODE lzo
	,w_sub_stage_desc VARCHAR(765)   ENCODE lzo
	,w_stage_code VARCHAR(150)   ENCODE lzo
	,w_stage_desc VARCHAR(765)   ENCODE lzo
	,w_reason_code VARCHAR(150)   ENCODE lzo
	,w_reason_desc VARCHAR(765)   ENCODE lzo
	,w_reason_type_code VARCHAR(150)   ENCODE lzo
	,w_reason_type_desc VARCHAR(765)   ENCODE lzo
	,event_seq_num NUMERIC(10,0)   ENCODE az64
	,w_req_event_flg VARCHAR(3)   ENCODE lzo
	,w_apl_event_flg VARCHAR(3)   ENCODE lzo
	,created_by_wid NUMERIC(10,0)   ENCODE az64
	,changed_by_wid NUMERIC(10,0)   ENCODE az64
	,created_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux1_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux2_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux3_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux4_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,delete_flg VARCHAR(3)   ENCODE lzo
	,w_insert_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,w_update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,etl_proc_wid NUMERIC(10,0)   ENCODE az64
	,integration_id VARCHAR(240)   ENCODE lzo
	,tenant_id VARCHAR(240)   ENCODE lzo
	,x_custom VARCHAR(30)   ENCODE lzo
	,stage_code_wd VARCHAR(765)   ENCODE lzo
	,stage_desc_wd VARCHAR(765)   ENCODE lzo
	,appl_stage_wd VARCHAR(765)   ENCODE lzo
	,appl_step_wd VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.lnk_dim_rcrtmnt_event_type owner to dbadmin;


-- gna_load_schema.lnk_dim_rcrtmnt_source definition

-- Drop table

-- DROP TABLE gna_load_schema.lnk_dim_rcrtmnt_source;

--DROP TABLE gna_load_schema.lnk_dim_rcrtmnt_source;
CREATE TABLE IF NOT EXISTS gna_load_schema.lnk_dim_rcrtmnt_source
(
	dim_rcrtmnt_source_key NUMERIC(10,0)   ENCODE az64
	,row_wid NUMERIC(10,0)   ENCODE az64
	,parent_type_wid NUMERIC(10,0)   ENCODE az64
	,parent_type_integration_id VARCHAR(240)   ENCODE lzo
	,source_type_code VARCHAR(765)   ENCODE lzo
	,source_type_name VARCHAR(765)   ENCODE lzo
	,w_source_type_code VARCHAR(150)   ENCODE lzo
	,w_source_type_desc VARCHAR(765)   ENCODE lzo
	,source_code VARCHAR(765)   ENCODE lzo
	,source_name VARCHAR(765)   ENCODE lzo
	,level_id VARCHAR(240)   ENCODE lzo
	,type_enabled_flg VARCHAR(3)   ENCODE lzo
	,type_valid_from_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,type_valid_to_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,source_valid_from_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,source_valid_to_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_wid NUMERIC(10,0)   ENCODE az64
	,changed_by_wid NUMERIC(10,0)   ENCODE az64
	,created_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux1_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux2_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux3_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,aux4_changed_on_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,delete_flg VARCHAR(3)   ENCODE lzo
	,w_insert_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,w_update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,etl_proc_wid NUMERIC(10,0)   ENCODE az64
	,integration_id VARCHAR(1500)   ENCODE lzo
	,tenant_id VARCHAR(240)   ENCODE lzo
	,x_custom VARCHAR(60)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.lnk_dim_rcrtmnt_source owner to dbadmin;


-- gna_load_schema.mv_fact_vfw_badge_dtl definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_fact_vfw_badge_dtl;

--DROP TABLE gna_load_schema.mv_fact_vfw_badge_dtl;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_fact_vfw_badge_dtl
(
	access_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,fedid VARCHAR(765)   ENCODE lzo
	,access_dt_key VARCHAR(24)   ENCODE lzo
	,worker_key NUMERIC(20,0)   ENCODE az64
	,doorname VARCHAR(765)   ENCODE lzo
	,sitename VARCHAR(765)   ENCODE lzo
	,access_datime_local VARCHAR(765)   ENCODE lzo
	,timezone VARCHAR(765)   ENCODE lzo
	,city VARCHAR(765)   ENCODE lzo
	,cardnumber VARCHAR(765)   ENCODE lzo
	,admitstatus VARCHAR(765)   ENCODE lzo
	,leave_status NUMERIC(1,0)   ENCODE az64
	,payroll_status NUMERIC(1,0)   ENCODE az64
	,worker_key_fact NUMERIC(10,0)   ENCODE az64
	,event_dt_key NUMERIC(10,0)   ENCODE az64
	,event_month_key NUMERIC(10,0)   ENCODE az64
	,event_qtr_key NUMERIC(10,0)   ENCODE az64
	,disability_demographic_key NUMERIC(10,0)   ENCODE az64
	,veteran_sts_demographic_key NUMERIC(10,0)   ENCODE az64
	,worker_event_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_key NUMERIC(10,0)   ENCODE az64
	,worker_type_prv_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_key NUMERIC(10,0)   ENCODE az64
	,dept_prv_key NUMERIC(10,0)   ENCODE az64
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,loc_hier_prv_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,perf_band_key NUMERIC(10,0)   ENCODE az64
	,perf_band_prv_key NUMERIC(10,0)   ENCODE az64
	,ser_band_key NUMERIC(10,0)   ENCODE az64
	,ser_band_prv_key NUMERIC(10,0)   ENCODE az64
	,job_key NUMERIC(10,0)   ENCODE az64
	,job_prv_key NUMERIC(10,0)   ENCODE az64
	,age_band_key NUMERIC(10,0)   ENCODE az64
	,age_band_prv_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,pay_grade_prv_key NUMERIC(10,0)   ENCODE az64
	,position_key NUMERIC(10,0)   ENCODE az64
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,mgrlead_perf_band_key NUMERIC(10,0)   ENCODE az64
	,rqstn_key NUMERIC(10,0)   ENCODE az64
	,last_date_of_month_key NUMERIC(10,0)   ENCODE az64
	,applicant_key NUMERIC(10,0)   ENCODE az64
	,recruiter_key NUMERIC(10,0)   ENCODE az64
	,recruiter_hier_key NUMERIC(10,0)   ENCODE az64
	,event_year_key NUMERIC(10,0)   ENCODE az64
	,sup_hier_pit_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_fact_vfw_badge_dtl owner to dbadmin;


-- gna_load_schema.mv_job_req_tag definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_job_req_tag;

--DROP TABLE gna_load_schema.mv_job_req_tag;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_job_req_tag
(
	job_req_tag VARCHAR(765)   ENCODE lzo
	,source_id VARCHAR(300)   ENCODE lzo
	,rqstn_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_job_req_tag owner to dbadmin;


-- gna_load_schema.mv_job_tiercode_country definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_job_tiercode_country;

--DROP TABLE gna_load_schema.mv_job_tiercode_country;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_job_tiercode_country
(
	"JOB_KEY" NUMERIC(10,0)   ENCODE az64
	,"JOB_CODE" VARCHAR(300)   ENCODE lzo
	,"JOB_FAMILY_GROUP" VARCHAR(750)   ENCODE lzo
	,"JOB_FAMILY_DESC" VARCHAR(765)   ENCODE lzo
	,"JOB_DESC" VARCHAR(765)   ENCODE lzo
	,"PAY_GRADE_KEY" NUMERIC(10,0)   ENCODE az64
	,"COUNTRY" VARCHAR(765)   ENCODE lzo
	,"PAYLINE_CODE" VARCHAR(240)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_job_tiercode_country owner to dbadmin;


-- gna_load_schema.mv_mobility_expenses definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_mobility_expenses;

--DROP TABLE gna_load_schema.mv_mobility_expenses;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_mobility_expenses
(
	customer_id_fact VARCHAR(765)   ENCODE lzo
	,expense_id VARCHAR(3060)   ENCODE lzo
	,expense_key VARCHAR(765)   ENCODE lzo
	,service VARCHAR(765)   ENCODE lzo
	,benefit VARCHAR(765)   ENCODE lzo
	,acct_desc VARCHAR(765)   ENCODE lzo
	,acct_num VARCHAR(765)   ENCODE lzo
	,taxstatus_usa VARCHAR(765)   ENCODE lzo
	,description VARCHAR(765)   ENCODE lzo
	,reference_num VARCHAR(765)   ENCODE lzo
	,company_paid VARCHAR(765)   ENCODE lzo
	,payee_name VARCHAR(765)   ENCODE lzo
	,payee_number VARCHAR(765)   ENCODE lzo
	,payee_type VARCHAR(765)   ENCODE lzo
	,financial_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,invoice_num NUMERIC(10,0)   ENCODE az64
	,invoice_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,billed_amount NUMERIC(10,2)   ENCODE az64
	,billed_currency VARCHAR(240)   ENCODE lzo
	,client_amount NUMERIC(10,2)   ENCODE az64
	,client_currency VARCHAR(240)   ENCODE lzo
	,datasource_name_fact VARCHAR(240)   ENCODE lzo
	,datasource_num_fact NUMERIC(10,0)   ENCODE az64
	,receieved_file_name_fact VARCHAR(3060)   ENCODE lzo
	,load_dt_fact TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,hashdiff_fact VARCHAR(765)   ENCODE lzo
	,row_id_fact NUMERIC(10,0)   ENCODE az64
	,valid_flag_fact VARCHAR(12)   ENCODE lzo
	,dateimported_fact TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt_fact TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt_fact TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key_fact NUMERIC(10,0)   ENCODE az64
	,updated_by_key_fact NUMERIC(10,0)   ENCODE az64
	,file_type_fact VARCHAR(765)   ENCODE lzo
	,demographics_key NUMERIC(10,0)   ENCODE az64
	,customer_id VARCHAR(240)   ENCODE lzo
	,company_name VARCHAR(765)   ENCODE lzo
	,division_name VARCHAR(765)   ENCODE lzo
	,department_name VARCHAR(765)   ENCODE lzo
	,file_num VARCHAR(765)   ENCODE lzo
	,employee_name VARCHAR(765)   ENCODE lzo
	,employee_email VARCHAR(765)   ENCODE lzo
	,authorization_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,candidate_key NUMERIC(10,0)   ENCODE az64
	,worker_key NUMERIC(10,0)   ENCODE az64
	,requisition_key NUMERIC(10,0)   ENCODE az64
	,cost_center VARCHAR(765)   ENCODE lzo
	,department_code VARCHAR(765)   ENCODE lzo
	,gl_code VARCHAR(765)   ENCODE lzo
	,grade_level VARCHAR(765)   ENCODE lzo
	,legal_entity VARCHAR(765)   ENCODE lzo
	,location_code VARCHAR(765)   ENCODE lzo
	,product_number VARCHAR(765)   ENCODE lzo
	,purchase_ord_number VARCHAR(765)   ENCODE lzo
	,employment_type VARCHAR(765)   ENCODE lzo
	,move_type VARCHAR(765)   ENCODE lzo
	,relocation_type VARCHAR(765)   ENCODE lzo
	,policy_type VARCHAR(765)   ENCODE lzo
	,departure_work_city VARCHAR(765)   ENCODE lzo
	,departure_work_state VARCHAR(765)   ENCODE lzo
	,departure_work_country VARCHAR(765)   ENCODE lzo
	,destination_work_city VARCHAR(765)   ENCODE lzo
	,destination_work_state VARCHAR(765)   ENCODE lzo
	,destination_work_country VARCHAR(765)   ENCODE lzo
	,relocation_counselor VARCHAR(765)   ENCODE lzo
	,move_type_status VARCHAR(240)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,received_file_name VARCHAR(765)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
	,hashdiff VARCHAR(765)   ENCODE lzo
	,row_id NUMERIC(10,0)   ENCODE az64
	,valid_flag VARCHAR(3)   ENCODE lzo
	,dateimported TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,loc_hier_key NUMERIC(10,0)   ENCODE az64
	,dept_hier_key NUMERIC(10,0)   ENCODE az64
	,supervisor_hier_key NUMERIC(10,0)   ENCODE az64
	,intl_assgn_key NUMERIC(10,0)   ENCODE az64
	,subsidy_type VARCHAR(765)   ENCODE lzo
	,subsidy_start_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,subsidy_end_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,total_subsidy_amount VARCHAR(765)   ENCODE lzo
	,worker_email VARCHAR(765)   ENCODE lzo
	,pay_grade_key NUMERIC(10,0)   ENCODE az64
	,cc_hier_key NUMERIC(10,0)   ENCODE az64
	,prod_hier_key NUMERIC(10,0)   ENCODE az64
	,file_type VARCHAR(240)   ENCODE lzo
	,le_hier_key NUMERIC(10,0)   ENCODE az64
	,assignment_type VARCHAR(765)   ENCODE lzo
	,assignment_sub_type VARCHAR(765)   ENCODE lzo
	,worker_type VARCHAR(765)   ENCODE lzo
	,supervisor_key NUMERIC(10,0)   ENCODE az64
	,candidate_id VARCHAR(765)   ENCODE lzo
	,employee_id VARCHAR(765)   ENCODE lzo
	,requisition_num VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_mobility_expenses owner to dbadmin;


-- gna_load_schema.mv_people_manager definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_people_manager;

--DROP TABLE gna_load_schema.mv_people_manager;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_people_manager
(
	supervisor_key NUMERIC(10,0)   ENCODE az64
	,cal_date_key NUMERIC(19,0)   ENCODE az64
	,people_manager_flg VARCHAR(3)   ENCODE lzo
	,calendar_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_people_manager owner to dbadmin;


-- gna_load_schema.mv_proxy_user definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_proxy_user;

--DROP TABLE gna_load_schema.mv_proxy_user;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_proxy_user
(
	proxyid VARCHAR(1200)   ENCODE lzo
	,targetid VARCHAR(1200)   ENCODE lzo
	,proxylevel VARCHAR(12)   ENCODE lzo
	,targetid_name VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_proxy_user owner to dbadmin;


-- gna_load_schema.mv_rcrtmnt_source_worker definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_rcrtmnt_source_worker;

--DROP TABLE gna_load_schema.mv_rcrtmnt_source_worker;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_rcrtmnt_source_worker
(
	worker_key NUMERIC(20,0)   ENCODE az64
	,dim_rcrtmnt_source_key NUMERIC(10,0)   ENCODE az64
	,integration_id VARCHAR(1500)   ENCODE lzo
	,source_type_name VARCHAR(765)   ENCODE lzo
	,source_code VARCHAR(765)   ENCODE lzo
	,jstype VARCHAR(765)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_rcrtmnt_source_worker owner to dbadmin;


-- gna_load_schema.mv_time_since_grade_change definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_time_since_grade_change;

--DROP TABLE gna_load_schema.mv_time_since_grade_change;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_time_since_grade_change
(
	metric_type VARCHAR(100)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE az64
	,latest_event_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_date_key NUMERIC(10,0)   ENCODE az64
	,last_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_date_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_time_since_grade_change owner to dbadmin;


-- gna_load_schema.mv_time_since_grade_changes definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_time_since_grade_changes;

--DROP TABLE gna_load_schema.mv_time_since_grade_changes;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_time_since_grade_changes
(
	metric_type VARCHAR(100)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE az64
	,latest_event_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_date_key NUMERIC(10,0)   ENCODE az64
	,last_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_date_key NUMERIC(10,0)   ENCODE az64
	,time_since_grade_change NUMERIC(13,10)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_time_since_grade_changes owner to dbadmin;


-- gna_load_schema.mv_time_since_last_mvmt definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_time_since_last_mvmt;

--DROP TABLE gna_load_schema.mv_time_since_last_mvmt;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_time_since_last_mvmt
(
	metric_type VARCHAR(100)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE az64
	,latest_event_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_date_key NUMERIC(10,0)   ENCODE az64
	,last_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_date_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_time_since_last_mvmt owner to dbadmin;


-- gna_load_schema.mv_time_since_last_mvmts definition

-- Drop table

-- DROP TABLE gna_load_schema.mv_time_since_last_mvmts;

--DROP TABLE gna_load_schema.mv_time_since_last_mvmts;
CREATE TABLE IF NOT EXISTS gna_load_schema.mv_time_since_last_mvmts
(
	metric_type VARCHAR(100)   ENCODE lzo
	,worker_key NUMERIC(10,0)   ENCODE az64
	,latest_event_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_date_key NUMERIC(10,0)   ENCODE az64
	,last_hire_date TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,latest_event_end_date_key NUMERIC(10,0)   ENCODE az64
	,time_since_last_mvmt NUMERIC(13,10)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.mv_time_since_last_mvmts owner to dbadmin;


-- gna_load_schema.override_availability_dates definition

-- Drop table

-- DROP TABLE gna_load_schema.override_availability_dates;

--DROP TABLE gna_load_schema.override_availability_dates;
CREATE TABLE IF NOT EXISTS gna_load_schema.override_availability_dates
(
	batch_date INTEGER   ENCODE az64
	,availability_date INTEGER   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.override_availability_dates owner to dbadmin;


-- gna_load_schema.pap_log_batch_dtl definition

-- Drop table

-- DROP TABLE gna_load_schema.pap_log_batch_dtl;

--DROP TABLE gna_load_schema.pap_log_batch_dtl;
CREATE TABLE IF NOT EXISTS gna_load_schema.pap_log_batch_dtl
(
	batch_date VARCHAR(20)   ENCODE lzo
	,batch_id VARCHAR(100)   ENCODE lzo
	,batch_name VARCHAR(10)   ENCODE lzo
	,status VARCHAR(20)   ENCODE lzo
	,start_time VARCHAR(100)   ENCODE lzo
	,end_time VARCHAR(100)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.pap_log_batch_dtl owner to dbadmin;


-- gna_load_schema.tab_level_security definition

-- Drop table

-- DROP TABLE gna_load_schema.tab_level_security;

--DROP TABLE gna_load_schema.tab_level_security;
CREATE TABLE IF NOT EXISTS gna_load_schema.tab_level_security
(
	dashboard_name VARCHAR(256)   ENCODE lzo
	,roles VARCHAR(256)   ENCODE lzo
	,flag VARCHAR(256)   ENCODE lzo
	,extra_condition VARCHAR(256)   ENCODE lzo
	,url VARCHAR(256)   ENCODE lzo
	,no_hr VARCHAR(256)   ENCODE lzo
	,no_detail VARCHAR(256)   ENCODE lzo
	,no_diversity_detail VARCHAR(256)   ENCODE lzo
	,no_grade_35_plus VARCHAR(256)   ENCODE lzo
	,no_hr_no_grade_35_plus VARCHAR(256)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.tab_level_security owner to dbadmin;


-- gna_load_schema.w_exch_rate_g definition

-- Drop table

-- DROP TABLE gna_load_schema.w_exch_rate_g;

--DROP TABLE gna_load_schema.w_exch_rate_g;
CREATE TABLE IF NOT EXISTS gna_load_schema.w_exch_rate_g
(
	start_dt_key NUMERIC(19,0)   ENCODE az64
	,end_dt_key NUMERIC(19,0)   ENCODE az64
	,exch_rate NUMERIC(38,10)   ENCODE az64
	,from_curcy_cd VARCHAR(360)   ENCODE lzo
	,to_curcy_cd VARCHAR(360)   ENCODE lzo
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.w_exch_rate_g owner to dbadmin;


-- gna_load_schema.worker_talent_dtl definition

-- Drop table

-- DROP TABLE gna_load_schema.worker_talent_dtl;

--DROP TABLE gna_load_schema.worker_talent_dtl;
CREATE TABLE IF NOT EXISTS gna_load_schema.worker_talent_dtl
(
	worker_key NUMERIC(10,0)   ENCODE az64
	,career_preference VARCHAR(765)   ENCODE lzo
	,career_interests VARCHAR(12000)   ENCODE lzo
	,talent_language VARCHAR(765)   ENCODE lzo
	,language_comments VARCHAR(12000)   ENCODE lzo
	,ability_proficiency VARCHAR(765)   ENCODE lzo
	,native_flg VARCHAR(765)   ENCODE lzo
	,talent_assessed_as_of VARCHAR(765)   ENCODE lzo
	,source_id VARCHAR(240)   ENCODE lzo
	,datasource_name VARCHAR(240)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.worker_talent_dtl owner to dbadmin;

-- gna_load_schema.dim_radford_gls_turnover_trends definition

-- Drop table

-- DROP TABLE gna_load_schema.dim_radford_gls_turnover_trends;

--DROP TABLE gna_load_schema.dim_radford_gls_turnover_trends;
CREATE TABLE IF NOT EXISTS gna_load_schema.dim_radford_gls_turnover_trends
(
	year VARCHAR(720)   ENCODE lzo
	,quarter VARCHAR(720)   ENCODE lzo
	,month VARCHAR(720)   ENCODE lzo
	,overall VARCHAR(720)   ENCODE lzo
	,voluntary VARCHAR(720)   ENCODE lzo
	,involuntary VARCHAR(720)   ENCODE lzo
	,load_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,row_id NUMERIC(10,0)   ENCODE az64
	,received_file_name VARCHAR(720)   ENCODE lzo
	,datasource_name VARCHAR(720)   ENCODE lzo
	,datasource_num_id NUMERIC(10,0)   ENCODE az64
	,created_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,created_by_key NUMERIC(10,0)   ENCODE az64
	,update_dt TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
	,updated_by_key NUMERIC(10,0)   ENCODE az64
)
DISTSTYLE AUTO
;
ALTER TABLE gna_load_schema.dim_radford_gls_turnover_trends owner to dbadmin;